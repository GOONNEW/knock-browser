// Knock 원격: 이 컴퓨터 화면을 보여 주거나(share), 다른 컴퓨터에 연결해 보고 조작한다(view).
// 영상과 조작 신호는 두 컴퓨터가 직접 주고받는다(WebRTC, 암호화). 연결 안내 서버(remote-signal.js)는 처음 서로를 찾을 때만 쓴다.
// 보여 주는 쪽은 연결마다 직접 허락하고, "보기만"을 고르면 조작 신호는 받지 않는다.
// 시험용 주소 옵션: ?local=1 (같은 브라우저 안에서 연결) · ?fake=1 (화면 대신 그림을 보냄)
import { iceServers } from './rb-wire.js';
import { openSignal, signalReady } from './remote-signal.js';
import { REMOTE_CONFIG } from './remote-config.js';

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const LOCAL = params.has('local');
const FAKE = params.has('fake');
// PC 원격제어(2026-11-06): 브라우저 연동 중에 연결한 쪽이 [PC 원격제어로 바꾸기]를 누르면 그 PC 가 이 화면을 ?ticket= 으로 연다.
// 이 PC 사람이 [이 PC 화면 보여 주기]를 한 번 눌러 화면을 고르면, 번호를 연결한 쪽에 저절로 보내고 그 쪽 연결은 묻지 않고 받는다.
const TICKET = params.get('ticket') || '';
const AUTO_CODE = params.get('code') || '';
// 창 없이 뒤에서(보이지 않는 문서 안) 도는 공유 화면 — 창 닫기 대신 그 문서에 빼 달라고 한다
const BG = params.has('bg');
const closeSelf = () => (BG ? parent.postMessage({ knockPcShareDone: TICKET }, location.origin) : window.close());
// 원격 비밀번호로 이은 PC 원격제어(같은 계정·원격 등록): 번호는 연결에만 쓰고 보이지 않게 한다 — 번호 화면은 계정이 다르거나 등록 안 된 장치용
if (TICKET) { document.body.classList.add('ticket'); document.getElementById('code')?.closest('section')?.classList.add('code-only'); }
const me = crypto.randomUUID();
const port = chrome.runtime.connect({ name: 'remote' });
const pending = new Map();
let reqSeq = 1;

// 배경(background.js)에 묻고 답 받기
function ask(type, data = {}) {
  const reqId = reqSeq++;
  port.postMessage({ type, reqId, ...data });
  return new Promise((resolve) => pending.set(reqId, resolve));
}
port.onMessage.addListener((m) => {
  // 이 PC 의 윈도우가 원격 조작 입력을 막았다 — 보는 쪽에 까닭을 알린다
  if (m.type === 'inputBlocked' && share.dc?.readyState === 'open') {
    share.dc.send(JSON.stringify({ t: 'blocked', code: m.code }));
    return;
  }
  if (m.reqId && pending.has(m.reqId)) {
    pending.get(m.reqId)(m);
    pending.delete(m.reqId);
  }
});

function setTab(name) {
  $('share').classList.toggle('hidden', name !== 'share');
  $('view').classList.toggle('hidden', name !== 'view');
  $('tab-share').classList.toggle('on', name === 'share');
  $('tab-view').classList.toggle('on', name === 'view');
  if (location.hash !== `#${name}`) history.replaceState(null, '', `${location.search}#${name}`);
  if (name === 'share' && !share.signal && !TICKET) startShare();
}
$('tab-share').addEventListener('click', () => setTab('share'));
$('tab-view').addEventListener('click', () => setTab('view'));

const prettyCode = (c) => c.replace(/(\d{3})(?=\d)/g, '$1 ');
const cleanCode = (s) => String(s).replace(/\D/g, '');

async function newPeer() {
  return new RTCPeerConnection({ iceServers: await iceServers() });
}

// ---------------- 내 화면 보여주기 ----------------
const share = { signal: null, code: '', viewer: null, pc: null, stream: null, control: false, asking: null };

async function startShare() {
  stopShare(true);
  if (!LOCAL && !signalReady()) {
    $('share-status').textContent = '연결 안내 서버가 아직 준비되지 않았습니다(Supabase 설정 필요).';
    return;
  }
  const n = crypto.getRandomValues(new Uint32Array(1))[0] % 1e9;
  share.code = String(n).padStart(9, '0');
  $('code').textContent = prettyCode(share.code);
  // 번호는 10분 동안만(2026-11-06) — 그 안에 접속이 없으면 번호를 닫는다. 이미 이어진 연결은 그대로 둔다.
  share.expires = Date.now() + 10 * 60 * 1000;
  clearInterval(share.clock);
  share.clock = setInterval(tickShareCode, 1000);
  $('share-status').textContent = '연결 안내 서버에 들어가는 중…';
  try {
    share.signal = await openSignal(share.code, onShareMessage, { local: LOCAL });
    $('share-status').textContent = TICKET ? '연결을 기다리는 중…' : '상대가 이 번호를 넣기를 기다리는 중…';
  } catch (err) {
    $('share-status').textContent = err.message;
  }
  checkPerm(false);
}

async function checkPerm(prompt, tell = false) {
  $('perm-note').textContent = tell ? '확인하는 중…' : '';
  const r = await ask('check', { prompt });
  if (r.ok && tell) {
    $('perm-note').textContent = '✅ 켜져 있어요. 이제 조작도 받을 수 있어요.';
    setTimeout(() => $('perm').classList.add('hidden'), 2500);
  } else {
    $('perm').classList.toggle('hidden', !!r.ok);
    if (tell) $('perm-note').textContent = r.error ? `확인하지 못했어요: ${r.error}` : '아직 꺼져 있어요. 손쉬운 사용 목록에서 Knock 스위치를 켠 뒤 다시 눌러 주세요. 목록에 Knock 이 없으면 "설정 열기"를 먼저 눌러 주세요.';
  }
  return !!r.ok;
}
$('open-perm').addEventListener('click', () => checkPerm(true, true));
$('recheck-perm').addEventListener('click', () => checkPerm(false, true));
$('new-code').addEventListener('click', () => startShare());
function tickShareCode() {
  if (!share.code || share.viewer || share.asking) return;
  const left = Math.max(0, share.expires - Date.now());
  const el = $('code-left') || Object.assign(document.createElement('p'), { id: 'code-left', className: 'status' });
  if (!el.isConnected) $('share-status').after(el);
  if (left > 0) {
    const m = Math.floor(left / 60000), s = Math.floor((left % 60000) / 1000);
    el.textContent = TICKET ? '' : `남은 시간 ${m}:${String(s).padStart(2, '0')}`;
    return;
  }
  clearInterval(share.clock);
  stopShare(true);
  share.code = '';
  $('code').textContent = '··· ··· ···';
  $('share-status').textContent = TICKET ? '10분 동안 연결이 없어 끝냈어요. 다른 PC 에서 다시 연결하면 바로 이어져요.' : '10분이 지나 번호가 끝났어요. [새 번호]를 눌러 다시 만드세요.';
  el.textContent = '';
}

function onShareMessage(msg) {
  if (!msg || msg.to && msg.to !== me) return;
  if (msg.kind === 'hello') {
    if (share.viewer || share.asking) return share.signal.send({ kind: 'busy', to: msg.from });
    share.asking = { id: msg.from, name: String(msg.name || '이름 없음').slice(0, 40) };
    // 브라우저 연동으로 이미 비밀번호를 거쳐 들어온 쪽이 PC 원격제어로 바꾼 것 — 묻지 않고 보기 + 조작으로
    // 원격 목록(비밀번호)으로 들어온 내 PC 연결은 "보고 조작하는 중" 팝업 알림을 띄우지 않는다(2026-11-08 "원격지에 이게 생기지 않게") —
    // 도구 막대의 원격 표시와 크롬의 화면 공유 띠는 그대로 남는다
    if (TICKET && msg.ticket === TICKET) { share.quiet = true; return answer('control'); }
    share.quiet = false;
    $('ask-text').textContent = `"${share.asking.name}" 님이 이 컴퓨터에 연결하려고 해요. 허락할까요?`;
    $('ask').classList.remove('hidden');
    ask('attention', { text: `"${share.asking.name}" 님이 원격 연결을 허락해 달라고 해요.` });
    clearTimeout(share.askTimer);
    share.askTimer = setTimeout(() => answer(null), 60000); // 1분 안에 답이 없으면 거절
  } else if (msg.from === share.viewer?.id) {
    if (msg.kind === 'answer') share.pc?.setRemoteDescription(msg.sdp);
    else if (msg.kind === 'ice' && msg.candidate) share.pc?.addIceCandidate(msg.candidate).catch(() => {});
    else if (msg.kind === 'bye') endShare('상대가 연결을 끊었습니다.');
  }
}

async function answer(mode) {
  const who = share.asking;
  share.asking = null;
  clearTimeout(share.askTimer);
  $('ask').classList.add('hidden');
  if (!who) return;
  if (!mode) {
    share.signal.send({ kind: 'denied', to: who.id, from: me });
    $('share-status').textContent = '연결을 거절했습니다. 다시 기다리는 중…';
    return;
  }
  try {
    share.stream = share.stream || FAKE ? share.stream || fakeScreen() : await navigator.mediaDevices.getDisplayMedia({ video: { displaySurface: 'monitor', frameRate: 30 }, audio: false, monitorTypeSurfaces: 'include', selfBrowserSurface: 'exclude' });
  } catch {
    share.signal.send({ kind: 'denied', to: who.id, from: me });
    $('share-status').textContent = '화면을 고르지 않아 연결하지 않았습니다.';
    return;
  }
  share.viewer = who;
  share.control = mode === 'control';
  const track = share.stream.getVideoTracks()[0];
  track.addEventListener('ended', () => endShare('화면 보내기를 멈췄습니다.'));
  const { width, height } = track.getSettings();
  // 도우미가 답하지 않아도(3초) 멈추지 않는다
  if (share.control) await Promise.race([ask('display', { w: width, h: height }), new Promise((r) => setTimeout(r, 3000))]);

  const pc = (share.pc = await newPeer());
  pc.addTrack(track, share.stream);
  const dc = (share.dc = pc.createDataChannel('input', { ordered: true }));
  dc.onopen = () => dc.send(JSON.stringify({ t: 'info', control: share.control }));
  dc.onmessage = (e) => {
    if (!share.control) return;
    let ev;
    try { ev = JSON.parse(e.data); } catch { return; }
    port.postMessage({ type: 'input', ev: safeInput(ev) });
  };
  pc.onicecandidate = (e) => e.candidate && share.signal.send({ kind: 'ice', to: who.id, from: me, candidate: e.candidate.toJSON() });
  pc.onconnectionstatechange = () => {
    if (pc.connectionState === 'connected') liveShare();
    if (['failed', 'closed'].includes(pc.connectionState)) endShare('연결이 끊겼습니다.');
  };
  share.signal.send({ kind: 'welcome', to: who.id, from: me, control: share.control });
  await pc.setLocalDescription(await pc.createOffer());
  share.signal.send({ kind: 'offer', to: who.id, from: me, sdp: pc.localDescription.toJSON() });
  $('share-status').textContent = '연결하는 중…';
}
$('ask-no').addEventListener('click', () => answer(null));
$('ask-view').addEventListener('click', () => answer('view'));
$('ask-control').addEventListener('click', () => answer('control'));

// 원격에서 온 조작 신호는 정해진 모양만 넘긴다
function safeInput(ev) {
  const num = (v, lo, hi) => Math.min(Math.max(Number(v) || 0, lo), hi);
  switch (ev?.t) {
    case 'move': return { t: 'move', x: num(ev.x, 0, 1), y: num(ev.y, 0, 1) };
    case 'down': case 'up': return { t: ev.t, x: num(ev.x, 0, 1), y: num(ev.y, 0, 1), button: ev.button === 2 ? 2 : 0, clicks: ev.clicks === 2 ? 2 : 1, ...(Array.isArray(ev.mods) ? { mods: (Array.isArray(ev.mods) ? ev.mods : []).filter((m) => ['shift', 'cmd', 'alt', 'ctrl'].includes(m)) } : {}) };
    case 'release': return { t: 'release' }; // 눌린 채 남은 키를 모두 뗀다
    case 'wheel': return { t: 'wheel', dx: num(ev.dx, -2000, 2000), dy: num(ev.dy, -2000, 2000) };
    case 'key': return { t: 'key', code: String(ev.code || '').slice(0, 20), down: !!ev.down, mods: (Array.isArray(ev.mods) ? ev.mods : []).filter((m) => ['shift', 'cmd', 'alt', 'ctrl'].includes(m)) };
    case 'text': return { t: 'text', text: String(ev.text || '').slice(0, 2000) };
    case 'clip': return { t: 'clip', text: String(ev.text || '').slice(0, 100000), html: String(ev.html || '').slice(0, 300000) };
    default: return null;
  }
}

// 연결 상태(2026-11-06 "원활 보통 지연과 동일하게 현재 속도에 따라") — 브라우저 연동 창과 같은 말·색·기준(응답 시간).
// 두 PC 사이를 한 번 오가는 시간(WebRTC 가 재는 것)으로 2초마다 다시 그린다.
async function rttOf(pc) {
  if (!pc || pc.connectionState === 'closed') return null;
  try {
    let rtt = null;
    (await pc.getStats()).forEach((r) => { if (r.type === 'candidate-pair' && r.nominated && r.state === 'succeeded' && r.currentRoundTripTime != null) rtt = r.currentRoundTripTime; });
    return rtt;
  } catch { return null; }
}
function drawNet(el, sec) {
  if (sec == null) { el.classList.add('hidden'); return; }
  const state = sec < 0.3 ? 'good' : sec < 1 ? 'slow' : 'bad';
  el.className = `net ${state}`;
  el.textContent = state === 'good' ? '● 원활' : state === 'slow' ? '● 보통' : '● 지연';
  el.title = state === 'good' ? '연결이 원활해요.' : '인터넷이 느려 화면이 늦게 갈 수 있어요. 유선(랜선)으로 연결하면 나아져요.';
  return state;
}
setInterval(async () => {
  if (share.viewer) {
    const state = drawNet($('live-net'), await rttOf(share.pc));
    if (state && state !== share.netState) { share.netState = state; ask('sessionNet', { state }); } // 알림 색도 바뀔 때만
  } else share.netState = '';
  if (!$('screen').classList.contains('hidden')) drawNet($('view-net'), await rttOf(view.pc));
}, 2000);

function liveShare() {
  // PC 원격제어(ticket): 이어지면 안내를 바꾸고 이 창은 작업 표시줄로 내린다(화면 보내기는 이 창이 하므로 닫지는 않는다 —
  // 끊을 때는 화면 아래 "공유 중지"나 알림의 "연결 끊기", 또는 이 창을 다시 열어 [연결 끊기])
  if (TICKET) {
    $('pc-status').textContent = '';
    $('pc-desc').textContent = '이 PC 화면을 보내고 있어요. 끝내려면 화면 아래 "공유 중지"를 누르거나 이 창의 [연결 끊기]를 누르세요.';
    if (!BG) setTimeout(() => chrome.windows.getCurrent().then((w) => chrome.windows.update(w.id, { state: 'minimized' })).catch(() => {}), 1500);
  }
  const what = share.control ? '이 컴퓨터를 보고 조작할 수 있어요' : '이 컴퓨터 화면을 보고 있어요(조작은 못 함)';
  $('live-text').textContent = `연결됨 — "${share.viewer.name}" 님이 ${what}.`;
  $('live').classList.remove('hidden');
  $('share-status').textContent = '';
  ask('session', { on: true, name: share.viewer.name, control: share.control, quiet: !!share.quiet });
}

function endShare(note) {
  // 연결이 끝나면 저쪽에서 누르고 있던 키(Shift 등)가 이 PC 에 눌린 채 남지 않게 모두 뗀다(2026-11-06 "누르는 만큼 새창")
  if (share.viewer && share.control) port.postMessage({ type: 'input', ev: { t: 'release' } });
  if (share.viewer) share.signal?.send({ kind: 'bye', to: share.viewer.id, from: me });
  share.pc?.close();
  share.stream?.getTracks().forEach((t) => t.stop());
  if (share.viewer) ask('session', { on: false });
  share.pc = share.stream = share.viewer = null;
  share.control = false;
  $('live').classList.add('hidden');
  $('share-status').textContent = `${note || '연결을 끊었습니다.'} 다시 기다리는 중…`;
  // PC 원격제어(ticket)는 한 번 쓰고 끝 — 화면 보내기를 멈추고 창을 닫는다(다음 연결은 새로 연다)
  if (TICKET) { stopShare(true); $('share-status').textContent = note || '연결을 끊었습니다.'; setTimeout(closeSelf, 2500); }
}
$('end-share').addEventListener('click', () => endShare());

function stopShare(silent) {
  if (share.viewer) endShare();
  share.signal?.close();
  share.signal = null;
  if (!silent) $('share-status').textContent = '';
}

// 시험용 가짜 화면
function fakeScreen() {
  const c = Object.assign(document.createElement('canvas'), { width: 1280, height: 800 });
  const g = c.getContext('2d');
  let f = 0;
  setInterval(() => {
    g.fillStyle = `hsl(${(f++ * 3) % 360},60%,55%)`;
    g.fillRect(0, 0, 1280, 800);
    g.fillStyle = '#fff';
    g.font = '64px sans-serif';
    g.fillText('Knock 원격 시험 화면', 300, 420);
  }, 50);
  return c.captureStream(20);
}

// ---------------- 다른 컴퓨터 연결 ----------------
const view = { signal: null, host: null, pc: null, dc: null, control: false };

$('join-code').addEventListener('input', (e) => {
  const c = cleanCode(e.target.value).slice(0, 9);
  e.target.value = prettyCode(c);
});
$('join-code').addEventListener('keydown', (e) => e.key === 'Enter' && join());
$('join-btn').addEventListener('click', () => join());

async function join() {
  const code = cleanCode($('join-code').value);
  if (code.length !== 9) return ($('view-status').textContent = '9자리 번호를 넣어 주세요.');
  if (!LOCAL && !signalReady()) return ($('view-status').textContent = '연결 안내 서버가 아직 준비되지 않았습니다(Supabase 설정 필요).');
  endView(true);
  $('view-status').textContent = '상대 컴퓨터를 찾는 중…';
  try {
    view.signal = await openSignal(code, onViewMessage, { local: LOCAL });
  } catch (err) {
    $('view-status').textContent = err.message;
    return;
  }
  const { name } = await ask('profileName');
  view.signal.send({ kind: 'hello', from: me, name: name || 'Knock 사용자', ...(TICKET ? { ticket: TICKET } : {}) });
  view.waitTimer = setTimeout(() => {
    if (!view.host) $('view-status').textContent = TICKET ? '그 PC 가 답하지 않아요. 잠시 뒤 다시 연결해 주세요.' : '답이 없습니다. 번호를 확인하거나, 상대가 Knock 원격 화면을 열어 두었는지 확인하세요.';
  }, 70000);
  $('view-status').textContent = TICKET ? '그 PC 화면을 기다리는 중…' : '상대가 허락하기를 기다리는 중…';
}

async function onViewMessage(msg) {
  if (!msg || msg.to !== me) return;
  if (msg.kind === 'busy') $('view-status').textContent = '상대 컴퓨터가 이미 다른 연결을 받고 있습니다.';
  else if (msg.kind === 'denied') $('view-status').textContent = '상대가 연결을 허락하지 않았습니다.';
  else if (msg.kind === 'welcome') {
    view.host = msg.from;
    view.control = !!msg.control;
    $('view-status').textContent = '연결하는 중…';
  } else if (msg.from !== view.host) {
    // 허락한 상대가 보낸 것만 받는다
  } else if (msg.kind === 'offer') {
    const pc = (view.pc = await newPeer());
    pc.ontrack = (e) => {
      $('video').srcObject = e.streams[0] || new MediaStream([e.track]);
      showScreen();
    };
    pc.ondatachannel = (e) => {
      view.dc = e.channel;
      view.dc.onmessage = (m) => {
        const info = JSON.parse(m.data);
        if (info.t === 'info') view.control = !!info.control, showScreen();
        // 그 PC 가 마우스·키보드 입력을 받지 않음(관리자 권한 창이 앞에 있거나 보안 프로그램이 막음)
        if (info.t === 'blocked') $('screen-text').textContent = `⚠ 그 PC가 원격 조작을 막고 있어요(${info.code === 5 ? '관리자 권한으로 켠 창이 앞에 있음' : `막힘 ${info.code}`}). 그 PC에서 맨 앞 창을 바꾸거나 보안 프로그램(키보드 보안 등)을 확인해 주세요.`;
      };
    };
    pc.onicecandidate = (e) => e.candidate && view.signal.send({ kind: 'ice', to: view.host, from: me, candidate: e.candidate.toJSON() });
    pc.onconnectionstatechange = () => ['failed', 'closed'].includes(pc.connectionState) && endView(false, '연결이 끊겼습니다.');
    await pc.setRemoteDescription(msg.sdp);
    await pc.setLocalDescription(await pc.createAnswer());
    view.signal.send({ kind: 'answer', to: view.host, from: me, sdp: pc.localDescription.toJSON() });
  } else if (msg.kind === 'ice' && msg.candidate) view.pc?.addIceCandidate(msg.candidate).catch(() => {});
  else if (msg.kind === 'bye') endView(false, '상대가 연결을 끊었습니다.');
}

function showScreen() {
  clearTimeout(view.waitTimer);
  $('join').classList.add('hidden');
  $('screen').classList.remove('hidden');
  $('control-on').disabled = !view.control;
  $('control-on').checked = view.control && $('control-on').checked;
  $('send-text').disabled = !view.control;
  $('screen-text').textContent = view.control ? '상대 컴퓨터를 보고 조작하는 중' : '상대 컴퓨터를 보는 중(상대가 보기만 허락함)';
  $('stage').classList.toggle('control', controlling());
  $('stage').focus();
}

function endView(silent, note) {
  // PC 원격제어(ticket)로 연 창은 끊기면 닫는다 — 함께 연 브라우저 연동 연결도 그때 끝난다(remote-browser.js)
  if (TICKET && view.pc && !silent) setTimeout(() => window.close(), 2000);
  if (view.host) view.signal?.send({ kind: 'bye', to: view.host, from: me });
  view.pc?.close();
  view.signal?.close();
  clearTimeout(view.waitTimer);
  Object.assign(view, { signal: null, host: null, pc: null, dc: null, control: false });
  $('video').srcObject = null;
  $('screen').classList.add('hidden');
  $('join').classList.remove('hidden');
  if (!silent) $('view-status').textContent = note || '연결을 끊었습니다.';
  if (document.fullscreenElement) document.exitFullscreen();
}
$('end-view').addEventListener('click', () => endView(false));
$('conn').addEventListener('click', (e) => { e.stopPropagation(); $('conn-menu').classList.toggle('hidden'); });
document.addEventListener('click', () => $('conn-menu').classList.add('hidden'));
// PC 원격제어 → 브라우저 연동(그 PC 의 Knock Browser 탭만): 이 화면을 끝내고 같은 창에서 브라우저 연동으로 다시 잇는다
const DEV = params.get('dev') || '';
if (TICKET && DEV) $('to-browser').classList.remove('hidden');
$('to-browser').addEventListener('click', async () => {
  $('to-browser').disabled = true;
  const r = await chrome.runtime.sendMessage({ type: 'remoteSwitch', toDeviceId: DEV, mode: 'browser' }).catch((err) => ({ error: err.message }));
  if (!r?.url) {
    $('to-browser').disabled = false;
    // 비밀번호를 기억해 두지 않았으면 원격 연결 화면에서 다시 넣는다
    if (r?.reason === 'password') chrome.tabs.create({ url: chrome.runtime.getURL('remote-connect.html') });
    $('screen-text').textContent = r?.reason === 'password' ? '비밀번호가 필요해요 — 원격 연결 화면에서 브라우저 연동을 골라 주세요.' : (r?.error || '브라우저 연동으로 바꾸지 못했어요.');
    $('conn-menu').classList.add('hidden');
    return;
  }
  endView(true);
  location.replace(r.url);
});
$('full').addEventListener('click', () => $('stage').requestFullscreen());
$('control-on').addEventListener('change', () => $('stage').classList.toggle('control', controlling()));
$('send-text').addEventListener('click', () => {
  const text = prompt('상대 컴퓨터에 넣을 글자(커서가 있는 곳에 들어갑니다)');
  if (text) sendInput({ t: 'text', text });
});

const controlling = () => view.control && $('control-on').checked && view.dc?.readyState === 'open';
function sendInput(ev) {
  if (controlling()) view.dc.send(JSON.stringify(ev));
}

// 영상 안의 위치를 0~1 비율로(검은 여백은 뺀다)
function spot(e) {
  const v = $('video');
  const r = v.getBoundingClientRect();
  const scale = Math.min(r.width / v.videoWidth, r.height / v.videoHeight);
  const w = v.videoWidth * scale;
  const h = v.videoHeight * scale;
  const x = (e.clientX - r.left - (r.width - w) / 2) / w;
  const y = (e.clientY - r.top - (r.height - h) / 2) / h;
  return { x: Math.min(Math.max(x, 0), 1), y: Math.min(Math.max(y, 0), 1) };
}

let moveQueued = null;
const stage = $('stage');
stage.addEventListener('mousemove', (e) => {
  if (!controlling()) return;
  const first = !moveQueued;
  moveQueued = spot(e);
  if (first) requestAnimationFrame(() => {
    sendInput({ t: 'move', ...moveQueued });
    moveQueued = null;
  });
});
stage.addEventListener('mousedown', (e) => {
  if (!controlling()) return;
  e.preventDefault();
  stage.focus();
  sendInput({ t: 'down', ...spot(e), button: e.button === 2 ? 2 : 0, clicks: e.detail === 2 ? 2 : 1, mods: mods(e) });
});
stage.addEventListener('mouseup', (e) => {
  if (!controlling()) return;
  e.preventDefault();
  sendInput({ t: 'up', ...spot(e), button: e.button === 2 ? 2 : 0, clicks: e.detail === 2 ? 2 : 1, mods: mods(e) });
});
stage.addEventListener('contextmenu', (e) => controlling() && e.preventDefault());
stage.addEventListener('wheel', (e) => {
  if (!controlling()) return;
  e.preventDefault();
  sendInput({ t: 'wheel', dx: e.deltaX, dy: e.deltaY });
}, { passive: false });
const mods = (e) => [e.shiftKey && 'shift', e.metaKey && 'cmd', e.altKey && 'alt', e.ctrlKey && 'ctrl'].filter(Boolean);
// 누르고 있는 키 — 이 창을 벗어나면(다른 앱으로 가기 등) 뗀다는 신호가 저쪽에 안 가서 Shift 가 눌린 채 남았다
// (그 PC 에서 작업 표시줄을 누를 때마다 새 창이 열림 — 2026-11-06). 창을 벗어나면 다 뗀다.
const heldKeys = new Set();
function releaseKeys() {
  for (const code of heldKeys) sendInput({ t: 'key', code, down: false, mods: [] });
  heldKeys.clear();
  sendInput({ t: 'release' });
}
// ⌘V(Ctrl+V): 이 맥에서 복사한 것(엑셀 셀 등)을 그 PC 클립보드에 넣고 그 PC 에서 붙여넣는다(2026-11-09 "가상 PC 에서도 이 맥에서 복사한 엑셀 내용이 붙여넣기 되게").
// 키만 보내면 그 PC 자신의 클립보드가 붙어, 맥에서 복사한 것은 PC 마다 되기도 안 되기도 했다. 숨은 칸에 붙여넣어 맥 클립보드를 읽는다(권한 창 없이)
const clipBox = $('clip');
let clipKey = false;
// 그 PC 안에서 복사(⌘C·⌘X)한 뒤 이 창을 떠나지 않았으면 ⌘V 는 그 PC 클립보드 그대로(맥 클립보드는 옛것일 수 있다).
// 이 창을 떠났다 오면(맥에서 복사했을 수 있다) 맥 클립보드를 보낸다
let remoteCopy = false;
window.addEventListener('blur', () => { remoteCopy = false; });
clipBox.addEventListener('paste', (e) => {
  e.preventDefault();
  const text = (e.clipboardData?.getData('text/plain') || '').replace(/\r\n?/g, '\n').replace(/[\n\t ]+$/, ''); // 엑셀 셀 끝의 줄바꿈은 뺀다
  const html = e.clipboardData?.getData('text/html') || '';
  if (text || html) sendInput({ t: 'clip', text, html });
  stage.focus();
});
for (const type of ['keydown', 'keyup']) {
  stage.addEventListener(type, (e) => {
    if (!controlling() || e.isComposing) return;
    if (type === 'keydown' && (e.code === 'KeyC' || e.code === 'KeyX') && (e.metaKey || e.ctrlKey)) remoteCopy = true;
    if (e.code === 'KeyV' && (type === 'keydown' ? (e.metaKey || e.ctrlKey) && !e.altKey && !e.shiftKey && !remoteCopy : clipKey)) {
      clipKey = type === 'keydown';
      if (type === 'keydown') clipBox.focus(); // 기본 붙여넣기가 숨은 칸으로 간다(키는 보내지 않는다 — 그 PC 가 클립보드를 넣은 뒤 스스로 누른다)
      else e.preventDefault();
      return;
    }
    e.preventDefault();
    if (type === 'keydown') heldKeys.add(e.code); else heldKeys.delete(e.code);
    sendInput({ t: 'key', code: e.code, down: type === 'keydown', mods: mods(e) });
  });
}
stage.addEventListener('blur', releaseKeys);
window.addEventListener('blur', releaseKeys);
document.addEventListener('visibilitychange', () => { if (document.hidden) releaseKeys(); });

// 알림의 "연결 끊기" 단추
chrome.runtime.onMessage.addListener((m) => {
  if (m?.type === 'remoteEndAll' && share.viewer) endShare();
});

window.addEventListener('beforeunload', () => {
  endView(true);
  stopShare(true);
});

setTab(location.hash === '#view' ? 'view' : 'share');

// ---------------- PC 원격제어(ticket) ----------------
if (TICKET && location.hash !== '#view') {
  // 이 PC: 화면 고르기는 사람이 눌러야만 뜬다(브라우저 보안) — 큰 단추 하나
  const card = document.createElement('section');
  card.className = 'card center';
  card.innerHTML = '<p><b>다른 PC 에서 이 PC 전체 화면 원격제어를 요청했어요.</b></p><p id="pc-desc" class="muted">원격 비밀번호로 연결한 요청이라 바로 이어져요. 바로 시작되지 않으면 아래 단추를 눌러 전체 화면을 골라 주세요.</p><div class="row"><button id="pc-go" class="btn primary">이 PC 화면 보여 주기</button></div><p id="pc-status" class="status"></p>';
  $('share').prepend(card);
  // 원격 비밀번호로 들어온 요청이라 원격 데스크톱처럼 이 PC 에서 누르지 않아도 시작한다(2026-11-06 결정).
  // Knock 본체 ver 11~ 은 이 창(remote.html?ticket=)만 화면 고르기 없이 전체 화면을 준다. 옛 본체면 단추로 시작한다.
  let pcStarting = false;
  const pcGo = async (auto) => {
    if (pcStarting || share.signal) return;
    pcStarting = true;
    try {
      share.stream = FAKE ? fakeScreen() : await navigator.mediaDevices.getDisplayMedia({ video: { displaySurface: 'monitor', frameRate: 30 }, audio: false, monitorTypeSurfaces: 'include', selfBrowserSurface: 'exclude' });
    } catch {
      pcStarting = false;
      // 창 없이 뒤에서 하다 막혔으면(옛 본체) 작은 창으로 다시 해 달라고 한다
      if (BG) return parent.postMessage({ knockPcShareFallback: TICKET }, location.origin);
      $('pc-status').textContent = auto ? '' : '화면을 고르지 않았어요. 다시 누르세요.';
      return;
    }
    $('pc-status').textContent = '연결하는 중…';
    $('pc-go').classList.add('hidden');
    $('pc-desc').textContent = '이 PC 화면을 보내고 있어요. 끝내려면 화면 아래 "공유 중지"를 누르거나 이 창을 닫으세요.';
    await startShare();
    pcStarting = false;
    if (share.code) chrome.runtime.sendMessage({ type: 'pcRemoteCode', ticket: TICKET, code: share.code }).catch(() => {});
  };
  $('pc-go').addEventListener('click', () => pcGo(false));
  // 지금 받은 요청으로 연 창일 때만 저절로 시작한다 — 브라우저를 다시 켜며 되살아난 옛 창이면 공유하지 않고 닫는다
  chrome.runtime.sendMessage({ type: 'pcTicketValid', ticket: TICKET }).then((r) => {
    if (r?.ok || FAKE) return pcGo(true);
    $('pc-desc').textContent = '끝난 원격 요청이에요. 이 창은 닫을게요.';
    $('pc-go').classList.add('hidden');
    setTimeout(closeSelf, 2000);
  }).catch(() => {});
}
if (AUTO_CODE && location.hash === '#view') {
  // 연결하는 쪽: 번호를 받아 바로 잇는다
  $('join-code').value = prettyCode(cleanCode(AUTO_CODE));
  setTimeout(() => join(), 300);
}
