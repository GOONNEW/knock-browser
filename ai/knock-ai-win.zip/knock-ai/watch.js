// 영상 빨리 읽기(watch_video, 2026-11-24 원장님 "영상을 보는 시간이 너무 긴데" → 조사 보고서 순서대로 "진행해").
// 영상을 실제 길이만큼 틀기 전에 먼저 해 본다:
//   1) 자막 바로 받기 — 유튜브(플레이어가 받아 오는 자막)·틱톡·네이버·<track>
//   2) 영상 파일 주소 바로 받기 — 인스타그램·틱톡·네이버·일반 mp4 → 이 컴퓨터 안에서 소리 받아쓰기·장면 뽑기
// 둘 다 안 되면 지금처럼 틀어서 본다(1.5배속).

// 페이지 안(MAIN)에서 돈다. 바깥 변수 쓰지 않음.
// 돌려줌: { found, embeds[], captions: { lang, asr, segments[{start,text}] } | null, captionUrls[{lang,url,asr}], file: { url, audioUrl, site } | null, site, notes[] }
export async function videoSourceInPage(lang) {
  const want = (lang || 'korean').toLowerCase().startsWith('kor') || lang === 'ko' ? 'ko' : String(lang || 'ko').slice(0, 2).toLowerCase();
  const out = { found: false, embeds: [], captions: null, captionUrls: [], file: null, site: '', notes: [] };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const timed = (p, ms) => Promise.race([p, sleep(ms).then(() => null)]);
  const okHttp = (u) => /^https?:/i.test(u || '');

  // 같은 사이트 틀(네이버 블로그·카페 본문)까지 뒤진다
  const docs = [];
  const walk = (d, depth) => {
    docs.push(d);
    if (depth > 3) return;
    for (const f of d.querySelectorAll('iframe,frame')) {
      let cd = null;
      try { cd = f.contentDocument; } catch {}
      if (cd) walk(cd, depth + 1);
      else {
        const r = f.getBoundingClientRect();
        if (r.width > 200 && r.height > 120 && okHttp(f.src)) out.embeds.push(f.src);
      }
    }
  };
  walk(document, 0);
  const videos = docs.flatMap((d) => [...d.querySelectorAll('video')]);
  const big = (v) => { const r = v.getBoundingClientRect(); return r.width * r.height; };
  const video = document.querySelector('video[data-knock-watch]') || videos.filter((v) => big(v) > 6400).sort((a, b) => big(b) - big(a))[0] || null;
  out.found = Boolean(video);
  const perf = () => docs.flatMap((d) => { try { return d.defaultView.performance.getEntriesByType('resource').map((e) => e.name); } catch { return []; } });

  // ---- 유튜브: 플레이어에게 자막을 켜게 하고, 플레이어가 받아 온 자막 주소(확인 표시 붙은 것)를 다시 받는다 ----
  if (/(^|\.)youtube\.com$/.test(location.hostname)) {
    out.site = '유튜브';
    const player = document.querySelector('#shorts-player') && /\/shorts\//.test(location.pathname) ? document.querySelector('#shorts-player') : document.querySelector('#movie_player');
    const pr = player?.getPlayerResponse?.() || window.ytInitialPlayerResponse;
    const tracks = pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
    const score = (t) => (t.languageCode?.startsWith(want) ? 4 : 0) + (t.kind === 'asr' ? 0 : 2) + (t.languageCode?.startsWith('en') ? 1 : 0);
    const track = [...tracks].sort((a, b) => score(b) - score(a))[0];
    const json3 = (j) => (j?.events || []).filter((e) => e.segs).map((e) => ({ start: (e.tStartMs || 0) / 1000, text: e.segs.map((s) => s.utf8 || '').join('').replace(/\s+/g, ' ').trim() })).filter((s) => s.text);
    const get = async (u) => {
      const url = new URL(u, location.href);
      url.searchParams.set('fmt', 'json3');
      const res = await timed(fetch(url, { credentials: 'include' }), 10000);
      const t = res?.ok ? await res.text() : '';
      return t ? json3(JSON.parse(t)) : [];
    };
    if (track) {
      // 광고가 나오는 동안은 자막을 받지 않는다 — 끝나기를 40초까지 기다린다
      for (let i = 0; i < 80 && document.querySelector('#movie_player.ad-showing, .ad-showing'); i++) await sleep(500);
      let segs = [];
      try { segs = await get(track.baseUrl); } catch {}
      if (!segs.length && player?.setOption) {
        // 2025년부터 자막 주소는 한 번만 쓰는 확인 표시가 붙어 다시 부르면 빈 답이 온다 —
        // 플레이어가 받아 오는 자막 응답을 옆에서 그대로 받는다
        const got = [];
        const tap = (u, text) => { if (String(u).includes('/api/timedtext') && text) got.push(text); };
        const of = window.fetch;
        window.fetch = function (...a) {
          const p = of.apply(this, a);
          const u = String(a[0]?.url || a[0]);
          if (u.includes('/api/timedtext')) p.then((r) => r.clone().text()).then((t) => tap(u, t), () => {});
          return p;
        };
        const oo = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function (m, u, ...r) {
          if (String(u).includes('/api/timedtext')) this.addEventListener('load', () => { try { tap(u, this.responseText); } catch {} });
          return oo.call(this, m, u, ...r);
        };
        let had = null;
        try { had = player.getOption('captions', 'track'); } catch {}
        const want1 = { languageCode: track.languageCode, ...(track.kind ? { kind: track.kind } : {}) };
        try {
          player.loadModule?.('captions');
          player.setOption('captions', 'track', {}); // 이미 켜져 있으면 다시 받게 껐다 켠다
          await sleep(150);
          player.setOption('captions', 'track', want1);
        } catch {}
        for (let i = 0; i < 40 && !got.length; i++) await sleep(200);
        window.fetch = of;
        XMLHttpRequest.prototype.open = oo;
        for (const t of got) {
          try {
            segs = /^\s*\{/.test(t) ? json3(JSON.parse(t))
              : [...t.matchAll(/<p[^>]*\bt="(\d+)"[^>]*>([\s\S]*?)<\/p>/g)].map((m) => ({ start: Number(m[1]) / 1000, text: m[2].replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\s+/g, ' ').trim() })).filter((x) => x.text);
          } catch {}
          if (segs.length) break;
        }
        try { if (!had || !had.languageCode) player.unloadModule?.('captions'); else player.setOption('captions', 'track', had); } catch {}
      }
      if (segs.length) out.captions = { lang: track.name?.simpleText || track.languageCode, asr: track.kind === 'asr', segments: segs };
      else out.notes.push(`유튜브 자막을 받지 못했습니다${document.querySelector('.ad-showing') ? '(광고 중)' : ''}`);
    } else out.notes.push('유튜브 자막이 없는 영상입니다');
    return out;
  }

  // ---- 틱톡: 페이지 자료에 자막·영상 주소 ----
  if (/(^|\.)tiktok\.com$/.test(location.hostname)) {
    out.site = '틱톡';
    try {
      const it = JSON.parse(document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__')?.textContent || '{}').__DEFAULT_SCOPE__?.['webapp.video-detail']?.itemInfo?.itemStruct;
      for (const s of [...(it?.video?.subtitleInfos || [])]) if (s.Url) out.captionUrls.push({ lang: s.LanguageCodeName || '', url: s.Url, asr: s.Source === 'ASR' });
      const u = it?.video?.playAddr || it?.video?.bitrateInfo?.[0]?.PlayAddr?.UrlList?.[0];
      if (okHttp(u)) out.file = { url: u, site: '틱톡' };
    } catch {}
  }

  // ---- 인스타그램: 로그인했으면 게시물 정보(영상 주소), 아니면 페이지 자료·플레이어가 받은 조각 주소 ----
  if (/(^|\.)instagram\.com$/.test(location.hostname)) {
    out.site = '인스타그램';
    const codeOf = (href) => (String(href || '').match(/\/(?:reels?|p|tv)\/([\w-]{5,})/) || [])[1] || '';
    let code = '';
    // 피드에서는 영상이 든 글의 주소에서
    for (let el = video; el && !code; el = el.parentElement) {
      if (el.tagName === 'ARTICLE' || el.parentElement === document.body) {
        code = codeOf([...el.querySelectorAll('a[href*="/p/"],a[href*="/reel/"]')].map((a) => a.getAttribute('href'))[0]);
        break;
      }
    }
    code = code || codeOf(location.pathname);
    const versions = (m) => {
      const node = (m?.carousel_media || []).find((c) => c.video_versions?.length) || m;
      const vv = [...(node?.video_versions || [])].sort((a, b) => (a.width || 0) - (b.width || 0));
      const pickV = vv.find((v) => (v.width || 0) >= 480) || vv[vv.length - 1];
      let audioUrl = '';
      const dash = node?.video_dash_manifest || '';
      const am = dash.match(/<AdaptationSet[^>]*contentType="audio"[\s\S]*?<BaseURL>([^<]+)<\/BaseURL>/);
      if (am) audioUrl = am[1].replace(/&amp;/g, '&');
      return pickV?.url ? { url: pickV.url, audioUrl, site: '인스타그램' } : null;
    };
    if (code) {
      try {
        const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
        let id = 0n;
        for (const ch of code.length > 28 ? code.slice(0, 11) : code) id = id * 64n + BigInt(A.indexOf(ch));
        const res = await timed(fetch(`/api/v1/media/${id}/info/`, { credentials: 'include', headers: { 'X-IG-App-ID': '936619743392459', 'X-Requested-With': 'XMLHttpRequest' } }), 10000);
        if (res?.ok) out.file = versions((await res.json())?.items?.[0]);
      } catch {}
    }
    if (!out.file) {
      // 페이지에 박힌 자료에서(로그인 안 한 릴스 주소 등)
      const html = [...document.querySelectorAll('script[type="application/json"]')].map((s) => s.textContent).join('\n');
      const i = code ? html.indexOf(`"code":"${code}"`) : -1;
      const m = (i >= 0 ? html.slice(Math.max(0, i - 200000), i + 200000) : html).match(/"video_versions":\s*(\[[^\]]*\])/);
      try { const vv = JSON.parse(m[1]); const v = vv.sort((a, b) => (a.width || 0) - (b.width || 0)).find((x) => x.width >= 480) || vv[vv.length - 1]; if (v?.url) out.file = { url: v.url, site: '인스타그램' }; } catch {}
    }
  }

  // ---- 네이버(블로그·카페·TV): 플레이어가 받은 재생 정보에 자막·mp4 주소 ----
  if (/(^|\.)naver\.com$/.test(location.hostname)) {
    out.site = '네이버';
    // 새 방식(2026): apis.naver.com/neonplayer/vodplay/v3/playback/<vid>?key= → DASH 목록(JSON)
    for (const u of perf().filter((n) => /\/neonplayer\/vodplay\/v\d+\/playback\//.test(n)).reverse()) {
      try {
        const res = await timed(fetch(u, { credentials: 'include' }), 10000);
        const j = res?.ok ? await res.json() : null;
        const sets = [];
        const walk = (o) => { if (!o || typeof o !== 'object') return; if (o.AdaptationSet) sets.push(...[].concat(o.AdaptationSet)); for (const v of Object.values(o)) walk(v); };
        walk(j);
        const first = (x) => (Array.isArray(x) ? x[0] : x);
        const urlOf = (r) => { const b = first(r?.BaseURL); return typeof b === 'string' ? b : b?.['#text'] || ''; };
        const mp4 = [];
        for (const a of sets) {
          const mime = String(a['@mimeType'] || first(a.Representation)?.['@mimeType'] || '');
          const reps = [].concat(a.Representation || []);
          if (/vtt|ttml|text/i.test(mime + (a['@contentType'] || ''))) {
            for (const r of reps) if (urlOf(r)) out.captionUrls.push({ lang: a['@lang'] || a['@label'] || '', url: urlOf(r), asr: /auto/i.test(JSON.stringify(a).slice(0, 2000)) });
          } else if (/video\/mp4|audio\/mp4/.test(mime)) for (const r of reps) if (urlOf(r)) mp4.push({ h: Number(r['@height']) || 0, url: urlOf(r) });
        }
        mp4.sort((x, y) => x.h - y.h);
        const v = mp4.find((x) => x.h >= 360) || mp4[mp4.length - 1];
        if (v) { out.file = { url: v.url, site: '네이버' }; break; }
      } catch {}
    }
    const play = perf().filter((n) => /rmcnmv\.naver\.com\/vod\/play\/v2\.0\//.test(n));
    // 영상이 여럿이면 화면에 가장 큰 영상의 것을 고르기 어렵다 — 마지막에 불린 것(대개 지금 보는 영상)
    for (const u of out.file ? [] : play.reverse()) {
      try {
        const res = await timed(fetch(u), 10000);
        const j = res?.ok ? await res.json() : null;
        if (!j) continue;
        for (const c of j.captions?.list || []) if (c.source) out.captionUrls.push({ lang: c.label || c.locale || '', url: c.source, asr: c.type === 'auto' });
        const vids = [...(j.videos?.list || [])].sort((a, b) => (a.encodingOption?.height || 0) - (b.encodingOption?.height || 0));
        const v = vids.find((x) => (x.encodingOption?.height || 0) >= 360) || vids[vids.length - 1];
        if (v?.source) out.file = { url: v.source, site: '네이버' };
        break;
      } catch {}
    }
  }

  // ---- 일반: <track> 자막, 보통 파일로 재생하는 영상 ----
  if (video) {
    for (const t of video.textTracks || []) {
      if (!/captions|subtitles/.test(t.kind)) continue;
      if (t.mode === 'disabled') { t.mode = 'hidden'; await sleep(1500); }
      const segs = t.cues ? [...t.cues].map((c) => ({ start: c.startTime, text: String(c.text || '').replace(/<[^>]+>/g, '').trim() })).filter((s) => s.text) : [];
      if (segs.length && !out.captions) out.captions = { lang: t.label || t.language || '', asr: false, segments: segs };
    }
    const src = video.currentSrc || video.src;
    if (!out.file && okHttp(src)) out.file = { url: src, site: out.site || location.hostname };
  }
  return out;
}

// 자막 파일(webvtt·srt) → [{ start, text }]
export function cuesOf(raw) {
  const s = String(raw || '').replace(/\r/g, '');
  const out = [];
  const sec = (t) => { const p = t.replace(',', '.').split(':').map(Number); return p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p[0] * 60 + p[1]; };
  for (const block of s.split(/\n\n+/)) {
    const lines = block.split('\n');
    const i = lines.findIndex((l) => l.includes('-->'));
    if (i < 0) continue;
    const text = lines.slice(i + 1).join(' ').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
    if (text && out[out.length - 1]?.text !== text) out.push({ start: sec(lines[i].split('-->')[0].trim()), text });
  }
  return out;
}

// 페이지 안(MAIN)에서 영상 파일을 받아 data: 주소로 돌려준다(바깥에서 받으면 막히는 사이트 — 틱톡 등). 40MB 까지
export async function fetchInPage(url) {
  const res = await fetch(url, { credentials: 'include' });
  if (!res.ok) return { error: `영상 파일을 받지 못했습니다(${res.status})` };
  const buf = new Uint8Array(await res.arrayBuffer());
  if (buf.length > 40 * 1024 * 1024) return { error: '영상 파일이 너무 큽니다' };
  let s = '';
  for (let k = 0; k < buf.length; k += 0x8000) s += String.fromCharCode(...buf.subarray(k, k + 0x8000));
  return { url: `data:${res.headers.get('content-type') || 'video/mp4'};base64,${btoa(s)}` };
}
