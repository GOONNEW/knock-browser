// 지난 대화를 같은 계정의 모든 PC 에서(2026-11-09 원장님 "전체로 하자" · "목록은 모든 PC 공유, 내용은 사용자 선택 —
// [허용 안 함·이번만 허용·항상 허용], 허용은 계정 비밀번호, 항상 허용한 PC 는 그다음부터 비밀번호 없이").
//
// 잠금(끝-끝 암호화): 계정마다 열쇠 한 쌍(ECDH P-256)을 처음 허용한 PC 가 만든다.
//   - 공개 열쇠는 서버에 그대로 — 어느 PC 든 비밀번호 없이 대화를 잠가 올린다(대화마다 새 열쇠로 AES-GCM).
//   - 비밀 열쇠는 계정 비밀번호로 만든 열쇠(PBKDF2 60만 번)로 잠가 서버에 둔다. 서버는 풀지 못한다.
//   - [항상 허용]한 PC 는 푼 비밀 열쇠를 이 프로필의 IndexedDB 에만 둔다. [이번만 허용]은 그 대화 하나만 풀고 버린다.
// 서버가 읽을 수 있는 것은 목록에 보일 것뿐: PC·프로필 이름, 사이트 이름, 글 개수, 시각. 제목·첫 질문·주소·내용은 잠근다.
import { accountApi } from './account.js';

const ITER = 600000;
const enc = new TextEncoder();
const dec = new TextDecoder();
const b64 = (buf) => { let s = ''; const u = new Uint8Array(buf); for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s); };
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const EC = { name: 'ECDH', namedCurve: 'P-256' };

// ---------- [항상 허용] 열쇠 보관(이 프로필의 IndexedDB) ----------
function db() {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open('knock-chat-key', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('k');
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
async function idb(mode, fn) {
  const d = await db();
  return new Promise((resolve, reject) => {
    const tx = d.transaction('k', mode);
    const req = fn(tx.objectStore('k'));
    tx.oncomplete = () => { d.close(); resolve(req?.result); };
    tx.onerror = () => { d.close(); reject(tx.error); };
  });
}
export async function savedKey() {
  try { return (await idb('readonly', (s) => s.get('priv'))) || null; } catch { return null; }
}
const saveKey = (priv) => idb('readwrite', (s) => s.put(priv, 'priv'));
export const forgetKey = () => idb('readwrite', (s) => s.delete('priv')).catch(() => {});

// ---------- 잠그기·풀기 ----------
async function passKey(password, salt, iter) {
  const base = await crypto.subtle.importKey('raw', enc.encode(password.normalize('NFC')), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
async function wrapPriv(priv, password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const pk = await crypto.subtle.exportKey('pkcs8', priv);
  const wrapped = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await passKey(password, salt, ITER), pk);
  return { wrapped: b64(wrapped), salt: b64(salt), iv: b64(iv), iter: ITER };
}
async function unwrapPriv(password, k) {
  const pk = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(k.iv) }, await passKey(password, unb64(k.salt), k.iter), unb64(k.wrapped));
  return crypto.subtle.importKey('pkcs8', pk, EC, true, ['deriveKey']); // 다시 잠글 수 있게 꺼낼 수 있는 열쇠로(계정 비밀번호를 바꿀 때)
}
async function zip(text) {
  const s = new Blob([enc.encode(text)]).stream().pipeThrough(new CompressionStream('gzip'));
  return new Uint8Array(await new Response(s).arrayBuffer());
}
async function unzip(bytes) {
  const s = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
  return dec.decode(await new Response(s).arrayBuffer());
}
async function seal(publicKey, obj) {
  const pub = await crypto.subtle.importKey('raw', unb64(publicKey), EC, false, []);
  const eph = await crypto.subtle.generateKey(EC, true, ['deriveKey']);
  const key = await crypto.subtle.deriveKey({ name: 'ECDH', public: pub }, eph.privateKey, { name: 'AES-GCM', length: 256 }, false, ['encrypt']);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const c = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, await zip(JSON.stringify(obj)));
  return JSON.stringify({ v: 1, e: b64(await crypto.subtle.exportKey('raw', eph.publicKey)), iv: b64(iv), c: b64(c) });
}
async function unseal(priv, text) {
  const s = JSON.parse(text);
  const eph = await crypto.subtle.importKey('raw', unb64(s.e), EC, false, []);
  const key = await crypto.subtle.deriveKey({ name: 'ECDH', public: eph }, priv, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);
  return JSON.parse(await unzip(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(s.iv) }, key, unb64(s.c))));
}

// ---------- 서버 ----------
const loggedIn = async () => Boolean((await chrome.storage.local.get('knockAccount')).knockAccount);
let publicKey = null; // 계정 공개 열쇠(목록을 받을 때마다 새로)

/** 목록 받기: 서버 목록 + (항상 허용한 PC 면) 푼 제목·첫 질문. 서버에서 지운 대화는 이 PC 보관함에서도 뺀다. */
export async function cloudList(forgetLocal) {
  if (!(await loggedIn())) return null;
  const d = await accountApi('/api/knock/chats');
  publicKey = d.key?.publicKey || null;
  const priv = await savedKey();
  const gone = d.chats.filter((c) => c.deleted).map((c) => [c.key, c.at]);
  if (gone.length) await forgetLocal(gone);
  const rows = [];
  for (const c of d.chats) {
    if (c.deleted) continue;
    let meta = null;
    if (priv && c.meta) meta = await unseal(priv, c.meta).catch(() => null);
    rows.push({ ...c, meta: undefined, title: meta?.title || '', url: meta?.url || '', first: meta?.first || '', locked: !meta });
  }
  return { thisDevice: d.thisDevice, devices: d.devices, rows, hasKey: Boolean(priv), keyStale: Boolean(d.key?.stale && priv) };
}

// 올리기: 바뀐 대화만(올린 시각 표시 pastUp), 열쇠가 없던 때 목록만 올린 것은 열쇠가 생기면 다시
const remoteDevOf = (url) => { try { return new URL(url).searchParams.get('dev') || ''; } catch { return ''; } };
const siteOf = (url) => { try { return /^https?:/.test(url) ? new URL(url).hostname : ''; } catch { return ''; } };
let upping = null;
export function cloudUp(ctx) {
  upping ||= doUp(ctx).catch(() => {}).finally(() => { upping = null; });
  return upping;
}
async function doUp({ profile, remoteNameOf, isRemoteUrl }) {
  if (!(await loggedIn())) return;
  if (!publicKey) publicKey = (await accountApi('/api/knock/chats').catch(() => null))?.key?.publicKey || null;
  const { pastChats = {}, pastUp = {} } = await chrome.storage.local.get(['pastChats', 'pastUp']);
  const next = {};
  for (const [key, v] of Object.entries(pastChats)) {
    const was = pastUp[key];
    next[key] = was;
    if (v.busy || (was && was.at >= v.at && (was.sealed || !publicKey))) continue;
    const remote = isRemoteUrl(v.url) ? remoteNameOf(v.url) : '';
    // 다른 PC 에서 가져와 아직 이어 가지 않은 대화는 올리지 않는다(올린 PC 이름이 바뀌지 않게)
    if (v.fromCloud && v.at <= v.fromCloud) { next[key] = { at: v.at, sealed: true }; continue; }
    const items = v.chat?.items || [];
    const { sessions, seen, busy, open, ...chat } = v.chat || {};
    let body = { ...chat, items };
    if (JSON.stringify(body).length > 2_000_000) body = { ...chat, items: items.map((i) => (i.files?.length ? { ...i, files: i.files.map((f) => ({ name: f.name })) } : i)) };
    const first = (items.find((i) => i.kind === 'user')?.text || '').slice(0, 80);
    const r = await accountApi('/api/knock/chats', {
      method: 'POST',
      body: {
        action: 'put', key, at: v.at, n: v.n, profile, site: remote ? '' : siteOf(v.url), remoteName: remote,
        targetDeviceId: remote ? remoteDevOf(v.url) : '',
        meta: publicKey ? await seal(publicKey, { title: v.title || '', url: v.url || '', first }) : null,
        content: publicKey ? await seal(publicKey, { chat: body }) : null,
      },
    }).catch(() => null);
    if (r?.ok) next[key] = { at: v.at, sealed: Boolean(publicKey) };
  }
  await chrome.storage.local.set({ pastUp: Object.fromEntries(Object.entries(next).filter(([, x]) => x)) });
}

/**
 * 다른 PC 대화 가져오기. choice: 'auto'(항상 허용한 PC 면 바로) | 'once' | 'always' — 허용은 계정 비밀번호와 함께.
 * 돌려줌: { chat, at, title, url } | { needChoice } | { error, reason }
 */
export async function cloudOpen(key, choice = 'auto', password = '') {
  let priv = await savedKey();
  if (!priv) {
    if (choice !== 'once' && choice !== 'always') return { needChoice: true };
    if (!password) return { error: '계정 비밀번호를 넣어 주세요.', reason: 'password' };
    const u = await accountApi('/api/knock/chats/key', { method: 'POST', body: { action: 'unlock', password } }).catch((e) => ({ error: e.message, reason: e.reason }));
    if (u.error) return u;
    if (u.none) {
      // 처음 허용: 이 PC 가 열쇠 한 쌍을 만든다(그때까지 다른 PC 는 목록만 올려 두었다)
      const pair = await crypto.subtle.generateKey(EC, true, ['deriveKey']);
      const pub = b64(await crypto.subtle.exportKey('raw', pair.publicKey));
      const made = await accountApi('/api/knock/chats/key', { method: 'POST', body: { action: 'create', password, publicKey: pub, ...(await wrapPriv(pair.privateKey, password)) } }).catch((e) => ({ error: e.message, reason: e.reason }));
      if (made.error) return made;
      priv = pair.privateKey;
      publicKey = pub;
    } else {
      priv = await unwrapPriv(password, u.key).catch(() => null);
      if (!priv) {
        await accountApi('/api/knock/chats/key', { method: 'POST', body: { action: 'stale' } }).catch(() => {});
        return { error: '계정 비밀번호가 바뀌어서 잠금이 맞지 않아요. [항상 허용]한 PC에서 지난 대화 화면을 열고 새 비밀번호를 한 번 넣어 주세요.', reason: 'stale' };
      }
    }
    if (choice === 'always') await saveKey(priv);
  }
  const g = await accountApi(`/api/knock/chats?key=${encodeURIComponent(key)}`).catch((e) => ({ error: e.message }));
  if (g.error) return g;
  if (!g.chat.content) return { error: `"${g.chat.deviceName}"이(가) 아직 내용을 올리지 않았어요. 그 PC에서 Knock Browser가 켜지면 몇 분 안에 올라와요.` };
  const body = await unseal(priv, g.chat.content).catch(() => null);
  const meta = g.chat.meta ? await unseal(priv, g.chat.meta).catch(() => null) : null;
  if (!body?.chat) return { error: '잠긴 내용을 풀지 못했어요.' };
  return { chat: body.chat, at: g.chat.at, n: g.chat.n, title: meta?.title || '', url: meta?.url || '' };
}

/** 계정 비밀번호를 바꾼 뒤: [항상 허용]한 PC 에서 새 비밀번호로 비밀 열쇠를 다시 잠근다 */
export async function cloudRewrap(password) {
  const priv = await savedKey();
  if (!priv) return { error: '이 PC에는 열쇠가 없어요.' };
  if (!password) return { error: '새 계정 비밀번호를 넣어 주세요.' };
  return accountApi('/api/knock/chats/key', { method: 'POST', body: { action: 'rewrap', password, ...(await wrapPriv(priv, password)) } }).catch((e) => ({ error: e.message }));
}

export async function cloudDelete(key) {
  if (!(await loggedIn())) return;
  await accountApi('/api/knock/chats', { method: 'POST', body: { action: 'delete', key } }).catch(() => {});
}
