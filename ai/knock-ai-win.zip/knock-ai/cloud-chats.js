// 지난 대화를 같은 계정의 모든 PC 에서(2026-11-09 원장님 "전체로 하자").
// 목록 관리 규칙(2026-11-09 원장님): 지난 대화 목록은 기본으로 모두 잠김 → [잠금 풀기]에 똑소리툴즈 계정 비밀번호.
// "이 장치에서는 잠금 풀어 두기"를 고르면 이 장치는 다음부터 비밀번호 없이(설정 → 보안에서 끄기·다시 잠그기).
//
// 잠금(끝-끝 암호화): 계정마다 열쇠 한 쌍(ECDH P-256)을 처음 잠금을 푼 PC 가 만든다.
//   - 공개 열쇠는 서버에 그대로 — 어느 PC 든 비밀번호 없이 대화를 잠가 올린다(대화마다 새 열쇠로 AES-GCM).
//   - 비밀 열쇠는 계정 비밀번호로 만든 열쇠(PBKDF2 60만 번)로 잠가 서버에 둔다. 서버는 풀지 못한다.
//   - "풀어 두기"면 푼 비밀 열쇠를 이 프로필의 IndexedDB 에, 아니면 Knock 을 끌 때까지만(storage.session) 둔다.
// 서버가 읽을 수 있는 것: 장치·프로필 이름, 사이트 이름, 글 개수, 시각. 대화 이름·제목·첫 명령·주소·내용은 잠근다.
import { accountApi } from './account.js';

const ITER = 600000;
const enc = new TextEncoder();
const dec = new TextDecoder();
const b64 = (buf) => { let s = ''; const u = new Uint8Array(buf); for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s); };
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const EC = { name: 'ECDH', namedCurve: 'P-256' };

// ---------- 푼 열쇠 보관: 풀어 두기 → IndexedDB, 아니면 storage.session(Knock 을 끄면 사라짐) ----------
function db() {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open('knock-chat-key', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('k');
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
async function idb(mode, fn) {
  const d = await db();
  return new Promise((resolve, reject) => {
    const tx = d.transaction('k', mode);
    const req = fn(tx.objectStore('k'));
    tx.oncomplete = () => { d.close(); resolve(req?.result); };
    tx.onerror = () => { d.close(); reject(tx.error); };
  });
}
export async function savedKey() {
  try { return (await idb('readonly', (s) => s.get('priv'))) || null; } catch { return null; }
}
const saveKey = (priv) => idb('readwrite', (s) => s.put(priv, 'priv'));
export const forgetKey = () => idb('readwrite', (s) => s.delete('priv')).catch(() => {});
async function sessionKey() {
  const { chatKeyS } = await chrome.storage.session.get('chatKeyS').catch(() => ({}));
  return chatKeyS ? crypto.subtle.importKey('pkcs8', unb64(chatKeyS), EC, true, ['deriveKey']).catch(() => null) : null;
}
const saveSession = async (priv) => chrome.storage.session.set({ chatKeyS: b64(await crypto.subtle.exportKey('pkcs8', priv)) });
const forgetSession = () => chrome.storage.session.remove('chatKeyS').catch(() => {});
/** 지금 쓸 수 있는 열쇠(풀어 둔 것 → 이번에 푼 것) */
async function currentKey() { return (await savedKey()) || (await sessionKey()); }
/** 잠금 상태: loggedIn(로그인해야 잠금을 쓸 수 있다) · unlocked · keep(이 장치에서 풀어 둠) */
export async function lockState() {
  const keep = Boolean(await savedKey());
  return { loggedIn: await loggedIn(), unlocked: keep || Boolean(await sessionKey()), keep };
}

const loggedIn = async () => Boolean((await chrome.storage.local.get('knockAccount')).knockAccount);

// ---------- 잠그기·풀기 ----------
async function passKey(password, salt, iter) {
  const base = await crypto.subtle.importKey('raw', enc.encode(password.normalize('NFC')), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
async function wrapPriv(priv, password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const pk = await crypto.subtle.exportKey('pkcs8', priv);
  const wrapped = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await passKey(password, salt, ITER), pk);
  return { wrapped: b64(wrapped), salt: b64(salt), iv: b64(iv), iter: ITER };
}
async function unwrapPriv(password, k) {
  const pk = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(k.iv) }, await passKey(password, unb64(k.salt), k.iter), unb64(k.wrapped));
  return crypto.subtle.importKey('pkcs8', pk, EC, true, ['deriveKey']); // 다시 잠글 수 있게 꺼낼 수 있는 열쇠로(계정 비밀번호를 바꿀 때)
}
async function zip(text) {
  const s = new Blob([enc.encode(text)]).stream().pipeThrough(new CompressionStream('gzip'));
  return new Uint8Array(await new Response(s).arrayBuffer());
}
async function unzip(bytes) {
  const s = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
  return dec.decode(await new Response(s).arrayBuffer());
}
async function seal(publicKey, obj) {
  const pub = await crypto.subtle.importKey('raw', unb64(publicKey), EC, false, []);
  const eph = await crypto.subtle.generateKey(EC, true, ['deriveKey']);
  const key = await crypto.subtle.deriveKey({ name: 'ECDH', public: pub }, eph.privateKey, { name: 'AES-GCM', length: 256 }, false, ['encrypt']);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const c = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, await zip(JSON.stringify(obj)));
  return JSON.stringify({ v: 1, e: b64(await crypto.subtle.exportKey('raw', eph.publicKey)), iv: b64(iv), c: b64(c) });
}
async function unseal(priv, text) {
  const s = JSON.parse(text);
  const eph = await crypto.subtle.importKey('raw', unb64(s.e), EC, false, []);
  const key = await crypto.subtle.deriveKey({ name: 'ECDH', public: eph }, priv, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);
  return JSON.parse(await unzip(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(s.iv) }, key, unb64(s.c))));
}

// ---------- 서버 ----------
let publicKey = null; // 계정 공개 열쇠(목록을 받을 때마다 새로)

/** [잠금 풀기]: 계정 비밀번호로 서버의 잠긴 열쇠를 받아 이 장치에서 푼다(계정에 열쇠가 없으면 지금 만든다). keep: 이 장치에서 풀어 두기 */
const plainErr = (e) => ({ error: /fetch|network|Failed/i.test(String(e?.message || e)) ? '똑소리 서버에 연결하지 못했어요. 인터넷 연결을 확인한 뒤 다시 해 주세요.' : String(e?.message || e) });
export async function cloudUnlock(password, keep) {
  if (!password) return { error: '계정 비밀번호를 넣어 주세요.' };
  const u = await accountApi('/api/knock/chats/key', { method: 'POST', body: { action: 'unlock', password } }).catch(plainErr);
  if (u.error) return u;
  let priv;
  if (u.none) {
    const pair = await crypto.subtle.generateKey(EC, true, ['deriveKey']);
    const pub = b64(await crypto.subtle.exportKey('raw', pair.publicKey));
    const made = await accountApi('/api/knock/chats/key', { method: 'POST', body: { action: 'create', password, publicKey: pub, ...(await wrapPriv(pair.privateKey, password)) } }).catch(plainErr);
    if (made.error) return made;
    priv = pair.privateKey;
    publicKey = pub;
  } else {
    priv = await unwrapPriv(password, u.key).catch(() => null);
    if (!priv) {
      await accountApi('/api/knock/chats/key', { method: 'POST', body: { action: 'stale' } }).catch(() => {});
      return { error: '계정 비밀번호가 바뀌어서 잠금이 맞지 않아요. 잠금을 풀어 둔 다른 장치에서 지난 대화 화면을 열고 새 비밀번호를 한 번 넣어 주세요.' };
    }
  }
  await forgetSession();
  if (keep) await saveKey(priv);
  else { await forgetKey(); await saveSession(priv); }
  return { ok: true };
}
/** 지금 다시 잠그기(풀어 둔 것도 지운다) */
export async function cloudLock() { await forgetKey(); await forgetSession(); return { ok: true }; }
/** "이 장치에서는 잠금 풀어 두기" 켜기·끄기 — 켜기는 지금 풀려 있어야, 끄면 Knock 을 끌 때까지만 풀린 채로 */
export async function cloudKeep(on) {
  const priv = await currentKey();
  if (on) {
    if (!priv) return { error: '먼저 지난 대화 화면에서 [잠금 풀기]를 해 주세요.' };
    await saveKey(priv);
    await forgetSession();
  } else if (await savedKey()) {
    await saveSession(priv);
    await forgetKey();
  }
  return { ok: true };
}

/**
 * 목록 받기: 서버 목록 + (잠금이 풀렸으면) 푼 대화 이름·제목·첫 명령·마지막 페이지.
 * 서버에서 지운 대화는 이 PC 보관함에서도 빼고(forgetLocal), 다른 장치에서 고친 이름은 이 PC 보관함에도(takeNames).
 */
export async function cloudList(forgetLocal, takeNames) {
  if (!(await loggedIn())) return null;
  const d = await accountApi('/api/knock/chats');
  publicKey = d.key?.publicKey || null;
  const priv = await currentKey();
  const gone = d.chats.filter((c) => c.deleted).map((c) => [c.key, c.at]);
  if (gone.length) await forgetLocal(gone);
  const rows = [];
  const names = [];
  for (const c of d.chats) {
    if (c.deleted) continue;
    let meta = null;
    let name = '';
    if (priv && c.meta) meta = await unseal(priv, c.meta).catch(() => null);
    if (priv && c.name) name = (await unseal(priv, c.name).catch(() => null))?.name || '';
    if (name) names.push([c.key, name, c.nameAt]);
    // pending: 그 PC 가 목록만 올리고 내용은 아직(열쇠가 생기기 전에 올렸거나, 그 PC 가 꺼져 있음)
    rows.push({ ...c, meta: undefined, name, title: meta?.title || '', url: meta?.url || '', page: meta?.page || '', first: meta?.first || '', pending: !c.hasContent, locked: !meta });
  }
  if (names.length) await takeNames(names);
  return { thisDevice: d.thisDevice, devices: d.devices, rows, unlocked: Boolean(priv), serverKey: Boolean(d.key), keyStale: Boolean(d.key?.stale && priv) };
}

const items_has_user = (v) => (v.chat?.items || []).some((i) => i.kind === 'user' && (i.text || i.files?.length));
// 올리기: 바뀐 대화만(올린 시각 표시 pastUp), 열쇠가 없던 때 목록만 올린 것은 열쇠가 생기면 다시
const remoteDevOf = (url) => { try { return new URL(url).searchParams.get('dev') || ''; } catch { return ''; } };
const siteOf = (url) => { try { return /^https?:/.test(url) ? new URL(url).hostname : ''; } catch { return ''; } };
let upping = null;
export function cloudUp(ctx) {
  upping ||= doUp(ctx).catch(() => {}).finally(() => { upping = null; });
  return upping;
}
async function doUp({ profile, remoteNameOf, isRemoteUrl, busyKeys = new Set() }) {
  if (!(await loggedIn())) return;
  await sendProfileName(profile);
  if (!publicKey) publicKey = (await accountApi('/api/knock/chats').catch(() => null))?.key?.publicKey || null;
  const { pastChats = {}, pastUp = {} } = await chrome.storage.local.get(['pastChats', 'pastUp']);
  const next = { ...pastUp };
  const log = { at: Date.now(), ok: 0, fail: 0, waiting: 0, err: '' };
  // 하나 올릴 때마다 남긴다 — 도중에 Knock 이 쉬어도(서비스 워커 멈춤) 다음에 처음부터 다시 하지 않게(2026-11-10 노트북 대화가 안 올라감)
  const keepNext = () => chrome.storage.local.set({ pastUp: Object.fromEntries(Object.entries(next).filter(([k, x]) => x && pastChats[k])) });
  // 최근 대화부터
  for (const [key, v] of Object.entries(pastChats).sort((a, b) => b[1].at - a[1].at)) {
    const was = pastUp[key];
    // 이 PC 에서 고친 이름이 아직 서버에 안 갔으면 보낸다(서버에 그 대화가 있을 때 — 없으면 올린 바로 뒤에)
    const sendName = async () => {
      if (!(v.name != null && v.nameAt && !(next[key]?.nameAt >= v.nameAt) && publicKey)) return;
      const r = await cloudRenameRaw(key, v.name);
      if (r?.ok) { next[key] = { ...(next[key] || { at: 0 }), nameAt: v.nameAt }; await keepNext(); }
    };
    if (was) await sendName();
    // 지금 정말 일하는 중인 대화만 건너뛴다 — 보관함의 busy 표시는 Knock 이 일하던 중에 꺼지면 그대로 남아 영영 안 올라갔다
    if (busyKeys.has(key) || (was && was.at >= v.at && (was.sealed || !publicKey))) continue;
    if (!items_has_user(v)) continue; // 명령 없는 빈 대화는 올리지 않는다
    if (v.fromCloud && v.at <= v.fromCloud) { next[key] = { ...(next[key] || {}), at: v.at, sealed: true }; continue; }
    if (!publicKey) log.waiting++;
    try {
      const items = v.chat?.items || [];
      const { sessions, seen, busy, open, ...chat } = v.chat || {};
      const first = (items.find((i) => i.kind === 'user')?.text || '').slice(0, 80);
      const content = publicKey ? await sealChat(chat, items) : null;
      const meta = publicKey ? await seal(publicKey, { title: String(v.title || '').slice(0, 300), url: String(v.url || '').slice(0, 2000), page: String(v.page || '').slice(0, 2000), first }) : null;
      const remote = isRemoteUrl(v.url) ? remoteNameOf(v.url) : '';
      const r = await accountApi('/api/knock/chats', {
        method: 'POST',
        body: {
          action: 'put', key, at: v.at, n: v.n, profile, site: remote ? '' : siteOf(v.page || v.url), remoteName: remote,
          targetDeviceId: remote ? remoteDevOf(v.url) : '', meta, content,
        },
      });
      if (r?.ok) { next[key] = { ...(next[key] || {}), at: v.at, sealed: Boolean(publicKey) }; log.ok++; await keepNext(); await sendName(); }
    } catch (e) {
      log.fail++;
      log.err = String(e?.message || e).slice(0, 160);
      console.warn('[Knock] 지난 대화 올리기 실패', key, log.err);
      if (e?.loggedOut) break;
    }
  }
  await keepNext();
  await chrome.storage.local.set({ pastUpLog: log });
}
// 이 프로필 이름을 바꾸면 이 장치가 전에 올린 대화도 새 이름으로 묶이게 서버에 알린다(2026-11-10 옛 이름 "직장" 묶음이 남음)
async function sendProfileName(profile) {
  if (!profile) return;
  const { cloudProfileSent, knockAccount } = await chrome.storage.local.get(['cloudProfileSent', 'knockAccount']);
  const mark = `${knockAccount?.device?.id || ''}|${profile}`;
  if (cloudProfileSent === mark) return;
  const r = await accountApi('/api/knock/chats', { method: 'POST', body: { action: 'profile', profile } }).catch(() => null);
  if (r?.ok) await chrome.storage.local.set({ cloudProfileSent: mark });
}
// 대화 내용 잠그기 — 서버 한도(3MB) 안으로: 사진 미리보기 빼기 → 아주 긴 글 줄이기 → 앞부분 덜기(최근 것을 남긴다)
async function sealChat(chat, items) {
  const LIMIT = 2_800_000;
  let list = items;
  let content = await seal(publicKey, { chat: { ...chat, items: list } });
  if (content.length <= LIMIT) return content;
  list = list.map((i) => (i.files?.length ? { ...i, files: i.files.map((f) => ({ name: f.name })) } : i));
  content = await seal(publicKey, { chat: { ...chat, items: list } });
  if (content.length <= LIMIT) return content;
  list = list.map((i) => (typeof i.text === 'string' && i.text.length > 20000 ? { ...i, text: `${i.text.slice(0, 20000)}\n…(너무 길어 뒷부분은 다른 PC로 옮기지 않았어요)` } : i));
  content = await seal(publicKey, { chat: { ...chat, items: list } });
  for (let keepN = Math.floor(list.length / 2); content.length > LIMIT && keepN >= 1; keepN = Math.floor(keepN / 2)) {
    content = await seal(publicKey, { chat: { ...chat, items: [{ kind: 'step', text: `(앞의 ${list.length - keepN}개는 너무 길어 다른 PC로 옮기지 않았어요)` }, ...list.slice(-keepN)] } });
  }
  return content;
}
/** 이 장치에서 올리기 상태(설정·지난 대화 화면에 보인다) */
export async function upState() {
  const { pastChats = {}, pastUp = {}, pastUpLog = null } = await chrome.storage.local.get(['pastChats', 'pastUp', 'pastUpLog']);
  const mine = Object.entries(pastChats).filter(([, v]) => items_has_user(v) && !(v.fromCloud && v.at <= v.fromCloud));
  const left = mine.filter(([k, v]) => !(pastUp[k] && pastUp[k].at >= v.at && pastUp[k].sealed)).length;
  return { total: mine.length, left, log: pastUpLog, loggedIn: await loggedIn() };
}

/** 다른 PC 대화 가져오기(잠금이 풀려 있어야). 돌려줌: { chat, at, n, title, url, page, name } | { locked } | { pending, error } | { error } */
export async function cloudOpen(key) {
  const g = await accountApi(`/api/knock/chats?key=${encodeURIComponent(key)}`).catch(plainErr);
  if (g.error) return g;
  if (!g.chat.content) return { pending: true, error: notUpYet(g.chat.deviceName) };
  const priv = await currentKey();
  if (!priv) return { locked: true, error: '지난 대화가 잠겨 있어요. 목록 위 [잠금 풀기]를 눌러 주세요.' };
  const body = await unseal(priv, g.chat.content).catch(() => null);
  const meta = g.chat.meta ? await unseal(priv, g.chat.meta).catch(() => null) : null;
  const name = g.chat.name ? (await unseal(priv, g.chat.name).catch(() => null))?.name || '' : '';
  if (!body?.chat) return { error: '잠긴 내용을 풀지 못했어요. 지금 다시 잠근 뒤 [잠금 풀기]를 다시 해 주세요.' };
  return { chat: body.chat, at: g.chat.at, n: g.chat.n, title: meta?.title || '', url: meta?.url || '', page: meta?.page || '', name, nameAt: g.chat.nameAt || 0,
    deviceId: g.chat.deviceId, deviceName: g.chat.deviceName, profile: g.chat.profile || '', targetDeviceId: g.chat.targetDeviceId || '' };
}

/** 대화 이름 고치기 — 이름은 잠가서 서버에(모든 장치에 같이 보인다) */
async function cloudRenameRaw(key, name) {
  if (!publicKey) publicKey = (await accountApi('/api/knock/chats').catch(() => null))?.key?.publicKey || null;
  if (!publicKey) return null;
  return accountApi('/api/knock/chats', { method: 'POST', body: { action: 'rename', key, name: await seal(publicKey, { name }) } })
    .catch((e) => (/없어요/.test(e.message) ? { error: '이 대화는 아직 서버에 올라오지 않았어요. 그 대화를 한 기기(프로필)에서 이름을 바꿔 주세요.', notUp: true } : plainErr(e)));
}
export async function cloudRename(key, name) {
  if (!(await loggedIn())) return { ok: true, local: true };
  return (await cloudRenameRaw(key, name)) || { error: '아직 잠금 열쇠가 없어요. 먼저 [잠금 풀기]를 해 주세요.' };
}

/** 그 PC 가 아직 내용을 올리지 않았을 때 알릴 글 */
export function notUpYet(device) {
  return `"${device}"에서 아직 내용이 올라오지 않았어요. 그 장치의 Knock Browser를 최신 버전으로 업데이트하고 켜 두면 5분 안에 올라와요.`;
}

/** 계정 비밀번호를 바꾼 뒤: 잠금을 풀어 둔 장치에서 새 비밀번호로 비밀 열쇠를 다시 잠근다 */
export async function cloudRewrap(password) {
  const priv = await currentKey();
  if (!priv) return { error: '이 장치는 잠금이 풀려 있지 않아요.' };
  if (!password) return { error: '새 계정 비밀번호를 넣어 주세요.' };
  return accountApi('/api/knock/chats/key', { method: 'POST', body: { action: 'rewrap', password, ...(await wrapPriv(priv, password)) } }).catch((e) => ({ error: e.message }));
}

export async function cloudDelete(key) {
  if (!(await loggedIn())) return;
  await accountApi('/api/knock/chats', { method: 'POST', body: { action: 'delete', key } }).catch(() => {});
}
