// 브라우저 연동 — 들어와지는 쪽의 배경 일(2026-11-05 2단계). 통로는 rhost.js(offscreen)가 맡고, 여기서는
// 이 Knock Browser 창의 탭 목록을 보내고, 보는 탭의 화면을 개발자 도구 통로(Page.startScreencast)로 찍어 보내고,
// 받은 누르기·입력을 그 탭에 넣는다. 화면 고르기 창 없이 되므로 아무도 없는 PC 에도 들어갈 수 있다.
// 연결 중에는 알림(끊기 단추)과 도구 막대 배지로 "누가 쓰는 중"인지 늘 보인다(I-3 화면).
import { accountState, accountRemoteState, accountRemoteClaim, accountRemoteEnd } from './account.js';
import { addLocalSite, forgetLocalSite, localSites, localSitesSupported, siteOf } from './local-sites.js';

let deps = null; // { ensureOffscreen, page }
const live = { on: false, sessionId: '', name: '', windowId: null, tabId: null, view: { w: 1280, h: 800, dpr: 1 }, meta: null, tabsTimer: null, focus: null };

const out = (data) => chrome.runtime.sendMessage({ target: 'offscreen', type: 'rhost', cmd: 'out', data }).catch(() => {});
const outFrame = (data) => chrome.runtime.sendMessage({ target: 'offscreen', type: 'rhost', cmd: 'frame', data }).catch(() => ({ ok: false }));

// ---- 화질 자동 조절(2026-11-05) ----
// 한 장을 다 보내는 데 걸린 시간으로 이 연결의 속도를 재고(초당 바이트), 거기 맞는 단계로 바꾼다.
// 노트북 쪽 올리기 속도가 2.8Mbps(초당 약 350KB)인 곳에서도 쌓이지 않고 움직이게 — 느리면 작고 흐리게, 빠르면 또렷하게.
const LEVELS = [
  { name: '아주 낮게', dpr: 1, q: 40, scale: 0.6 },
  { name: '낮게', dpr: 1, q: 50, scale: 0.8 },
  { name: '보통', dpr: 1, q: 65, scale: 1 },
  { name: '좋게', dpr: 1.5, q: 75, scale: 1 },
  { name: '아주 좋게', dpr: 2, q: 85, scale: 1 },
];
// 이 속도(초당 바이트)보다 빠르면 한 단계 위로, 이것의 0.8배보다 느리면 아래로 — 초당 10장쯤 움직이게 잡았다
// (2.8Mbps≈350KB/s 노트북은 "낮게": 한 장 30KB 안팎)
const UP_AT = [200e3, 600e3, 1500e3, 3500e3];
const q = { level: 2, rate: 0, since: 0, sent: 0, sentAt: 0 };
function levelNow() {
  const L = LEVELS[q.level];
  return { ...L, dpr: Math.min(L.dpr, live.view.dpr || 1) };
}
function adapt(bytes, ms) {
  // 바로 빠진 작은 그림(쉬는 화면)은 속도를 재지 않는다
  if (ms > 30) q.rate = q.rate ? q.rate * 0.7 + (bytes / ms) * 1000 * 0.3 : (bytes / ms) * 1000;
  q.sent += bytes;
  const now = Date.now();
  if (now - q.since < 3000) return;
  q.since = now;
  let want = q.level;
  if (q.rate && q.level > 0 && q.rate < UP_AT[q.level - 1] * 0.8) want = q.level - 1; // 느려서 내림
  else if ((!q.rate || q.rate > UP_AT[q.level]) && q.level < LEVELS.length - 1) want = q.level + 1; // 넉넉해서 올림
  const perSec = q.sentAt ? Math.round((q.sent / (now - q.sentAt)) * 1000) : 0;
  q.sent = 0;
  q.sentAt = now;
  if (want !== q.level) {
    q.level = want;
    if (live.tabId && live.mode !== 'video') stream(live.tabId);
  }
  out({ t: 'quality', level: q.level, name: LEVELS[q.level].name, rate: Math.round(q.rate || 0), perSec });
}

export function initRemoteHost(d) {
  deps = d;
  clearPopups(); // 원격 중에 꺼졌다 켜졌으면 열어 둔 팝업 허용이 남아 있다
  chrome.debugger.onEvent.addListener(({ tabId }, method, params) => {
    // 페이지 알림창(alert·confirm·prompt)은 화면 사진에 안 찍히고 페이지가 멈춘다 — 연결한 쪽에 같은 창을 띄우게 알린다(2026-11-05)
    if (live.on && tabId === live.tabId && method === 'Page.javascriptDialogOpening') {
      out({ t: 'dialog', type: params.type, message: String(params.message || '').slice(0, 2000), prompt: params.defaultPrompt || '' });
      return;
    }
    if (live.on && tabId === live.tabId && method === 'Page.javascriptDialogClosed') {
      out({ t: 'dialog', closed: true });
      return;
    }
    // 사람이 [사진]·[파일]을 눌러 뜬 파일 선택 창(2026-11-07 "브라우저 연동에서 사진을 눌러도 창이 안 떠"):
    // 이 PC 의 윈도우 창은 보는 쪽 화면에 안 보이므로 가로채 두고, 보는 쪽(맥)에서 파일을 고르게 한다
    if (live.on && tabId === live.tabId && method === 'Page.fileChooserOpened' && !deps.page.aiChoosing?.has(tabId)) {
      live.chooser = { tabId, backendNodeId: params.backendNodeId, mode: params.mode, files: [] };
      out({ t: 'fileChooser', multiple: params.mode === 'selectMultiple' });
      return;
    }
    if (method !== 'Page.screencastFrame' || !live.on || tabId !== live.tabId) return;
    live.meta = params.metadata;
    // 다 보낸 뒤에 다음 장을 달라고 한다(받았다고 바로 답하면 그림이 줄줄이 쌓여 지연이 커졌다)
    outFrame({ t: 'frame', tabId, data: params.data, w: params.metadata.deviceWidth, h: params.metadata.deviceHeight }).then((r) => {
      if (r?.ok) adapt(r.bytes, r.ms);
      chrome.debugger.sendCommand({ tabId }, 'Page.screencastFrameAck', { sessionId: params.sessionId }).catch(() => {});
    });
  });
  const tabsChanged = () => {
    if (!live.on) return;
    clearTimeout(live.tabsTimer);
    live.tabsTimer = setTimeout(sendTabs, 200);
  };
  chrome.tabs.onCreated.addListener(tabsChanged);
  // 은행·관공서가 window.open 으로 띄운 팝업 창(2026-11-08 "브라우저 연동 시 팝업창은 안 떠"): 새로 뜨면 바로 그 창을 보여 준다
  chrome.tabs.onCreated.addListener(async (t) => {
    if (!live.on || t.windowId === live.windowId) return;
    const w = await chrome.windows.get(t.windowId).catch(() => null);
    if (w?.type === 'popup' && !NOT_PAGE.test(t.pendingUrl || t.url || '')) { live.focus = t.id; tabsChanged(); }
  });
  chrome.tabs.onRemoved.addListener(tabsChanged);
  chrome.tabs.onUpdated.addListener((_id, info) => { if (info.title || info.url || info.status === 'complete' || info.favIconUrl) tabsChanged(); });
  chrome.tabs.onActivated.addListener(({ tabId, windowId }) => {
    if (!live.on || windowId !== live.windowId) return;
    live.focus = null;
    stream(tabId);
    tabsChanged();
  });
  chrome.notifications.onButtonClicked.addListener((id) => { if (id === 'knock-rhost') endHost('이 PC에서 연결을 끊었어요.'); });
  // 보는 탭이 보안 사이트로 들어가려 하면 새 페이지가 열리기 전에 디버거를 뗀다 / 보안 사이트에서 나가면 다시 붙인다
  chrome.webNavigation.onBeforeNavigate.addListener(({ tabId, frameId, url }) => {
    if (!live.on || frameId !== 0 || tabId !== live.tabId || live.cleanTab === tabId || !IS_WIN || !isSecureUrl(url)) return;
    live.forceClean = tabId;
    live.tabId = null;
    stream(tabId);
  });
  chrome.webNavigation.onCommitted.addListener(async ({ tabId, frameId, url }) => {
    if (!live.on || frameId !== 0 || tabId !== live.cleanTab || isSecureUrl(url) || !/^https?:/.test(url)) return;
    if (await cleanTab(await chrome.tabs.get(tabId).catch(() => null))) return; // 은행이 연 팝업은 그대로
    live.cleanTab = null;
    leaveSecure();
  });
  // 원격으로 보는 탭이 이 PC 의 보안 프로그램(127.0.0.1·localhost)을 부르면 보는 쪽 대화창에 허용할지 묻는다(2026-11-08 "대화창에서 항상 허용 3단계로 물어봐") —
  // 권한 창은 이 PC 에만 떠서 보는 쪽에서는 누를 수 없었다. 원격 중에, 보는 쪽에 보이는 탭에서만 묻는다.
  chrome.webRequest?.onBeforeRequest.addListener(({ tabId, initiator }) => {
    if (live.on && tabId >= 0 && localSitesSupported()) askLocal(tabId, initiator).catch(() => {});
  }, { urls: ['*://127.0.0.1/*', '*://localhost/*'] });
}

// 이번 연결 동안만: 허용 안 한 사이트(다시 묻지 않음), "이번만 허용"한 사이트(연결이 끝나면 지움), 지금 묻는 중
const lnaNo = new Set();
const lnaOnce = new Set();
let lnaAsk = null;
async function askLocal(tabId, initiator) {
  const tab = (await allTabs()).find((t) => t.id === tabId);
  const site = siteOf(tab?.url || '');
  if (!site || lnaNo.has(site) || lnaAsk?.site === site) return;
  const have = await localSites();
  const want = [site, siteOf(initiator || '')].filter((s, i, a) => s && a.indexOf(s) === i && !have.includes(s));
  if (!want.length) return;
  lnaAsk = { site, want, tabId };
  out({ t: 'askLocal', site });
}
async function answerLocal({ site, pick }) {
  const a = lnaAsk;
  if (!a || a.site !== site) return;
  lnaAsk = null;
  if (pick !== 'once' && pick !== 'always') {
    lnaNo.add(site);
    return out({ t: 'note', text: '허용하지 않았어요. 그 PC에 뜬 권한 창 때문에 페이지가 멈춰 있을 수 있어요.' });
  }
  for (const s of a.want) await addLocalSite(s);
  if (pick === 'once') a.want.forEach((s) => lnaOnce.add(s));
  out({ t: 'note', text: `${site} 의 보안 프로그램 연결을 ${pick === 'once' ? '이번 연결 동안' : '항상'} 허용해요. 페이지를 다시 읽어요.` });
  await chrome.tabs.reload(a.tabId).catch(() => {});
}

/** 로그인했고 원격을 켰으면 알림 채널을 듣는다(켤 때·1분마다·원격 켜고 끌 때 부른다) */
export async function syncRemoteHost() {
  const st = await accountState();
  let inboxId = '';
  let sure = !st.loggedIn; // 서버에 묻지 못했으면(인터넷 끊김 등) 뒤에서 돌기 권한은 그대로 둔다
  if (st.loggedIn) {
    const r = await accountRemoteState().catch(() => null);
    inboxId = r?.remoteEnabled ? r.inboxId || '' : '';
    sure = r !== null;
  }
  // 원격을 켠 PC 만 브라우저를 닫아도 뒤에서 돈다(bg-mode.js) — 원격을 끄면 그 권한도 돌려놓는다
  if (sure) {
    chrome.storage.local.set({ remoteHostOn: !!inboxId }).catch(() => {});
    // 브라우저에 넣은 Knock AI(내장 부품)는 누르지 않아도 권한을 받을 수 있다 — 화면을 누를 때 받는 것(bg-mode.js)은 예비
    if (inboxId) chrome.permissions.request({ permissions: ['background'] }).catch(() => {});
    else chrome.permissions.remove({ permissions: ['background'] }).catch(() => {});
  }
  if (!inboxId && !(await chrome.offscreen.hasDocument())) return;
  await deps.ensureOffscreen();
  await chrome.runtime.sendMessage({ target: 'offscreen', type: 'rhost', cmd: 'listen', inboxId }).catch(() => {});
}

// "PC 원격제어"로 온 연결(2026-11-06): 브라우저 연동을 열지 않고 바로 전체 화면 공유 창을 연다.
// 그 창이 만든 번호는 확인된 통로(rhost.js 의 연결 방)로 연결한 쪽에만 보낸다. ticket → 세션 번호
// 배경이 잠들었다 깨어나도 알 수 있게 세션 저장소에도 둔다(브라우저를 다시 켜면 지워진다 — 되살아난 옛 공유 창은 무효)
const pcShares = new Map();
const PC_TICKETS = 'pcTickets';
async function rememberTicket(ticket) {
  const { [PC_TICKETS]: t = {} } = await chrome.storage.session.get(PC_TICKETS).catch(() => ({}));
  for (const [k, at] of Object.entries(t)) if (Date.now() - at > 10 * 60 * 1000) delete t[k];
  t[ticket] = Date.now();
  await chrome.storage.session.set({ [PC_TICKETS]: t }).catch(() => {});
}
/** 이 공유 창(remote.html?ticket)이 지금 받은 PC 원격제어 요청으로 연 것인가 */
export async function pcTicketValid(ticket) {
  if (!ticket) return false;
  if (pcShares.has(ticket) || ticket === live.pcTicket) return true;
  const { [PC_TICKETS]: t = {} } = await chrome.storage.session.get(PC_TICKETS).catch(() => ({}));
  return !!t[ticket] && Date.now() - t[ticket] < 10 * 60 * 1000;
}
async function openPcShare(ticket, sessionId) {
  pcShares.set(ticket, sessionId);
  setTimeout(() => pcShares.delete(ticket), 10 * 60 * 1000);
  await rememberTicket(ticket);
  await openShareFor(ticket);
}
// 화면 보내기 시작: 먼저 창 없이(보이지 않는 문서 안에서) 해 보고, 본체가 허락하지 않으면(옛 본체) 그 화면이
// 알려 와서(rhostPcWindow) 예전처럼 작은 창으로 연다. 한 번 안 되면 이 브라우저를 다시 켤 때까지 창 방식으로.
let bgShareOk = true;
async function openShareFor(ticket) {
  if (bgShareOk) {
    await deps.ensureOffscreen();
    const r = await chrome.runtime.sendMessage({ target: 'offscreen', type: 'rhost', cmd: 'pcShareStart', ticket }).catch(() => null);
    if (r?.ok) return;
  }
  openShareWindow(ticket);
}
function openShareWindow(ticket) {
  const url = chrome.runtime.getURL(`remote.html?ticket=${ticket}#share`);
  return chrome.windows.create({ url, type: 'popup', width: 720, height: 560, focused: true }).catch(() => chrome.tabs.create({ url, active: true }));
}

export async function handleRemoteHost(msg) {
  if (msg.type === 'rhostClaim') return accountRemoteClaim(msg.sessionId).catch(() => null);
  if (msg.type === 'rhostPcOpen') return openPcShare(String(msg.ticket || ''), msg.sessionId);
  if (msg.type === 'rhostPcWindow') { bgShareOk = false; return openShareWindow(String(msg.ticket || '')); }
  if (msg.type === 'rhostPcDone') { if (msg.sessionId) accountRemoteEnd(msg.sessionId); return true; }
  if (msg.type === 'rhostLive') return msg.on ? startHost(msg) : stopHost(msg);
  if (msg.type === 'rhostIn') return onInput(msg.ev);
  // 원격으로 보는 탭의 새 탭 카드(지난 대화 등) — 이 PC 가 아니라 보는 쪽 창 안 AI 창에서 연다
  if (msg.type === 'rhostPanelView') { if (live.on) out({ t: 'panelView', view: msg.view }); return live.on; }
  return undefined;
}

async function startHost({ name, sessionId, account }) {
  Object.assign(q, { level: 2, rate: 0, since: Date.now(), sent: 0, sentAt: Date.now() });
  let win = await chrome.windows.getLastFocused({ windowTypes: ['normal'] }).catch(() => null);
  // 브라우저 창을 다 닫고 뒤에서 기다리던 중이면(bg-mode.js) 보여 줄 창을 하나 연다
  if (!win) win = await chrome.windows.create({ type: 'normal', focused: false }).catch(() => null);
  Object.assign(live, { on: true, sessionId, name, windowId: win?.id ?? null });
  chrome.storage.session.set({ rhostLive: name || '다른 PC' }).catch(() => {}); // 도구 막대 원격 알약: 연결 받는 중
  const who = account ? `${name}(${account})` : name;
  chrome.notifications.create('knock-rhost', {
    type: 'basic', iconUrl: 'icons/icon128.png', requireInteraction: true, priority: 2,
    title: `🖥 ${who}이(가) 이 Knock Browser를 쓰는 중`,
    message: '브라우저 연동 · 이 창의 탭을 보고 조작해요. 마우스로 같이 눌러도 돼요.',
    buttons: [{ title: '연결 끊기' }],
  });
  chrome.action.setBadgeText({ text: '원격' });
  chrome.action.setBadgeBackgroundColor({ color: '#FF6A3D' });
  await sendTabs();
}

// 원격으로 보지 않게 된 탭은 파일 선택 창을 다시 그 PC 에 띄운다
function releaseChooser(tabId) {
  if (!tabId) return;
  deps.page.keepChooser?.delete(tabId);
  chrome.debugger.sendCommand({ tabId }, 'Page.setInterceptFileChooserDialog', { enabled: false }).catch(() => {});
}
async function stopHost({ note, sessionId }) {
  live.videoOk = false;
  live.chooser = null;
  releaseChooser(live.tabId);
  if (live.tabId) chrome.debugger.sendCommand({ tabId: live.tabId }, 'Page.stopScreencast').catch(() => {});
  unfit(live.tabId);
  if (sessionId) accountRemoteEnd(sessionId);
  clearInterval(live.secureTimer);
  clearTimeout(live.secureLeave);
  // 보안 사이트 때문에 최대화한 창은 원래 크기로
  for (const [id, b] of live.restoreWins || []) chrome.windows.update(id, b.state === 'normal' ? { state: 'normal', left: b.left, top: b.top, width: b.width, height: b.height } : { state: b.state }).catch(() => {});
  live.restoreWins = null;
  Object.assign(live, { on: false, sessionId: '', tabId: null, want: null, mode: '', meta: null, focus: null, secureTab: null, secureGeo: null, cleanTab: null, cleanNoted: null, forceClean: null, cleanGeo: null });
  clearPopups();
  for (const site of lnaOnce) forgetLocalSite(site).catch(() => {});
  lnaOnce.clear();
  lnaNo.clear();
  lnaAsk = null;
  chrome.storage.session.remove(['rhostLive', 'rhostTab']).catch(() => {});
  chrome.notifications.clear('knock-rhost');
  chrome.action.setBadgeText({ text: '' });
  if (note) chrome.notifications.create(`knock-rhost-end-${Date.now()}`, { type: 'basic', iconUrl: 'icons/icon128.png', title: '원격 연결이 끝났어요', message: note });
}

export function endHost(note) {
  return chrome.runtime.sendMessage({ target: 'offscreen', type: 'rhost', cmd: 'end', note }).catch(() => {});
}

async function windowTabs() {
  if (live.windowId != null && !(await chrome.windows.get(live.windowId).catch(() => null))) {
    const w = await chrome.windows.getLastFocused({ windowTypes: ['normal'] }).catch(() => null);
    live.windowId = w?.id ?? null;
  }
  return live.windowId == null ? [] : chrome.tabs.query({ windowId: live.windowId });
}

// 그 PC 의 북마크 줄(원격용 창에 같은 줄을 그린다 — 2026-11-05 "북마크가 사라졌어"). 폴더는 두 단계까지, 300개까지.
async function sendBookmarks() {
  const [root] = await chrome.bookmarks.getTree().catch(() => []);
  const bar = root?.children?.[0]?.children || [];
  let n = 0;
  const pack = (node, depth) => {
    if (n++ > 300) return null;
    if (node.url) return /^https?:/.test(node.url) ? { title: node.title || node.url, url: node.url } : null;
    return { title: node.title || '폴더', children: depth < 2 ? (node.children || []).map((c) => pack(c, depth + 1)).filter(Boolean) : [] };
  };
  out({ t: 'bookmarks', items: bar.map((x) => pack(x, 0)).filter(Boolean) });
}
const bookmarksChanged = () => { if (live.on) { clearTimeout(live.bmTimer); live.bmTimer = setTimeout(sendBookmarks, 500); } };
for (const ev of ['onCreated', 'onRemoved', 'onChanged', 'onMoved']) chrome.bookmarks?.[ev]?.addListener(bookmarksChanged);

// 기본 창 탭 + 팝업 창 탭(Knock 자체 창·설정 화면은 빼고) — 팝업은 따로 된 창이라 예전엔 보는 쪽에 안 보였다
const NOT_PAGE = /^(chrome|chrome-extension|devtools|chrome-untrusted):/;
async function allTabs() {
  const wins = await chrome.windows.getAll({ windowTypes: ['popup'], populate: true }).catch(() => []);
  // 팝업 창 크기도 함께(보는 쪽이 같은 크기의 창으로 띄운다)
  const pops = wins.flatMap((w) => (w.tabs || []).map((t) => ({ ...t, popup: true, ww: w.width, wh: w.height }))).filter((t) => !NOT_PAGE.test(t.url || t.pendingUrl || ''));
  return [...(await windowTabs()), ...pops];
}

// 원격으로 보는 사이트는 팝업을 막지 않는다(2026-11-08 "브라우저 연동 시 팝업 차단됨") — 이 PC 의 팝업 차단 알림은 보는 쪽에 안 보여
// 누를 수 없었다. 연결 동안만 열어 두고 끝나면 지운다(이 확장의 팝업 설정은 원격만 쓴다). 이미 허용된 사이트는 그대로 둔다.
const popupSites = new Set();
async function allowPopups(tabs) {
  const api = chrome.contentSettings?.popups;
  if (!api) return;
  for (const t of tabs) {
    const url = t.url || t.pendingUrl || '';
    const site = siteOf(url);
    if (!site || popupSites.has(site)) continue;
    popupSites.add(site);
    const cur = await api.get({ primaryUrl: url }).catch(() => null);
    if (cur?.setting !== 'allow') await api.set({ primaryPattern: `*://*.${site}/*`, setting: 'allow', scope: 'regular' }).catch(() => {});
  }
}
function clearPopups() {
  popupSites.clear();
  chrome.contentSettings?.popups?.clear({ scope: 'regular' }).catch(() => {});
}

async function sendTabs() {
  const tabs = await allTabs();
  allowPopups(tabs).catch(() => {});
  const active = tabs.find((t) => t.popup && t.id === live.focus) || tabs.find((t) => !t.popup && t.active);
  if (!tabs.some((t) => t.id === live.focus)) live.focus = null;
  out({ t: 'tabs', active: active?.id ?? null, list: tabs.map((t) => ({ id: t.id, title: t.title || t.url || '새 탭', url: t.url || t.pendingUrl || '', favIconUrl: /^https?:|^data:/.test(t.favIconUrl || '') ? t.favIconUrl : '', loading: t.status === 'loading', popup: !!t.popup, ...(t.popup ? { ww: t.ww, wh: t.wh } : {}) })) });
  if (active && active.id !== (live.want ?? live.tabId)) stream(active.id);
}

// 연결한 쪽 창 크기로 이 탭을 그린다(2026-11-05 "화면 일부가 잘려서 보여" — 이 PC 창이 작으면 넓은 사이트가 가로로 잘렸다).
// 연결이 끝나거나 다른 탭으로 옮기면 원래대로 돌린다. 화면 그림도 그 창의 점 수(레티나 2배)로 또렷하게 나온다.
function fitTo(tabId) {
  const { w, h } = live.view;
  const dpr = live.videoOk ? Math.min(live.view.dpr || 1, 2) : levelNow().dpr;
  return chrome.debugger.sendCommand({ tabId }, 'Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: dpr, mobile: false }).catch(() => {});
}
function unfit(tabId) {
  if (tabId) chrome.debugger.sendCommand({ tabId }, 'Emulation.clearDeviceMetricsOverride').catch(() => {});
}

// 영상으로 보내기 — 보는 쪽이 영상을 받을 수 있고(hello 의 video) 이 Knock Browser 가 탭 영상을 허락할 때만.
// 안 되면 예전처럼 사진(Page.startScreencast)으로 보낸다.
async function videoFor(tabId) {
  if (!live.videoOk) return false;
  try {
    const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
    const { w, h } = live.view;
    const dpr = Math.min(live.view.dpr || 1, 2);
    const r = await chrome.runtime.sendMessage({ target: 'offscreen', type: 'rhost', cmd: 'video', streamId, w: Math.round(w * dpr), h: Math.round(h * dpr) });
    if (!r?.ok) throw new Error(r?.error || '영상 실패');
    // 누르기 위치 계산용(사진 방식에서는 그림 정보에 왔다)
    live.meta = { deviceWidth: w, deviceHeight: h };
    live.mode = 'video';
    out({ t: 'mode', video: true });
    return true;
  } catch (err) {
    live.videoOk = false; // 이 연결에서는 사진으로
    live.mode = 'jpeg';
    out({ t: 'mode', video: false, why: err.message });
    return false;
  }
}

// 화면 보내기 시작은 한 번에 하나씩(2026-11-06 "원격지 브라우저 속도가 나빠졌어 · Screencast is already active") —
// 연결하자마자 두 번이 겹치면 두 번째가 탭 영상을 못 잡아(먼저 잡은 영상이 아직 있어서) 이 연결 내내 느린 사진 방식이 됐다.
let streamQ = Promise.resolve();
function stream(tabId) {
  live.want = tabId;
  streamQ = streamQ.then(() => (live.want === tabId ? doStream(tabId) : null)).catch(() => {});
  return streamQ;
}

async function doStream(tabId) {
  if (live.secureTab != null && live.secureTab !== tabId) { live.secureTab = null; clearInterval(live.secureTimer); } // 다른 탭으로 옮김 — 떼 둔 탭은 다시 볼 때 붙는다
  if (live.cleanTab !== tabId) live.cleanTab = null;
  if (live.tabId && live.tabId !== tabId) {
    releaseChooser(live.tabId);
    chrome.debugger.sendCommand({ tabId: live.tabId }, 'Page.stopScreencast').catch(() => {});
    unfit(live.tabId);
  }
  live.tabId = tabId;
  chrome.storage.session.set({ rhostTab: tabId }).catch(() => {}); // 새 탭 카드가 원격으로 보이는 탭인지 안다
  // 보안 사이트 탭은 디버거를 붙이지 않는다(윈도우 — 진짜 입력 도우미가 있을 때)
  if (IS_WIN && deps.toHost && (live.forceClean === tabId || (await cleanTab(await chrome.tabs.get(tabId).catch(() => null))))) {
    live.forceClean = null;
    return streamClean(tabId);
  }
  try {
    await deps.page.attach(tabId);
    // 파일 선택 창은 가로채 보는 쪽에서 고르게(위 Page.fileChooserOpened)
    deps.page.keepChooser?.add(tabId);
    chrome.debugger.sendCommand({ tabId }, 'Page.enable').catch(() => {});
    chrome.debugger.sendCommand({ tabId }, 'Page.setInterceptFileChooserDialog', { enabled: true }).catch(() => {});
    await fitTo(tabId);
    if (live.videoOk) await chrome.runtime.sendMessage({ target: 'offscreen', type: 'rhost', cmd: 'videoOff' }).catch(() => {}); // 같은 탭은 두 번 못 잡는다
    if (await videoFor(tabId)) {
      chrome.debugger.sendCommand({ tabId }, 'Page.stopScreencast').catch(() => {});
      const d = deps.page.dialog?.(tabId);
      out(d ? { t: 'dialog', type: d.type, message: String(d.message || '').slice(0, 2000), prompt: '' } : { t: 'dialog', closed: true });
      return;
    }
    // 이미 알림창이 떠 있는 탭이면 바로 알린다
    const d = deps.page.dialog?.(tabId);
    out(d ? { t: 'dialog', type: d.type, message: String(d.message || '').slice(0, 2000), prompt: '' } : { t: 'dialog', closed: true });
    await chrome.debugger.sendCommand({ tabId }, 'Page.stopScreencast').catch(() => {}); // 화질을 바꿀 때 — 켜진 채로 다시 켜면 오류
    await chrome.debugger.sendCommand({ tabId }, 'Page.startScreencast', (() => { const L = levelNow(); return { format: 'jpeg', quality: L.q, maxWidth: Math.round(live.view.w * L.dpr * L.scale), maxHeight: Math.round(live.view.h * L.dpr * L.scale), everyNthFrame: 1 }; })());
  } catch (err) {
    // 화면을 보낼 수 없는 탭(새 탭·설정 화면 등): 앞 탭의 영상·그림이 남아 은행 화면이 계속 보였다(2026-11-08) — 끄고 보는 쪽 화면을 비운다
    if (live.mode === 'video') chrome.runtime.sendMessage({ target: 'offscreen', type: 'rhost', cmd: 'videoOff' }).catch(() => {});
    out({ t: 'blank', tabId, text: /chrome:|chrome-extension:|webstore/.test(err.message) ? '이 탭(새 탭·설정 화면 등)은 보안상 화면을 보낼 수 없어요. 주소창에 주소를 넣거나 다른 탭을 고르세요.' : `화면을 보내지 못했어요: ${err.message}` });
  }
}

const KEYS = { Enter: 13, Backspace: 8, Tab: 9, Escape: 27, ArrowLeft: 37, ArrowUp: 38, ArrowRight: 39, ArrowDown: 40, Delete: 46, Home: 36, End: 35, PageUp: 33, PageDown: 34, ' ': 32 };
const toUrl = (s) => {
  const v = String(s || '').trim();
  if (/^[a-z]+:\/\//i.test(v)) return v;
  if (/^[^\s]+\.[^\s]{2,}(\/\S*)?$/.test(v)) return `https://${v}`;
  return `https://search.naver.com/search.naver?query=${encodeURIComponent(v)}`;
};

// 은행 비밀번호 칸(키보드 보안)은 브라우저 안으로 넣은 글자를 받지 않는다(2026-11-08 "비밀번호를 입력했는데 미입력이래") —
// 그 칸에 있을 때만 이 PC(윈도우)의 키보드 입력으로 보낸다(도우미 input-win.js 의 SendInput, 화면 키 번호 그대로).
const IS_WIN = /Windows/.test(navigator.userAgent);
const SHIFTED = { '!': 'Digit1', '@': 'Digit2', '#': 'Digit3', $: 'Digit4', '%': 'Digit5', '^': 'Digit6', '&': 'Digit7', '*': 'Digit8', '(': 'Digit9', ')': 'Digit0', _: 'Minus', '+': 'Equal', '{': 'BracketLeft', '}': 'BracketRight', '|': 'Backslash', ':': 'Semicolon', '"': 'Quote', '<': 'Comma', '>': 'Period', '?': 'Slash', '~': 'Backquote' };
const PLAIN = { '-': 'Minus', '=': 'Equal', '[': 'BracketLeft', ']': 'BracketRight', '\\': 'Backslash', ';': 'Semicolon', "'": 'Quote', ',': 'Comma', '.': 'Period', '/': 'Slash', '`': 'Backquote', ' ': 'Space' };
function keyOf(c) {
  if (/[0-9]/.test(c)) return { code: `Digit${c}` };
  if (/[a-z]/.test(c)) return { code: `Key${c.toUpperCase()}` };
  if (/[A-Z]/.test(c)) return { code: `Key${c}`, shift: true };
  if (PLAIN[c]) return { code: PLAIN[c] };
  if (SHIFTED[c]) return { code: SHIFTED[c], shift: true };
  return null;
}
// 지금 글자가 들어갈 칸이 비밀번호 칸인지(같은 출처 iframe 안까지)
const SECURE_PROBE = `(() => { let d = document, a = d.activeElement;
  for (let i = 0; i < 5 && a; i++) {
    if (a.shadowRoot?.activeElement) { a = a.shadowRoot.activeElement; continue; }
    if (/^(IFRAME|FRAME)$/.test(a.tagName)) { try { d = a.contentDocument; a = d && d.activeElement; continue; } catch { return false; } }
    break;
  }
  return !!a && a.tagName === 'INPUT' && a.type === 'password'; })()`;
const ACTIVE_PROBE = `(() => { let d = document, a = d.activeElement;
  for (let i = 0; i < 5 && a; i++) {
    if (a.shadowRoot?.activeElement) { a = a.shadowRoot.activeElement; continue; }
    if (/^(IFRAME|FRAME)$/.test(a.tagName)) { try { d = a.contentDocument; a = d && d.activeElement; continue; } catch { return 'cross-origin frame'; } }
    break;
  }
  return a ? [a.tagName, a.type || '', a.id || a.name || ''].join(' ') : 'none'; })()`;
async function secureField(tabId) {
  if (!IS_WIN || !deps.toHost || !tabId) return false;
  const r = await chrome.debugger.sendCommand({ tabId }, 'Runtime.evaluate', { expression: SECURE_PROBE, returnByValue: true }).catch(() => null);
  return r?.result?.value === true;
}
async function osKeys(tabId, list) {
  // 윈도우 키 입력은 맨 앞 창으로만 간다 — 이 탭의 창을 맨 앞으로 올린 뒤(브라우저 연동은 화면을 누른 게 아니라 창이 뒤에 있을 수 있다),
  // 사람이 치는 것처럼 키 하나씩 조금씩 쉬며 보낸다(한꺼번에 보내면 키보드 보안이 버렸다, 2026-11-08 "PC 원격제어에서는 돼")
  // 키 누름 시간도 사람처럼(누른 채 80~120ms, 뗀 뒤 50~90ms) — PC 원격제어는 사람이 누른 그대로였고 우리는 25ms 였다(2026-11-08).
  // 창을 맨 앞으로 올리던 focus 는 뺐다(진짜 마우스로 누르면 그 창이 이미 맨 앞이고, PC 원격제어에는 없는 동작이다)
  deps.toHost({ type: 'remoteInput', ev: { t: 'diag', text: `키 ${list.filter((e) => e.down && !/^Shift/.test(e.code)).length}개 보냄` } });
  for (const ev of list) {
    deps.toHost({ type: 'remoteInput', ev });
    deps.toHost({ type: 'remoteInput', ev: { t: 'wait', ms: ev.t === 'key' && ev.down ? 80 + Math.round(Math.random() * 40) : 50 + Math.round(Math.random() * 40) } });
  }
}
function osText(text) {
  const out = [];
  for (const c of text) {
    const k = keyOf(c);
    if (!k) return null; // 키보드로 칠 수 없는 글자(한글 등)가 섞이면 예전 방식으로
    if (k.shift) out.push({ t: 'key', code: 'ShiftLeft', down: true });
    out.push({ t: 'key', code: k.code, down: true }, { t: 'key', code: k.code, down: false });
    if (k.shift) out.push({ t: 'key', code: 'ShiftLeft', down: false });
  }
  return out;
}
// 비밀번호 칸을 원격으로 누르면 이 PC 의 진짜 마우스로도 한 번 눌러 둔다 — PC 원격제어(진짜 마우스·키)에서는 키보드 보안이
// 받아 주고 브라우저 연동에서는 "미입력"이었다(2026-11-08). 화면 맞춤(Emulation)을 잠깐 풀어야 실제 화면 자리가 나온다.
const pause = (ms) => new Promise((r) => setTimeout(r, ms));
let realClicking = false;
// 비밀번호 칸(2026-11-08 기록: 칸 인식·진짜 마우스·키 보내기·맨 앞 창 모두 맞는데 "미입력"): PC 원격제어와 남은 차이는
// 이 탭에 붙은 디버거(화면 맞춤·화면 보내기)다. 은행 보안 프로그램이 이를 보고 키를 받지 않는 것으로 보여, 비밀번호를 치는 동안은
// 디버거를 떼고(영상으로 보내는 중이면 화면은 그대로 보인다) 다른 곳을 누르면 다시 붙인다.
// 탭 안 자리 재기 — 디버거를 뗀 뒤 chrome.scripting 으로(디버거·화면 맞춤이 없는 실제 크기). 지금 칸의 자리와 탭 화면의 실제 자리·크기(CSS 점)
// (2026-11-08 기록: 화면 맞춤을 푼 직후 디버거로 재니 맞춤 크기가 나와 진짜 마우스가 화면 밖 2747,1648 을 눌렀다)
function geoProbe() {
  let d = document, a = d.activeElement, ox = 0, oy = 0;
  for (let i = 0; i < 5 && a; i++) {
    if (a.shadowRoot?.activeElement) { a = a.shadowRoot.activeElement; continue; }
    if (/^(IFRAME|FRAME)$/.test(a.tagName)) { const f = a.getBoundingClientRect(); ox += f.left; oy += f.top; try { d = a.contentDocument; a = d && d.activeElement; continue; } catch { break; } }
    break;
  }
  const bx = (outerWidth - innerWidth) / 2;
  const cx = screenX + bx, cy = screenY + outerHeight - innerHeight - bx;
  const r = a && a.getBoundingClientRect();
  // 키보드 보안이 디버거가 붙어 있던 때 칸에 들어간(포커스) 상태를 기억할 수 있어, 칸을 비우고 포커스를 뺀다 — 뒤에 진짜 마우스로 다시 눌러
  // 디버거 없는 상태에서 새로 포커스를 받게 한다(2026-11-08: 진짜 키·진짜 [확인]까지 했는데도 "미입력")
  let fresh = false;
  if (a && a.tagName === 'INPUT' && a.type === 'password') { try { a.value = ''; a.blur(); fresh = true; } catch {} }
  const sec = Object.keys(window).filter((k) => /npp|npk|nos|transkey|raon|touchen|kings|astx|veraport/i.test(k)).slice(0, 8).join(',');
  return { cx, cy, iw: innerWidth, ih: innerHeight, dpr: devicePixelRatio, password: !!a && a.tagName === 'INPUT' && a.type === 'password', fresh, sec,
    fx: r ? cx + ox + r.left + Math.min(r.width / 2, 24) : null, fy: r ? cy + oy + r.top + r.height / 2 : null };
}
const diag = (text) => deps.toHost?.({ type: 'remoteInput', ev: { t: 'diag', text } });
async function realClick(tabId) {
  if (realClicking) return;
  realClicking = true;
  try {
    // 화면 보내기를 멈추고 화면 맞춤을 풀고 디버거를 뗀다
    releaseChooser(tabId);
    await chrome.debugger.sendCommand({ tabId }, 'Page.stopScreencast').catch(() => {});
    await chrome.debugger.sendCommand({ tabId }, 'Emulation.clearDeviceMetricsOverride').catch(() => {});
    await deps.page.detach(tabId);
    live.secureTab = tabId;
    await pause(300);
    const [res] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: geoProbe }).catch(() => []);
    const g = res?.result;
    if (!g?.iw) { diag('자리를 재지 못함'); await leaveSecure(); return; }
    live.secureGeo = g;
    secureFrames(tabId);
    out({ t: 'note', text: '비밀번호 칸: 보안 프로그램이 받을 수 있게 진짜 키보드·마우스로 바꿨어요(화면이 조금 느려요). [확인]까지 누르면 잠시 뒤 원래대로 돌아와요.' });
    const t = await chrome.tabs.get(tabId).catch(() => null);
    if (g.fx != null) deps.toHost({ type: 'remoteInput', ev: { t: 'clickPx', x: Math.round(g.fx * g.dpr), y: Math.round(g.fy * g.dpr) } });
    if (g.sec) learnSecure(t?.url); // 키보드 보안이 있는 사이트 — 다음부터 처음부터 디버거 없이
    diag(`디버거 뗌 · 탭 화면 ${Math.round(g.cx)},${Math.round(g.cy)} ${g.iw}x${g.ih} 배율 ${g.dpr} · 비밀번호 칸 ${g.password} · 새로 누름 ${g.fresh} · 보안 ${g.sec || '없음'}`);
  } finally {
    realClicking = false;
  }
}
// 비밀번호 칸을 떠나면(다른 곳을 누르거나 다른 탭으로) 디버거를 다시 붙여 보내기를 잇는다
// 디버거 없이 화면 보내기: 보이는 탭 사진(1초에 2장까지) — 사진 연결일 때만(영상 연결은 그대로 이어진다)
function secureFrames(tabId) {
  clearInterval(live.secureTimer);
  if (live.mode === 'video') return;
  live.secureTimer = setInterval(async () => {
    if (live.secureTab !== tabId || !live.on) return clearInterval(live.secureTimer);
    const t = await chrome.tabs.get(tabId).catch(() => null);
    const url = t && await chrome.tabs.captureVisibleTab(t.windowId, { format: 'jpeg', quality: 70 }).catch(() => null);
    if (url && live.secureTab === tabId) outFrame({ t: 'frame', tabId, data: url.replace(/^data:image\/jpeg;base64,/, ''), w: live.secureGeo?.iw || live.view.w, h: live.secureGeo?.ih || live.view.h }).catch(() => {});
  }, 600);
}
// 비밀번호를 치는 동안의 누르기: 그 PC 의 진짜 마우스로(화면 사진의 자리 → 실제 화면 점)
// 누른 자리를 실제 화면 점으로 — 누를 때마다 디버거 없이(chrome.scripting) 창·탭 화면 자리를 새로 잰다(창을 옮겨도 맞게).
// 단추인지도 함께 본다(그때만 은행이 비밀번호를 가져간 뒤 원래대로 돌아간다 — 스크롤바를 눌러도 돌아가 버렸다, 2026-11-08)
function pointInfo(nx, ny) {
  const bx = (outerWidth - innerWidth) / 2;
  const cx = screenX + bx, cy = screenY + outerHeight - innerHeight - bx;
  const x = nx * innerWidth, y = ny * innerHeight;
  const el = document.elementFromPoint(x, y);
  const kind = el?.closest('button,a,input[type=submit],input[type=button],input[type=image],[role=button],[onclick]') ? 'button' : el?.closest('input,textarea,select') ? 'field' : 'other';
  return { px: Math.round((cx + x) * devicePixelRatio), py: Math.round((cy + y) * devicePixelRatio), kind, geo: { cx, cy, iw: innerWidth, ih: innerHeight, dpr: devicePixelRatio } };
}
// 스크롤은 페이지 안에서(디버거 없이) — 그 자리의 스크롤되는 칸을 굴린다
function scrollAt(nx, ny, dx, dy) {
  let el = document.elementFromPoint(nx * innerWidth, ny * innerHeight);
  while (el && el !== document.documentElement && el !== document.body) {
    const st = getComputedStyle(el);
    if (/(auto|scroll)/.test(st.overflowY + st.overflowX) && (el.scrollHeight > el.clientHeight || el.scrollWidth > el.clientWidth)) { el.scrollBy(dx, dy); return; }
    el = el.parentElement;
  }
  window.scrollBy(dx, dy);
}
const norm = (v) => Math.min(Math.max(Number(v) || 0, 0), 1);
// 탭 영상(tabCapture)은 보는 쪽 창 비율의 틀 안에 페이지를 맞춰 넣어 위아래나 양옆에 검은 띠가 생긴다 — 보는 쪽 자리(틀 기준)를
// 페이지 기준으로 바꾼다(2026-11-08 이든치과: 금융인증서에 올렸는데 사고신고 근처로 갔다). 사진(captureVisibleTab)은 띠가 없다
function pageXY(ev, g) {
  let nx = norm(ev.x), ny = norm(ev.y);
  if (live.mode === 'video' && g?.iw && g?.ih) {
    const W = live.view.w, H = live.view.h;
    const k = Math.min(W / g.iw, H / g.ih);
    const cw = g.iw * k, ch = g.ih * k;
    nx = norm((nx * W - (W - cw) / 2) / cw);
    ny = norm((ny * H - (H - ch) / 2) / ch);
  }
  return { nx, ny };
}
// 창 자리·크기는 1초마다 새로 잰다(최대화가 끝나기 전이나 창을 옮긴 뒤 옛 값으로 계산하지 않게)
async function freshGeo(tabId) {
  if (live.cleanGeo && Date.now() - (live.cleanGeoAt || 0) < 1000) return live.cleanGeo;
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: 'ISOLATED', func: pointInfo, args: [0, 0] }).catch(() => []);
  if (r?.result?.geo) { live.cleanGeo = r.result.geo; live.cleanGeoAt = Date.now(); }
  return live.cleanGeo;
}
async function secureClick(ev, tabId) {
  const { nx, ny } = pageXY(ev, await freshGeo(tabId));
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: 'ISOLATED', func: pointInfo, args: [nx, ny] }).catch(() => []);
  const p = r?.result;
  if (!p) return diag('누를 자리를 재지 못함');
  live.cleanGeo = p.geo;
  live.cleanGeoAt = Date.now();
  deps.toHost({ type: 'remoteInput', ev: { t: 'clickPx', x: p.px, y: p.py } });
  if (p.kind === 'button') { const n = (await chrome.debugger.getTargets().catch(() => [])).filter((x) => x.attached && x.tabId != null).length; diag(`누름 button · 디버거 붙은 탭 ${n}개 · 화면 ${live.mode}`); }
  else diag(`누름 ${p.kind}`);
  // 비밀번호 칸만 잠깐 바꾼 탭: [확인] 같은 단추면 은행이 비밀번호를 가져갈 시간을 주고 3초 뒤 원래대로 돌아온다(보안 사이트 탭은 계속 이 방식)
  if (p.kind === 'button' && live.cleanTab !== tabId) { clearTimeout(live.secureLeave); live.secureLeave = setTimeout(() => leaveSecure(), 3000); }
}
// 마우스 움직임(메뉴가 마우스를 올려야 열리는 사이트): 마지막으로 잰 자리로 계산해 1초에 10번까지 진짜 마우스를 옮긴다
async function secureMove(ev, tabId) {
  if (Date.now() - (live.moveAt || 0) < 100) return;
  live.moveAt = Date.now();
  const g = await freshGeo(tabId);
  if (!g) return;
  const { nx, ny } = pageXY(ev, g);
  deps.toHost({ type: 'remoteInput', ev: { t: 'movePx', x: Math.round((g.cx + nx * g.iw) * g.dpr), y: Math.round((g.cy + ny * g.ih) * g.dpr) } });
}
async function secureWheel(ev, tabId) {
  const { nx, ny } = pageXY(ev, await freshGeo(tabId));
  chrome.scripting.executeScript({ target: { tabId }, world: 'ISOLATED', func: scrollAt, args: [nx, ny, Number(ev.dx) || 0, Number(ev.dy) || 0] }).catch(() => {});
}

// ---- 보안 사이트(은행 등): 디버거를 아예 붙이지 않는다(2026-11-08) ----
// 광주은행: 페이지가 디버거가 붙은 채 열리면, 나중에 떼고 진짜 키·진짜 [확인]을 해도 "미입력"이었다. 그래서 그 사이트의 메인 탭과 팝업은
// 처음부터 디버거 없이 — 화면은 탭 영상(안 되면 보이는 탭 사진), 누르기·글자·키는 그 PC 의 진짜 마우스·키보드, 스크롤은 페이지 안에서.
// 비밀번호 보안 칸을 본 사이트는 기억해 다음부터 처음부터 이 방식으로 연다.
const SECURE_DEFAULT = ['kjbank.com'];
const secureSites = new Set(SECURE_DEFAULT);
chrome.storage.local.get('secureSites').then(({ secureSites: list }) => { for (const x of list || []) secureSites.add(x); }).catch(() => {});
function isSecureUrl(url) {
  const h = siteOf(url || '');
  return !!h && [...secureSites].some((x) => h === x || h.endsWith(`.${x}`));
}
async function cleanTab(t) {
  if (!t) return false;
  if (isSecureUrl(t.pendingUrl || t.url)) return true;
  // 은행 페이지가 연 팝업(처음엔 about:blank 일 수 있다)
  const o = t.openerTabId != null ? await chrome.tabs.get(t.openerTabId).catch(() => null) : null;
  return !!o && isSecureUrl(o.url);
}
function learnSecure(url) {
  const h = siteOf(url || '');
  if (!h || isSecureUrl(url)) return;
  secureSites.add(h);
  chrome.storage.local.set({ secureSites: [...secureSites].filter((x) => !SECURE_DEFAULT.includes(x)) }).catch(() => {});
}
async function detachOthers(keep) {
  const list = (await chrome.debugger.getTargets().catch(() => [])).filter((x) => x.attached && x.tabId != null && x.tabId !== keep);
  for (const x of list) await deps.page.detach(x.tabId);
  return list.length;
}
async function streamClean(tabId) {
  clearInterval(live.secureTimer);
  releaseChooser(tabId);
  await chrome.debugger.sendCommand({ tabId }, 'Page.stopScreencast').catch(() => {});
  await chrome.debugger.sendCommand({ tabId }, 'Emulation.clearDeviceMetricsOverride').catch(() => {});
  await deps.page.detach(tabId);
  live.secureTab = tabId;
  live.cleanTab = tabId;
  // 같은 브라우저의 다른 탭에 붙은 디버거도 뗀다 — PC 원격제어(조회 성공) 때는 어디에도 붙어 있지 않았다(2026-11-08)
  const others = await detachOthers(tabId);
  // 화면 맞춤(Emulation)을 못 쓰니 그 PC 의 실제 창 크기 그대로 보인다 — 창이 작으면 페이지가 잘려 보였다(2026-11-08 이든치과 노트북).
  // 보는 동안 그 창을 최대화하고, 연결이 끝나면 원래 크기로 돌려 둔다(팝업 창은 은행이 정한 크기 그대로)
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  const win = tab && await chrome.windows.get(tab.windowId).catch(() => null);
  if (win?.type === 'normal' && win.state !== 'maximized' && win.state !== 'fullscreen') {
    if (!live.restoreWins) live.restoreWins = new Map();
    if (!live.restoreWins.has(win.id)) live.restoreWins.set(win.id, { state: win.state, left: win.left, top: win.top, width: win.width, height: win.height });
    await chrome.windows.update(win.id, { state: 'maximized' }).catch(() => {});
    await pause(300);
  }
  const [g] = await chrome.scripting.executeScript({ target: { tabId }, world: 'ISOLATED', func: pointInfo, args: [0, 0] }).catch(() => []);
  live.cleanGeo = g?.result?.geo || null;
  if (live.videoOk) await chrome.runtime.sendMessage({ target: 'offscreen', type: 'rhost', cmd: 'videoOff' }).catch(() => {});
  if (!(await videoFor(tabId))) secureFrames(tabId);
  out({ t: 'dialog', closed: true });
  diag(`보안 사이트: 디버거 없이 보냄 · 다른 탭에서 뗀 디버거 ${others}개 · 화면 ${live.mode}`);
  if (live.cleanNoted !== tabId) {
    live.cleanNoted = tabId;
    out({ t: 'note', text: '보안 사이트(은행 등)라 보안 프로그램이 받을 수 있게 그 PC 의 진짜 마우스·키보드로 조작해요. 화면이 조금 느릴 수 있어요.' });
  }
}
async function leaveSecure() {
  const tabId = live.secureTab;
  if (tabId == null) return;
  live.secureTab = null;
  clearInterval(live.secureTimer);
  clearTimeout(live.secureLeave);
  if (live.on && live.tabId === tabId) { live.tabId = null; await stream(tabId); }
}
const OS_KEYS = new Set(['Backspace', 'Delete', 'Enter', 'Tab', 'ArrowLeft', 'ArrowRight', 'Home', 'End']);

async function onInput(ev) {
  if (!live.on || !ev) return;
  const tabId = live.tabId;
  const send = (method, params) => (tabId ? chrome.debugger.sendCommand({ tabId }, method, params).catch(() => {}) : null);
  const px = (v, max) => Math.min(Math.max(Number(v) || 0, 0), 1) * (max || 0);
  const w = live.meta?.deviceWidth || 0;
  const h = live.meta?.deviceHeight || 0;
  const mods = (Number(ev.mods) || 0) & 15;
  switch (ev.t) {
    case 'hello':
    case 'size':
      // w·h: 연결한 쪽 화면 칸 크기(CSS 점), dpr: 그 화면의 점 배율(옛 판은 dpr 없이 실제 점 수를 보냈다)
      if (ev.t === 'hello') live.videoOk = ev.video === true;
      live.view = {
        w: Math.min(Math.max(Math.round(Number(ev.w) || 1280), 320), 3840),
        h: Math.min(Math.max(Math.round(Number(ev.h) || 800), 240), 2400),
        dpr: Math.min(Math.max(Number(ev.dpr) || 1, 1), 2),
      };
      if (ev.t === 'hello') { const had = live.want; sendBookmarks().catch(() => {}); await sendTabs().catch(() => {}); if (had && live.want === had) stream(had); } // 받은 창 크기로 다시 찍기(sendTabs 가 막 시작했으면 또 하지 않는다)
      else if (tabId) stream(tabId);
      return;
    case 'getBookmarks':
      sendBookmarks();
      return;
    case 'select': {
      const t = (await allTabs()).find((x) => x.id === ev.tabId);
      if (!t) return;
      live.focus = t.popup ? t.id : null;
      if (t.popup) chrome.windows.update(t.windowId, { focused: true }).catch(() => {});
      else await chrome.tabs.update(t.id, { active: true });
      await sendTabs();
      return;
    }
    case 'newtab':
      if (live.windowId == null) await windowTabs(); // 보던 창이 닫혔으면 다른 창을 찾는다
      if (live.windowId != null) await chrome.tabs.create({ windowId: live.windowId, url: ev.url ? toUrl(ev.url) : undefined, active: true });
      else { const w = await chrome.windows.create({ url: ev.url ? toUrl(ev.url) : undefined, focused: false }).catch(() => null); live.windowId = w?.id ?? null; sendTabs(); } // 창이 하나도 없으면 새 창
      return;
    case 'close': {
      const all = await allTabs();
      const t = all.find((x) => x.id === ev.tabId);
      if (!t) return;
      // 마지막 탭을 닫으면 창까지 닫혀 보는 쪽에 옛 화면만 남았다(2026-11-08) — 새 탭을 먼저 열어 창을 남긴다
      if (!t.popup && live.windowId != null && all.filter((x) => !x.popup).length === 1) await chrome.tabs.create({ windowId: live.windowId, active: true }).catch(() => {});
      await chrome.tabs.remove(ev.tabId).catch(() => {});
      return;
    }
    case 'nav': {
      if (!tabId) return;
      const url = toUrl(ev.url);
      // 보안 사이트로 가면 화면 맞춤 해제·디버거 떼기를 먼저 끝내고 이동한다(은행 페이지가 열린 뒤 떼면 늦다 — 2026-11-08 검토)
      if (IS_WIN && deps.toHost && live.cleanTab !== tabId && isSecureUrl(url)) { live.forceClean = tabId; live.tabId = null; await stream(tabId); }
      await chrome.tabs.update(tabId, { url });
      return;
    }
    case 'back': if (tabId) chrome.tabs.goBack(tabId).catch(() => {}); return;
    case 'forward': if (tabId) chrome.tabs.goForward(tabId).catch(() => {}); return;
    case 'reload': if (tabId) chrome.tabs.reload(tabId); return;
    case 'mouse': {
      const type = { down: 'mousePressed', up: 'mouseReleased', move: 'mouseMoved', wheel: 'mouseWheel' }[ev.kind];
      if (!type) return;
      if (live.secureTab != null) {
        // 비밀번호를 치는 동안은 진짜 마우스로 누르고, 휠은 페이지 안에서 굴린다(움직임은 보내지 않는다)
        if (ev.kind === 'up' && (ev.button || 0) === 0) await secureClick(ev, live.secureTab);
        else if (ev.kind === 'wheel') secureWheel(ev, live.secureTab);
        else if (ev.kind === 'move' && live.cleanTab === live.secureTab) secureMove(ev, live.secureTab);
        return;
      }
      const button = ev.kind === 'move' || ev.kind === 'wheel' ? 'none' : ev.button === 2 ? 'right' : ev.button === 1 ? 'middle' : 'left';
      await send('Input.dispatchMouseEvent', { type, x: px(ev.x, w), y: px(ev.y, h), button, clickCount: ev.kind === 'move' ? 0 : Math.min(Number(ev.clicks) || 1, 3), modifiers: mods, deltaX: Number(ev.dx) || 0, deltaY: Number(ev.dy) || 0 });
      if (ev.kind === 'up' && button === 'left') {
        // 비밀번호 칸인지 보고 바꾸는 동안 온 글자는 기다렸다가 보낸다(첫 글자가 디버거를 떼기 전에 들어갔다 — 2026-11-08 기록)
        let done;
        live.secureReady = new Promise((r) => { done = r; });
        try { if (await secureField(tabId)) await realClick(tabId); } finally { done(); live.secureReady = null; }
      }
      return;
    }
    case 'text': {
      if (live.secureReady) await live.secureReady;
      const text = String(ev.text || '').slice(0, 2000);
      if (live.secureTab === tabId) return osKeys(tabId, osText(text) || [{ t: 'text', text }]); // 키보드로 칠 수 없는 글자(한글 등)는 글자 입력으로
      const secure = await secureField(tabId);
      const keys = secure && osText(text);
      if (keys) return osKeys(tabId, keys);
      // 시험 기록: 비밀번호 칸으로 보지 않았을 때 지금 칸이 무엇인지(5초에 한 번, 글자는 남기지 않는다)
      if (IS_WIN && deps.toHost && Date.now() - (live.diagAt || 0) > 5000) {
        live.diagAt = Date.now();
        const r = await chrome.debugger.sendCommand({ tabId }, 'Runtime.evaluate', { expression: ACTIVE_PROBE, returnByValue: true }).catch(() => null);
        deps.toHost({ type: 'remoteInput', ev: { t: 'diag', text: `${secure ? '비밀번호 칸이지만 키로 못 바꾸는 글자' : '보통 칸으로 넣음'}: ${String(r?.result?.value || '?').slice(0, 80)}` } });
      }
      return send('Input.insertText', { text });
    }
    case 'key': {
      if (live.secureReady) await live.secureReady;
      if (live.secureTab === tabId) {
        const code = String(ev.code || '').slice(0, 20);
        if (ev.code === 'Enter' && ev.down && live.cleanTab !== tabId) { clearTimeout(live.secureLeave); live.secureLeave = setTimeout(() => leaveSecure(), 3000); } // Enter 로 보냈을 때도 3초 뒤 원래대로
        if (!mods) return osKeys(tabId, [{ t: 'key', code, down: !!ev.down }]);
        // 단축키(⌘·Ctrl → Ctrl, Shift, Alt): 누를 때 한 번에 눌렀다 뗀다
        if (!ev.down) return;
        const wrap = [mods & 6 ? 'ControlLeft' : '', mods & 8 ? 'ShiftLeft' : '', mods & 1 ? 'AltLeft' : ''].filter(Boolean);
        return osKeys(tabId, [...wrap.map((c) => ({ t: 'key', code: c, down: true })), { t: 'key', code, down: true }, { t: 'key', code, down: false }, ...wrap.reverse().map((c) => ({ t: 'key', code: c, down: false }))]);
      }
      if (!mods && OS_KEYS.has(String(ev.code || '')) && (await secureField(tabId))) return osKeys(tabId, [{ t: 'key', code: ev.code, down: !!ev.down }]);
      const key = String(ev.key || '').slice(0, 20);
      const code = String(ev.code || '').slice(0, 20);
      const vk = KEYS[key] || (key.length === 1 ? key.toUpperCase().charCodeAt(0) : 0);
      const type = ev.down ? 'rawKeyDown' : 'keyUp';
      await send('Input.dispatchKeyEvent', { type, key, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk, modifiers: mods });
      // Enter 같은 키는 글자 입력도 함께(폼 보내기·줄바꿈)
      if (ev.down && key === 'Enter') await send('Input.dispatchKeyEvent', { type: 'char', key, text: '\r', unmodifiedText: '\r', modifiers: mods });
      return;
    }
    case 'ai': {
      // 연결한 쪽 AI 가 이 PC 의 탭을 읽고 조작한다(다른 프로필이 묻는 것과 같은 답 — 이 PC 의 멈춤·막은 사이트를 지킨다)
      const op = ['listTabs', 'tabInfo', 'raw', 'toksori'].includes(ev.op) ? ev.op : null;
      let result = null;
      if (op && deps.answer) {
        try { result = await deps.answer(op, ev.args || {}); } catch (err) { result = { error: err.message }; }
      }
      out({ t: 'aiRes', id: ev.id, result });
      return;
    }
    case 'dialog':
      if (tabId) await deps.page.answerDialog(tabId, Boolean(ev.accept), ev.text != null ? String(ev.text).slice(0, 2000) : undefined).catch(() => {});
      return;
    // 보는 쪽에서 고른 파일: 조각을 이 PC 임시 칸에 쓰고, 다 오면 가로챈 선택 창 자리에 넣는다
    case 'fileData': {
      const c = live.chooser;
      if (!c) return;
      const cur = c.files[ev.i] || (c.files[ev.i] = { file: '' });
      const r = await deps.askHost('saveUploadChunk', { file: cur.file, name: String(ev.name || 'file'), b64: ev.b64 || '' }).catch((err) => ({ error: err.message }));
      if (r.error) { out({ t: 'note', text: `파일을 넣지 못했어요: ${r.error}` }); live.chooser = null; return; }
      cur.file = r.file;
      out({ t: 'fileAck', i: ev.i, seq: ev.seq });
      return;
    }
    case 'fileDone': {
      const c = live.chooser;
      live.chooser = null;
      if (!c || ev.cancel || !c.files.length) return;
      await chrome.debugger.sendCommand({ tabId: c.tabId }, 'DOM.setFileInputFiles', { files: c.files.map((f) => f.file), backendNodeId: c.backendNodeId })
        .then(() => out({ t: 'note', text: `파일 ${c.files.length}개를 넣었어요.` }))
        .catch((err) => out({ t: 'note', text: `파일을 넣지 못했어요: ${err.message}` }));
      return;
    }
    case 'pcRemote': {
      // PC 원격제어로 바꾸기: 이 PC 에 [이 PC 화면 보여 주기] 화면을 연다(화면 고르기는 이 PC 사람이 한 번 눌러야 한다)
      live.pcTicket = crypto.randomUUID();
      await rememberTicket(live.pcTicket);
      await openShareFor(live.pcTicket);
      out({ t: 'note', text: '그 PC 에 "이 PC 화면 보여 주기" 화면을 띄웠어요. 그 PC 에서 단추를 누르고 화면을 고르면 바로 이어져요.' });
      return;
    }
    case 'allowSite': {
      // 보는 탭의 사이트를 이 PC 에서 묻지 않고 허용하고, 떠 있던 권한 창이 사라지게 다시 읽는다
      if (!localSitesSupported()) return out({ t: 'note', text: '그 PC 의 Knock Browser 를 업데이트해야 쓸 수 있어요.' });
      const tab = tabId ? await chrome.tabs.get(tabId).catch(() => null) : null;
      const r = await addLocalSite(tab?.url || '');
      if (r.error) return out({ t: 'note', text: r.error });
      out({ t: 'note', text: `이제 ${r.site} 에서는 권한 창 없이 허용해요. 페이지를 다시 읽어요.` });
      if (tabId) chrome.tabs.reload(tabId);
      return;
    }
    case 'localAnswer':
      return answerLocal(ev);
    case 'bye':
      return endHost('상대가 연결을 끊었어요.');
    default:
  }
}

/** 이 PC 의 원격 화면(remote.html?ticket)이 번호를 만들었다 — 연결한 쪽에 보낸다 */
export function pcRemoteCode({ ticket, code }) {
  if (ticket && pcShares.has(ticket) && /^\d{9}$/.test(String(code))) {
    chrome.runtime.sendMessage({ target: 'offscreen', type: 'rhost', cmd: 'pcCode', ticket, code: String(code) }).catch(() => {});
    return true;
  }
  if (!live.on || !ticket || ticket !== live.pcTicket || !/^\d{9}$/.test(String(code))) return false;
  out({ t: 'pcCode', ticket, code: String(code) });
  return true;
}
