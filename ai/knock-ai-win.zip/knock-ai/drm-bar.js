// 보호 영상 재생이 막혔을 때 맨 위 띠: "크롬에서 열기 · 엣지에서 열기"(2026-11-10).
// drm-watch.js(페이지 안)가 알리면 백그라운드에 넘기고, 백그라운드가 맨 위 화면에 띠를 띄우게 한다.
(() => {
  if (window.__knockDrmBar) return;
  window.__knockDrmBar = true;
  window.addEventListener('message', (e) => {
    if (e.source !== window) return;
    if (e.data?.__knockDrm === 'fail') {
      try { chrome.runtime.sendMessage({ type: 'drmFail', reason: e.data.reason, url: location.href }); } catch {}
    }
    if (e.data?.__knockDrm === 'netflix-watch' && window === window.top) netflixWatch(String(e.data.url || location.href));
  });
  if (window !== window.top) return;

  // 넷플릭스는 사이트 전체를 넷플릭스 창에서 연다(2026-11-10 원장님 결정): 로그인은 넷플릭스 창에서 한 번만.
  // 이 탭은 들어오기 전 화면으로 돌아간다(없으면 새 탭 화면). 넷플릭스 창이 없으면(윈도우 등) 그냥 여기서 연다.
  let sentSite = false;
  if (/(^|\.)netflix\.com$/.test(location.hostname)) {
    sentSite = true;
    chrome.runtime.sendMessage({ type: 'drmAutoVideo', url: location.href, leave: true })
      .then((r) => { if (!r?.ok) sentSite = false; }, () => { sentSite = false; });
  }

  // 넷플릭스 영상을 누르면: 넷플릭스 창에서 바로 재생하고, 이 탭은 누르기 전 화면으로 돌려 놓는다(오류 화면 없이)
  // 넷플릭스 창이 없으면(윈도우 등) 띠를 띄운다.
  async function netflixWatch(url) {
    if (sentSite) return; // 사이트째 넷플릭스 창으로 넘기는 중
    document.querySelectorAll('video').forEach((v) => { try { v.pause(); v.muted = true; } catch {} });
    let r = null;
    try { r = await chrome.runtime.sendMessage({ type: 'drmAutoVideo', url }); } catch {}
    if (!r?.ok) { try { chrome.runtime.sendMessage({ type: 'drmFail', reason: 'netflix watch', url }); } catch {} return; }
    if (history.length > 1) history.back(); else location.replace('https://www.netflix.com/browse');
    toast('넷플릭스 창에서 재생해요');
  }
  function toast(text) {
    const t = document.createElement('div');
    t.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:2147483647;padding:10px 18px;border-radius:8px;'
      + 'background:#1f2937;color:#fff;font:14px/1.4 -apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Malgun Gothic",sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.35)';
    t.textContent = text;
    (document.body || document.documentElement).appendChild(t);
    setTimeout(() => t.remove(), 3000);
  }

  const NAMES = { video: '넷플릭스 창', chrome: '크롬', edge: '엣지' };
  const netflix = /(^|\.)netflix\.com$/.test(location.hostname);
  function show(browsers) {
    if (document.getElementById('knock-drm-bar')) return;
    const host = document.createElement('div');
    host.id = 'knock-drm-bar';
    host.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483647;';
    const root = host.attachShadow({ mode: 'closed' });
    // 넷플릭스 창(Knock Browser Video)은 넷플릭스에서만, 맨 앞에
    const list = ['video', 'chrome', 'edge'].filter((b) => (browsers || []).includes(b) && (b !== 'video' || netflix));
    root.innerHTML = `<style>
      .bar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:10px 16px;background:#1f2937;color:#fff;
        font:14px/1.4 -apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Malgun Gothic",sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.35)}
      .msg{flex:1;min-width:200px}
      button{font:inherit;border:0;border-radius:6px;padding:6px 12px;cursor:pointer}
      .go{background:#2563eb;color:#fff}.go:hover{background:#1d4ed8}
      .go.sub{background:#374151}.go.sub:hover{background:#4b5563}
      .x{background:transparent;color:#cbd5e1;font-size:18px;padding:2px 8px}
    </style>
    <div class="bar" role="alert">
      <span class="msg">${list.includes('video')
        ? '넷플릭스는 Knock Browser 안에서 재생되지 않아요. 넷플릭스 창에서 보세요. 넷플릭스 창에서 처음 한 번만 로그인하면 계속 기억해요.'
        : list.length
        ? '이 영상은 Knock Browser에서 재생이 막혔어요. 아래 단추를 누르면 같은 화면이 다른 브라우저에서 열려요.'
        : '이 영상은 Knock Browser에서 재생이 막혔어요. 크롬이나 엣지를 설치하면 거기서 볼 수 있어요.'}</span>
      ${list.map((b, i) => `<button class="go${i ? ' sub' : ''}" data-b="${b}">${b === 'video' ? '넷플릭스 창에서 보기' : `${NAMES[b]}에서 열기`}</button>`).join('')}
      <button class="x" title="닫기" aria-label="닫기">✕</button>
    </div>`;
    root.querySelectorAll('.go').forEach((btn) => btn.addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'drmOpenExternal', browser: btn.dataset.b, url: location.href });
      btn.textContent = `${NAMES[btn.dataset.b]}에서 여는 중…`;
      // 넷플릭스 창으로 넘기면 여기 영상은 멈춘다(소리가 겹치지 않게)
      if (btn.dataset.b === 'video') document.querySelectorAll('video').forEach((v) => { try { v.pause(); } catch {} });
    }));
    root.querySelector('.x').addEventListener('click', () => {
      host.remove();
      chrome.runtime.sendMessage({ type: 'drmDismiss', url: location.href });
    });
    (document.body || document.documentElement).appendChild(host);
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'drmShowBar') show(msg.browsers);
  });
})();
