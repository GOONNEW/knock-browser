// 사이트 요령: AI 가 그 사이트에서 헤매지 않도록 미리 알려 주는 짧은 방법들.
// - 기본 요령(여기 적은 것): 실제 작업 기록에서 뽑았다.
// - 배운 요령: AI 가 시행착오 끝에 알아낸 것을 remember_site_tip 으로 저장한다(chrome.storage.local siteTips).
// - 자동 개선: AI 는 요령 번호(id)로 틀린 요령을 고치거나 지운다(기본 요령도 끌 수 있다 — siteTipsOff).
//   긴 작업이 끝나면 background.js 가 AI 에게 보이지 않는 회고를 시켜 요령을 다듬게 한다.
// 사용자는 ⚙︎ 설정 → 사이트 요령에서 결과를 보고 지울 수도 있다.

export const BUILTIN_TIPS = {
  // 2026-11-09 원장님 개선 요청: "일정을 하나씩 열어서 하면 속도가 느려" — 월 보기에서 끌기·오른쪽 클릭으로 한다
  'calendar.google.com': [
    '일정을 다른 날로 옮길 때는 일정을 열어 날짜를 고치지 않는다. 월 보기(/r/month)에서 screenshot 으로 자리를 보고, 그 일정을 옮길 날짜 칸으로 drag 한다. 반복 일정이면 "이 일정만" 묻는 창이 뜨니 고른다. 놓은 뒤 screenshot 으로 확인한다.',
    '일정 색 바꾸기(완료 표시의 흑연 등)와 삭제는 일정을 열지 않는다. 그 일정을 오른쪽 클릭(click_at 의 right=true, 또는 click 의 right=true)하면 색 목록과 [삭제]가 뜨니 거기서 고른다.',
    '여러 일정을 처리할 때도 월 보기 한 화면에서 끌기·오른쪽 클릭으로 차례로 한다(하나씩 열고 닫으면 느리다). 사용자가 보던 보기(월·주·일)는 바꾸지 않는다.',
  ],
  // 2026-11-09 AI 로그인이 3번 모두 400 오류(매크로 막는 보안 프로그램) → 2026-11-12 한 글자씩 키를 눌러 넣게 고침
  'cardsales.or.kr': [
    '로그인 칸은 매크로 막는 보안 프로그램이 지킨다. 아이디는 type_text, 비밀번호는 request_password 로 넣고(둘 다 한 글자씩 키를 눌러 들어간다), [LOGIN] 단추는 click 으로 누른다. 칸 값을 스크립트로 바꾸지 않는다.',
    '400 오류 화면이 뜨면 https://www.cardsales.or.kr/signin 을 새로 열어 한 번만 다시 한다. 또 400 이면 멈추고 사용자에게 화면 칸에 직접 넣어 달라고 한다(비밀번호 5번 틀리면 30분 막힌다).',
  ],
  'blog.naver.com': [
    '글쓰기 편집기(스마트에디터)의 제목·본문칸은 get_page 에 입력칸으로 잡히지 않는다. screenshot 으로 자리를 보고 click_at 으로 커서를 놓은 뒤, 제목은 type_text(id 없이), 본문은 paste_html 로 넣는다.',
    '원고를 한꺼번에 붙인 뒤 소제목을 인용구로 바꾸면 문단이 쪼개지고 위치가 어긋난다. 처음부터 차례로 짓는다: ① 툴바 "인용구 선택"(▾)에서 모양 고르기 → ② 인용구 안에 소제목 입력 → ③ "본문 추가" 단추로 인용구 아래 새 문단 만들기 → ④ 그 줄을 click_at 한 뒤 그 섹션 본문만 paste_html → 다음 소제목으로 반복.',
    '인용구 안에 커서가 있는 채로 본문을 붙이면 본문이 인용구 안으로 들어간다. 붙이기 전에 "본문 추가"로 인용구 밖으로 나왔는지 screenshot 으로 확인한다.',
    '"인용구 선택" 목록의 모양 6개는 get_page 에 "인용구 1~6" 번호로만 나온다(이름은 그림). 처음 한 번 screenshot 으로 이름과 번호를 맞춰 보고 remember_site_tip 으로 저장해 둔다.',
    '사진 넣기: 본문에서 넣을 자리에 커서를 둔 뒤, 위쪽 도구 [사진] 단추의 번호를 upload_file 의 id 로 준다(파일 선택 창은 뜨지 않고 바로 들어간다 — 원격 PC 탭도 같음). 붙여넣기·네이버 메모를 거치는 방법은 쓰지 않는다(라이브러리에 안 남고 느리다). 넣은 뒤 사진을 click 하면 위에 크기·정렬 도구(옆트임·화면 폭 맞춤 등)가 뜬다.',
    '사진 여러 장을 한 줄로 묶기(2×2·3×3 배치): 개별 사진으로 넣은 뒤, drag 로 둘째 사진을 첫째 사진의 오른쪽 가장자리(초록 세로선이 뜨는 곳)에 놓는다 → 같은 줄로 묶인다. 한 줄에 3장이면 셋째도 둘째 오른쪽에. 한 번 놓을 때마다 screenshot 으로 확인한다.',
    '붙여넣은 글의 줄간격(style)은 편집기가 무시한다. 본문을 모두 넣은 뒤 본문 글자를 클릭 → press_key a + ["cmd"](전체 선택) → 툴바 "줄간격 열기"에서 값을 고른다.',
    '표 꾸미기: 표 안의 칸을 클릭하면 표 도구가 나온다 → "셀 전체 선택" → "표 스타일 열기"에서 고르기(목록 두 번째가 표2) → "가운데 정렬". 첫 줄(머리글)만 굵게 하려면 첫 줄 칸들을 Shift+화살표로 선택하고 "굵게".',
    '굵게가 켜진 채로 남아 다음 글이 굵어질 수 있다. 툴바 단추 이름이 "굵게 굵기 해제"면 켜져 있는 것이니 눌러 끈다.',
    '오른쪽 위 "저장" 단추가 임시저장이다. "발행"은 사용자가 시키지 않으면 누르지 않는다.',
    '스크롤 중에 찍힌 screenshot 은 좌표가 어긋난다. 스크롤한 뒤에는 잠깐 기다렸다가 다시 찍고, 화면 밖의 줄은 클릭하지 않는다.',
    '글쓰기 화면을 나갔다 들어오면 "작성 중인 글이 있습니다" 창이 뜬다. 이어 쓰려면 확인, 새로 쓰려면 취소.',
  ],
};

const MAX_LEARNED = 30;

export function tipHost(url) {
  try {
    const u = new URL(url);
    return /^https?:$/.test(u.protocol) ? u.hostname.replace(/^www\./, '') : null;
  } catch {
    return null;
  }
}

// 예전에 업로드가 막혀(2026-11-07 이전) AI 가 스스로 익힌 잘못된 요령 — "사진은 메모를 거쳐 붙여넣기", "선택 창을 못 다룸" — 을 한 번 지운다
export async function dropStaleUploadTips() {
  const { tipsCleanup1107 } = await chrome.storage.local.get('tipsCleanup1107');
  if (tipsCleanup1107) return;
  const all = await learnedTips();
  const bad = /memo\.naver|메모.{0,12}(경유|거쳐|거치|올렸다가|올린 뒤)|파일 선택 창.{0,20}(다룰 수 없|못 다|조작할 수 없)|올리기 칸(이)? 없|Not allowed/;
  let n = 0;
  for (const host of Object.keys(all)) {
    const keep = (all[host] || []).filter((t) => !bad.test(t.text));
    n += (all[host] || []).length - keep.length;
    if (keep.length) all[host] = keep; else delete all[host];
  }
  await chrome.storage.local.set({ siteTips: all, tipsCleanup1107: n || true });
}

export async function learnedTips() {
  const { siteTips } = await chrome.storage.local.get('siteTips');
  return siteTips || {};
}

async function builtinOff() {
  const { siteTipsOff } = await chrome.storage.local.get('siteTipsOff');
  return siteTipsOff || {}; // host → [기본 요령 번호]
}

// 그 사이트(위 도메인 포함: m.blog.naver.com → blog.naver.com 도)의 요령 목록. 요령마다 고치거나 지울 때 쓰는 id 가 있다.
export async function tipsFor(url) {
  const host = tipHost(url);
  if (!host) return { host: null, tips: [] };
  const [learned, off] = await Promise.all([learnedTips(), builtinOff()]);
  const parts = host.split('.');
  const names = [];
  for (let i = 0; i < parts.length - 1; i++) names.push(parts.slice(i).join('.'));
  const tips = [];
  for (const name of names) {
    (BUILTIN_TIPS[name] || []).forEach((text, i) => { if (!(off[name] || []).includes(i)) tips.push({ id: `b-${name}-${i}`, text }); });
    for (const t of learned[name] || []) tips.push({ id: `l-${t.at}`, text: t.text });
  }
  return { host, tips };
}

// 새 요령 저장. replaceId 를 주면 그 요령을 이것으로 바꾼다(틀린 요령 고치기).
export async function rememberTip(url, text, replaceId) {
  const host = tipHost(url);
  if (!host) throw new Error('이 탭은 웹사이트가 아니라 요령을 저장할 수 없습니다.');
  const tip = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 400);
  if (!tip) throw new Error('저장할 요령이 비어 있습니다.');
  if (replaceId) await forgetTipById(replaceId);
  const all = await learnedTips();
  const list = (all[host] || []).filter((t) => t.text !== tip);
  list.push({ text: tip, at: Date.now() });
  all[host] = list.slice(-MAX_LEARNED);
  await chrome.storage.local.set({ siteTips: all });
  return host;
}

// 요령 지우기(id): 배운 요령은 지우고, 기본 요령은 끈다
export async function forgetTipById(id) {
  const b = String(id).match(/^b-(.+)-(\d+)$/);
  if (b) {
    if (!BUILTIN_TIPS[b[1]]?.[Number(b[2])]) throw new Error(`없는 요령 번호입니다: ${id}`);
    const off = await builtinOff();
    off[b[1]] = [...new Set([...(off[b[1]] || []), Number(b[2])])];
    await chrome.storage.local.set({ siteTipsOff: off });
    return b[1];
  }
  const l = String(id).match(/^l-(\d+)$/);
  const all = await learnedTips();
  const host = l && Object.keys(all).find((h) => all[h].some((t) => t.at === Number(l[1])));
  if (!host) throw new Error(`없는 요령 번호입니다: ${id}`);
  await forgetTip(host, Number(l[1]));
  return host;
}

export async function offBuiltins() {
  return builtinOff();
}

export async function restoreBuiltin(host, i) {
  const off = await builtinOff();
  off[host] = (off[host] || []).filter((x) => x !== i);
  if (!off[host].length) delete off[host];
  await chrome.storage.local.set({ siteTipsOff: off });
}

export async function forgetTip(host, at) {
  const all = await learnedTips();
  all[host] = (all[host] || []).filter((t) => t.at !== at);
  if (!all[host].length) delete all[host];
  await chrome.storage.local.set({ siteTips: all });
}
