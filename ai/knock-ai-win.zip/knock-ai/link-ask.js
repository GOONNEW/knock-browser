// 다른 컴퓨터의 AI 가 이 컴퓨터를 쓰려 할 때 묻는 창(배경이 띄운다). 3분 안에 고르지 않으면 취소.
const q = new URLSearchParams(location.search);
const askId = q.get('id');
document.getElementById('ask').textContent = `"${q.get('name') || '다른 컴퓨터'}"의 AI가 이 컴퓨터의 Knock을 쓰려고 합니다.`;
let left = 170;
const tick = () => { document.getElementById('left').textContent = `(${left}초 뒤 취소)`; if (left-- <= 0) pick('timeout'); };
tick();
setInterval(tick, 1000);
function pick(value) {
  chrome.runtime.sendMessage({ type: 'linkAnswer', askId, pick: value }).finally(() => window.close());
}
for (const id of ['no', 'once', 'always']) document.getElementById(id).addEventListener('click', () => pick(id));
