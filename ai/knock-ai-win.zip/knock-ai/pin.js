// PIN 6칸 입력 · 자물쇠 · 프로필 색 점 — 잠금 창(lock.html)·설정(panel)·위쪽 프로필 메뉴(toolbar)가 함께 쓴다(2026-11-10 피그마 ④).
export const PROFILE_COLORS = ['#3B6FD8', '#2E8B57', '#FF6A3D', '#8A5CD6', '#E0A100', '#6B7280'];

export const el = (tag, cls, text) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
};

/** 자물쇠 그림(피그마 icon/lock) */
export function lockIcon(size = 14) {
  const ns = 'http://www.w3.org/2000/svg';
  const s = document.createElementNS(ns, 'svg');
  s.setAttribute('viewBox', '0 0 16 16');
  s.setAttribute('width', size);
  s.setAttribute('height', size);
  s.setAttribute('class', 'lock-ic');
  s.setAttribute('aria-label', '잠김');
  s.innerHTML = '<rect x="3" y="7" width="10" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2" fill="none" stroke="currentColor" stroke-width="1.4"/>';
  return s;
}
export function dot(color, size = 12) {
  const d = el('span', 'pdot');
  d.style.width = d.style.height = `${size}px`;
  d.style.background = color || '#FF6A3D';
  return d;
}

/** PIN 6칸. onFull(pin): 6자리를 다 넣으면. 숫자만 받는다. small: 프로필 메뉴의 작은 칸 */
export function pinBoxes({ onFull, small = false, label = 'PIN 6자리' } = {}) {
  const wrap = el('div', `pin-boxes${small ? ' small' : ''}`);
  wrap.setAttribute('role', 'group');
  wrap.setAttribute('aria-label', label);
  const boxes = [];
  const value = () => boxes.map((b) => b.value).join('');
  for (let i = 0; i < 6; i++) {
    const b = el('input', 'pin-box');
    Object.assign(b, { type: 'password', inputMode: 'numeric', maxLength: 1, autocomplete: 'off' });
    b.setAttribute('aria-label', `${label} ${i + 1}번째`);
    b.addEventListener('input', () => {
      b.value = b.value.replace(/\D/g, '').slice(-1);
      wrap.classList.remove('bad');
      if (b.value && i < 5) boxes[i + 1].focus();
      if (value().length === 6) onFull?.(value());
    });
    b.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !b.value && i > 0) { boxes[i - 1].value = ''; boxes[i - 1].focus(); e.preventDefault(); }
      if (e.key === 'ArrowLeft' && i > 0) boxes[i - 1].focus();
      if (e.key === 'ArrowRight' && i < 5) boxes[i + 1].focus();
    });
    b.addEventListener('paste', (e) => {
      const t = (e.clipboardData?.getData('text') || '').replace(/\D/g, '').slice(0, 6);
      if (!t) return;
      e.preventDefault();
      t.split('').forEach((c, k) => { if (boxes[k]) boxes[k].value = c; });
      boxes[Math.min(t.length, 5)].focus();
      if (value().length === 6) onFull?.(value());
    });
    boxes.push(b);
    wrap.append(b);
  }
  return {
    el: wrap,
    value,
    clear() { for (const b of boxes) b.value = ''; },
    focus() { (boxes.find((b) => !b.value) || boxes[0]).focus(); },
    bad(on = true) { wrap.classList.toggle('bad', on); },
    disable(on = true) { for (const b of boxes) b.disabled = on; },
  };
}

/** 체크 상자(피그마 "체크 · 켬/끔") */
export function checkRow(text, sub) {
  const l = el('label', 'chk-row');
  const c = el('input');
  c.type = 'checkbox';
  const t = el('span', 'chk-text');
  t.append(el('b', '', text));
  if (sub) t.append(el('small', '', sub));
  l.append(c, t);
  return { el: l, box: c };
}

/** "막힌 때까지 남은 분" */
export const blockedText = (r) => r?.error || 'PIN이 맞지 않습니다.';
