// 브라우저 연동: 그 PC 페이지의 목록 상자(<select>) 목록을 이 창에 그린다(2026-11-14).
// 그 PC 에서 뜨는 목록은 탭 밖의 따로 된 창이라 화면에 안 찍힌다 — 그 PC 가 항목을 보내 주면 같은 자리에 그린다.
// 고르면 { t:'selectPick', id, i }, 그냥 닫으면 { t:'selectClose', id } 를 보낸다. 원격 창(remote-browser.js)과 팝업 창이 같이 쓴다.
let cur = null; // { id, el, doc, off }

const CSS = `
.ksel { position: fixed; z-index: 30; box-sizing: border-box; overflow-y: auto; background: #fff; color: #1d1b19; border: 1px solid #b9b3ac; border-radius: 6px; box-shadow: 0 6px 18px rgba(0,0,0,.22); padding: 3px 0; font-family: system-ui, -apple-system, "Segoe UI", "Malgun Gothic", sans-serif; outline: none; }
.ksel div { padding: 3px 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; cursor: default; line-height: 1.45; }
.ksel .g { font-weight: 700; color: #5b5550; }
.ksel .o.in { padding-left: 20px; }
.ksel .o.on { background: #e8eefc; }
.ksel .o.hl { background: #2f6fde; color: #fff; }
.ksel .o.dis { color: #a8a29c; }
@media (prefers-color-scheme: dark) {
  .ksel { background: #2b2825; color: #eee9e3; border-color: #57514b; }
  .ksel .g { color: #bfb7ae; }
  .ksel .o.on { background: #3a3f4f; }
  .ksel .o.dis { color: #7d766f; }
}`;

export function closeSelectList(send, tell = true) {
  if (!cur) return;
  const c = cur;
  cur = null;
  c.off();
  c.el.remove();
  if (tell) send({ t: 'selectClose', id: c.id });
}
export const selectListOpen = () => (cur ? cur.id : null);

// m: 그 PC 가 보낸 { id, rect:{x,y,w,h}(그림에 대한 비율), font(그림 높이에 대한 비율), items:[{i,text,sel,dis}|{group}] }
// canvas: 그 PC 화면을 그린 캔버스(이 창의 것)
export function showSelectList(m, canvas, send) {
  const doc = canvas.ownerDocument;
  closeSelectList(send);
  if (!doc.getElementById('ksel-css')) doc.head.append(Object.assign(doc.createElement('style'), { id: 'ksel-css', textContent: CSS }));
  const cr = canvas.getBoundingClientRect();
  if (!cr.width || !cr.height) return;
  const top = cr.top + m.rect.y * cr.height;
  const bottom = top + m.rect.h * cr.height;
  const left = cr.left + m.rect.x * cr.width;
  const font = Math.min(Math.max((m.font || 0) * cr.height, 12), 20);
  const box = doc.createElement('div');
  box.className = 'ksel';
  box.tabIndex = -1;
  box.style.fontSize = `${font}px`;
  box.style.minWidth = `${Math.max(m.rect.w * cr.width, 80)}px`;
  box.style.maxWidth = `${Math.max(cr.width - 16, 160)}px`;
  let inGroup = false;
  const opts = [];
  for (const it of m.items || []) {
    const d = doc.createElement('div');
    if ('group' in it) { d.className = 'g'; d.textContent = it.group; inGroup = true; box.append(d); continue; }
    d.className = `o${inGroup ? ' in' : ''}${it.sel ? ' on' : ''}${it.dis ? ' dis' : ''}`;
    d.textContent = it.text || ' ';
    d.title = it.text || '';
    d.dataset.i = it.i;
    if (!it.dis) opts.push(d);
    box.append(d);
  }
  // 아래에 자리가 모자라면 위로 펼친다(그 PC 와 같게). 길면 그 안에서 굴린다.
  const view = doc.documentElement.clientHeight;
  const below = view - bottom - 8, above = top - 8;
  const up = below < 160 && above > below;
  box.style.maxHeight = `${Math.max(Math.min(up ? above : below, 20 * font * 1.45 + 8), 60)}px`;
  box.style.left = `${Math.max(Math.min(left, doc.documentElement.clientWidth - 160), 4)}px`;
  doc.body.append(box);
  if (up) box.style.top = `${Math.max(top - box.offsetHeight, 4)}px`;
  else box.style.top = `${bottom}px`;
  // 고른 항목이 보이게, 그 항목부터 밝게
  let hl = opts.find((d) => d.classList.contains('on')) || opts[0];
  const light = (d) => { hl?.classList.remove('hl'); hl = d; if (d) { d.classList.add('hl'); d.scrollIntoView({ block: 'nearest' }); } };
  light(hl);
  const pick = (d) => { if (!d) return; const id = cur?.id; closeSelectList(send, false); send({ t: 'selectPick', id, i: Number(d.dataset.i) }); };
  box.addEventListener('mousemove', (e) => { const d = e.target.closest('.o'); if (d && !d.classList.contains('dis') && d !== hl) light(d); });
  box.addEventListener('mousedown', (e) => e.preventDefault());
  box.addEventListener('click', (e) => { const d = e.target.closest('.o'); if (d && !d.classList.contains('dis')) pick(d); });
  const onKey = (e) => {
    if (!cur) return;
    const k = e.key;
    if (!['ArrowDown', 'ArrowUp', 'Enter', 'Escape', 'Tab', 'Home', 'End', 'PageUp', 'PageDown', ' '].includes(k)) return;
    e.preventDefault(); e.stopImmediatePropagation(); // 그 PC 로 보내지 않는다
    if (e.type !== 'keydown') return;
    const at = opts.indexOf(hl);
    if (k === 'Escape' || k === 'Tab') return closeSelectList(send);
    if (k === 'Enter' || k === ' ') return pick(hl);
    const step = k === 'ArrowDown' ? 1 : k === 'ArrowUp' ? -1 : k === 'PageDown' ? 10 : k === 'PageUp' ? -10 : k === 'Home' ? -1e6 : 1e6;
    light(opts[Math.min(Math.max(at + step, 0), opts.length - 1)]);
  };
  // 바깥을 누르거나 창이 바뀌면 닫는다(목록 위 누르기는 위에서 처리)
  // 목록 상자 자리를 다시 누르면 닫기만 한다(그 PC 에 누르기를 보내면 또 열린다)
  const onDown = (e) => {
    if (box.contains(e.target)) return;
    const r = canvas.getBoundingClientRect();
    const onSel = e.target === canvas && e.clientX >= left && e.clientX <= left + m.rect.w * r.width && e.clientY >= top && e.clientY <= bottom;
    closeSelectList(send);
    if (!onSel) return;
    e.preventDefault(); e.stopImmediatePropagation();
    win.addEventListener('mouseup', (u) => { u.stopImmediatePropagation(); }, { capture: true, once: true });
  };
  const onWheel = (e) => { if (!box.contains(e.target)) closeSelectList(send); };
  const onBlur = () => closeSelectList(send);
  const win = doc.defaultView;
  win.addEventListener('keydown', onKey, true);
  win.addEventListener('keyup', onKey, true);
  win.addEventListener('mousedown', onDown, true);
  win.addEventListener('wheel', onWheel, true);
  win.addEventListener('resize', onBlur);
  win.addEventListener('blur', onBlur);
  cur = { id: m.id, el: box, doc, off: () => { win.removeEventListener('keydown', onKey, true); win.removeEventListener('keyup', onKey, true); win.removeEventListener('mousedown', onDown, true); win.removeEventListener('wheel', onWheel, true); win.removeEventListener('resize', onBlur); win.removeEventListener('blur', onBlur); } };
}
