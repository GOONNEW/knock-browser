// 똑소리 가림표(2026-11-03 원장님 "열어" — 브라우저에서도 계좌·주민번호·연락처 조회).
// 2026-11-04: 페이지에서 가린 개인정보(계좌번호 등)도 같은 가림표로 맡긴다 — "캘린더의 계좌를 은행 화면에 넣어 줘".
//
// 똑소리HR 은 민감한 값을 AI 에게 [[비공개1]] 같은 가림표로만 주고, 실제 값은 응답의 secrets 로 따로 준다.
// - 백그라운드(toksori.js)가 secrets 를 떼어 여기에 맡기고, AI 에게는 가림표만 넘긴다.
// - AI 창(panel.js)이 답을 그릴 때만 가림표를 실제 값으로 바꿔 끼운다. 대화 기록(chats)에는 가림표 그대로 남는다
//   — 다음 턴·개선 요청·대화 공유로 실제 값이 새지 않는다.
// 서버의 가림표 번호는 요청마다 1부터라 그대로 쓰면 겹친다 → 브라우저 전체에서 겹치지 않게 번호를 새로 매긴다.
// 맡긴 값은 storage.session(메모리, 브라우저를 끄면 사라짐)에만 둔다 — 대화 기록(chats)과 수명이 같다.

const KEY = 'toksoriSecrets';
export const TOKEN = /\[\[비공개\d+\]\]/g;

let chain = Promise.resolve(); // 동시에 두 조회가 와도 번호가 겹치지 않게 차례로

/** 서버가 준 글과 가림표 표를 받아, 겹치지 않는 가림표로 바꾼 글을 돌려준다. */
export function keepSecrets(content, secrets) {
  const pairs = Object.entries(secrets || {}).filter(([k, v]) => /^\[\[비공개\d+\]\]$/.test(k) && typeof v === 'string');
  if (!pairs.length) return Promise.resolve(String(content));
  const run = chain.then(async () => {
    const { [KEY]: saved } = await chrome.storage.session.get(KEY);
    const store = { n: saved?.n || 0, map: { ...(saved?.map || {}) }, hidden: [...(saved?.hidden || [])] };
    const rename = new Map();
    for (const [token, value] of pairs) {
      const same = Object.keys(store.map).find((k) => store.map[k] === value);
      const next = same || `[[비공개${++store.n}]]`;
      store.map[next] = value;
      rename.set(token, next);
    }
    await chrome.storage.session.set({ [KEY]: store });
    // 한 번에 바꾼다(차례로 바꾸면 [[비공개1]]→[[비공개2]] 뒤 [[비공개2]]→… 처럼 겹쳐 꼬인다)
    return String(content).replace(TOKEN, (t) => rename.get(t) ?? '(확인 불가)');
  });
  chain = run.catch(() => {});
  return run;
}

/** 실제 값들에 가림표를 매긴다(이미 맡긴 값이면 그 가림표 그대로). 값 → 가림표 Map.
 *  페이지에서 가린 계좌번호 같은 개인정보도 이것으로 맡겨, AI 가 가림표로 다른 칸(은행 이체 화면 등)에 넣을 수 있게 한다. */
export function tokensFor(values, { hidden = false } = {}) {
  const list = [...new Set(values.filter((v) => typeof v === 'string' && v))];
  if (!list.length) return Promise.resolve(new Map());
  const run = chain.then(async () => {
    const { [KEY]: saved } = await chrome.storage.session.get(KEY);
    // hidden: 사용자가 가려진 칸에 넣은 값(비밀번호·CVC 등) — AI 창에서도 실제 값을 보이지 않는다
    const store = { n: saved?.n || 0, map: { ...(saved?.map || {}) }, hidden: [...(saved?.hidden || [])] };
    const out = new Map();
    for (const value of list) {
      const same = Object.keys(store.map).find((k) => store.map[k] === value);
      const token = same || `[[비공개${++store.n}]]`;
      store.map[token] = value;
      if (hidden && !store.hidden.includes(token)) store.hidden.push(token);
      out.set(value, token);
    }
    await chrome.storage.session.set({ [KEY]: store });
    return out;
  });
  chain = run.catch(() => {});
  return run;
}

// ---------- 채팅에 적은 민감정보 ----------
// 사용자가 채팅에 카드번호·카드 비밀번호·CVC·비밀번호·인증번호를 적으면 AI 에게 보내기 전에 지우고, 가려진 칸으로 다시 받는다.
// 지운 자리는 [[입력칸1]] 로 남겨 두었다가, 가려진 칸에 넣은 값의 가림표([[비공개N]])로 바꿔 AI 에게 보낸다.
const SECRET_WORDS = [
  [/cvc|cvv2?|보안\s*코드|씨브이씨|시브이시/i, 'CVC(카드 뒷면 3자리)'],
  [/카드\s*비밀\s*번호|카드\s*비번/i, '카드 비밀번호'],
  [/인증\s*번호|otp|일회용/i, '인증번호'],
  [/비밀\s*번호|비번|패스워드|password|passwd|pw|암호|pin|핀\s*번호/i, '비밀번호'],
];
function luhn(d) {
  let sum = 0;
  for (let i = 0; i < d.length; i++) {
    let n = Number(d[d.length - 1 - i]);
    if (i % 2) { n *= 2; if (n > 9) n -= 9; }
    sum += n;
  }
  return sum % 10 === 0;
}
/** 글에서 민감정보를 떼어 낸다. → { clean: 지운 글([[입력칸N]] 자리표), found: [{ label, value }] } */
export function takeTypedSecrets(text) {
  const found = [];
  const slot = (label, value) => { found.push({ label, value }); return `[[입력칸${found.length}]]`; };
  let clean = String(text ?? '');
  // 카드번호: 13~19자리(띄어쓰기·줄표 섞여도), 카드번호 검산이 맞는 것만
  clean = clean.replace(/(?<![\d-])\d(?:[ -]?\d){12,18}(?![\d-])/g, (m) => {
    const d = m.replace(/\D/g, '');
    const grouped = /^\d{4}([ -])\d{4}\1\d{4}\1\d{3,4}$/.test(m); // 1234-5678-… 꼴은 검산이 틀려도 카드번호로 본다
    return grouped || luhn(d) ? slot('카드번호', d) : m;
  });
  // "비밀번호 1234", "CVC: 123", "pw=abcd1234" 처럼 이름 뒤에 바로 오는 값
  const words = SECRET_WORDS.map(([re]) => re.source).join('|');
  clean = clean.replace(new RegExp(`(${words})\\s*(?:는|은|이|가|:|=|：)?\\s*([A-Za-z0-9!@#$%^&*._~+\\-]{2,40})`, 'gi'), (m, word, value) => {
    const isWord = /^[A-Za-z]+$/.test(value) && value.length < 6; // "pw is" 같은 말은 값이 아니다
    if (isWord || !/\d/.test(value) && value.length < 6) return m;
    const label = SECRET_WORDS.find(([re]) => re.test(word))?.[1] || '비밀번호';
    return `${word} ${slot(label, value)}`;
  });
  return { clean, found };
}

// ---------- AI 창에서 보여 줄 때 ----------
let shown = {};
let hiddenSet = new Set();

/** AI 창이 처음 뜰 때 한 번. 바뀌면 onChange 로 다시 그리게 한다. */
export async function watchSecrets(onChange) {
  const { [KEY]: saved } = await chrome.storage.session.get(KEY).catch(() => ({}));
  shown = saved?.map || {};
  hiddenSet = new Set(saved?.hidden || []);
  chrome.storage.session.onChanged.addListener((changes) => {
    if (!changes[KEY]) return;
    shown = changes[KEY].newValue?.map || {};
    hiddenSet = new Set(changes[KEY].newValue?.hidden || []);
    onChange?.();
  });
}

/** 글 속 가림표를 실제 값으로(모르는 가림표 — 브라우저를 다시 켰거나 AI 가 지어낸 것 — 는 다시 물어보라고). */
export function revealSecrets(text) {
  return String(text ?? '').replace(TOKEN, (t) => (hiddenSet.has(t) ? '🔒(가려짐)' : shown[t] != null ? chatValue(shown[t]) : '(가려진 값 — 다시 물어보세요)'));
}

// 대화창에서 민감정보 가리기(설정 › AI 동작 보안, 기본 켬 — 피그마 ②): 앞 3자·뒤 4자만 보이고 가운데 글자는 * (기호는 그대로)
// 예) 110-123-457637 → 110-***-**7637. 페이지 칸에 넣을 때는 늘 진짜 값이다(이것은 보이는 글만 바꾼다).
let maskInChat = true;
export function setChatMask(on) { maskInChat = on !== false; }
function chatValue(v) {
  const str = String(v);
  if (!maskInChat || str.length < 8) return str;
  const chars = [...str];
  return chars.map((c, i) => (i < 3 || i >= chars.length - 4 || !/[0-9A-Za-z가-힣]/.test(c) ? c : '*')).join('');
}

// ---------- 다른 사이트·앱 칸에 넣을 때(백그라운드) ----------
// AI 가 가림표를 칸에 넣으려 하면, 사용자에게 물은 뒤 그 칸에만 실제 값을 넣는다(AI 에게는 끝까지 가림표).
// 넣은 뒤 그 페이지를 다시 읽으면 실제 값이 보이므로, AI 에게 가는 결과에서는 실제 값을 다시 가림표로 바꾼다.

async function savedMap() {
  const { [KEY]: saved } = await chrome.storage.session.get(KEY).catch(() => ({}));
  return saved?.map || {};
}

/** 글 속 가림표들. 모르는 것(브라우저를 다시 켰거나 AI 가 지어낸 것)은 missing. */
export async function secretsIn(text) {
  const tokens = [...new Set(String(text ?? '').match(TOKEN) || [])];
  if (!tokens.length) return { tokens, missing: [], real: String(text ?? '') };
  const map = await savedMap();
  const missing = tokens.filter((t) => !(t in map));
  return { tokens, missing, real: String(text).replace(TOKEN, (t) => map[t] ?? t) };
}

// 계좌·전화번호는 페이지에 110-619-257637 처럼 줄표·띄어쓰기가 섞여 나올 수 있다
const escape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function looseOf(value) {
  const digits = value.replace(/\D/g, '');
  if (digits.length >= 6 && digits.length >= value.replace(/[\s-]/g, '').length - 1) return digits.split('').join('[\\s-]?');
  return escape(value);
}

/** 화면 사진에서 검게 덮을 맡아 둔 실제 값들의 무늬(칸에 넣은 뒤 찍은 사진에 보이지 않게). */
export async function secretSources() {
  return Object.values(await savedMap()).filter((v) => v && v.length >= 4).map((v) => [looseOf(v), 'g']);
}

/** AI 에게 보낼 글에서 맡아 둔 실제 값을 가림표로 되돌린다. */
export async function hideSecrets(text) {
  const map = await savedMap();
  let out = String(text ?? '');
  for (const [token, value] of Object.entries(map).sort((a, b) => b[1].length - a[1].length)) {
    if (!value || value.length < 4) continue;
    out = out.replace(new RegExp(looseOf(value), 'g'), token);
  }
  return out;
}
