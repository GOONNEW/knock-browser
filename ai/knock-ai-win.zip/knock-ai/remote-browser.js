// 원격용 브라우저 창(Figma ① 5 묶음 F-1·F-3) — 그 PC Knock Browser 의 탭 전체를 이 창에서 보고 조작한다.
// 탭 줄은 그 PC 의 탭 목록대로 그린다. 화면은 그 PC 가 보는 탭을 찍어 보낸 그림이고, 누르기·입력은 그 탭에 들어간다.
// 이 창을 닫으면 연결이 끊긴다.
import { openSignal } from './remote-signal.js';
import { sendWire, wireReader, iceServers } from './rb-wire.js';
import { showPw, hidePw, showPill, hidePill } from './remote-pw.js';
import { pinBoxes, lockIcon } from './pin.js';

const $ = (id) => document.getElementById(id);
const q = new URLSearchParams(location.search);
const S = { session: q.get('session'), room: q.get('room'), inbox: q.get('inbox'), name: q.get('name') || '다른 PC', mode: q.get('mode') || 'browser', dev: q.get('dev') || '', update: q.get('update') === '1', retry: Number(q.get('retry')) || 0, quiet: q.get('quiet') === '1' };
// quiet: 원격 목록이 보이지 않는 칸에서 연 것(옛 버전 PC 업데이트만 보내고 닫힘) — 결과는 부모 화면에 알린다
const tellParent = (data) => { if (S.quiet) window.parent.postMessage({ type: 'rbUpdate', ...data }, location.origin); };
if (S.quiet) document.getElementById('ai')?.setAttribute('src', 'about:blank');
const me = crypto.randomUUID();
const st = { room: null, inbox: null, pc: null, dc: null, host: null, tabs: [], active: null, img: null, w: 0, h: 0, ended: false, ringTimer: null };
document.title = `${S.name} — 원격 브라우저`;
$('badge').textContent = `🖥 ${S.name} · 원격 브라우저`;
$('chip').textContent = `● ${S.name}`;

// 작은 쪽지(누르기·입력·탭 고르기)는 ctl 통로로 — 화면 그림이 밀려도 기다리지 않는다(옛 판은 ctl 이 없어 rb 로)
const send = (obj) => sendWire(st.ctl?.readyState === 'open' ? st.ctl : st.dc, obj);
// 이 창에서 시킨 AI 일을 그 PC 로 나르는 통로(background 의 'rb')
const bg = chrome.runtime.connect({ name: 'rb' });
bg.postMessage({ type: 'rbHello', name: S.name });
bg.onMessage.addListener((m) => {
  // 지난 대화 이어 가기: 그 대화가 마지막으로 있던 페이지를 그 PC 에 새 탭으로(2026-11-09)
  if (m.type === 'rbNewTab') { if (st.dc?.readyState === 'open') send({ t: 'newtab', ...(/^https?:\/\//i.test(m.url || '') ? { url: m.url } : {}) }); return; } // 마지막 페이지가 없으면 빈 새 탭
  if (m.type === 'rbSelect') { if (st.dc?.readyState === 'open' && m.tabId != null) send({ t: 'select', tabId: m.tabId }); return; } // 그 대화가 열린 원격 탭으로
  if (m.type !== 'rbCall') return;
  if (!st.dc || st.dc.readyState !== 'open') return bg.postMessage({ type: 'rbRes', id: m.id, result: null });
  send({ t: 'ai', id: m.id, op: m.op, args: m.args });
});
const toast = (t) => { $('toast').textContent = t; $('toast').classList.remove('hidden'); clearTimeout(toast.t); toast.t = setTimeout(() => $('toast').classList.add('hidden'), 3000); };
function cover(title, text = '', closeBtn = false, hello = false) {
  $('cover').classList.toggle('hello', hello);
  $('cover-logo').classList.toggle('hidden', !hello);
  $('cover-title').textContent = title;
  $('cover-text').textContent = text;
  $('close-btn').classList.toggle('hidden', !closeBtn);
  $('cover').classList.toggle('hidden', !title);
}
// 끊긴 화면의 [다시 연결](창 닫기는 창의 ✕ 로 — 2026-11-07): 같은 PC 에 같은 방식으로 새로 잇는다(기억한 비밀번호로)
$('close-btn').addEventListener('click', async () => {
  const b = $('close-btn');
  if (!S.dev) { location.href = chrome.runtime.getURL('remote-connect.html'); return; }
  b.disabled = true;
  b.textContent = '연결하는 중…';
  const r = await chrome.runtime.sendMessage({ type: 'remoteSwitch', toDeviceId: S.dev, mode: S.mode }).catch((err) => ({ error: err.message }));
  if (r?.url) return location.replace(r.url);
  b.disabled = false;
  b.textContent = '다시 연결';
  if (r?.reason === 'password') { location.href = chrome.runtime.getURL('remote-connect.html'); return; }
  $('cover-text').textContent = r?.error || '다시 잇지 못했어요. 잠시 뒤 다시 눌러 주세요.';
});

async function start() {
  if (!S.session || !S.room || !S.inbox) return cover('연결 정보가 없어요', '원격 연결 화면에서 다시 [연결]을 눌러 주세요.', true);
  cover('연결하는 중…', `${S.name}에 연결하고 있어요`);
  st.room = await openSignal(`room:${S.room}`, onRoom).catch(() => null);
  st.inbox = await openSignal(`inbox:${S.inbox}`, (m) => { if (m?.kind === 'busy' && m.to === me) fail('그 PC가 이미 다른 연결을 받고 있어요.'); }).catch(() => null);
  if (!st.room || !st.inbox) return fail('연결 안내 서버에 들어가지 못했어요. 인터넷 연결을 확인해 주세요.');
  // 그 PC 가 알림을 놓쳤을 수 있어 답이 올 때까지 3초마다 다시 알린다(1분까지)
  const ring = () => st.inbox?.send({ kind: 'ring', sessionId: S.session, from: me });
  ring();
  let n = 0;
  st.ringTimer = setInterval(() => {
    if (st.host || ++n > 20) {
      clearInterval(st.ringTimer);
      if (!st.host && Date.now() < S.retry) reconnect(); // 업데이트로 다시 켜지는 중이면 기다렸다 다시 잇는다
      else if (!st.host) fail('그 PC가 답하지 않아요. 그 PC에서 Knock Browser가 켜져 있는지 확인해 주세요.');
      return;
    }
    ring();
  }, 3000);
}

async function onRoom(msg) {
  if (!msg || msg.to !== me) return;
  if (msg.kind === 'welcome') {
    st.host = msg.from; clearInterval(st.ringTimer); st.inbox?.close(); st.inbox = null;
    if (msg.update) rememberUpdate(msg.update);
    if (msg.pc) cover('PC 원격제어를 여는 중…', `${S.name} 화면을 기다리고 있어요`);
    return;
  }
  if (msg.from !== st.host) return;
  // "PC 원격제어": 그 PC 가 전체 화면 공유를 열고 번호를 보냈다 — 이 창이 그대로 전체 화면 보기가 된다(브라우저 연동 없이)
  if (msg.kind === 'pcCode' && S.mode === 'pc' && /^\d{9}$/.test(String(msg.code))) {
    st.room.send({ kind: 'pcGot', to: st.host, from: me });
    st.ended = true; // 이 창을 떠나도 '끊김' 처리를 하지 않는다
    setTimeout(() => location.replace(chrome.runtime.getURL(`remote.html?${new URLSearchParams({ ticket: msg.ticket, code: msg.code, dev: S.dev, name: S.name })}#view`)), 300);
    return;
  }
  if (msg.kind === 'offer') {
    const pc = (st.pc = new RTCPeerConnection({ iceServers: await iceServers() }));
    pc.ondatachannel = (e) => {
      const ch = e.channel;
      const read = wireReader(onWire);
      if (ch.label === 'ctl') {
        st.ctl = ch;
        ch.onmessage = (m) => read(m.data);
        return;
      }
      st.dc = ch;
      st.dc.onmessage = (m) => { net.bytes += m.data.length || 0; read(m.data); };
      st.dc.onopen = () => {
        st.opened = true;
        bg.postMessage({ type: 'rbLive', on: true });
        cover('화면을 받는 중…');
        send({ t: 'hello', video: true, ...wantSize() });
        send({ t: 'profiles' }); // 그 PC 의 프로필(위쪽 프로필 칩)
        // "PC 원격제어"로 이었으면 바로 그 PC 에 전체 화면 공유를 요청한다(원격 비밀번호로 이었으니 그 PC 에서 누를 것 없음)
        if (S.mode === 'pc' && !st.pcAsked) { st.pcAsked = true; send({ t: 'pcRemote' }); cover('PC 원격제어를 여는 중…'); }
        // 북마크 목록을 못 받았으면 다시 달라고 한다(2026-11-06 "원격지 북마크가 안 보여")
        for (const ms of [3000, 8000]) setTimeout(() => { if (!st.gotBookmarks && !st.ended) send({ t: 'getBookmarks' }); }, ms);
        // 원격 목록에서 [업데이트]로 이었으면 바로 업데이트를 시킨다
        if (S.update && !st.updAsked) { st.updAsked = true; setTimeout(updateHost, 500); }
      };
      st.dc.onclose = () => fail('연결이 끊겼어요.');
    };
    // 영상(그 PC 탭 화면) — 받는 대로 같은 화면 칸(canvas)에 그린다(누르기 위치 계산은 그대로)
    pc.ontrack = (e) => {
      if (e.track.kind !== 'video') return;
      const v = $('vid');
      v.srcObject = new MediaStream([e.track]);
      v.play().catch(() => {});
      st.video = v;
      drawVideo();
    };
    pc.onicecandidate = (e) => e.candidate && st.room.send({ kind: 'ice', to: st.host, from: me, candidate: e.candidate.toJSON() });
    // 한 번도 이어지지 못하고 실패: 두 PC 가 서로 찾았지만 인터넷(공유기·통신사 망)이 직접 연결을 막은 것 — 중계 서버가 필요하다
    pc.onconnectionstatechange = () => {
      if (!['failed', 'closed'].includes(pc.connectionState)) return;
      fail(st.opened ? '연결이 끊겼어요.' : `${S.name}을(를) 찾았지만 두 PC가 직접 이어지지 못했어요. 한쪽 인터넷(병원·회사 공유기, 휴대폰 핫스팟 등)이 직접 연결을 막는 경우예요.`);
    };
    await pc.setRemoteDescription(msg.sdp);
    await pc.setLocalDescription(await pc.createAnswer());
    st.room.send({ kind: 'answer', to: st.host, from: me, sdp: pc.localDescription.toJSON() });
  } else if (msg.kind === 'ice' && msg.candidate) st.pc?.addIceCandidate(msg.candidate).catch(() => {});
  else if (msg.kind === 'bye') fail('그 PC에서 연결을 끊었어요.');
}

function fail(text) {
  if (st.ended) return;
  if (S.quiet) {
    // 보이지 않는 칸: 다시 잇지 않고 끝낸다. 업데이트를 보낸 뒤 끊겼으면 설치가 시작된 것(다시 켜지는 중)
    st.ended = true;
    if (st.updating) { st.updating = false; tellParent({ ok: true }); } else if (text) tellParent({ error: text });
    try { send({ t: 'bye' }); st.room?.send({ kind: 'bye', to: st.host, from: me }); } catch {} // 그 PC 도 바로 '연결 끝'으로
    try { bg.postMessage({ type: 'rbLive', on: false }); } catch {}
    clearInterval(st.ringTimer);
    st.pc?.close();
    st.room?.close();
    st.inbox?.close();
    return;
  }
  if (st.updating) return reconnect(); // 업데이트로 끊긴 것 — 다시 켜지면 저절로 다시 잇는다
  st.ended = true;
  try { bg.postMessage({ type: 'rbLive', on: false }); } catch {}
  clearInterval(st.ringTimer);
  st.pc?.close();
  st.room?.close();
  st.inbox?.close();
  cover('연결이 끊겼어요', text, true);
  // 끊기면 창을 그대로 두고 [다시 연결]을 보인다(2026-11-07 "창 닫기는 그냥 할 수 있으니 재연결을 넣어줘").
  // 사용자가 [연결 끊기]를 누른 것은 그 단추가 창을 닫는다.
}

// 그 탭은 화면을 보낼 수 없다(새 탭·설정 화면 등) — 앞 탭의 화면이 남지 않게 지우고 알린다
function blankScreen(text = '') {
  const c = $('screen');
  c.getContext('2d').clearRect(0, 0, c.width, c.height);
  st.img = null;
  st.blank = true; // 영상이 남아 있어도 다시 그리지 않는다(다음 그림·영상이 오면 풀린다)
  // 새 탭이면 일반 새 탭과 같은 인사만(2026-11-09 "일반 새탭과 동일하게 메시지 띄워줘. 아래 단추들은 삭제")
  const url = st.tabs.find((t) => t.id === st.active)?.url || '';
  if (!url || /^chrome:\/\/newtab|^chrome-search:|\/newtab\.html/.test(url)) {
    const h = new Date().getHours();
    return cover(`${h < 5 ? '늦은 밤이에요' : h < 12 ? '좋은 아침이에요' : h < 18 ? '좋은 오후예요' : '좋은 저녁이에요'}. 무엇을 할까요?`, '', false, true);
  }
  cover('화면을 보낼 수 없는 탭이에요', text || '이 탭(설정 화면 등)은 보안상 화면을 보낼 수 없어요. 주소창에 주소를 넣거나 다른 탭을 고르세요.');
}
const NO_SCREEN = /^(chrome|chrome-extension|chrome-search|edge|devtools):/;
let pendingBlank = null; // 탭 목록보다 먼저 온 "화면 못 보냄"(새 탭을 열면 그쪽이 먼저 온다 — 2026-11-09 "새 탭에 이전 화면이 그대로")

function onWire(m) {
  if (m.t === 'tabs') {
    const was = st.active;
    st.tabs = m.list || []; st.active = m.active;
    if (!isPopup(m.active)) st.lastMain = m.active;
    // 팝업을 보는 동안 그 PC 화면 크기를 팝업 창 크기로 바꿨다 — 메인 탭으로 돌아오면(팝업이 닫혀도) 이 창 크기로 되돌린다.
    // 되돌리지 않아 메인 탭이 팝업 크기로 그려져 오른쪽이 비고 가로 스크롤이 생겼다(2026-11-09 "가상pc 화면크기가 예전과 달라졌어")
    if (!isPopup(m.active) && st.sizeFrom === 'popup') { st.sizeFrom = 'main'; send({ t: 'size', ...wantSize() }); }
    drawTabs(); syncPopups(); bg.postMessage({ type: 'rbActive', active: m.active, tabs: st.tabs.map((t) => ({ id: t.id, title: t.title || '', url: t.url || '' })) }); // AI 창은 원격 탭마다 대화가 따로(2026-11-09)
    // 새로 고른 탭이 화면을 보낼 수 없는 탭이면(새 탭 등) 앞 탭 화면을 바로 지운다
    const now = st.tabs.find((t) => t.id === m.active);
    if (pendingBlank?.tabId === m.active) { blankScreen(pendingBlank.text); pendingBlank = null; }
    else if (now && m.active !== was && NO_SCREEN.test(now.url || '')) blankScreen();
    // 보여 줄 탭이 없으면 옛 화면을 지우고 알린다(그 PC 에서 창을 다 닫은 때 등)
    if (m.active == null && !st.tabs.some((t) => !t.popup)) {
      const c = $('screen');
      c.getContext('2d').clearRect(0, 0, c.width, c.height);
      cover('열린 탭이 없어요', '위쪽 + 를 눌러 새 탭을 열어 주세요.');
    }
  }
  else if (m.t === 'aiRes') bg.postMessage({ type: 'rbRes', id: m.id, result: m.result });
  else if (m.t === 'profiles') { prof.items = m.items || []; drawProfChip(); if (prof.open && !prof.pinFor) drawProfMenu(); }
  else if (m.t === 'switching') switchingTo(m.name);
  else if (m.t === 'profileSwitch') profSwitchResult(m);
  else if (m.t === 'bookmarks') { st.gotBookmarks = true; drawBookmarks(m.items || []); }
  else if (m.t === 'dialog') showPageDialog(m);
  else if (m.t === 'pong') { net.rtt = performance.now() - m.at; drawNet(); }
  else if (m.t === 'quality') { net.level = m.name; net.levelNo = m.level; drawNet(); }
  else if (m.t === 'mode') { st.blank = false; st.mode = m.video ? 'video' : 'jpeg'; if (m.video) drawVideo(); }
  else if (m.t === 'frame') {
    if (m.tabId !== st.active || st.mode === 'video') return;
    const img = new Image();
    img.onload = () => { st.blank = false; st.img = img; st.w = m.w; st.h = m.h; st.frameAt = performance.now(); paint(); cover(''); };
    img.src = `data:image/jpeg;base64,${m.data}`;
  } else if (m.t === 'note') toast(m.text);
  else if (m.t === 'pw') pwBox(m);
  else if (m.t === 'blank') {
    if (m.tabId === st.active) blankScreen(m.text);
    else pendingBlank = { tabId: m.tabId, text: m.text }; // 탭 목록이 아직 옛 탭이면 기다렸다가
  }
  else if (m.t === 'askLocal') askLocal(m.site);
  else if (m.t === 'fileChooser') showFileChooser(m);
  else if (m.t === 'fileAck') fileAcks.get(`${m.i}:${m.seq}`)?.();
  else if (m.t === 'updating') {
    if (S.quiet) { st.updating = false; tellParent({ ok: Boolean(m.ok) }); return fail(''); }
    if (m.ok) return;
    st.updating = false;
    cover('');
    rememberUpdate({ has: false });
    toast('그 PC에 받을 업데이트가 없어요');
  }
  else if (m.t === 'panelView') { setAi(true); $('ai').contentWindow?.postMessage({ type: 'panelView', view: m.view }, location.origin); }
  else if (m.t === 'pcCode') {
    // 그 PC 가 화면을 골라 번호를 보냈다 — PC 원격제어 창을 열어 바로 잇는다(이 창은 브라우저 연동 그대로)
    const url = chrome.runtime.getURL(`remote.html?ticket=${encodeURIComponent(m.ticket)}&code=${encodeURIComponent(m.code)}#view`);
    chrome.windows.getCurrent().then((w) => chrome.windows.create({ url, type: 'popup', left: w.left + 40, top: w.top + 40, width: w.width, height: w.height, focused: true }))
      .catch(() => chrome.windows.create({ url, type: 'popup', focused: true }))
      .then((w) => { st.pcWin = w?.id ?? null; });
    toast('PC 원격제어 창을 열었어요.');
    // PC 원격제어로 이었으면 이 브라우저 연동 창은 내려 둔다(연결은 그대로 — 닫으면 원격도 끝난다)
    if (S.mode === 'pc') chrome.windows.getCurrent().then((w) => chrome.windows.update(w.id, { state: 'minimized' })).catch(() => {});
  }
}

// ---- 그 PC 의 팝업 창(2026-11-08 "팝업은 새 탭이 아니라 창으로 띄우면 좋겠어") ----
// 팝업은 탭 줄에 넣지 않고 같은 크기의 창(remote-popup.html)으로 띄운다. 화면은 하나만 오므로 손대는 창의 탭을 보내 달라고 한다 —
// 팝업 창을 쓰는 동안 이 창은 마지막 그림 그대로 멈춰 보인다(원격제어 화면처럼 뒤에 깔린 페이지).
const isPopup = (id) => !!st.tabs.find((t) => t.id === id)?.popup;
const popWins = new Map(); // 팝업 탭 id → 띄운 창 id
window.__rb = { key: me, st, send, isPopup };
// 은행 비밀번호 칸: 그 PC 가 화면을 멈추면 입력 칸을 띄운다 — 그 탭이 팝업이면 그 팝업 창 위에(2026-11-08)
function pwBox(m) {
  const views = chrome.extension.getViews();
  for (const v of views) { hidePw(v.document); if (!m.on) hidePill(v.document); }
  if (!m.on) return;
  const pop = views.find((v) => v.__pwId != null && v.__pwId === m.tabId);
  const win = pop || window;
  showPw(win.document, {
    onSend: (text, submit) => { send({ t: 'pwText', text, submit }); showPill(win.document); },
    onCancel: () => send({ t: 'pwCancel' }),
  });
  win.focus();
}
async function syncPopups() {
  const pops = st.tabs.filter((t) => t.popup);
  for (const t of pops) {
    if (popWins.has(t.id)) continue;
    popWins.set(t.id, null);
    const me0 = await chrome.windows.getCurrent().catch(() => null);
    const width = Math.min(Math.max(Number(t.ww) || 800, 360), screen.availWidth - 40);
    const height = Math.min(Math.max(Number(t.wh) || 600, 300), screen.availHeight - 40);
    const left = me0 ? Math.round(me0.left + Math.max((me0.width - width) / 2, 0)) : undefined;
    const top = me0 ? Math.round(me0.top + Math.max((me0.height - height) / 3, 0)) : undefined;
    const w = await chrome.windows.create({ url: `remote-popup.html?key=${me}&id=${t.id}`, type: 'popup', width, height, left, top, focused: t.id === st.active }).catch(() => null);
    if (!w) { popWins.delete(t.id); continue; }
    if (!st.tabs.some((x) => x.id === t.id)) { chrome.windows.remove(w.id).catch(() => {}); popWins.delete(t.id); continue; }
    popWins.set(t.id, w.id);
  }
  // 그 PC 에서 닫힌 팝업은 이쪽 창도 닫는다
  for (const [id, wid] of popWins) {
    if (pops.some((t) => t.id === id)) continue;
    popWins.delete(id);
    if (wid != null) chrome.windows.remove(wid).catch(() => {});
  }
}
// 팝업 창을 이쪽에서 닫으면 그 PC 의 팝업도 닫는다
chrome.windows.onRemoved.addListener((wid) => {
  for (const [id, w] of popWins) if (w === wid) { popWins.delete(id); if (st.tabs.some((t) => t.id === id)) send({ t: 'close', tabId: id }); }
});
// 이 창으로 돌아오면 원래 탭을 다시 보내 달라고 한다
window.addEventListener('focus', () => {
  if (!isPopup(st.active) || st.lastMain == null) return;
  send({ t: 'select', tabId: st.lastMain });
  st.sizeFrom = 'main';
  send({ t: 'size', ...wantSize() });
});
window.addEventListener('beforeunload', () => { for (const w of popWins.values()) if (w != null) chrome.windows.remove(w).catch(() => {}); });

function drawTabs() {
  const box = $('tabs');
  [...box.querySelectorAll('.tab,.plus')].forEach((x) => x.remove());
  for (const t of st.tabs) {
    if (t.popup) continue;
    const b = document.createElement('button');
    b.className = `tab${t.id === st.active ? ' on' : ''}`;
    b.title = t.title;
    const fav = t.favIconUrl ? Object.assign(document.createElement('img'), { src: t.favIconUrl, alt: '' }) : Object.assign(document.createElement('span'), { className: 'fav' });
    const title = Object.assign(document.createElement('span'), { className: 't', textContent: `${t.loading ? '⏳ ' : ''}${t.popup ? '팝업 · ' : ''}${t.title}` });
    const x = Object.assign(document.createElement('button'), { className: 'x', textContent: '✕', title: '이 탭 닫기(그 PC에서 닫혀요)' });
    x.addEventListener('click', (e) => { e.stopPropagation(); send({ t: 'close', tabId: t.id }); });
    b.append(fav, title, x);
    b.addEventListener('click', () => send({ t: 'select', tabId: t.id }));
    box.append(b);
  }
  const plus = Object.assign(document.createElement('button'), { className: 'plus', textContent: '+', title: '새 탭(그 PC에 열려요)' });
  plus.addEventListener('click', () => send({ t: 'newtab' }));
  box.append(plus);
  const a = st.tabs.find((t) => t.id === (isPopup(st.active) ? st.lastMain : st.active));
  if (document.activeElement !== $('url')) $('url').value = a?.url || '';
  document.title = `${a?.title || S.name} — ${S.name} 원격`;
}

// 그림을 이 창 화면 칸에 맞게 그린다(비율 그대로)
function viewSize() {
  const r = $('stage').getBoundingClientRect();
  return { w: Math.round(r.width), h: Math.round(r.height) };
}
// 그 PC 에 보낼 크기: 이 화면의 실제 점 수(레티나는 2배)로 받아야 글자가 또렷하다(2026-11-05 "화질 개선")
function wantSize() {
  // 그 PC 는 이 크기(CSS 점)로 탭을 그리고, dpr 배로 찍어 보낸다
  return { ...viewSize(), dpr: Math.min(window.devicePixelRatio || 1, 2) };
}
function paint() {
  if (isPopup(st.active) || st.blank) return; // 팝업 화면은 팝업 창이 그린다 — 이 창은 마지막 그림 그대로
  const src = st.mode === 'video' ? st.video : st.img;
  const iw = st.mode === 'video' ? src?.videoWidth : src?.width;
  const ih = st.mode === 'video' ? src?.videoHeight : src?.height;
  if (!src || !iw || !ih) return;
  const { w, h } = viewSize();
  // 화면 칸에 맞춘다(레티나용으로 2배로 받은 그림은 절반 크기로 그려 또렷하게, 작게 받은 그림은 2배까지 키운다)
  const k = Math.min(w / iw, h / ih, 2);
  const c = $('screen');
  const cw = `${Math.round(iw * k)}px`;
  const ch = `${Math.round(ih * k)}px`;
  if (c.style.width !== cw) c.style.width = cw;
  if (c.style.height !== ch) c.style.height = ch;
  if (c.width !== iw) c.width = iw;
  if (c.height !== ih) c.height = ih;
  c.getContext('2d').drawImage(src, 0, 0);
}
// 영상은 새 장면이 올 때마다 그린다
// (영상 정보와 영상 자체 중 늦게 온 쪽이 부른다. 새 장면 알림이 안 오는 경우를 위해 0.1초마다도 그린다)
let videoLoop = null;
function drawVideo() {
  const v = st.video;
  if (!v || st.mode !== 'video' || st.ended || videoLoop) return;
  let lastFrame = 0;
  const draw = () => { if (v.videoWidth && !st.blank) { paint(); cover(''); } };
  const next = () => { if (st.mode !== 'video' || st.ended) return; lastFrame = performance.now(); draw(); v.requestVideoFrameCallback(next); };
  if (v.requestVideoFrameCallback) v.requestVideoFrameCallback(next);
  videoLoop = setInterval(() => {
    if (st.mode !== 'video' || st.ended) { clearInterval(videoLoop); videoLoop = null; return; }
    if (performance.now() - lastFrame > 300) draw();
  }, 100);
}
let resizeT = null;
window.addEventListener('resize', () => { paint(); clearTimeout(resizeT); resizeT = setTimeout(() => send({ t: 'size', ...wantSize() }), 300); });

// ---- 누르기·입력 ----
const canvas = $('screen');
const pos = (e) => { const r = canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height }; };
const mods = (e) => (e.altKey ? 1 : 0) | (e.ctrlKey ? 2 : 0) | (e.metaKey ? 4 : 0) | (e.shiftKey ? 8 : 0);
canvas.addEventListener('mousedown', (e) => { e.preventDefault(); $('ime').focus(); send({ t: 'mouse', kind: 'down', ...pos(e), button: e.button, clicks: e.detail, mods: mods(e) }); });
canvas.addEventListener('mouseup', (e) => send({ t: 'mouse', kind: 'up', ...pos(e), button: e.button, clicks: e.detail, mods: mods(e) }));
let moveQ = null;
canvas.addEventListener('mousemove', (e) => { const p = pos(e); if (moveQ) { moveQ = p; return; } moveQ = p; requestAnimationFrame(() => { send({ t: 'mouse', kind: 'move', ...moveQ, mods: mods(e) }); moveQ = null; }); });
canvas.addEventListener('wheel', (e) => { e.preventDefault(); send({ t: 'mouse', kind: 'wheel', ...pos(e), dx: e.deltaX, dy: e.deltaY, mods: mods(e) }); }, { passive: false });
canvas.addEventListener('contextmenu', (e) => e.preventDefault());
// 글자는 숨은 입력칸으로 받는다(한글 조합도 그대로) — 특수 키·단축키만 키로 보낸다
const ime = $('ime');
const SPECIAL = new Set(['Enter', 'Backspace', 'Tab', 'Escape', 'ArrowLeft', 'ArrowUp', 'ArrowRight', 'ArrowDown', 'Delete', 'Home', 'End', 'PageUp', 'PageDown']);
// ⌘V·Ctrl+V 는 키로 보내지 않고 이 컴퓨터에 복사해 둔 글을 그대로 넣는다(2026-11-08 "대화창 숫자를 붙여넣기가 안 돼" —
// 키로 보내면 그 PC 의 클립보드를 붙이거나, 윈도우는 ⌘V 를 붙여넣기로 알아듣지 못했다)
const isPaste = (e) => (e.ctrlKey || e.metaKey) && !e.altKey && e.code === 'KeyV';
ime.addEventListener('keydown', (e) => {
  if (e.isComposing || isPaste(e)) return;
  if (SPECIAL.has(e.key) || e.ctrlKey || e.metaKey || e.altKey) { e.preventDefault(); send({ t: 'key', down: true, key: e.key, code: e.code, mods: mods(e) }); }
});
ime.addEventListener('keyup', (e) => { if (!e.isComposing && !isPaste(e) && (SPECIAL.has(e.key) || e.ctrlKey || e.metaKey || e.altKey)) send({ t: 'key', down: false, key: e.key, code: e.code, mods: mods(e) }); });
ime.addEventListener('paste', (e) => {
  e.preventDefault();
  // 엑셀 칸을 복사하면 끝에 줄바꿈이 붙는다 — 그대로 보내면 한 줄 칸에 안 들어가거나 비밀번호 칸 키 입력이 막혔다(2026-11-08)
  const text = (e.clipboardData?.getData('text/plain') || '').replace(/\r\n?/g, '\n').replace(/[\n\t ]+$/, '');
  for (let i = 0; i < text.length; i += 2000) send({ t: 'text', text: text.slice(i, i + 2000) });
  ime.value = '';
});
ime.addEventListener('compositionend', (e) => { if (e.data) send({ t: 'text', text: e.data }); ime.value = ''; });
ime.addEventListener('input', (e) => { if (e.isComposing) return; if (e.data) send({ t: 'text', text: e.data }); ime.value = ''; });
$('stage').addEventListener('click', () => ime.focus());

// ---- 주소창·메뉴 ----
$('url').addEventListener('keydown', (e) => { if (e.key === 'Enter' && $('url').value.trim()) { send({ t: 'nav', url: $('url').value.trim() }); ime.focus(); } });
$('back').addEventListener('click', () => send({ t: 'back' }));
$('fwd').addEventListener('click', () => send({ t: 'forward' }));
$('reload').addEventListener('click', () => send({ t: 'reload' }));
// 그 PC 브라우저의 권한 창(이 기기의 다른 앱 및 서비스)은 이 창에 안 보인다 — 지금 사이트를 그 PC 에서 묻지 않고 허용
// PC 원격제어로 바꾸기: 이 연결을 끝내고 같은 창에서 "PC 원격제어"로 다시 잇는다(2026-11-06 — 서로 바꾸기).
// 어느 PC 인지 모르는 옛 창이면 예전처럼 이 연결 위에서 연다
$('to-pc').addEventListener('click', async () => {
  if (!S.dev) return send({ t: 'pcRemote' });
  $('to-pc').disabled = true;
  const r = await chrome.runtime.sendMessage({ type: 'remoteSwitch', toDeviceId: S.dev, mode: 'pc' }).catch((err) => ({ error: err.message }));
  if (!r?.url) {
    $('to-pc').disabled = false;
    if (r?.reason === 'password') chrome.tabs.create({ url: chrome.runtime.getURL('remote-connect.html') });
    return toast(r?.reason === 'password' ? '비밀번호가 필요해요 — 원격 연결 화면에서 PC 원격제어를 골라 주세요.' : (r?.error || 'PC 원격제어로 바꾸지 못했어요.'));
  }
  send({ t: 'bye' });
  st.room?.send({ kind: 'bye', to: st.host, from: me });
  st.ended = true;
  setTimeout(() => location.replace(r.url), 300);
});
$('conn').addEventListener('click', (e) => { e.stopPropagation(); $('menu').classList.toggle('hidden'); });
document.addEventListener('click', () => $('menu').classList.add('hidden'));
// 내가 끊으면 바로 닫는다
$('disconnect').addEventListener('click', () => { send({ t: 'bye' }); st.room?.send({ kind: 'bye', to: st.host, from: me }); fail('연결을 끊었어요.'); window.close(); });
// "PC 원격제어"로 이었으면 PC 원격제어 창을 닫을 때 이 연결도 끝낸다(남아 있으면 그 PC 가 '사용 중'이라 다시 연결이 안 됐다 — 2026-11-06)
// PC 원격제어 창(이 연결 위에 따로 연 창)을 닫으면 이 연결도 끝낸다 — 끊으면 브라우저 연동으로 돌아오지 않고 그냥 끊긴다(2026-11-06)
chrome.windows.onRemoved.addListener((id) => { if (id === st.pcWin) $('disconnect').click(); });
window.addEventListener('beforeunload', () => { send({ t: 'bye' }); st.room?.send({ kind: 'bye', to: st.host, from: me }); });

start();

// ---- 그 PC 페이지의 파일 선택 창(2026-11-07 "브라우저 연동에서 사진을 눌러도 창이 안 떠") ----
// 그 PC 에서 [사진]·[파일]을 누르면 윈도우 선택 창 대신 여기서 고른다 → 조각으로 보내 그 PC 임시 칸에 쓰고 → 그 자리에 넣는다
const fileAcks = new Map();
let fileSeq = 0;
function showFileChooser(m) {
  $('fpick').multiple = Boolean(m.multiple);
  $('fpick').value = '';
  $('fdlg-msg').textContent = `이 맥에서 올릴 파일을 ${m.multiple ? '고르면(여러 개 됨)' : '하나 고르면'} 그 PC 페이지에 들어가요.`;
  $('fdlg-ok').disabled = false;
  $('fdlg').classList.remove('hidden');
}
$('fdlg-ok').addEventListener('click', () => $('fpick').click());
$('fdlg-no').addEventListener('click', () => { $('fdlg').classList.add('hidden'); send({ t: 'fileDone', cancel: true }); });
$('fpick').addEventListener('change', async () => {
  const files = [...$('fpick').files];
  if (!files.length) return;
  $('fdlg-ok').disabled = true;
  const total = files.reduce((a, f) => a + f.size, 0);
  let sent = 0;
  const CHUNK = 450 * 1024;
  try {
    for (const [i, f] of files.entries()) {
      for (let off = 0; off === 0 || off < f.size; off += CHUNK) {
        const buf = new Uint8Array(await f.slice(off, off + CHUNK).arrayBuffer());
        let bin = '';
        for (let k = 0; k < buf.length; k += 0x8000) bin += String.fromCharCode(...buf.subarray(k, k + 0x8000));
        const seq = ++fileSeq;
        // 그 PC 가 조각을 쓴 뒤 답할 때까지 기다린다(순서가 섞이지 않게)
        await new Promise((resolve, reject) => {
          const timer = setTimeout(() => { fileAcks.delete(`${i}:${seq}`); reject(new Error('그 PC가 답하지 않아요')); }, 30000);
          fileAcks.set(`${i}:${seq}`, () => { clearTimeout(timer); fileAcks.delete(`${i}:${seq}`); resolve(); });
          send({ t: 'fileData', i, seq, name: f.name, b64: btoa(bin) });
        });
        sent += buf.length;
        $('fdlg-msg').textContent = `보내는 중… ${Math.round((sent / Math.max(total, 1)) * 100)}% (${i + 1}/${files.length})`;
        if (!f.size) break;
      }
    }
    send({ t: 'fileDone' });
    $('fdlg').classList.add('hidden');
  } catch (err) {
    $('fdlg-msg').textContent = `보내지 못했어요: ${err.message}`;
    send({ t: 'fileDone', cancel: true });
    $('fdlg-ok').disabled = false;
  }
});

// ---- 그 PC 업데이트(2026-11-07 "원격지 브라우저에 업데이트가 있으면 업데이트 명령, 업데이트 후에는 자동 연결 가능") ----
// 그 PC 가 연결할 때 "받을 업데이트 있음"을 알려 주면 [⬆ 그 PC 업데이트] 를 보인다. 누르면 그 PC 가 설치하고 다시 켜지고,
// 이 창은 끊긴 채 기다리다가 그 PC 가 다시 켜지면 같은 방식으로 저절로 다시 잇는다(비밀번호는 이 PC 가 기억한 것으로).
function rememberUpdate(u) {
  $('rup').classList.toggle('hidden', !u?.has);
  if (!S.dev) return;
  chrome.storage.local.get('remoteUpdates').then(({ remoteUpdates = {} }) => {
    remoteUpdates[S.dev] = { has: Boolean(u?.has), version: u?.version || '', at: Date.now() };
    return chrome.storage.local.set({ remoteUpdates });
  }).catch(() => {});
}
function updateHost() {
  if (st.updating || !st.dc || st.dc.readyState !== 'open') return;
  st.updating = true;
  send({ t: 'update' });
  $('rup').classList.add('hidden');
  cover('그 PC를 업데이트하는 중…', `${S.name}의 Knock Browser가 업데이트 후 다시 켜지면 저절로 다시 연결해요 (1~3분)`);
}
$('rup').addEventListener('click', updateHost);
// 다시 잇기: 같은 PC 에 같은 방식으로 새 연결(이 PC 가 기억한 비밀번호). 다시 켜지는 중이면 15초마다, 6분까지
async function reconnect() {
  if (st.reconnecting) return;
  st.reconnecting = true;
  st.ended = true;
  try { bg.postMessage({ type: 'rbLive', on: false }); } catch {}
  clearInterval(st.ringTimer);
  st.pc?.close();
  st.room?.close();
  st.inbox?.close();
  const until = S.retry || Date.now() + 6 * 60 * 1000;
  cover('그 PC가 다시 켜지기를 기다리는 중…', `${S.name}이(가) 업데이트 후 다시 켜지면 저절로 연결해요`);
  if (!S.dev) return cover('다시 연결하지 못했어요', '원격 연결 화면에서 다시 [연결]을 눌러 주세요.', true);
  for (;;) {
    await new Promise((r) => setTimeout(r, 15000));
    const r = await chrome.runtime.sendMessage({ type: 'remoteSwitch', toDeviceId: S.dev, mode: S.mode }).catch((err) => ({ error: err.message }));
    if (r?.url) return location.replace(`${r.url}&retry=${until}`);
    if (r?.reason === 'password') return cover('다시 연결하지 못했어요', '이 PC에 그 PC 비밀번호가 기억되어 있지 않아요. 원격 연결 화면에서 다시 [연결]을 눌러 주세요.', true);
    if (Date.now() > until) return cover('다시 연결하지 못했어요', `${S.name}이(가) 아직 켜지지 않았어요. 잠시 뒤 원격 연결 화면에서 다시 [연결]을 눌러 주세요.`, true);
  }
}

// 창 안 Knock AI 창 열기·닫기(이 컴퓨터에 기억)
function setAi(on) {
  $('ai').classList.toggle('hidden', !on);
  $('ai-btn').classList.toggle('on', on);
  try { localStorage.setItem('rbAi', on ? '1' : '0'); } catch {}
  window.dispatchEvent(new Event('resize')); // 화면 칸 크기가 바뀌었으니 그 PC 에 알린다
}
let aiOn = true;
try { aiOn = localStorage.getItem('rbAi') !== '0'; } catch {}
setAi(aiOn);
$('ai-btn').addEventListener('click', () => setAi($('ai').classList.contains('hidden')));
// AI 창의 대화 속 링크는 그 PC 에 새 탭으로(이 맥에서 열지 않게)
window.addEventListener('message', (e) => {
  if (e.origin !== location.origin || e.source !== $('ai').contentWindow || e.data?.type !== 'openRemote' || typeof e.data.url !== 'string' || !/^https?:\/\//i.test(e.data.url)) return;
  if (st.dc?.readyState !== 'open') return toast('그 PC와 연결이 끊겨 링크를 열지 못했어요');
  send({ t: 'newtab', url: e.data.url });
});

// 그 PC 의 사이트가 보안 프로그램과 연결하려 할 때 — 그 PC 에 뜬 권한 창은 여기서 안 보이므로 AI 대화창에 카드로 묻는다(2026-11-08)
function askLocal(site) {
  if (typeof site !== 'string' || !site) return;
  setAi(true);
  $('ai').contentWindow?.postMessage({
    type: 'remoteAsk',
    id: `lna:${site}`,
    text: `${site} 사이트가 그 PC의 보안 프로그램(인증서·키보드 보안 등)과 연결하려고 해요. 허용할까요?\n허용하지 않으면 그 PC에 뜬 권한 창 때문에 페이지가 멈출 수 있어요.`,
    choices: [{ value: 'no', label: '허용 안 함' }, { value: 'once', label: '이번만 허용' }, { value: 'always', label: '항상 허용', primary: true }],
  }, location.origin);
}
window.addEventListener('message', (e) => {
  if (e.origin !== location.origin || e.source !== $('ai').contentWindow || e.data?.type !== 'remoteAskAnswer' || !String(e.data.id || '').startsWith('lna:')) return;
  send({ t: 'localAnswer', site: e.data.id.slice(4), pick: e.data.value });
});

// ---- 그 PC 의 북마크 줄 ----
// 누르면 그 PC 의 지금 탭에서 연다(⌘·Ctrl 누르고 누르면 새 탭). 폴더는 아래로 펼친다.
function openBm(url, e) {
  if (e && (e.metaKey || e.ctrlKey)) send({ t: 'newtab', url });
  else send({ t: 'nav', url });
  closePop();
}
let pop = null;
function closePop() { pop?.remove(); pop = null; }
function showFolder(items, x, y) {
  closePop();
  pop = Object.assign(document.createElement('div'), { className: 'bm-pop' });
  for (const it of items) {
    const b = Object.assign(document.createElement('button'), { textContent: it.url ? it.title : `📁 ${it.title} ›`, title: it.url || it.title });
    b.addEventListener('click', (e) => {
      e.stopPropagation();
      if (it.url) openBm(it.url, e);
      else { const r = b.getBoundingClientRect(); showFolder(it.children || [], r.right, r.top); }
    });
    pop.append(b);
  }
  if (!items.length) pop.append(Object.assign(document.createElement('button'), { textContent: '(비어 있음)', disabled: true }));
  document.body.append(pop);
  pop.style.left = `${Math.min(x, window.innerWidth - pop.offsetWidth - 8)}px`;
  pop.style.top = `${Math.min(y, window.innerHeight - pop.offsetHeight - 8)}px`;
}
document.addEventListener('click', () => closePop());
function drawBookmarks(items) {
  const bar = $('bm');
  bar.replaceChildren();
  for (const it of items) {
    const b = Object.assign(document.createElement('button'), { textContent: it.url ? it.title : `📁 ${it.title}`, title: it.url || it.title });
    b.addEventListener('click', (e) => {
      e.stopPropagation();
      if (it.url) return openBm(it.url, e);
      const r = b.getBoundingClientRect();
      showFolder(it.children || [], r.left, r.bottom + 2);
    });
    bar.append(b);
  }
  window.dispatchEvent(new Event('resize')); // 화면 칸 높이가 바뀌었다
}

// ---- 그 PC 페이지의 알림창(alert·confirm·prompt) ----
// 알림창은 화면 그림에 찍히지 않고, 답할 때까지 그 페이지가 멈춘다. 여기서 같은 창을 띄워 답을 그 PC 로 보낸다.
let pdlgType = '';
function showPageDialog(m) {
  if (m.closed) { $('pdlg').classList.add('hidden'); return; }
  pdlgType = m.type || 'alert';
  const a = st.tabs.find((t) => t.id === st.active);
  let site = '';
  try { site = new URL(a?.url || '').hostname; } catch {}
  $('pdlg-from').textContent = `${site || S.name} 내용:`;
  $('pdlg-msg').textContent = m.message || '';
  $('pdlg-in').classList.toggle('hidden', pdlgType !== 'prompt');
  $('pdlg-in').value = m.prompt || '';
  $('pdlg-no').classList.toggle('hidden', pdlgType === 'alert');
  $('pdlg').classList.remove('hidden');
  (pdlgType === 'prompt' ? $('pdlg-in') : $('pdlg-ok')).focus();
}
function answerPageDialog(accept) {
  send({ t: 'dialog', accept, ...(pdlgType === 'prompt' && accept ? { text: $('pdlg-in').value } : {}) });
  $('pdlg').classList.add('hidden');
  $('stage').focus();
}
$('pdlg-ok').addEventListener('click', () => answerPageDialog(true));
$('pdlg-no').addEventListener('click', () => answerPageDialog(false));
$('pdlg').addEventListener('keydown', (e) => {
  e.stopPropagation(); // 알림창에서 누른 키는 그 PC 페이지로 보내지 않는다
  if (e.key === 'Enter' && !e.isComposing) answerPageDialog(true);
  if (e.key === 'Escape') answerPageDialog(pdlgType === 'alert');
});

// ---- 연결 상태(2026-11-05) — 응답 시간·받는 속도·화질 단계. 느릴 때 인터넷 탓인지 바로 보이게 ----
const net = { rtt: null, bytes: 0, perSec: 0, level: '', levelNo: 2 };
setInterval(() => {
  net.perSec = net.bytes / 2;
  net.bytes = 0;
  if (st.dc?.readyState === 'open') send({ t: 'ping', at: performance.now() });
  drawNet();
}, 2000);
function drawNet() {
  const el = $('net');
  if (!el || st.ended || net.rtt == null) { el?.classList.add('hidden'); return; }
  // 한 단어만(2026-11-05 원장님): 원활 · 보통 · 지연 — 응답 시간 기준
  const sec = net.rtt / 1000;
  const state = sec < 0.3 ? 'good' : sec < 1 ? 'slow' : 'bad';
  el.className = `net ${state}`;
  el.textContent = state === 'good' ? '● 원활' : state === 'slow' ? '● 보통' : '● 지연';
  el.title = state === 'good' ? '연결이 원활해요.' : '그 PC 쪽 인터넷이 느려서 화질을 낮춰 보내고 있어요. 그 PC를 유선(랜선)으로 연결하면 나아져요.';
}


// ---------- 그 PC 의 프로필 고르기(2026-11-10 원장님 "원격에서도 프로필을 선택할 수 있어야해") ----------
// 탭 줄 앞 칩 → 그 PC 에서 쓰는 프로필 목록(잠김 표시) → 고르면 그 PC 가 그 프로필 창을 열고 이 연결을 그 프로필로 넘긴다.
// 잠긴 프로필은 칩 아래 PIN 창(피그마 ④ 화면 8·9).
const prof = { items: [], open: false, pinFor: null, pins: null, msg: null };
const pwrap = Object.assign(document.createElement('div'), { className: 'pwrap hidden' });
const pchip = Object.assign(document.createElement('button'), { className: 'pchip', type: 'button', title: '그 PC의 프로필 고르기' });
pwrap.append(pchip);
$('badge').after(pwrap);
function drawProfChip() {
  const cur = prof.items.find((p) => p.current);
  pwrap.classList.toggle('hidden', !prof.items.length);
  const d = Object.assign(document.createElement('span'), { className: 'pd' });
  if (cur?.color) d.style.background = cur.color;
  pchip.replaceChildren(d, document.createTextNode(cur?.name || '프로필'), document.createTextNode(' ⌄'));
}
function closeProfMenu() {
  prof.open = false;
  prof.pinFor = null;
  pwrap.querySelector('.pmenu')?.remove();
}
function drawProfMenu() {
  pwrap.querySelector('.pmenu')?.remove();
  const m = Object.assign(document.createElement('div'), { className: 'pmenu' });
  const list = [...prof.items].sort((x, y) => Number(y.current) - Number(x.current));
  for (const p of list) {
    const b = Object.assign(document.createElement('button'), { className: 'pi', type: 'button' });
    b.append(Object.assign(document.createElement('span'), { className: 'ck', textContent: p.current ? '✓' : '' }), Object.assign(document.createElement('span'), { className: 'nm', textContent: p.name }));
    if (p.locked) {
      const tag = Object.assign(document.createElement('span'), { className: 'tag' });
      tag.append(lockIcon(), document.createTextNode(p.noAsk ? '그 PC에서 묻지 않음' : '잠김'));
      b.append(tag);
    }
    b.addEventListener('click', () => {
      if (p.current) return closeProfMenu();
      if (p.locked && !p.noAsk) return drawProfPin(p);
      askSwitch(p, '');
    });
    m.append(b);
  }
  pwrap.append(m);
}
function drawProfPin(p, note = '') {
  prof.pinFor = p;
  pwrap.querySelector('.pmenu')?.remove();
  const m = Object.assign(document.createElement('div'), { className: 'pmenu pin' });
  const h = Object.assign(document.createElement('div'), { className: 'ph' });
  const d = Object.assign(document.createElement('span'), { className: 'pdot' });
  Object.assign(d.style, { width: '12px', height: '12px', background: p.color || 'var(--accent)' });
  h.append(d, document.createTextNode(p.name), lockIcon(16));
  const msg = Object.assign(document.createElement('p'), { className: `pin-msg${note ? ' bad' : ''}`, textContent: note });
  const no = Object.assign(document.createElement('label'), { className: 'chk-row' });
  const nb = Object.assign(document.createElement('input'), { type: 'checkbox' });
  no.append(nb, Object.assign(document.createElement('span'), { textContent: '그 PC에서는 더 묻지 않음' }));
  const pins = pinBoxes({ small: true, onFull: (pin) => { msg.className = 'pin-msg'; msg.textContent = '확인하는 중…'; pins.disable(true); askSwitch(p, pin, nb.checked); } });
  prof.pins = pins;
  prof.msg = msg;
  const acts = Object.assign(document.createElement('div'), { className: 'acts' });
  const cancel = Object.assign(document.createElement('button'), { type: 'button', textContent: '취소' });
  cancel.addEventListener('click', closeProfMenu);
  acts.append(cancel);
  m.append(h, Object.assign(document.createElement('p'), { className: 'pt', textContent: `잠긴 프로필입니다. PIN 6자리를 넣으면 ${p.name} 창으로 바뀌어요.` }), pins.el, msg, no, acts);
  pwrap.append(m);
  pins.focus();
}
function askSwitch(p, pin, noAsk = false) {
  if (!st.dc || st.dc.readyState !== 'open') return toast('연결이 끊겨 있어요.');
  send({ t: 'switchProfile', ...(p.id ? { id: p.id } : { dir: p.dir }), ...(pin ? { pin } : {}), noAsk });
  if (!pin) { closeProfMenu(); cover('프로필을 바꾸는 중…', `${S.name}에서 ${p.name} 창을 열고 있어요`); }
}
function profSwitchResult(r) {
  if (r.ok) return; // 곧 'switching' 이 온다
  if (prof.pinFor && (r.reason === 'pin' || r.reason === 'blocked' || /PIN/.test(r.error || ''))) {
    prof.pins?.disable(false);
    prof.pins?.clear();
    prof.pins?.bad(true);
    if (prof.msg) { prof.msg.className = 'pin-msg bad'; prof.msg.textContent = r.error || 'PIN이 맞지 않습니다.'; }
    prof.pins?.focus();
    return;
  }
  closeProfMenu();
  cover('');
  toast(r.error || '프로필을 바꾸지 못했어요.');
}
// 그 PC 의 다른 프로필이 이 연결을 넘겨받는다: 옛 연결을 '끊김' 없이 닫고, 같은 연결 방에서 새 프로필의 연결을 기다린다
function switchingTo(name) {
  closeProfMenu();
  cover('프로필을 바꾸는 중…', `${name || '그 프로필'} 창으로 다시 잇고 있어요`);
  const old = st.pc;
  if (st.dc) st.dc.onclose = null;
  if (old) old.onconnectionstatechange = null;
  st.host = null;
  st.dc = null;
  st.ctl = null;
  st.opened = false;
  st.gotBookmarks = false;
  setTimeout(() => old?.close(), 500);
  // 새 프로필이 15초 안에 잇지 못하면 끊김으로
  setTimeout(() => { if (!st.host && !st.ended) fail('다른 프로필로 다시 잇지 못했어요.'); }, 30000);
}
pchip.addEventListener('click', (e) => {
  e.stopPropagation();
  if (prof.open) return closeProfMenu();
  prof.open = true;
  drawProfMenu();
  send({ t: 'profiles' }); // 최신 목록으로 다시 그린다
});
pwrap.addEventListener('click', (e) => e.stopPropagation());
document.addEventListener('click', () => { if (prof.open) closeProfMenu(); });
