// 브라우저 연동: 은행 비밀번호 입력 칸(2026-11-08). 그 PC 가 비밀번호 칸에서 화면 보내기를 멈추면({t:'pw', on:true})
// 보는 창(또는 그 팝업 창) 위에 띄운다. 넣은 글은 원격 통로로만 보내고 어디에도 남기지 않는다.
export function showPw(doc, { onSend, onCancel }) {
  if (doc.getElementById('knock-pw')) return;
  const box = doc.createElement('div');
  box.id = 'knock-pw';
  box.innerHTML = `
    <style>
      #knock-pw { position: fixed; inset: 0; z-index: 2147483647; background: rgba(24,24,27,.45); display: flex; align-items: center; justify-content: center;
        font: 14px -apple-system, "Apple SD Gothic Neo", sans-serif; color: #18181b; }
      #knock-pw .c { width: min(380px, calc(100vw - 32px)); background: #fff; border-radius: 14px; padding: 20px; box-shadow: 0 12px 40px rgba(0,0,0,.25); }
      #knock-pw b { font-size: 16px; }
      #knock-pw p { margin: 8px 0 14px; color: #52525b; line-height: 1.5; font-size: 13px; }
      #knock-pw input[type=password] { width: 100%; box-sizing: border-box; font-size: 20px; letter-spacing: 4px; padding: 10px 12px; border: 1px solid #d4d4d8; border-radius: 10px; outline: none; }
      #knock-pw input[type=password]:focus { border-color: #f97316; }
      #knock-pw .b { display: flex; gap: 8px; justify-content: flex-end; margin-top: 14px; flex-wrap: wrap; }
      #knock-pw button { border: 0; border-radius: 9px; padding: 9px 14px; font: inherit; cursor: pointer; background: #f4f4f5; color: #18181b; }
      #knock-pw button.ok { background: #f97316; color: #fff; font-weight: 600; }
    </style>
    <div class="c" role="dialog" aria-label="은행 비밀번호 입력">
      <b>은행 비밀번호 입력</b>
      <p>보안 프로그램이 받을 수 있게 그 PC의 화면 보내기를 잠깐 멈췄어요. 여기에 넣으면 그 PC 키보드로 한 자씩 넣어요.</p>
      <input type="password" autocomplete="off" inputmode="numeric" aria-label="비밀번호">
      <div class="b">
        <button class="no">취소</button>
        <button class="only">넣기만</button>
        <button class="ok">넣고 [확인] 누르기</button>
      </div>
    </div>`;
  doc.body.append(box);
  const input = box.querySelector('input');
  const done = (submit) => {
    const text = input.value;
    input.value = '';
    if (!text) return input.focus();
    box.remove();
    onSend(text, submit);
  };
  // 이 칸의 키가 원격 화면 입력(ime)으로 새지 않게
  input.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); done(true); }
    if (e.key === 'Escape') { e.preventDefault(); box.remove(); onCancel(); }
  });
  box.querySelector('.ok').addEventListener('click', () => done(true));
  box.querySelector('.only').addEventListener('click', () => done(false));
  box.querySelector('.no').addEventListener('click', () => { input.value = ''; box.remove(); onCancel(); });
  setTimeout(() => input.focus(), 50);
}
export function hidePw(doc) { doc?.getElementById('knock-pw')?.remove(); }
