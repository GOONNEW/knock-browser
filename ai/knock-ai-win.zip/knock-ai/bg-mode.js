// 브라우저를 닫아도 원격 대기(2026-11-06 "크롬은 브라우저를 닫아놔도 원격데스크탑이 연결 되거든"):
// "내 장치 원격 허용"을 켠 PC 만 Knock AI 에 background 권한을 준다 → 창을 다 닫아도 Knock Browser 가 뒤에서 돌며
// (오른쪽 아래 아이콘 모음에 Knock 아이콘) 원격 연결을 기다리고, 윈도우를 켜면 창 없이 저절로 켜진다(본체의 뒤에서 돌기 기능).
// 권한 요청은 사용자가 누른 순간에만 되므로 Knock 화면을 누를 때 한 번 확인한다. 끄기(원격을 끔)는 background.js 가 한다.
export async function askBackgroundIfNeeded() {
  try {
    const { remoteHostOn } = await chrome.storage.local.get('remoteHostOn');
    if (!remoteHostOn || await chrome.permissions.contains({ permissions: ['background'] })) return;
    await chrome.permissions.request({ permissions: ['background'] });
  } catch {}
}
// 누를 때 한 번(권한이 이미 있으면 아무것도 안 한다)
export function watchClicksForBackground() {
  let busy = false;
  document.addEventListener('pointerdown', () => { if (!busy) { busy = true; askBackgroundIfNeeded().finally(() => { busy = false; }); } }, true);
}
