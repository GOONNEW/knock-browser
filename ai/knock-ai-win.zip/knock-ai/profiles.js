// 계정·프로필 기준안(2026-11-10 — 피그마 ④ 계정·프로필, 기준 요약 1~6).
// 1. 프로필 목록(이름·색·PIN 잠금 여부)은 똑소리 계정에 있다(/api/knock/profiles) — 모든 PC 에서 같다.
// 3. PC 마다 "이 PC 에서 쓸 프로필"을 고른다(도우미의 ~/.knock/pc-profiles.json — host/pc-profiles.js).
//    고르지 않은 프로필은 이 PC 에서 열리지 않는다(창이 뜨면 "이 PC 에서 쓰지 않는 프로필" 창으로 막는다).
// 4. PIN 잠금은 프로필마다 선택(숫자 6자리, 확인은 서버 — 5번 틀리면 5분).
// 5. 잠긴 프로필은 창을 열 때와 다른 프로필(AI 포함)이 그 내용을 가져갈 때 PIN 을 묻는다. 맥은 지문(Touch ID)으로도.
// 6. "이 PC 에서는 더 묻지 않음"은 이 PC 에만 — 설정의 [다시 묻기]로 되돌린다.
//
// 브라우저 프로필 하나마다 이 확장이 따로 돈다. 이 프로필이 계정의 어느 프로필인지는 storage.local.accountProfileId.
import { accountApi } from './account.js';

let H = null; // { askHost, askPeers, profileName, broadcast, updateToolbar }
export function initProfiles(deps) {
  H = deps;
}

const PIN_RE = /^\d{6}$/;
const ONCE_MS = 60 * 1000; // "이번만": 이 한 번(한 가지 일)만 — 1분 안
const IDLE_MS = 10 * 60 * 1000; // "브라우저를 닫을 때까지": 10분 쓰지 않으면 다시 잠김
const plainErr = (e) => (/fetch|network|Failed/i.test(String(e?.message || e)) ? '똑소리 서버에 연결하지 못했어요. 인터넷 연결을 확인한 뒤 다시 해 주세요.' : String(e?.message || e));

const local = (keys) => chrome.storage.local.get(keys);
const session = (keys) => chrome.storage.session.get(keys).catch(() => ({}));
export async function myPid() {
  return (await local('accountProfileId')).accountProfileId || '';
}
async function account() {
  const { knockAccount } = await local('knockAccount');
  return knockAccount ? String(knockAccount.account?.email || '') : '';
}
const host = (op, data = {}, ms = 20000) => H.askHost('pcProfiles', { op, ...data }, ms);

// ---------- 서버 목록 ----------
/** 계정의 프로필 목록 — 받은 것을 storage.local.accountProfiles 에 둔다(서버에 못 닿을 때·잠금 판단에 쓴다) */
export async function serverList(fresh = true) {
  if (!fresh) return (await local('accountProfiles')).accountProfiles?.list || [];
  const d = await accountApi('/api/knock/profiles');
  const list = Array.isArray(d.profiles) ? d.profiles : [];
  await chrome.storage.local.set({ accountProfiles: { at: Date.now(), list } });
  return list;
}
const act = (body) => accountApi('/api/knock/profiles', { method: 'POST', body });

/** 이 PC 설정 { pc, local } */
async function pcState() {
  const acct = await account();
  if (!acct) return { pc: { use: {}, noAsk: {}, peerNoAsk: {}, dirs: {}, picked: false }, local: [] };
  return host('get', { account: acct }).catch(() => ({ pc: { use: {}, noAsk: {}, peerNoAsk: {}, dirs: {}, picked: false }, local: [] }));
}
async function pcSet(patch) {
  const acct = await account();
  if (!acct) throw new Error('똑소리 계정으로 로그인해 주세요.');
  return (await host('set', { account: acct, patch })).pc;
}

// ---------- 프로필 맞추기(로그인했을 때 · 5분마다 · 설정을 열 때) ----------
let syncing = null;
export function syncProfiles() {
  syncing ||= (async () => {
    if (!(await account())) return null;
    let list;
    try { list = await serverList(true); } catch { return null; }
    let pid = await myPid();
    const meName = await H.profileName();
    if (!pid || !list.some((p) => p.id === pid)) {
      // 처음(또는 계정에서 지워짐): 이 프로필을 계정 목록에 올린다 — 같은 이름이 있으면 그것과 묶는다
      const { profileColor } = await local('profileColor');
      const r = await act({ action: 'adopt', name: meName, color: profileColor || '' }).catch(() => null);
      if (!r?.profile) return null;
      pid = r.profile.id;
      await chrome.storage.local.set({ accountProfileId: pid });
      list = await serverList(true).catch(() => list);
    }
    const me = list.find((p) => p.id === pid);
    // 다른 PC 에서 바꾼 이름·색을 이 PC 에도
    if (me) {
      const { profileColor } = await local('profileColor');
      const patch = {};
      if (me.name && me.name !== meName) Object.assign(patch, { profileName: me.name, profileNameSet: true });
      if (me.color && me.color !== profileColor) patch.profileColor = me.color;
      if (Object.keys(patch).length) await chrome.storage.local.set(patch);
    }
    // 이 프로필의 브라우저 폴더를 이 PC 설정에 적어 둔다(다른 프로필에서 이 프로필 창을 열 때 쓴다)
    const st = await pcState();
    if (!st.pc.dirs[pid]) {
      const { browserProfileName } = await local('browserProfileName');
      const names = new Set([browserProfileName, meName, me?.name].filter(Boolean));
      const found = st.local.filter((l) => names.has(l.name));
      let dir = found.length === 1 ? found[0].dir : '';
      // 이름으로 못 찾으면: 이 확장 저장소에 표를 적고 도우미가 그 표가 있는 프로필 폴더를 찾는다
      if (!dir) dir = await myDir();
      if (dir) await pcSet({ dirs: { [pid]: dir } }).catch(() => {});
    }
    // 이 PC 에서 이 프로필을 쓰는 중이니 "쓰기"로(처음 한 번 — 사용자가 끈 것은 그대로)
    if (st.pc.use[pid] === undefined) await pcSet({ use: { [pid]: true } }).catch(() => {});
    H.updateToolbar?.();
    return list;
  })().finally(() => { syncing = null; });
  return syncing;
}

let dirCache = '';
/** 이 프로필 폴더(한 번 찾으면 기억) */
export async function thisDir() {
  dirCache ||= await myDir();
  return dirCache;
}
/** 이 프로필의 브라우저 폴더(예: "Profile 2") — 저장소에 표를 적고 도우미가 그 표가 있는 폴더를 찾는다 */
async function myDir() {
  const marker = `knockdir-${crypto.randomUUID()}`;
  await chrome.storage.local.set({ dirMarker: marker });
  await new Promise((r) => setTimeout(r, 300));
  return (await host('whereAmI', { extId: chrome.runtime.id, marker }).catch(() => ({}))).dir || '';
}

// ---------- 화면에 줄 상태(설정 › 장치·프로필 · 로그인 다음 고르기 · 위쪽 프로필 메뉴) ----------
export async function profilesState() {
  const acct = await account();
  if (!acct) return { loggedIn: false, list: [] };
  let list;
  let error = '';
  try { list = (await syncProfiles()) || (await serverList(false)); } catch (e) { error = plainErr(e); list = await serverList(false); }
  const pid = await myPid();
  // 서버에 프로필 목록이 아직 없으면(서버를 새로 올리기 전·연결 안 됨) 예전 화면을 그대로 쓴다(로그인 안 한 것처럼)
  if (!list.length || !pid || !list.some((p) => p.id === pid)) return { loggedIn: false, unavailable: true, list: [], error };
  const { pc, local: locals } = await pcState();
  const running = new Map((await H.askPeers('whoami', {}, 1500)).filter((r) => r?.pid).map((r) => [r.pid, r]));
  const dirOf = (p) => pc.dirs[p.id] || locals.find((l) => l.name === p.name)?.dir || '';
  const rows = list.map((p) => {
    const dir = dirOf(p);
    const here = p.id === pid || Boolean(dir && locals.some((l) => l.dir === dir));
    return { ...p, current: p.id === pid, here, open: p.id === pid || running.has(p.id), use: p.id === pid ? true : pc.use[p.id] === undefined ? here : Boolean(pc.use[p.id]), noAsk: Boolean(pc.noAsk[p.id]) };
  });
  // 이 PC 에만 있고 아직 계정에 없는 브라우저 프로필(로그인하지 않은 프로필)
  const known = new Set([...rows.map((r) => dirOf(r)), ...Object.values(pc.dirs)].filter(Boolean));
  const names = new Set(rows.map((r) => r.name));
  const localOnly = locals.filter((l) => !known.has(l.dir) && !names.has(l.name)).map((l) => ({ dir: l.dir, name: l.name }));
  const touch = await H.askHost('profileKey', { action: 'check', id: '' }, 8000).catch(() => ({ available: false }));
  return { loggedIn: true, me: pid, list: rows, localOnly, picked: Boolean(pc.picked), touch: Boolean(touch.available), error };
}

/** 위쪽 프로필 메뉴(화면 7): 계정 목록이 있으면 이 PC 에서 쓰는 프로필, 없으면(서버 준비 전·로그인 안 함) 이 PC 의 브라우저 프로필 */
export async function menuState() {
  const st = await profilesState();
  if (st.loggedIn) {
    return { account: true, touch: st.touch, items: st.list.filter((p) => p.use).map((p) => ({ id: p.id, name: p.name, color: p.color, locked: p.locked, noAsk: p.noAsk, current: p.current })) };
  }
  const r = await host('get', { account: (await account()) || '-' }).catch(() => ({ local: [] }));
  const me = await thisDir();
  // 이름은 칩과 같게: 이 프로필·켜져 있는 프로필은 Knock Browser 에서 정한 이름, 꺼진 프로필은 브라우저 프로필 이름
  const { profileColor } = await local('profileColor');
  const running = new Map((await H.askPeers('whoami', {}, 1500)).filter((x) => x?.dir).map((x) => [x.dir, x]));
  const myName = await H.profileName();
  return { account: false, items: (r.local || []).map((l) => {
    const cur = l.dir === me;
    const peer = running.get(l.dir);
    return { dir: l.dir, name: cur ? myName : peer?.profile || l.name, color: cur ? profileColor || '' : peer?.color || '', current: cur };
  }) };
}
/** 계정 목록 없이: 이 PC 의 브라우저 프로필 창 열기 */
export async function openLocal(dir) {
  if (dir === (await myDir())) return { ok: true };
  await host('open', { dir });
  return { ok: true };
}

// ---------- 만들기 · 고치기 ----------
export async function createProfile({ name, color, pin, use = true }) {
  const r = await act({ action: 'create', name, color, ...(pin ? { pin } : {}) });
  await serverList(true).catch(() => {});
  if (use) await setUse(r.profile.id, true);
  return r.profile;
}
/** 이름·색 · PIN(켜기·바꾸기·끄기 — 이미 잠겼으면 currentPin) · 이 PC 에서 묻지 않음 */
export async function updateProfile({ id, name, color, pin, lockOff, currentPin, noAsk }) {
  // PIN 부터(지금 PIN 이 틀리면 이름·색도 바꾸지 않는다)
  if (lockOff || pin) {
    await act({ action: 'setPin', id, ...(lockOff ? { off: true } : { pin }), ...(currentPin ? { currentPin } : {}) });
    // 새 PIN 이면 지문에 둔 옛 PIN 은 지운다(다음에 PIN 을 넣으면 다시 둔다)
    H.askHost('profileKey', { action: 'remove', id }, 8000).catch(() => {});
  }
  if (name !== undefined || color !== undefined) await act({ action: 'update', id, ...(name !== undefined ? { name } : {}), ...(color !== undefined ? { color } : {}) });
  if (noAsk !== undefined) await pcSet({ noAsk: { [id]: noAsk ? true : null } });
  const list = await serverList(true);
  // 이 프로필이면 이름·색을 바로 이 창에도
  if (id === (await myPid())) await syncProfiles();
  else H.askPeers('profileChanged', { pid: id }, 2000).catch(() => {});
  return list.find((p) => p.id === id);
}
// ---------- 삭제(2026-11-12 원장님 "프로필 지우기 기능") ----------
/**
 * 프로필 하나를 지운다: 계정 목록(id 가 있으면, PIN 이 있으면 PIN 확인) → 그 프로필이 받은 장치 열쇠 끊기(원격 목록에서 빠짐)
 * → 이 PC 설정에서 빼기 → 이 PC 에 폴더가 있으면 프로필 고르기 화면을 열어 사용자가 [⋮ → 삭제]로 지우게 한다.
 * 지금 쓰는 프로필은 지우지 않는다.
 */
export async function deleteProfile({ id = '', dir = '', pin = '' }) {
  const me = await myPid();
  const myD = await thisDir();
  if ((id && id === me) || (dir && dir === myD)) throw new Error('지금 쓰는 프로필은 삭제할 수 없어요. 다른 프로필 창에서 삭제해 주세요.');
  const { pc, local: locals } = await pcState();
  let d = dir;
  if (id) {
    const p = (await serverList(false)).find((x) => x.id === id);
    d = pc.dirs[id] || (p && locals.find((l) => l.name === p.name)?.dir) || '';
    if (d && d === myD) throw new Error('지금 쓰는 프로필은 삭제할 수 없어요. 다른 프로필 창에서 삭제해 주세요.');
    await act({ action: 'delete', id, ...(pin ? { currentPin: pin } : {}) });
  }
  if (d) {
    const dev = await host('deviceOf', { dir: d, extId: chrome.runtime.id }).catch(() => ({}));
    if (dev.id) await accountApi('/api/knock/devices/logout', { method: 'POST', body: { id: dev.id } }).catch(() => {});
  }
  if (id) {
    await pcSet({ use: { [id]: null }, noAsk: { [id]: null }, dirs: { [id]: null } }).catch(() => {});
    H.askHost('profileKey', { action: 'remove', id }, 8000).catch(() => {});
  }
  // 이 PC 의 브라우저 프로필 폴더는 브라우저의 프로필 고르기 화면에서만 안전하게 지울 수 있다(확장은 chrome:// 화면에 손댈 수 없음 — 11-12 시험).
  // 그 화면을 열어 주고, 어느 카드를 지울지 알려 준다.
  const left = d ? locals.find((l) => l.dir === d) : null;
  if (left) await chrome.tabs.create({ url: 'chrome://profile-picker', active: true }).catch(() => {});
  await serverList(true).catch(() => {});
  return { ok: true, localName: left?.name || '' };
}

export async function markPicked() {
  await pcSet({ picked: true });
}
export async function askAgain(id) {
  await pcSet({ noAsk: { [id]: null } });
  // 이 PC 에서 그 프로필로 가져가기를 묻지 않게 한 것도 함께 되돌린다
  const { pc } = await pcState();
  const drop = Object.fromEntries(Object.keys(pc.peerNoAsk).filter((k) => k.endsWith(`>${id}`)).map((k) => [k, null]));
  if (Object.keys(drop).length) await pcSet({ peerNoAsk: drop });
}

/** 이 PC 에서 쓰기 켜기·끄기 — 켰는데 이 PC 에 없으면 새로 만든다(이 계정으로 로그인된 채로) */
export async function setUse(id, on) {
  if (!on && id === (await myPid())) throw new Error('지금 쓰고 있는 프로필은 끌 수 없어요. 다른 프로필 창에서 꺼 주세요.');
  await pcSet({ use: { [id]: Boolean(on) } });
  if (!on) { H.askPeers('profileChanged', { pid: id }, 2000).catch(() => {}); return { ok: true }; }
  const { pc, local: locals } = await pcState();
  const p = (await serverList(false)).find((x) => x.id === id);
  if (!p) throw new Error('프로필을 찾지 못했어요.');
  const dir = pc.dirs[id] || locals.find((l) => l.name === p.name)?.dir;
  if (dir && locals.some((l) => l.dir === dir)) {
    if (!pc.dirs[id]) await pcSet({ dirs: { [id]: dir } });
    H.askPeers('profileChanged', { pid: id }, 2000).catch(() => {});
    return { ok: true, here: true };
  }
  return makeHere(p);
}
/** 계정에 있는 프로필을 이 PC 에 새로 만든다: 같은 PC 이름으로 장치 열쇠를 받아 넘기고, 새 프로필 창을 연다 */
async function makeHere(p, dir0 = '') {
  const s = await act({ action: 'spawn', appVersion: chrome.runtime.getManifest().version });
  const { knockAccount } = await local('knockAccount');
  const dir = dir0 || (await host('newDir')).dir;
  await host('handoffPut', { data: { pid: p.id, name: p.name, color: p.color || '', dir, account: { origin: knockAccount.origin, token: s.token, device: s.device, account: s.account } } });
  await pcSet({ dirs: { [p.id]: dir }, use: { [p.id]: true } });
  // 새 프로필 창을 연다 — 그 프로필의 확장이 켜지며 자기 폴더로 넘겨 둔 로그인을 가져간다(claimSetup)
  await host('open', { dir });
  return { ok: true, made: true, dir };
}
/** 이 PC 에만 있던 브라우저 프로필을 계정 목록에 올린다(그 프로필이 켜질 때 이 계정으로 로그인된다) */
export async function adoptLocal({ dir, name }) {
  const r = await act({ action: 'adopt', name });
  const s = await act({ action: 'spawn', appVersion: chrome.runtime.getManifest().version });
  const { knockAccount } = await local('knockAccount');
  await host('handoffPut', { data: { pid: r.profile.id, name, dir, account: { origin: knockAccount.origin, token: s.token, device: s.device, account: s.account } } });
  await pcSet({ dirs: { [r.profile.id]: dir }, use: { [r.profile.id]: true } });
  // 켜져 있으면 바로 가져가게
  H.askPeers('profileChanged', { name }, 2000).catch(() => {});
  return r.profile;
}

/** 새 프로필이 처음 켜질 때(lock.html#setup=… 또는 이름이 같은 넘김): 로그인·프로필 번호·이름·색을 받는다 */
export async function claimSetup(nonce) {
  if ((await local('knockAccount')).knockAccount && (await myPid())) return { ok: true, already: true };
  const { browserProfileName } = await local('browserProfileName');
  let r = nonce ? await host('handoffTake', { nonce }).catch(() => ({})) : null;
  // 새로 만든 프로필: 이 확장 저장소에 표를 적어 이 프로필 폴더를 찾고, 그 폴더로 넘겨 둔 로그인을 가져간다
  if (!r?.data) {
    const dir = await myDir();
    if (dir) r = await host('handoffTake', { dir }).catch(() => ({}));
  }
  if (!r?.data && browserProfileName) r = await host('handoffTake', { name: browserProfileName }).catch(() => ({}));
  const d = r?.data;
  if (!d?.account?.token) return { ok: false };
  await chrome.storage.local.set({
    knockAccount: d.account, accountProfileId: d.pid,
    ...(d.name ? { profileName: d.name, profileNameSet: true } : {}), ...(d.color ? { profileColor: d.color } : {}),
  });
  await syncProfiles();
  return { ok: true, name: d.name };
}

// ---------- PIN 확인 ----------
/** 서버에 PIN 확인 → { ok } | { error, left, until } */
export async function verifyPin(id, pin) {
  if (!PIN_RE.test(String(pin || ''))) return { error: 'PIN 6자리를 넣어 주세요.' };
  try {
    await act({ action: 'verify', id, pin: String(pin) });
    // 맥: 다음부터 지문으로도 열 수 있게 PIN 을 키체인에(지문이 맞을 때만 꺼낸다)
    H.askHost('profileKey', { action: 'save', id, pin: String(pin) }, 8000).catch(() => {});
    return { ok: true };
  } catch (e) {
    return { error: plainErr(e), reason: e.reason || '' };
  }
}
export async function resetPin(id, password, pin) {
  try {
    await act({ action: 'reset', id, password, pin });
    H.askHost('profileKey', { action: 'remove', id }, 8000).catch(() => {});
    await serverList(true).catch(() => {});
    return { ok: true };
  } catch (e) {
    return { error: plainErr(e) };
  }
}
/** 맥 지문으로 PIN 꺼내기 → 확인까지 */
export async function touchPin(id, reason) {
  const r = await H.askHost('profileKey', { action: 'get', id, reason }, 70000).catch((e) => ({ error: e.message }));
  if (r.error || !r.pin) return { error: r.error || '지문을 확인하지 못했어요.' };
  const v = await verifyPin(id, r.pin);
  if (v.error && v.reason === 'pin') H.askHost('profileKey', { action: 'remove', id }, 8000).catch(() => {});
  return v.ok ? { ok: true, pin: r.pin } : v;
}

// ---------- 이 프로필 창 잠금(화면 5) ----------
/** 'open' 쓸 수 있음 · 'locked' PIN 필요 · 'unused' 이 PC 에서 쓰지 않는 프로필 */
export async function selfMode() {
  const pid = await myPid();
  if (!pid || !(await account())) return 'open';
  const { pc } = await pcState();
  if (pc.use[pid] === false) return 'unused';
  const me = (await serverList(false)).find((p) => p.id === pid);
  if (!me?.locked || pc.noAsk[pid]) return 'open';
  if ((await session('selfUnlocked')).selfUnlocked) return 'open';
  // 다른 프로필의 메뉴에서 PIN 을 넣고 연 경우(2분 안)
  if ((await host('unlockTake', { pid }).catch(() => ({}))).ok) {
    await chrome.storage.session.set({ selfUnlocked: true });
    return 'open';
  }
  return 'locked';
}
export async function selfUnlock(pin, noAsk) {
  const pid = await myPid();
  const v = await verifyPin(pid, pin);
  if (!v.ok) return v;
  await chrome.storage.session.set({ selfUnlocked: true });
  if (noAsk) await pcSet({ noAsk: { [pid]: true } }).catch(() => {});
  await guardWindows();
  return { ok: true };
}

// 잠긴 동안: 이 프로필의 보통 창을 내려 두고 잠금 창만 보인다. 잠금 창을 닫으면 이 프로필 창도 닫는다.
// 잠금 창은 주소(lock.html#open · #unused)로 찾는다(확장이 다시 켜져도 남은 것을 놓치지 않게).
const LOCK_URL = () => chrome.runtime.getURL('lock.html#');
async function lockWindows() {
  const all = await chrome.windows.getAll({ populate: true, windowTypes: ['popup'] }).catch(() => []);
  return all.filter((w) => w.tabs?.some((t) => /lock\.html#(open|unused)$/.test(t.url || t.pendingUrl || '') && (t.url || t.pendingUrl).startsWith(LOCK_URL())));
}
let guarding = null;
export function guardWindows() {
  guarding ||= guardNow().finally(() => { guarding = null; });
  return guarding;
}
async function guardNow() {
  const mode = await selfMode();
  const locks = await lockWindows();
  const { lowered } = await session('lowered');
  if (mode === 'open') {
    await chrome.storage.session.set({ lockWin: 0 });
    for (const w of locks) await chrome.windows.remove(w.id).catch(() => {});
    for (const id of lowered || []) await chrome.windows.update(id, { state: 'normal', focused: true }).catch(() => {});
    if (lowered?.length) await chrome.storage.session.set({ lowered: [] });
    return;
  }
  const wins = await chrome.windows.getAll({ windowTypes: ['normal'] });
  if (!wins.length && !locks.length) return; // 창이 없으면(배경만) 열릴 때 다시
  const low = new Set(lowered || []);
  for (const w of wins) {
    if (w.state !== 'minimized') await chrome.windows.update(w.id, { state: 'minimized' }).catch(() => {});
    low.add(w.id);
  }
  await chrome.storage.session.set({ lowered: [...low] });
  const want = mode === 'unused' ? 'unused' : 'open';
  const keep = locks.find((w) => w.tabs.some((t) => (t.url || t.pendingUrl).endsWith(`#${want}`)));
  for (const w of locks) if (w !== keep) await chrome.windows.remove(w.id).catch(() => {});
  if (keep) {
    await chrome.storage.session.set({ lockWin: keep.id });
    await chrome.windows.update(keep.id, { focused: true }).catch(() => {});
    return;
  }
  const w = await chrome.windows.create({ url: chrome.runtime.getURL(`lock.html#${want}`), type: 'popup', width: 520, height: want === 'unused' ? 300 : 470, focused: true });
  await chrome.storage.session.set({ lockWin: w.id });
}
/** 잠금 창을 닫았다 — 열지 않았으면 이 프로필의 창을 모두 닫는다 */
export async function lockClosed(winId) {
  const { lockWin } = await session('lockWin');
  if (!lockWin || winId !== lockWin) return;
  await chrome.storage.session.set({ lockWin: 0 });
  if ((await selfMode()) === 'open') return;
  for (const w of await chrome.windows.getAll({ windowTypes: ['normal'] })) await chrome.windows.remove(w.id).catch(() => {});
  await chrome.storage.session.set({ lowered: [] });
}
/** 잠긴 동안 보통 창이 앞으로 오면 다시 내린다 */
export async function onFocus(winId) {
  const { lockWin } = await session('lockWin');
  if (!lockWin || winId === lockWin || winId < 0) return;
  const w = await chrome.windows.get(winId).catch(() => null);
  if (w?.type === 'normal' && (await selfMode()) !== 'open') guardWindows();
}

// ---------- 다른 프로필이 이 프로필의 내용을 가져갈 때(화면 6) — 잠긴 쪽 ----------
// 묻는 쪽(args.__asker)마다 허락을 둔다: 이번만(1분) · 브라우저를 닫을 때까지(10분 쓰지 않으면 다시 잠김) · 이 PC 에서는 더 묻지 않음
const FREE_OPS = new Set(['rhostTakeover', 'whoami', 'focusProfile', 'saveForRestart', 'unlockPeer', 'selfUnlockFrom', 'profileChanged']);
export async function peerGate(op, args = {}) {
  if (FREE_OPS.has(op)) return null;
  const pid = await myPid();
  if (!pid) return null;
  const me = (await serverList(false)).find((p) => p.id === pid);
  if (!me?.locked) return null;
  const asker = String(args.__asker || '');
  const { pc } = await pcState();
  if (asker && pc.peerNoAsk[`${asker}>${pid}`]) return null;
  const { peerGrants = {} } = await session('peerGrants');
  const g = peerGrants[asker || '?'];
  const now = Date.now();
  if (g && now < g.until && now - g.last < (g.idle || IDLE_MS)) {
    g.last = now;
    await chrome.storage.session.set({ peerGrants });
    return null;
  }
  return { locked: true, pid, profile: me.name, color: me.color || '' };
}
/** 묻는 쪽이 받은 PIN 을 넘겨 온다 — 이 프로필이 직접 서버에 확인하고 허락을 둔다 */
export async function unlockPeer({ pin, asker, keep }) {
  const pid = await myPid();
  const v = await verifyPin(pid, pin);
  if (!v.ok) return v;
  const now = Date.now();
  if (keep === 'pc' && asker && !asker.startsWith('?')) {
    await pcSet({ peerNoAsk: { [`${asker}>${pid}`]: true } });
  } else {
    const { peerGrants = {} } = await session('peerGrants');
    peerGrants[asker || '?'] = keep === 'session' ? { until: Number.MAX_SAFE_INTEGER, idle: IDLE_MS, last: now } : { until: now + ONCE_MS, idle: ONCE_MS, last: now };
    await chrome.storage.session.set({ peerGrants });
  }
  return { ok: true };
}

// ---------- 묻는 쪽(이 프로필)이 잠긴 프로필 내용을 가져갈 때: PIN 창 → 그 프로필에 넘기기 ----------
const waits = new Map(); // 창 번호 → 끝났을 때 부를 것
let askSeq = 0;
/** 잠긴 프로필(r: { pid, profile, color })의 PIN 을 묻는다. why: "AI가 은행 로그인에 쓰려고 합니다" · what: "가져올 것: …" */
export async function askPeerPin(r, why, what) {
  const id = `a${Date.now().toString(36)}${++askSeq}`;
  const { profileColor } = await local('profileColor');
  const q = new URLSearchParams({ id, pid: r.pid, name: r.profile, color: r.color || '', why: why || '', what: what || '', me: await H.profileName(), mecolor: profileColor || '', asker: await myPid() });
  const w = await chrome.windows.create({ url: chrome.runtime.getURL(`lock.html#peer?${q}`), type: 'popup', width: 540, height: 680, focused: true });
  return new Promise((resolve) => {
    const done = (v) => { waits.delete(id); chrome.windows.onRemoved.removeListener(gone); resolve(v); };
    const gone = (wid) => { if (wid === w.id) done(false); };
    chrome.windows.onRemoved.addListener(gone);
    waits.set(id, { done, win: w.id });
  });
}
/** 화면 6 에서 [열기]: 잠긴 프로필이 켜져 있으면 그 프로필에 PIN 을 넘겨 확인시키고, 꺼져 있으면(서버에 올라온 대화) 여기서 확인한다.
 *  맞으면 이 프로필 쪽에도 같은 허락을 두고(서버에서 내려받는 대화용) 기다리던 일을 이어 간다 */
export async function peerAnswer({ id, pid, pin, keep }) {
  const mine = await myPid();
  const asker = mine || `?${await H.profileName()}`;
  const answers = await H.askPeers('unlockPeer', { pid, pin, asker, keep }, 15000);
  const r = answers.find((a) => a && a.pid === pid) || (await verifyPin(pid, pin));
  if (r.ok) {
    if (keep === 'pc' && mine) await pcSet({ peerNoAsk: { [`${mine}>${pid}`]: true } }).catch(() => {});
    else {
      const { cloudGrants = {} } = await session('cloudGrants');
      const now = Date.now();
      cloudGrants[pid] = keep === 'session' ? { until: Number.MAX_SAFE_INTEGER, idle: IDLE_MS, last: now } : { until: now + ONCE_MS, idle: ONCE_MS, last: now };
      await chrome.storage.session.set({ cloudGrants });
    }
    const w = waits.get(id);
    if (w) { chrome.windows.remove(w.win).catch(() => {}); w.done(true); }
  }
  return r;
}
/** 서버에서 내려받는 잠긴 프로필 대화: 이 프로필에 허락이 있나 */
export async function cloudAllowed(pid) {
  const mine = await myPid();
  if (mine && (await pcState()).pc.peerNoAsk[`${mine}>${pid}`]) return true;
  const { cloudGrants = {} } = await session('cloudGrants');
  const g = cloudGrants[pid];
  const now = Date.now();
  if (!g || now >= g.until || now - g.last >= g.idle) return false;
  g.last = now;
  await chrome.storage.session.set({ cloudGrants });
  return true;
}
export function peerCancel(id) {
  const w = waits.get(id);
  if (w) { chrome.windows.remove(w.win).catch(() => {}); w.done(false); }
}

// ---------- 다른 프로필 창 열기(위쪽 프로필 메뉴 — 화면 7~9) ----------
/** 잠긴 프로필이면 pin(또는 이 PC 에서 묻지 않음)이 있어야 연다. noAsk: "이 PC 에서는 더 묻지 않음" 체크 */
export async function openProfile({ id, pin, noAsk }) {
  const st = await profilesState();
  const p = st.list.find((x) => x.id === id);
  if (!p) return { error: '프로필을 찾지 못했어요.' };
  if (p.current) return { ok: true };
  if (!p.use) return { error: '이 PC에서 쓰지 않는 프로필이에요. 설정 › 장치·프로필에서 "이 PC에서 쓰기"를 켜 주세요.', reason: 'unused' };
  if (p.locked && !p.noAsk) {
    if (!pin) return { error: 'PIN 6자리를 넣어 주세요.', reason: 'pin' };
    const v = await verifyPin(id, pin);
    if (!v.ok) return v;
    if (noAsk) await pcSet({ noAsk: { [id]: true } });
  }
  // 켜져 있으면 그 프로필이 스스로 풀고 창을 앞으로
  if (p.open) {
    const r = (await H.askPeers('selfUnlockFrom', { pid: id, pin: pin || '', focus: true }, 8000)).find((a) => a?.pid === id);
    if (r?.ok) return { ok: true };
  }
  if (p.locked && !p.noAsk) await host('unlockPut', { pid: id });
  const { pc, local: locals } = await pcState();
  const dir = pc.dirs[id] || locals.find((l) => l.name === p.name)?.dir;
  if (!dir) return makeHere(p);
  await host('open', { dir });
  return { ok: true };
}

/** 다른 프로필이 물어올 때(peers) — background 의 answerPeer 앞에서 부른다 */
export async function answerProfileOp(op, args) {
  const pid = await myPid();
  if (op === 'unlockPeer') return args.pid === pid && pid ? { pid, ...(await unlockPeer(args)) } : null;
  if (op === 'selfUnlockFrom') {
    if (args.pid !== pid || !pid) return null;
    if ((await selfMode()) === 'locked') {
      const v = await verifyPin(pid, args.pin);
      if (!v.ok) return { pid, ...v };
      await chrome.storage.session.set({ selfUnlocked: true });
    }
    await guardWindows();
    const w = await chrome.windows.getLastFocused({ windowTypes: ['normal'] }).catch(() => null);
    if (w && args.focus) await chrome.windows.update(w.id, { focused: true, ...(w.state === 'minimized' ? { state: 'normal' } : {}) }).catch(() => {});
    else if (!w && args.focus) await chrome.windows.create({ focused: true }).catch(() => {}); // 창이 없으면 새 창
    return { pid, ok: true };
  }
  if (op === 'profileChanged') {
    if ((args.pid && args.pid === pid) || (args.name && !pid)) {
      if (!pid) await claimSetup('');
      await syncProfiles();
      await guardWindows();
      return { pid, ok: true };
    }
    return null;
  }
  return undefined; // 이 모듈이 다루지 않는 요청
}
