// 대화 하나(탭 하나)의 화면 기록. 백그라운드와 AI 창이 같은 규칙으로 사건(ev)을 쌓는다.
// items: { kind: 'user' | 'ai' | 'step' | 'error', text, note?, error?, files?, queued? }
// queued: AI 가 일하는 중에 덧붙여, 아직 AI 에게 전해지지 않은 말
// feedback: 사용자가 이 답에 보낸 개선 요청(ai 항목)
// confirm: 되돌리기 어려운 작업 전에 사용자에게 묻는 카드 { id, text, answer: null | 'yes' | 'no' }

export function newChat() {
  // sessions: AI 서비스별 대화 번호(claude·chatgpt·gemini) — 이어 말하기용
  // key: 지난 대화 보관함(브라우저를 다시 켜도 남는 곳)에서 이 대화를 가리키는 이름
  return { items: [], busy: false, sessions: {}, open: false, key: crypto.randomUUID() };
}

export function apply(chat, ev) {
  const last = chat.items[chat.items.length - 1];
  const closeAi = (asNote) => {
    if (chat.open && last?.kind === 'ai' && asNote) last.note = true; // 글 다음에 바로 도구를 쓰면 진행 메모다
    chat.open = false;
  };
  switch (ev.type) {
    case 'reset':
      Object.assign(chat, newChat());
      break;
    case 'user':
      closeAi(false);
      chat.items.push({ kind: 'user', text: ev.text || '', files: ev.files || [], queued: Boolean(ev.queued) });
      break;
    case 'delivered':
      for (const item of chat.items) item.queued = false;
      break;
    case 'text': {
      let delta = ev.delta;
      if (!chat.open || ev.fresh || last?.kind !== 'ai') {
        delta = delta.replace(/^\s+/, ''); // 도구를 쓴 뒤 이어지는 글 앞의 빈 줄
        if (!delta) break;
        if (chat.open && last?.kind === 'ai') last.note = true;
        chat.items.push({ kind: 'ai', text: '' });
        chat.open = true;
      }
      chat.items[chat.items.length - 1].text += delta;
      break;
    }
    case 'step':
      closeAi(true);
      chat.items.push({ kind: 'step', text: ev.text, error: Boolean(ev.error) });
      break;
    case 'error':
      closeAi(false);
      chat.items.push({ kind: 'error', text: ev.message });
      break;
    case 'confirm':
      closeAi(true);
      chat.items.push({ kind: 'confirm', id: ev.id, text: ev.text, choices: ev.choices, ...(ev.pick ? { pick: ev.pick } : {}), answer: null });
      break;
    // 비밀번호 직접 넣기 칸: 값은 여기에 절대 남기지 않는다(넣었는지·취소했는지만)
    case 'secret':
      closeAi(true);
      chat.items.push({ kind: 'secret', id: ev.id, text: ev.text, canSave: !!ev.canSave, fields: ev.fields || null, answer: null });
      break;
    case 'secretDone': {
      const item = chat.items.find((x) => x.kind === 'secret' && x.id === ev.id);
      if (item) item.answer = ev.ok ? (ev.remembered ? 'saved' : 'done') : 'cancel';
      break;
    }
    case 'confirmed': {
      const item = chat.items.find((x) => x.kind === 'confirm' && x.id === ev.id);
      if (item) Object.assign(item, { answer: ev.ok ? 'yes' : 'no', picked: ev.label });
      break;
    }
    case 'feedback':
      if (chat.items[ev.index]) chat.items[ev.index].feedback = ev.comment;
      break;
    case 'busy':
      chat.busy = ev.busy;
      if (!ev.busy) chat.open = false;
      break;
  }
  return chat;
}
