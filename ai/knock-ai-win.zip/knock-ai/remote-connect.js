// 원격 연결 화면(Figma ① 3·4 묶음 D·D-2·E-1·E-2·H-1~H-3) — 내 계정의 PC 목록, [연결], 이 컴퓨터 [+ 추가].
import { watchClicksForBackground } from './bg-mode.js';
import { openSignal } from './remote-signal.js';
const $ = (id) => document.getElementById(id);
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
const port = chrome.runtime.connect({ name: 'panel' });
let state = null; // { device, devices, account }
let adding = null; // null = 아직 안 정함(?add 로 열면 바로 펼침)
let target = null; // [연결]을 누른 PC
let updating = false; // [업데이트]로 연 연결 창인지
// 지난 연결 때 그 PC 가 알려 준 "받을 업데이트 있음"(remote-browser.js 가 적는다)
let ups = {};
chrome.storage.local.get('remoteUpdates').then(({ remoteUpdates }) => { ups = remoteUpdates || {}; if (state) draw(); }).catch(() => {});
chrome.storage.onChanged.addListener((c) => { if (c.remoteUpdates) { ups = c.remoteUpdates.newValue || {}; if (state) draw(); } });
const add = new URLSearchParams(location.search).has('add');
// 그룹(계정에 저장 — 2026-11-07): 잠긴 그룹은 이 화면에서 연 동안만 보인다(닫으면 다시 잠김)
let groups = []; // [{ id, name, locked }]
const opened = new Map(); // 연 잠긴 그룹 → 잠금 비밀번호(바꾸기·옮기기 때 서버에 함께 보낸다)
const folded = new Set(); // 접은 그룹('' = 그룹 없음)
let touch = false; // 이 맥에서 지문(Touch ID)을 쓸 수 있나
const keys = {}; // 지문으로 열기를 켠 그룹(맥 키체인에 잠금 비밀번호가 있음)
let sel = 'all'; // 왼쪽에서 고른 것: 'all'(모든 PC) · 그룹 id · 'none'(그룹 없음)

// 원격 [업데이트]의 결과(2026-11-09 "다시 시도해야 하는지, 실패인지 간단하게 분간"): 장치 → 기록
//   { s: 'run', at, from }  업데이트 중(보낸 때 · 그때의 속 번호) — 다시 켜져 번호가 바뀔 때까지
//   { s: 'retry', text }    다시 시도: 명령이 안 갔거나, 다시 켜졌는데 번호가 그대로 → [다시 업데이트]
//   { s: 'fail', text }     실패: 그 PC 가 설치 실패를 알렸거나, 8분이 지나도 다시 켜지지 않음 → 그 PC 확인
// 화면을 닫았다 열어도(이 컴퓨터가 업데이트로 다시 켜져도) 남게 저장한다
let upRec = {};
const upLoaded = chrome.storage.local.get('remoteUpRec').then(({ remoteUpRec }) => { upRec = remoteUpRec || {}; }).catch(() => {});
function setRec(id, rec) {
  if (rec) upRec[id] = rec; else delete upRec[id];
  chrome.storage.local.set({ remoteUpRec: upRec }).catch(() => {});
  if (state) draw();
}
const UP_RETRY_SEND = '⚠ 업데이트가 안 갔어요 · [다시 업데이트]를 눌러 주세요';
const UP_RETRY_SAME = '⚠ 업데이트가 안 됐어요 · [다시 업데이트]를 눌러 주세요';
const UP_FAIL_INSTALL = '⚠ 업데이트 실패 · 그 PC를 한 번 다시 시작한 뒤 [다시 업데이트]를 눌러 주세요';
const UP_FAIL_GONE = '⚠ 업데이트 실패 · 그 PC가 다시 켜지지 않았어요 · 그 PC를 확인해 주세요';
// 목록을 받으면: 업데이트 중이던 PC 는 이어서 기다린다(화면을 다시 연 경우)
async function resumeWaits() {
  await upLoaded;
  for (const d of state?.devices || []) if (upRec[d.id]?.s === 'run') waitUpdated(d);
}

port.onMessage.addListener((m) => {
  if (m.type === 'remoteState') { state = m; if (m.ok) adding = false; draw(); resumeWaits(); }
  if (m.type === 'account' && !m.loggedIn && !m.waiting) { state = { loggedOut: true }; draw(); }
  if (m.type === 'remoteTrusted' && target && m.toDeviceId === target.id) showPw(!m.trusted);
  if (m.type === 'remoteConnected' && target && m.toDeviceId === target.id) {
    $('dlg-ok').disabled = false;
    $('dlg-ok').textContent = '연결';
    if (m.error) { $('dlg-err').textContent = m.error; if (m.reason === 'password') { showPw(true); $('pw').select(); } }
    else closeDlg();
  }
});
port.postMessage({ type: 'remoteState' });
// 그 PC 에 짧게 묻는다(그 PC 화면엔 아무것도 안 뜬다): op 없음 = 받을 업데이트 있나? · 'update' = 업데이트해(창 없이)
// 답: { has, version, updating? } · 기억한 비밀번호가 없으면 { reason: 'notrust' } · 못 이으면 { error } · 답이 없으면 null
async function askPc(d, op = '', password = '') {
  const r = await chrome.runtime.sendMessage({ type: 'remoteProbeSession', toDeviceId: d.id, ...(password ? { password } : {}) }).catch(() => null);
  if (!r?.roomId) return r;
  const me = crypto.randomUUID();
  let got;
  const answer = new Promise((res) => { got = res; });
  const room = await openSignal(`room:${r.roomId}`, (m) => { if (m?.kind === 'info' && m.to === me) got({ ...(m.update || { has: false }), ...('updating' in m ? { updating: m.updating } : {}) }); }).catch(() => null);
  const inbox = await openSignal(`inbox:${r.inboxId}`, () => {}).catch(() => null);
  let u = null;
  if (room && inbox) {
    const ring = () => inbox.send({ kind: 'probe', sessionId: r.sessionId, from: me, ...(op ? { op } : {}) });
    ring();
    const timer = setInterval(ring, 3000);
    u = await Promise.race([answer, new Promise((res) => setTimeout(() => res(null), 12000))]);
    clearInterval(timer);
  }
  room?.close();
  inbox?.close();
  if (u && !op) await remember(d.id, u);
  return u;
}
async function remember(id, u) {
  const { remoteUpdates = {} } = await chrome.storage.local.get('remoteUpdates');
  const was = remoteUpdates[id] || {};
  remoteUpdates[id] = { has: Boolean(u.has), version: u.version || was.version || '', build: u.build || was.build || '', at: Date.now() };
  await chrome.storage.local.set({ remoteUpdates });
  // 다시 시도·실패라고 띄워 둔 PC 가 그 뒤 최신이 되었으면(그 PC 에서 직접 업데이트 등) 표시를 지운다
  const rec = upRec[id];
  if (rec && rec.s !== 'run' && !u.has && u.build && latestWin && newer(latestWin, u.build) <= 0) setRec(id, null);
}
// 비밀번호를 기억한 켜진 PC 에 "받을 업데이트 있나?"를 조용히 묻는다. 5분에 한 번
const probing = new Set();
async function probe(d) {
  // 업데이트 있음·속 번호가 최신보다 낮음이면 45초마다 — 끝난 것·새로 나온 것이 새로 고침 없이 보이게
  const cur = ups[d.id];
  const stale = cur?.has || !cur?.build || (latestWin && newer(latestWin, cur.build) > 0);
  const every = stale ? 45 * 1000 : 5 * 60 * 1000;
  if (probing.has(d.id) || upBusy[d.id] || (!probeAgain && Date.now() - (cur?.at || 0) < every)) return;
  probing.add(d.id);
  try { await askPc(d); } finally { probing.delete(d.id); }
  probeAgain = false;
}

// 이 컴퓨터의 버전·업데이트
const local = { parts: [], version: '', known: false };
let localBusy = false;
async function loadLocal() {
  const r = await chrome.runtime.sendMessage({ type: 'localUpdateState' }).catch(() => null);
  if (!r) return;
  Object.assign(local, { parts: r.parts || [], version: r.version || '', known: true });
  if (state) draw();
}
loadLocal();
setInterval(loadLocal, 60 * 1000);
function updateLocal() {
  if (localBusy) return;
  localBusy = true;
  if (state) draw();
  // AI 창의 [업데이트]와 같다: 탭·대화를 저장하고 설치한 뒤 다시 켠다(이 화면도 함께 닫혔다 열린다)
  port.postMessage({ type: 'updateNow' });
}
// 전체 업데이트: 원격 PC 들에 업데이트를 보낸 뒤(보내지기만 하면 됨 — 설치는 그 PC 가 혼자 한다) 이 컴퓨터를 업데이트한다
async function updateAll(pcs, withLocal = true) {
  const sent = pcs.map((d) => new Promise((resolve) => { updatePc(d, '', resolve); setTimeout(resolve, 90000); }));
  await Promise.all(sent);
  if (withLocal && local.parts.length) updateLocal();
}

// [업데이트]: 창을 띄우지 않고 그 PC 만 업데이트한다 — 다시 켜질 때까지 목록 줄에 진행을 보인다(2026-11-07)
const upBusy = {}; // 장치 → 'run'(업데이트 중 — 단추만 "업데이트 중") · '⚠ …'(못 함 — 까닭 글)
function setBusy(id, text) {
  if (text) upBusy[id] = text; else delete upBusy[id];
  if (state) draw();
}
async function updatePc(d, password = '', onSent = null) {
  if (upRec[d.id]) setRec(d.id, null);
  setBusy(d.id, 'run');
  const u = await askPc(d, 'update', password);
  // 전체 업데이트: 명령이 갔다(또는 못 갔다) — 다음으로. 옛 버전 PC 는 보이지 않는 칸으로 보낸 뒤에
  if (u?.updating !== undefined || !u || u.error || u.reason) onSent?.();
  if (u?.reason === 'notrust' || u?.reason === 'password') { setBusy(d.id, ''); return openDlg(d, true, u.reason === 'password' ? u.error : ''); }
  if (u?.error || !u) { setBusy(d.id, ''); return setRec(d.id, { s: 'retry', text: UP_RETRY_SEND, why: u?.error || '그 PC가 답하지 않아요' }); }
  // 그 PC 가 아직 옛 버전(묻기로 업데이트를 모름): 창 없이 이 화면 안에서 보이지 않게 잠깐 이어 업데이트를 보낸다
  const ok = u.updating === undefined ? await updateOld(d) : u.updating;
  if (u.updating === undefined) onSent?.();
  if (ok === null) return;
  if (!ok) {
    await remember(d.id, { has: false });
    return setBusy(d.id, '');
  }
  setRec(d.id, { s: 'run', at: Date.now(), from: ups[d.id]?.build || '' });
  await waitUpdated(d);
}
// 옛 버전 PC: 보이지 않는 칸(iframe)에 원격 브라우저를 열어 업데이트만 보내고 닫는다 → true(설치 시작) · false(받을 것 없음) · null(실패, 진행 글은 이미 보임)
async function updateOld(d) {
  setBusy(d.id, 'run');
  const r = await chrome.runtime.sendMessage({ type: 'remoteSwitch', toDeviceId: d.id, mode: 'browser' }).catch((err) => ({ error: err.message }));
  if (!r?.url) { setBusy(d.id, `⚠ ${r?.error || '그 PC에 잇지 못했어요'}`); setTimeout(() => setBusy(d.id, ''), 6000); return null; }
  const f = document.createElement('iframe');
  f.style.display = 'none';
  f.src = `${r.url}&update=1&quiet=1`;
  document.body.append(f);
  const res = await new Promise((done) => {
    const on = (e) => { if (e.source === f.contentWindow && e.data?.type === 'rbUpdate') { window.removeEventListener('message', on); done(e.data); } };
    window.addEventListener('message', on);
    setTimeout(() => { window.removeEventListener('message', on); done(null); }, 90000);
  });
  setTimeout(() => f.remove(), 3000);
  if (!res || res.error) {
    // 옛 버전 PC 는 두 PC 가 직접 이어져야 업데이트를 보낼 수 있다 — 막힌 인터넷이면 그 PC 에서 한 번만 직접 업데이트하면 다음부터는 이 단추로 된다
    const blocked = /직접 이어지지|답하지/.test(res?.error || '그 PC가 답하지 않아요');
    setBusy(d.id, blocked ? `⚠ 그 PC가 옛 버전이라 여기서 보낼 수 없어요 · 그 PC에서 한 번만 직접 [업데이트]를 눌러 주세요` : `⚠ ${res.error}`);
    setTimeout(() => setBusy(d.id, ''), 15000);
    return null;
  }
  return Boolean(res.ok);
}
const waiting = new Set();
async function waitUpdated(d) {
  // 그 PC 가 설치하고 다시 켜지는 동안: 20초마다 다시 물어 속 번호가 바뀌었는지 본다(보낸 때부터 8분까지)
  const rec = upRec[d.id];
  if (rec?.s !== 'run' || waiting.has(d.id)) return;
  waiting.add(d.id);
  setBusy(d.id, 'run');
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const done = (next) => { setBusy(d.id, ''); setRec(d.id, next); };
  try {
    const until = rec.at + 8 * 60 * 1000;
    if (Date.now() < rec.at + 30000) await sleep(rec.at + 30000 - Date.now());
    let sameSince = 0; // 다시 켜진 뒤 같은 번호로 답하기 시작한 때
    while (Date.now() < until) {
      const now = await askPc(d);
      const answered = now && !now.error && !now.reason && 'has' in now;
      // 그 PC 가 "설치 실패"를 알림(보낸 뒤의 것만 — 두 컴퓨터 시계 차이 1분 봐줌)
      if (answered && now.failed?.at > rec.at - 60000) return done({ s: 'fail', text: UP_FAIL_INSTALL, why: now.failed.why || '' });
      if (answered && ((rec.from && now.build && now.build !== rec.from) || (!rec.from && !now.has))) return done(null); // 끝: 새 번호
      if (!answered) sameSince = 0; // 꺼졌다 켜지는 중
      else if (!sameSince) sameSince = Date.now();
      else if (Date.now() - sameSince > 3 * 60 * 1000) return done({ s: 'retry', text: UP_RETRY_SAME }); // 켜져 있는데 번호 그대로
      await sleep(20000);
    }
    done({ s: 'fail', text: UP_FAIL_GONE });
  } finally { waiting.delete(d.id); }
}
setInterval(() => port.postMessage({ type: 'remoteState' }), 30000);
// 최신 버전(윈도우): 업데이트 서버의 속 번호 "본체-AI"
let latestWin = '';
let latestVer = ''; // 최신 버전 세 자리(예 11.9.0 — 2026-11-07 버전 규칙)
let probeAgain = false; // 최신 번호가 바뀌었으면 5분 기다리지 않고 모든 PC 에 다시 묻는다
async function loadLatest() {
  const f = await fetch(`https://hr.knocktools.com/api/knock/release/win?t=${Date.now()}`, { cache: 'no-store' }).then((r) => r.json()).catch(() => null);
  if (!f?.release) return;
  const v = `${f.release}-${f.ai?.release ?? 0}`;
  latestVer = f.ai?.ver || f.ver || '';
  if (v !== latestWin) {
    if (latestWin) probeAgain = true;
    latestWin = v;
    if (state) draw();
  }
}
loadLatest();
setInterval(loadLatest, 60 * 1000);
// 번호 비교("17-34" > "17-33")
// 업데이트 알약 글: 받을 번호가 지금 번호보다 높을 때만 번호를 보인다(2026-11-09 "현재 버전과 업데이트 버전이 같아" —
// 맥 개발판은 아직 번호를 올리지 않은 고침도 [업데이트]로 받아서, 같은 번호가 두 번 보였다)
const verNum = (v) => String(v || '').split('.').map(Number);
const verHigher = (a, b) => { const x = verNum(a); const y = verNum(b); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
// 번호가 같으면 알약을 띄우지 않는다([업데이트] 단추만) — "⬆ 새 고침"은 헷갈린다(2026-11-09 원장님 "새 고침 배지 삭제해")
const upLabel = (now) => (latestVer && verHigher(latestVer, now) ? `⬆ ver ${latestVer}` : '');
const newer = (a, b) => { const x = String(a).split('-').map(Number); const y = String(b).split('-').map(Number); return x[0] - y[0] || (x[1] || 0) - (y[1] || 0); };

// 아이콘(선 그림) — 피그마 D-9·D-10(11-07)
const ICON = {
  pc: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
  folder: '<path d="M4 6a2 2 0 0 1 2-2h4l2 2h6a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/>',
  none: '<path d="M4 6a2 2 0 0 1 2-2h4l2 2h6a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><path d="M9 13h6"/>',
  finger: '<path d="M8 11a4 4 0 0 1 8 0v2a8 8 0 0 1-1 4"/><path d="M12 11v3a10 10 0 0 1-2 6"/><path d="M5 13a7 7 0 0 1 12.5-6.5"/><path d="M19 11v1a12 12 0 0 1-.6 4"/><path d="M5 17a10 10 0 0 0 1-4"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
};
const icon = (name, cls = 'ic') => { const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', cls); s.innerHTML = ICON[name]; return s; };

function draw() {
  const body = $('body');
  const side = $('side');
  body.replaceChildren();
  side.replaceChildren();
  $('me').replaceChildren();
  $('me-form').replaceChildren();
  if (!state || state.loggedOut || state.error) {
    $('pc-view').classList.add('solo');
    const box = el('div', 'center');
    box.append(el('p', 'muted', state?.error && !state.loggedOut ? state.error : '원격은 똑소리툴즈 계정으로 Knock Browser에 로그인해야 써요.'));
    const b = el('button', 'btn primary', '로그인');
    b.addEventListener('click', () => port.postMessage({ type: 'accountLogin' }));
    box.append(b);
    body.append(box);
    return;
  }
  $('pc-view').classList.remove('solo');
  const me = state.device;
  const list = state.devices || [];
  const mine = list.find((d) => d.thisDevice) || { name: me.name, os: '' };
  if (adding === null) adding = add && !me.remoteEnabled;
  drawMe(me, mine);

  // 내 계정 연동 — 왼쪽 그룹 · 오른쪽 장치 상자(2026-11-07 피그마 D-9)
  const others = list.filter((d) => !d.thisDevice);
  const known = new Set(groups.map((g) => g.id));
  const groupOf = (d) => (d.groupId && known.has(d.groupId) ? d.groupId : '');
  const hidden = (d) => { const g = groups.find((x) => x.id === groupOf(d)); return Boolean(g?.locked && !opened.has(g.id)); };
  const canUp = (d) => d.online && d.remoteEnabled && d.hasPassword && !upBusy[d.id] && (ups[d.id]?.has || (d.os === 'Windows' && latestWin && ups[d.id]?.build && newer(latestWin, ups[d.id].build) > 0));
  const loose = others.filter((d) => !groupOf(d));
  if (sel !== 'all' && sel !== 'none' && !known.has(sel)) sel = 'all';
  if (sel === 'none' && !loose.length) sel = 'all';
  const item = (key, ic, label, count, cls = '') => {
    const b = el('button', `side-item${sel === key ? ' on' : ''}${cls ? ` ${cls}` : ''}`);
    b.append(icon(ic), el('span', 'grow-text', label));
    if (count !== '') b.append(el('span', 'count', String(count)));
    b.addEventListener('click', () => pick(key));
    side.append(b);
    return b;
  };
  side.append(el('div', 'side-label', '원격 연결'));
  item('all', 'pc', '모든 PC', others.filter((d) => !hidden(d)).length);
  side.append(el('div', 'side-label', '그룹'));
  for (const g of groups) {
    const shut = g.locked && !opened.has(g.id);
    const b = item(g.id, shut ? 'finger' : 'folder', g.name, shut ? '잠김' : others.filter((d) => groupOf(d) === g.id).length, shut ? 'locked' : '');
    b.title = shut ? '잠긴 그룹 — 눌러서 열어요' : '';
  }
  if (groups.length && loose.length) item('none', 'none', '그룹 없음', loose.length);
  const ng = el('button', 'side-item add');
  ng.append(icon('plus'), el('span', 'grow-text', '새 그룹'));
  ng.addEventListener('click', () => newGroup());
  side.append(ng);

  // 오른쪽: 고른 것의 제목 줄 + 장치 상자
  const head = el('div', 'head');
  const acts = el('div', 'head-acts');
  const g = groups.find((x) => x.id === sel);
  const shut = Boolean(g?.locked && !opened.has(g.id));
  const pcs = sel === 'all' ? others.filter((d) => !hidden(d)) : sel === 'none' ? loose : g ? others.filter((d) => groupOf(d) === g.id) : [];
  head.append(el('h2', '', sel === 'all' ? '모든 PC' : sel === 'none' ? '그룹 없음' : g.name));
  if (!shut) {
    const upN = pcs.filter(canUp).length;
    head.append(el('span', 'meta', `${pcs.length}대${pcs.length ? ` · ${pcs.filter((d) => d.online).length}대 켜짐` : ''}${upN ? ` · 업데이트 ${upN}대` : ''}`));
  }
  head.append(acts);
  if (sel === 'all') {
    // 전체 업데이트: 업데이트가 있는 원격 PC 들에 먼저 보내고(창 없이), 마지막에 이 컴퓨터(다시 켜짐) — 잠긴 그룹의 PC 는 빼고
    const upPcs = pcs.filter(canUp);
    const allN = upPcs.length + (local.parts.length && !localBusy ? 1 : 0);
    if (allN > 1 || (allN === 1 && upPcs.length && local.parts.length)) {
      const b = el('button', 'btn up small', `전체 업데이트 (${allN}대)`);
      b.title = '업데이트가 있는 PC 를 모두 업데이트해요 · 이 컴퓨터는 마지막에 다시 켜져요';
      b.addEventListener('click', () => updateAll(upPcs));
      acts.append(b);
    }
  } else if (g) {
    if (shut) {
      const o = el('button', 'btn small lockbtn');
      o.append(icon('finger', 'ic sm'), '잠김');
      o.title = keys[g.id] && touch ? '지문으로 열어요' : '잠금 비밀번호로 열어요';
      o.addEventListener('click', () => openGroup(g));
      acts.append(o);
    } else {
      const gUp = pcs.filter(canUp);
      if (gUp.length) {
        const u = el('button', 'btn up small', `그룹 업데이트 (${gUp.length}대)`);
        u.title = '이 그룹에서 업데이트가 있는 PC 만 업데이트해요 · 창은 열리지 않아요';
        u.addEventListener('click', () => updateAll(gUp, false));
        acts.append(u);
      }
      if (g.locked) {
        const l = el('button', 'btn small', '잠그기');
        l.title = '다시 잠가요(목록에서 가려져요)';
        l.addEventListener('click', () => { opened.delete(g.id); draw(); });
        acts.append(l);
      }
    }
    const more = el('button', 'btn small more', '⋯');
    more.title = '그룹 이름·잠금·지우기';
    more.addEventListener('click', (e) => { e.stopPropagation(); groupMenu(g, more); });
    acts.append(more);
  }
  body.append(head);
  if (shut) {
    const p = el('button', 'locked-box');
    p.append(icon('finger', 'ic lg'), el('span', '', '잠긴 그룹이에요 · 열면 PC가 보여요'));
    p.addEventListener('click', () => openGroup(g));
    body.append(p);
    return;
  }
  if (!pcs.length) {
    body.append(el('p', 'empty muted', !others.length ? '다른 PC가 없어요. 그 PC의 Knock Browser에서 같은 똑소리툴즈 계정으로 로그인해 주세요.' : sel === 'all' ? '보이는 PC가 없어요. 잠긴 그룹을 열면 보여요.' : '비어 있어요 · 장치 상자의 ⋯ 에서 이 그룹으로 옮겨요'));
    return;
  }
  const grid = el('div', 'tiles');
  for (const d of pcs) grid.append(pcCard(d));
  body.append(grid);
}
function pick(key) {
  sel = key;
  chrome.storage.local.set({ remoteGroupSel: key }).catch(() => {});
  const g = groups.find((x) => x.id === key);
  if (g?.locked && !opened.has(g.id)) { draw(); return openGroup(g); }
  draw();
}

// 이 컴퓨터(위 줄 오른쪽) · [+ 추가]/[수정]을 누르면 아래에 이름·비밀번호 칸
function drawMe(me, mine) {
  const c = el('div', 'me-card');
  c.append(el('span', `dot${me.remoteEnabled ? ' on' : ''}`), el('b', '', mine.name), el('span', 'tag', '이 컴퓨터'));
  // 이 컴퓨터의 버전·업데이트(2026-11-07 "내 맥 업데이트도 표시")
  const localUp = local.parts.length > 0;
  const lv = el('span', 'meta grow-text', local.version ? `ver ${local.version}` : '개발 버전');
  // 업데이트 표시는 PC 상자와 같은 초록 알약(2026-11-08 "이 컴퓨터 업데이트 배지도 동일하게")
  if (localUp) { if (upLabel(local.version)) lv.append(' ', el('span', 'tile-up', upLabel(local.version))); }
  else if (local.known) lv.append(' · 최신 ✓');
  c.append(lv);
  if (localUp) {
    const u = el('button', `btn up small${localBusy ? ' busy' : ''}`, localBusy ? '업데이트 중' : '업데이트');
    u.title = '이 컴퓨터의 Knock Browser를 업데이트하고 다시 켜요(탭·대화는 그대로 돌아와요)';
    u.disabled = localBusy;
    u.addEventListener('click', () => updateLocal());
    c.append(u);
  }
  const b = el('button', 'btn soft small', me.remoteEnabled ? '수정' : '+ 추가');
  b.title = me.remoteEnabled ? '이 컴퓨터의 원격 이름·비밀번호' : '이 컴퓨터를 원격 목록에 추가해요';
  b.addEventListener('click', () => { adding = !adding; draw(); });
  c.append(b);
  $('me').append(c);
  if (!adding) return;
  const box = el('div', 'me-form');
  box.append(el('h3', '', me.remoteEnabled ? '이 컴퓨터 원격 설정' : '이 컴퓨터를 원격 목록에 추가해요'));
  const f = el('div', 'form');
  const name = Object.assign(el('input'), { type: 'text', value: mine.name, maxLength: 30 });
  const pw = Object.assign(el('input'), { type: 'password', placeholder: me.remoteEnabled ? '새 비밀번호(바꿀 때만 · 6자 이상)' : '다른 PC에서 들어올 때 쓸 비밀번호(6자 이상)', autocomplete: 'new-password' });
  const err = el('p', 'err');
  const acts = el('div', 'acts');
  const cancel = el('button', 'btn', '취소');
  const ok = el('button', 'btn primary', me.remoteEnabled ? '저장' : '추가');
  cancel.addEventListener('click', () => { adding = false; draw(); });
  ok.addEventListener('click', () => {
    const needPw = !me.remoteEnabled || pw.value;
    if (needPw && pw.value.length < 6) { err.textContent = '비밀번호는 6자 이상으로 정해 주세요.'; return pw.focus(); }
    ok.disabled = true;
    chrome.permissions.request({ permissions: ['background'] }).catch(() => {}); // 원격을 켜면 브라우저를 닫아도 원격 대기
    port.postMessage({ type: 'remoteSet', patch: { name: name.value.trim() || mine.name, ...(pw.value ? { remotePassword: pw.value } : {}), remoteEnabled: true }, okText: '저장했어요' });
  });
  if (me.remoteEnabled) {
    const offBtn = el('button', 'btn', '원격 끄기');
    offBtn.addEventListener('click', () => port.postMessage({ type: 'remoteSet', patch: { remoteEnabled: false }, okText: '원격을 껐어요' }));
    acts.append(offBtn);
  }
  acts.append(cancel, ok);
  f.append(el('span', 'muted', 'PC 이름'), name, el('span', 'muted', '비밀번호'), pw, el('span'), err, acts);
  box.append(f);
  $('me-form').append(box);
  setTimeout(() => pw.focus(), 0);
}

// 장치 상자(피그마 "장치 상자" 부품): 평소엔 상태만, 마우스를 올리면 ⋯ 과 [업데이트]·[연결](같은 크기)
function pcCard(d) {
  const ready = d.online && d.remoteEnabled && d.hasPassword;
  if (ready) probe(d);
  // 그 PC 가 "받을 업데이트 있음"이라고 했거나, 속 번호가 최신보다 낮으면(그 PC 가 아직 새 업데이트를 모를 때) 업데이트 있음
  const cur = ups[d.id];
  const behind = d.os === 'Windows' && latestWin && cur?.build ? newer(latestWin, cur.build) > 0 : false;
  const up = Boolean(cur?.has || behind);
  const busy = upBusy[d.id];
  const t = el('div', `tile${ready ? '' : ' off'}`);
  t.tabIndex = 0;
  const top = el('div', 'tile-top');
  top.append(el('span', 'os', d.os === 'Windows' ? 'Windows' : 'Mac'), el('span', `dot${d.online ? ' on' : ''}`));
  const more = el('button', 'tile-more', '⋯');
  more.title = '그룹 옮기기';
  more.addEventListener('click', (e) => { e.stopPropagation(); moveMenu(d, more); });
  top.append(more);
  const seen = d.online ? (d.remoteEnabled ? '켜져 있음' : '켜져 있음 · 원격 꺼짐') : `마지막 ${new Date(d.lastSeenAt).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false })}`;
  // 이름 아래 글: 잠깐 경고 > 업데이트 중 > 다시 시도·실패 > 켜짐/꺼짐
  const rec = busy ? null : upRec[d.id];
  const run = busy === 'run' || rec?.s === 'run';
  const sub = el('div', 'tile-sub', busy && busy !== 'run' ? busy : run ? '업데이트 중 · 다시 켜질 때까지 기다려요' : rec?.text || seen);
  if (busy && busy !== 'run') sub.classList.add('warn');
  else if (run) sub.classList.add('run');
  else if (rec?.s === 'fail') sub.classList.add('warn');
  else if (rec?.s === 'retry') sub.classList.add('retry');
  if (rec?.why) sub.title = rec.why;
  const nm = el('div', 'tile-name', d.name);
  nm.title = d.name;
  if (run) t.classList.add('busy');
  t.append(top, nm, sub);
  const ver = el('span', 'tile-ver', cur?.version ? `ver ${cur.version}` : '');
  ver.title = `속 번호 — 이 PC ${cur?.build || '모름'} · 최신 ${latestWin || '확인 중'}${latestVer ? ` (ver ${latestVer})` : ''}`;
  // 평소: 버전 · 상태
  const foot = el('div', 'tile-foot');
  foot.append(ver.cloneNode(true));
  if (run) foot.append(el('span', 'tile-state', '업데이트 중'));
  else if (!ready) foot.append(el('span', 'tile-state', !d.online ? '꺼져 있음' : '원격 꺼짐'));
  else if (up) { if (upLabel(cur?.version)) foot.append(el('span', 'tile-up', upLabel(cur?.version))); }
  else if (cur) foot.append(el('span', 'tile-state', '최신 ✓'));
  t.append(foot);
  if (ready || run) {
    // 마우스를 올리면(또는 업데이트 중이면 늘): 단추 — 업데이트 중에는 다시 켜지느라 꺼져 보여도 "업데이트 중"을 둔다
    const acts = el('div', 'tile-acts');
    const btns = el('span', 'tile-btns');
    if (run) {
      const u = el('button', 'btn up xs busy', '업데이트 중');
      u.disabled = true;
      btns.append(u);
    } else {
      if ((up || rec) && !busy) {
        const u = el('button', 'btn up xs', rec ? '다시 업데이트' : '업데이트');
        u.title = '그 PC의 Knock Browser를 업데이트하고 다시 켜요 · 창은 열리지 않아요';
        u.addEventListener('click', (e) => { e.stopPropagation(); updatePc(d); });
        btns.append(u);
      }
      const c = el('button', 'btn primary xs', '연결');
      c.addEventListener('click', (e) => { e.stopPropagation(); openDlg(d); });
      btns.append(c);
    }
    if (btns.children.length < 2) acts.append(ver);
    acts.append(btns);
    t.append(acts);
    t.addEventListener('click', () => { if (ready && !run) openDlg(d); });
    t.addEventListener('keydown', (e) => { if (ready && !run && e.key === 'Enter' && e.target === t) openDlg(d); });
  } else {
    t.title = !d.online ? `${d.name}가 꺼져 있어요 · 그 PC를 켜고 Knock Browser를 열면 연결할 수 있어요` : `${d.name}는 원격을 켜지 않았어요 · 그 PC 설정 › 장치·프로필에서 원격을 켜 주세요`;
    t.addEventListener('click', () => toast(t.title));
  }
  return t;
}

// ---------- 그룹(계정에 저장 · 잠금 · 맥 지문으로 열기 — 2026-11-07) ----------
async function loadGroups() {
  const r = await chrome.runtime.sendMessage({ type: 'remoteGroups' }).catch(() => null);
  if (!r || r.error || !Array.isArray(r.groups)) return;
  groups = r.groups;
  for (const id of [...opened.keys()]) if (!groups.some((g) => g.id === id && g.locked)) opened.delete(id);
  if (touch) {
    await Promise.all(groups.filter((g) => g.locked).map(async (g) => {
      keys[g.id] = Boolean((await chrome.runtime.sendMessage({ type: 'groupKey', action: 'check', id: g.id }).catch(() => null))?.has);
    }));
  }
  if (state) draw();
}
chrome.runtime.sendMessage({ type: 'groupKey', action: 'check' })
  .then((r) => { touch = Boolean(r?.available); }, () => {})
  .finally(() => loadGroups());
setInterval(loadGroups, 30000);
chrome.storage.local.get('remoteGroupFold').then(({ remoteGroupFold }) => { for (const id of remoteGroupFold || []) folded.add(id); if (state) draw(); }).catch(() => {});
function toggleFold(id) {
  if (folded.has(id)) folded.delete(id); else folded.add(id);
  chrome.storage.local.set({ remoteGroupFold: [...folded] }).catch(() => {});
  draw();
}
const act = (body) => chrome.runtime.sendMessage({ type: 'remoteGroupAct', body }).catch((err) => ({ error: err.message }));
async function saveKey(id, password) {
  const r = await chrome.runtime.sendMessage({ type: 'groupKey', action: 'save', id, password }).catch(() => null);
  keys[id] = Boolean(r?.ok);
}
async function dropKey(id) {
  if (keys[id]) await chrome.runtime.sendMessage({ type: 'groupKey', action: 'remove', id }).catch(() => {});
  keys[id] = false;
}
function toast(text) {
  document.querySelector('.toast')?.remove();
  const t = el('div', 'toast', text);
  document.body.append(t);
  setTimeout(() => t.remove(), 4000);
}

// 그룹 작은 창 — fields [{ key, type, placeholder, value }] · submit(값, 지문 켬) → 오류 글('' 이면 닫는다)
function form({ title, sub = '', fields = [], okText = '확인', danger = false, touchBox = false, submit }) {
  $('g-title').textContent = title;
  $('g-sub').textContent = sub;
  const inputs = {};
  $('g-fields').replaceChildren(...fields.map((f) => {
    const i = Object.assign(el('input'), { type: f.type || 'text', placeholder: f.placeholder || '', value: f.value || '', autocomplete: 'off', maxLength: f.type === 'password' ? 64 : 30 });
    i.addEventListener('keydown', (e) => e.key === 'Enter' && $('g-ok').click());
    inputs[f.key] = i;
    return i;
  }));
  $('g-touch-row').classList.toggle('hidden', !touchBox);
  $('g-touch').checked = true;
  $('g-err').textContent = '';
  const ok = $('g-ok');
  ok.textContent = okText;
  ok.className = `btn ${danger ? 'danger' : 'primary'}`;
  ok.disabled = false;
  ok.onclick = async () => {
    ok.disabled = true;
    const v = Object.fromEntries(Object.entries(inputs).map(([k, i]) => [k, i.value]));
    const err = await submit(v, touchBox && $('g-touch').checked).catch((e) => e.message);
    ok.disabled = false;
    if (err) $('g-err').textContent = err;
    else $('gdlg').classList.add('hidden');
  };
  $('gdlg').classList.remove('hidden');
  setTimeout(() => Object.values(inputs)[0]?.focus(), 0);
}
$('g-cancel').addEventListener('click', () => $('gdlg').classList.add('hidden'));

// ⋯ 작은 메뉴
function menu(anchor, items) {
  document.querySelector('.pop')?.remove();
  const m = el('div', 'pop');
  for (const it of items.filter(Boolean)) {
    const b = el('button', `pop-item${it.on ? ' on' : ''}${it.danger ? ' danger' : ''}`, it.label);
    b.addEventListener('click', () => { m.remove(); it.run(); });
    m.append(b);
  }
  document.body.append(m);
  const r = anchor.getBoundingClientRect();
  m.style.top = `${r.bottom + window.scrollY + 4}px`;
  m.style.left = `${Math.max(8, r.right + window.scrollX - m.offsetWidth)}px`;
  setTimeout(() => document.addEventListener('click', () => m.remove(), { once: true }), 0);
}

function newGroup() {
  form({
    title: '새 그룹',
    sub: '예: 이든치과, 집 · 잠금 비밀번호를 정하면 넣어야 그룹의 PC가 보여요(비우면 잠금 없음)',
    fields: [{ key: 'name', placeholder: '그룹 이름' }, { key: 'pw', type: 'password', placeholder: '잠금 비밀번호(선택 · 4자 이상)' }],
    okText: '만들기',
    touchBox: touch,
    submit: async (v, useTouch) => {
      if (!v.name.trim()) return '그룹 이름을 넣어 주세요.';
      if (v.pw && v.pw.length < 4) return '잠금 비밀번호는 4자 이상으로 정해 주세요.';
      const r = await act({ action: 'create', name: v.name, ...(v.pw ? { lockPassword: v.pw } : {}) });
      if (r?.error) return r.error;
      if (v.pw) {
        opened.set(r.group.id, v.pw);
        if (useTouch) await saveKey(r.group.id, v.pw);
      }
      await loadGroups();
      return '';
    },
  });
}

// 잠긴 그룹 열기: 지문으로 열기를 켰으면 지문 먼저 → 안 되면 잠금 비밀번호
async function openGroup(g) {
  const done = (pw) => { opened.set(g.id, pw); folded.delete(g.id); draw(); };
  if (keys[g.id] && touch) {
    const k = await chrome.runtime.sendMessage({ type: 'groupKey', action: 'get', id: g.id, reason: `"${g.name}" 원격 그룹을 열어요` }).catch(() => null);
    if (k?.password) {
      const r = await act({ action: 'open', id: g.id, password: k.password });
      if (!r?.error) return done(k.password);
      if (r.reason === 'password') await dropKey(g.id); // 다른 장치에서 잠금 비밀번호를 바꿨다 — 다시 넣게
    }
  }
  form({
    title: `${g.name} 열기`,
    sub: '그룹 잠금 비밀번호를 넣으세요',
    fields: [{ key: 'pw', type: 'password', placeholder: '잠금 비밀번호' }],
    okText: '열기',
    touchBox: touch && !keys[g.id],
    submit: async (v, useTouch) => {
      if (!v.pw) return '비밀번호를 넣어 주세요.';
      const r = await act({ action: 'open', id: g.id, password: v.pw });
      if (r?.error) return r.error;
      if (useTouch) await saveKey(g.id, v.pw);
      done(v.pw);
      return '';
    },
  });
}

function groupMenu(g, btn) {
  if (g.locked && !opened.has(g.id)) return menu(btn, [{ label: '열기', run: () => openGroup(g) }]); // 잠긴 그룹은 먼저 열어야 바꿀 수 있다
  const pw = opened.get(g.id) || '';
  const setLock = () => form({
    title: g.locked ? '잠금 비밀번호 바꾸기' : `${g.name} 잠금`,
    sub: '이 비밀번호를 넣어야 그룹의 PC가 보여요 · 같은 계정의 모든 장치에 같이 적용돼요',
    fields: [{ key: 'a', type: 'password', placeholder: '새 잠금 비밀번호(4자 이상)' }, { key: 'b', type: 'password', placeholder: '한 번 더' }],
    okText: '잠금 저장',
    touchBox: touch,
    submit: async (v, useTouch) => {
      if (v.a.length < 4) return '잠금 비밀번호는 4자 이상으로 정해 주세요.';
      if (v.a !== v.b) return '두 비밀번호가 달라요.';
      const r = await act({ action: 'lock', id: g.id, lockPassword: v.a, password: pw });
      if (r?.error) return r.error;
      opened.set(g.id, v.a);
      if (useTouch) await saveKey(g.id, v.a);
      else await dropKey(g.id);
      await loadGroups();
      return '';
    },
  });
  menu(btn, [
    {
      label: '이름 바꾸기',
      run: () => form({
        title: '그룹 이름 바꾸기',
        fields: [{ key: 'name', value: g.name, placeholder: '그룹 이름' }],
        okText: '저장',
        submit: async (v) => {
          if (!v.name.trim()) return '그룹 이름을 넣어 주세요.';
          const r = await act({ action: 'rename', id: g.id, name: v.name, password: pw });
          if (r?.error) return r.error;
          await loadGroups();
          return '';
        },
      }),
    },
    { label: g.locked ? '잠금 비밀번호 바꾸기' : '잠금 정하기', run: setLock },
    g.locked && touch && { label: keys[g.id] ? '지문으로 열기 끄기' : '지문으로 열기 켜기', run: async () => { if (keys[g.id]) await dropKey(g.id); else await saveKey(g.id, pw); draw(); } },
    g.locked && {
      label: '잠금 풀기',
      run: () => form({
        title: `${g.name} 잠금 풀기`,
        sub: '비밀번호 없이 누구나 이 그룹의 PC를 볼 수 있게 돼요',
        okText: '잠금 풀기',
        submit: async () => {
          const r = await act({ action: 'lock', id: g.id, lockPassword: '', password: pw });
          if (r?.error) return r.error;
          await dropKey(g.id);
          opened.delete(g.id);
          await loadGroups();
          return '';
        },
      }),
    },
    {
      label: '그룹 지우기',
      danger: true,
      run: () => form({
        title: `${g.name} 지우기`,
        sub: '그룹만 지워져요 · 안의 PC는 "그룹 없음"으로 옮겨져요',
        okText: '지우기',
        danger: true,
        submit: async () => {
          const r = await act({ action: 'delete', id: g.id, password: pw });
          if (r?.error) return r.error;
          await dropKey(g.id);
          opened.delete(g.id);
          await loadGroups();
          port.postMessage({ type: 'remoteState' });
          return '';
        },
      }),
    },
  ]);
}

// PC 줄 ⋯: 그룹 옮기기
function moveMenu(d, btn) {
  const cur = d.groupId && groups.some((g) => g.id === d.groupId) ? d.groupId : '';
  menu(btn, [
    ...groups.map((g) => ({ label: `${g.id === cur ? '✓ ' : ''}${g.locked ? '🔒 ' : ''}${g.name}`, on: g.id === cur, run: () => movePc(d, g.id) })),
    groups.length && { label: `${cur ? '' : '✓ '}그룹 없음`, on: !cur, run: () => movePc(d, '') },
    { label: '+ 새 그룹 만들기', run: () => newGroup() },
  ]);
}
async function movePc(d, to) {
  const from = d.groupId && groups.some((g) => g.id === d.groupId) ? d.groupId : '';
  if (from === to) return;
  const r = await act({ action: 'move', deviceId: d.id, groupId: to || null, password: opened.get(from) || '' });
  if (r?.error) return toast(r.error);
  d.groupId = to || null;
  const g = groups.find((x) => x.id === to);
  if (g?.locked && !opened.has(g.id)) toast(`${d.name}를 잠긴 그룹 "${g.name}"로 옮겼어요`);
  draw();
  port.postMessage({ type: 'remoteState' });
}

// 연결 방식: 브라우저 연동 · PC 원격제어(브라우저 연동으로 이은 뒤 그 PC 에 전체 화면 공유를 요청한다)
let connectMode = 'browser';
function setMode(m) {
  connectMode = m;
  for (const [id, on] of [['mode-browser', m === 'browser'], ['mode-pc', m === 'pc']]) {
    $(id).classList.toggle('on', on);
    $(id).querySelector('b').textContent = `${on ? '◉' : '○'} ${id === 'mode-pc' ? 'PC 원격제어' : '브라우저 연동'}`;
  }
}
$('mode-browser').addEventListener('click', () => setMode('browser'));
$('mode-pc').addEventListener('click', () => setMode('pc'));
function openDlg(d, update = false, err = '') {
  target = d;
  updating = update;
  setMode('browser');
  $('dlg-title').textContent = update ? `${d.name} 업데이트` : `${d.name} 연결`;
  // 업데이트는 비밀번호만 묻는다(연결 방식·창 없음)
  $('dlg-sub').textContent = update ? '그 PC의 원격 비밀번호를 넣으면 창 없이 업데이트해요' : '연결 방식을 고르고 비밀번호를 넣으세요';
  document.querySelector('.modes').classList.toggle('hidden', update);
  $('dlg-ok').textContent = update ? '업데이트' : '연결';
  $('dlg-err').textContent = err;
  $('pw').value = '';
  $('dlg').classList.remove('hidden');
  if (update) showPw(true);
  else port.postMessage({ type: 'remoteTrusted', toDeviceId: d.id });
}
function showPw(ask) {
  $('pw-box').classList.toggle('hidden', !ask);
  $('pw-saved').classList.toggle('hidden', ask);
  if (ask) $('pw').focus();
}
function closeDlg() { $('dlg').classList.add('hidden'); target = null; }
$('pw-again').addEventListener('click', (e) => { e.preventDefault(); showPw(true); });
$('dlg-cancel').addEventListener('click', closeDlg);
$('pw').addEventListener('keydown', (e) => e.key === 'Enter' && $('dlg-ok').click());
$('dlg-ok').addEventListener('click', () => {
  if (!target) return;
  const asking = !$('pw-box').classList.contains('hidden');
  if (asking && !$('pw').value) { $('dlg-err').textContent = '비밀번호를 넣어 주세요.'; return; }
  $('dlg-err').textContent = '';
  if (updating) {
    const d = target;
    const pw = $('pw').value;
    closeDlg();
    return updatePc(d, pw);
  }
  $('dlg-ok').disabled = true;
  $('dlg-ok').textContent = '연결 중…';
  port.postMessage({ type: 'remoteConnect', toDeviceId: target.id, mode: connectMode, ...(updating ? { update: true } : {}), ...(asking ? { password: $('pw').value, remember: $('remember').checked } : {}) });
});

// 위 [내 계정 연동 | 다른 사람과 연결](2026-11-07 피그마 D-9·D-10) — 마지막에 본 칸을 기억한다
function showPane(which) {
  $('seg-pc').classList.toggle('on', which === 'pc');
  $('seg-code').classList.toggle('on', which === 'code');
  $('pc-view').classList.toggle('hidden', which !== 'pc');
  $('me-form').classList.toggle('hidden', which !== 'pc');
  $('code-pane').classList.toggle('hidden', which !== 'code');
  chrome.storage.local.set({ remotePane: which }).catch(() => {});
  if (which === 'code') setTimeout(() => $('d1').focus(), 0);
}
$('seg-pc').addEventListener('click', () => showPane('pc'));
$('seg-code').addEventListener('click', () => showPane('code'));
chrome.storage.local.get(['remotePane', 'remoteGroupSel']).then(({ remotePane, remoteGroupSel }) => {
  if (remoteGroupSel) { sel = remoteGroupSel; if (state) draw(); }
  if (remotePane === 'code' && !add) showPane('code');
}).catch(() => {});
// 다른 장치에 접속: 9자리 번호(세 칸 — 채우면 다음 칸, 9자리를 붙여 넣으면 나눠 담는다) → 번호 원격 화면이 바로 잇는다
const digits = [$('d1'), $('d2'), $('d3')];
digits.forEach((inp, i) => {
  inp.addEventListener('input', () => {
    inp.value = inp.value.replace(/\D/g, '').slice(0, 3);
    if (inp.value.length === 3 && digits[i + 1]) digits[i + 1].focus();
    $('code-err').textContent = '';
  });
  inp.addEventListener('paste', (e) => {
    const v = (e.clipboardData?.getData('text') || '').replace(/\D/g, '');
    if (v.length >= 9) { e.preventDefault(); digits.forEach((d, k) => { d.value = v.slice(k * 3, k * 3 + 3); }); digits[2].focus(); }
  });
  inp.addEventListener('keydown', (e) => {
    if (e.key === 'Backspace' && !inp.value && digits[i - 1]) digits[i - 1].focus();
    if (e.key === 'Enter') $('code-join').click();
  });
});
$('code-join').addEventListener('click', () => {
  const code = digits.map((d) => d.value).join('');
  if (code.length !== 9) { $('code-err').textContent = '9자리 번호를 모두 넣어 주세요.'; return digits.find((d) => d.value.length < 3)?.focus(); }
  location.href = chrome.runtime.getURL(`remote.html?code=${code}#view`);
});
// 내 장치 접속 허용: 번호 원격 화면이 10분 동안 쓰는 번호를 만든다
$('code-make').addEventListener('click', () => { location.href = chrome.runtime.getURL('remote.html#share'); });

// 원격을 켠 PC 는 브라우저를 닫아도 원격 대기(누를 때 권한 확인 — bg-mode.js)
watchClicksForBackground();
