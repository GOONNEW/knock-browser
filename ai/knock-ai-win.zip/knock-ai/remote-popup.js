// 브라우저 연동: 그 PC 의 팝업을 따로 된 창으로 보여 준다(2026-11-08 "팝업은 새 탭이 아니라 창으로 띄우면 좋겠어").
// 연결은 원격 창(remote-browser.js)이 갖고 있다 — 이 창은 그 창의 그림을 그리고, 누르기·입력을 그 창으로 보낸다.
// 화면은 하나만 오므로 이 창을 쓰려 하면(앞으로 오거나 누르면) 이 팝업 탭을 보내 달라고 한다.
const $ = (id) => document.getElementById(id);
const q = new URLSearchParams(location.search);
const id = Number(q.get('id'));
window.__pwId = id; // 은행 비밀번호 입력 칸을 이 창 위에 띄울 때 찾는다(remote-browser.js pwBox)
const main = () => chrome.extension.getViews().find((v) => v.__rb?.key === q.get('key'))?.__rb;

const size = () => ({ w: Math.max(window.innerWidth, 320), h: Math.max(window.innerHeight, 240), dpr: Math.min(window.devicePixelRatio || 1, 2) });
// 이 팝업 탭을 보내 달라고 한다(이미 보내는 중이면 크기만 맞춘다)
let lastSize = '';
function take() {
  const m = main();
  if (!m) return window.close();
  const sz = size();
  const key = JSON.stringify(sz);
  if (m.st.active !== id) m.send({ t: 'select', tabId: id });
  else if (key === lastSize) return;
  lastSize = key;
  m.st.sizeFrom = 'popup'; // 원격 화면 크기가 지금 이 팝업 창 크기다 — 메인 탭으로 돌아가면 원격 창이 제 크기를 다시 보낸다
  m.send({ t: 'size', ...sz });
}
window.addEventListener('focus', take);
let resizeT = null;
window.addEventListener('resize', () => { clearTimeout(resizeT); resizeT = setTimeout(() => { lastSize = ''; take(); }, 300); });

// 그리기: 원격 창이 받은 그림(사진 또는 영상)을 이 팝업 탭일 때만 옮겨 그린다
const canvas = $('screen');
let drawnAt = -1;
function draw() {
  const m = main();
  if (!m) return window.close();
  const st = m.st;
  const t = st.tabs.find((x) => x.id === id);
  if (!t) return window.close(); // 그 PC 에서 닫혔다
  if (document.title !== t.title) document.title = t.title || '팝업';
  if (st.active !== id) lastSize = ''; // 다른 창이 화면 크기를 바꿨다 — 다시 쓸 때 이 창 크기를 알린다
  else {
    const video = st.mode === 'video';
    const src = video ? st.video : st.img;
    const iw = video ? src?.videoWidth : src?.width;
    const ih = video ? src?.videoHeight : src?.height;
    if (src && iw && ih && (video || st.frameAt !== drawnAt)) {
      drawnAt = st.frameAt;
      const k = Math.min(window.innerWidth / iw, window.innerHeight / ih, 2);
      const cw = `${Math.round(iw * k)}px`;
      const ch = `${Math.round(ih * k)}px`;
      if (canvas.style.width !== cw) canvas.style.width = cw;
      if (canvas.style.height !== ch) canvas.style.height = ch;
      if (canvas.width !== iw) canvas.width = iw;
      if (canvas.height !== ih) canvas.height = ih;
      canvas.getContext('2d').drawImage(src, 0, 0);
      $('wait').classList.add('hidden');
    }
  }
  requestAnimationFrame(draw);
}
requestAnimationFrame(draw);

// 누르기·입력 — 원격 창과 같은 약속(이 팝업 탭을 보내는 중이 아니면 먼저 보내 달라고 한다)
const send = (obj) => { const m = main(); if (!m) return; if (m.st.active !== id) take(); m.send(obj); };
const pos = (e) => { const r = canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height }; };
const mods = (e) => (e.altKey ? 1 : 0) | (e.ctrlKey ? 2 : 0) | (e.metaKey ? 4 : 0) | (e.shiftKey ? 8 : 0);
const ime = $('ime');
canvas.addEventListener('mousedown', (e) => { e.preventDefault(); ime.focus(); send({ t: 'mouse', kind: 'down', ...pos(e), button: e.button, clicks: e.detail, mods: mods(e) }); });
canvas.addEventListener('mouseup', (e) => send({ t: 'mouse', kind: 'up', ...pos(e), button: e.button, clicks: e.detail, mods: mods(e) }));
let moveQ = null;
canvas.addEventListener('mousemove', (e) => { const p = pos(e); if (moveQ) { moveQ = p; return; } moveQ = p; requestAnimationFrame(() => { send({ t: 'mouse', kind: 'move', ...moveQ, mods: mods(e) }); moveQ = null; }); });
canvas.addEventListener('wheel', (e) => { e.preventDefault(); send({ t: 'mouse', kind: 'wheel', ...pos(e), dx: e.deltaX, dy: e.deltaY, mods: mods(e) }); }, { passive: false });
canvas.addEventListener('contextmenu', (e) => e.preventDefault());
document.addEventListener('click', () => ime.focus());

const SPECIAL = new Set(['Enter', 'Backspace', 'Tab', 'Escape', 'ArrowLeft', 'ArrowUp', 'ArrowRight', 'ArrowDown', 'Delete', 'Home', 'End', 'PageUp', 'PageDown']);
const isPaste = (e) => (e.ctrlKey || e.metaKey) && !e.altKey && e.code === 'KeyV';
ime.addEventListener('keydown', (e) => {
  if (e.isComposing || isPaste(e)) return;
  if (SPECIAL.has(e.key) || e.ctrlKey || e.metaKey || e.altKey) { e.preventDefault(); send({ t: 'key', down: true, key: e.key, code: e.code, mods: mods(e) }); }
});
ime.addEventListener('keyup', (e) => { if (!e.isComposing && !isPaste(e) && (SPECIAL.has(e.key) || e.ctrlKey || e.metaKey || e.altKey)) send({ t: 'key', down: false, key: e.key, code: e.code, mods: mods(e) }); });
ime.addEventListener('paste', (e) => {
  e.preventDefault();
  // 엑셀 칸을 복사하면 끝에 줄바꿈이 붙는다 — 그대로 보내면 한 줄 칸에 안 들어가거나 비밀번호 칸 키 입력이 막혔다(2026-11-08)
  const text = (e.clipboardData?.getData('text/plain') || '').replace(/\r\n?/g, '\n').replace(/[\n\t ]+$/, '');
  for (let i = 0; i < text.length; i += 2000) send({ t: 'text', text: text.slice(i, i + 2000) });
  ime.value = '';
});
ime.addEventListener('compositionend', (e) => { if (e.data) send({ t: 'text', text: e.data }); ime.value = ''; });
ime.addEventListener('input', (e) => { if (e.isComposing) return; if (e.data) send({ t: 'text', text: e.data }); ime.value = ''; });

ime.focus();
take();
