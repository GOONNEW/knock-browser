// 환자 정보 가리기(2026-11-18 원장님 "환자 개인 정보가 AI 회사로 넘어가지 않게, 키는 PC 에만"):
// AI 에게 보내기 전에 이 PC 에서 환자 이름·차트번호를 가림표([[비공개N]])로 바꾼다. 진짜 값과 가림표의 짝은
// secrets.js 의 storage.session(메모리 — 브라우저를 끄면 사라짐)에만 있고 밖으로 나가지 않는다.
// - AI 가 가림표를 칸에 넣으면(type_text·win_type) fillSecrets 가 사용자에게 묻고 그 칸에만 진짜 값을 넣는다.
// - AI 창은 답을 그릴 때 가림표를 진짜 이름으로 바꿔 보여 준다(revealSecrets).
// 찾는 방법: ① 이름표가 붙은 칸("환자명" = 홍길동, 성명: 홍길동) ② 표의 이름·차트번호 열 ③ "홍길동님"
// 한 번 찾은 이름은 기억해 두고(storage.session patientNames) 다음 결과에서는 이름표가 없어도 가린다.
// 가리지 못하는 것: 이름표도 "님"도 없이 처음 나오는 이름, 사진·PDF 속 글자(2단계에서 창 사진만 따로 다룬다).

// 이름이 들어가는 칸 이름(띄어쓰기 없이 비교)
const NAME_LABELS = ['환자명', '환자이름', '환자성명', '수진자', '수진자명', '피보험자', '피보험자명', '계약자', '계약자명', '보호자', '보호자명', '고객명', '성명', '이름', '환자'];
// 차트번호 칸 이름
const ID_LABELS = ['차트번호', '챠트번호', '차트no', '차트no.', '차트#', '환자번호', '등록번호', '진료번호'];
const NAME_LABEL = new RegExp(`^(${NAME_LABELS.join('|')})$`);
const ID_LABEL = new RegExp(`^(${ID_LABELS.map((x) => x.replace('.', '\\.')).join('|')})$`, 'i');
// 칸 이름 비교용: 띄어쓰기·끝의 콜론·"(글자)" 같은 꼬리·앞의 "열:" 을 뗀다
const flat = (s) => String(s ?? '').replace(/^\s*열\s*[:：]/, '').replace(/\s+/g, '').replace(/\([^)]*\)$/, '').replace(/[:：]$/, '');

// 흔한 성(두 글자 성 포함)
const SURNAMES = new Set('김 이 박 최 정 강 조 윤 장 임 한 오 서 신 권 황 안 송 류 유 전 홍 고 문 양 손 배 백 허 남 심 노 하 곽 성 차 주 우 구 민 나 진 지 엄 채 원 천 방 공 현 함 변 염 여 추 도 소 석 선 설 마 길 연 위 표 명 기 반 라 왕 금 옥 육 인 맹 제 모 탁 국 어 은 편 용 예 경 봉 사 부 황보 남궁 제갈 선우 서문 독고 사공'.split(' '));
// "○○님"인데 이름이 아닌 것(뒤 두 글자가 직함·부름말)
const NOT_NAME_TAIL = new Set(['원장', '선생', '실장', '팀장', '과장', '부장', '대표', '기사', '사장', '이사', '위원', '소장', '교수', '박사', '주임', '대리', '차장', '상무', '전무', '여사', '고객', '환자', '담당', '간호', '위생', '직원', '회원', '손님', '어머', '아버', '할머', '할아', '보호', '학생', '부모', '형님', '누님', '언니', '오빠', '사모', '총무', '본부', '센터', '병원', '치과', '의원']);
const isName = (s) => /^[가-힣]{2,4}$/.test(s);
const isId = (s) => /^[A-Za-z0-9][A-Za-z0-9-]{1,19}$/.test(s) && /\d/.test(s);

// 한 줄을 칸으로 나눈다: " | "(엑셀 읽기·창 읽기), 탭, 쉼표(CSV — 따옴표 안 쉼표는 그대로)
function cells(line) {
  if (line.includes(' | ')) return line.split(' | ').map((c) => c.trim());
  if (line.includes('\t')) return line.split('\t').map((c) => c.trim());
  const out = [];
  let cur = '';
  let q = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') { if (q && line[i + 1] === '"') { cur += '"'; i++; } else q = !q; } else if (ch === ',' && !q) { out.push(cur.trim()); cur = ''; } else cur += ch;
  }
  out.push(cur.trim());
  return out;
}

/** 글에서 환자 이름·차트번호를 찾는다(바꾸지는 않음). → { names: Set, ids: Set } */
export function findPatients(text) {
  const names = new Set();
  const ids = new Set();
  const t = String(text ?? '');
  const take = (label, value) => {
    const v = String(value ?? '').trim();
    if (NAME_LABEL.test(flat(label))) { const m = /^([가-힣]{2,4})(?![가-힣])/.exec(v); if (m) names.add(m[1]); }
    else if (ID_LABEL.test(flat(label)) && isId(v)) ids.add(v);
  };
  // ① 창 읽기 줄: [w1-3] 입력칸 "환자명" = 홍길동 (커서)
  for (const m of t.matchAll(/"([^"\n]{1,12})"\s*=\s*([^\n(]+)/g)) take(m[1], m[2]);
  // ① 이름표: 환자명: 홍길동 · 오늘 성명 = 홍길동 · 차트번호: 12345 — 콜론 앞 글이 칸 이름으로 끝나면
  for (const m of t.matchAll(/[:：=]\s*([가-힣]{2,4}(?![가-힣])|[A-Za-z0-9][A-Za-z0-9-]{1,19})/g)) {
    const before = t.slice(Math.max(0, m.index - 14), m.index).replace(/\s+/g, '').toLowerCase();
    const label = [...NAME_LABELS, ...ID_LABELS].filter((l) => before.endsWith(l.toLowerCase())).sort((a, b) => b.length - a.length)[0];
    if (label) take(label, m[1]);
  }
  // ② 표: 머리줄에서 이름·차트번호 열을 찾아 그 아래 줄의 그 열 값
  const lines = t.split('\n');
  let cols = null;
  for (const line of lines) {
    if (!line.trim() || /^##\s/.test(line)) { cols = null; continue; }
    if (cols && /맨 앞 칸은 줄 번호/.test(line)) cols.offset = 1; // 엑셀 찾기 결과는 앞에 줄 번호가 붙는다
    const c = cells(line);
    if (c.length < 2) continue; // "마지막 2줄:" 같은 안내 줄
    const nameCols = c.map((x, i) => (NAME_LABEL.test(flat(x)) ? i : -1)).filter((i) => i >= 0);
    const idCols = c.map((x, i) => (ID_LABEL.test(flat(x)) ? i : -1)).filter((i) => i >= 0);
    if (nameCols.length || idCols.length) { cols = { nameCols, idCols, offset: 0 }; continue; }
    if (!cols) continue;
    for (const i of cols.nameCols) { const m = /^([가-힣]{2,4})(?![가-힣])/.exec(c[i + cols.offset] || ''); if (m) names.add(m[1]); }
    for (const i of cols.idCols) if (isId(c[i + cols.offset] || '')) ids.add(c[i + cols.offset]);
  }
  // ③ "홍길동님" — 성으로 시작하고 직함이 아닌 세 글자(두 글자 성이면 네 글자)
  for (const m of t.matchAll(/(?<![가-힣])([가-힣]{3,4})님/g)) {
    const w = m[1];
    const sur = SURNAMES.has(w.slice(0, 2)) && w.length === 4 ? w.slice(0, 2) : SURNAMES.has(w[0]) && w.length === 3 ? w[0] : null;
    if (sur && !NOT_NAME_TAIL.has(w.slice(-2))) names.add(w);
  }
  return { names, ids };
}

const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
/** 아는 이름·차트번호를 가림표로 바꾼다(앞 글자가 한글이 아닐 때만 — "김민수"의 "민수"는 그대로). → { text, hits } */
export function applyPatients(text, tokenOf) {
  let out = String(text ?? '');
  let hits = 0;
  const values = [...tokenOf.keys()].sort((a, b) => b.length - a.length);
  for (const v of values) {
    const re = isName(v) ? new RegExp(`(?<![가-힣])${esc(v)}`, 'g') : new RegExp(`(?<![A-Za-z0-9-])${esc(v)}(?![A-Za-z0-9-])`, 'g');
    out = out.replace(re, () => { hits++; return tokenOf.get(v); });
  }
  return { text: out, hits };
}

// ---------- 확장 안에서(가림표 맡기기·기억) ----------
const NAMES_KEY = 'patientNames';

/** AI 에게 보낼 글에서 환자 정보를 가린다. → { text, names, ids }(이번에 가린 개수) */
export async function maskPatients(text, tokensFor) {
  const found = findPatients(text);
  const { [NAMES_KEY]: saved = { names: [], ids: [] } } = await chrome.storage.session.get(NAMES_KEY).catch(() => ({}));
  const names = new Set([...(saved.names || []), ...found.names]);
  const ids = new Set([...(saved.ids || []), ...found.ids]);
  if (found.names.size || found.ids.size) {
    await chrome.storage.session.set({ [NAMES_KEY]: { names: [...names].slice(-2000), ids: [...ids].slice(-2000) } }).catch(() => {});
  }
  const present = [...names, ...ids].filter((v) => String(text ?? '').includes(v));
  if (!present.length) return { text: String(text ?? ''), names: 0, ids: 0 };
  const tokenOf = await tokensFor(present);
  const { text: out } = applyPatients(text, tokenOf);
  return { text: out, names: present.filter((v) => names.has(v)).length, ids: present.filter((v) => ids.has(v) && !names.has(v)).length };
}

/** 지금까지 찾은 환자 이름·차트번호(창 사진 가리기에 넘긴다). */
export async function knownPatients() {
  const { [NAMES_KEY]: saved = { names: [], ids: [] } } = await chrome.storage.session.get(NAMES_KEY).catch(() => ({}));
  return { names: (saved.names || []).slice(-500), ids: (saved.ids || []).slice(-500) };
}
