// AI 답의 마크다운을 화면용 HTML 로 바꾼다: 제목, 굵게·기울임, 코드, 링크, 목록, 표, 인용, 구분선.
// 페이지에서 읽은 글이 섞일 수 있으므로 모든 글자를 먼저 이스케이프하고, 허용한 모양만 태그로 만든다.

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}

// 한 줄 안의 꾸밈(이미 이스케이프된 글에 적용)
function inline(text) {
  const codes = [];
  let s = escapeHtml(text).replace(/`([^`]+)`/g, (_, c) => {
    codes.push(c);
    return `\u0000${codes.length - 1}\u0000`;
  });
  s = s
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" data-href="$2">$1</a>')
    .replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g, '$1<a href="$2" data-href="$2">$2</a>')
    .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
    .replace(/(^|[^*\w])\*(?!\s)(.+?)\*(?!\w)/g, '$1<i>$2</i>')
    .replace(/~~(.+?)~~/g, '<s>$1</s>');
  return s.replace(/\u0000(\d+)\u0000/g, (_, i) => `<code>${codes[Number(i)]}</code>`);
}

function splitRow(line) {
  return line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((c) => c.trim());
}

const isTableSep = (line) => /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(line);

export function renderMarkdown(src) {
  const lines = src.replace(/\r\n?/g, '\n').split('\n');
  const out = [];
  let para = [];
  const flush = () => {
    if (para.length) out.push(`<p>${para.map(inline).join('<br>')}</p>`);
    para = [];
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // 코드 묶음 ```
    if (/^\s*```/.test(line)) {
      flush();
      const body = [];
      for (i++; i < lines.length && !/^\s*```/.test(lines[i]); i++) body.push(lines[i]);
      out.push(`<pre><code>${escapeHtml(body.join('\n'))}</code></pre>`);
      continue;
    }
    // 표: 머리 줄 + 구분 줄(---)
    if (line.includes('|') && i + 1 < lines.length && isTableSep(lines[i + 1])) {
      flush();
      const head = splitRow(line);
      const aligns = splitRow(lines[i + 1]).map((c) => (/^:-+:$/.test(c) ? 'center' : /-:$/.test(c) ? 'right' : ''));
      const rows = [];
      for (i += 2; i < lines.length && lines[i].includes('|') && lines[i].trim(); i++) rows.push(splitRow(lines[i]));
      i--;
      const cell = (tag, c, k) => `<${tag}${aligns[k] ? ` style="text-align:${aligns[k]}"` : ''}>${inline(c)}</${tag}>`;
      out.push(`<div class="table-wrap"><table><thead><tr>${head.map((c, k) => cell('th', c, k)).join('')}</tr></thead><tbody>${
        rows.map((r) => `<tr>${head.map((_, k) => cell('td', r[k] ?? '', k)).join('')}</tr>`).join('')}</tbody></table></div>`);
      continue;
    }
    // 제목
    const h = line.match(/^\s*(#{1,4})\s+(.*)$/);
    if (h) {
      flush();
      out.push(`<h${h[1].length + 2}>${inline(h[2])}</h${h[1].length + 2}>`);
      continue;
    }
    // 구분선
    if (/^\s*([-*_])\s*\1\s*\1[\s\-*_]*$/.test(line)) {
      flush();
      out.push('<hr>');
      continue;
    }
    // 인용
    if (/^\s*>\s?/.test(line)) {
      flush();
      const body = [];
      for (; i < lines.length && /^\s*>\s?/.test(lines[i]); i++) body.push(lines[i].replace(/^\s*>\s?/, ''));
      i--;
      out.push(`<blockquote>${body.map(inline).join('<br>')}</blockquote>`);
      continue;
    }
    // 목록(번호·점). 들여쓴 줄은 한 단계 아래 목록으로.
    const li = line.match(/^(\s*)([-*•]|\d+[.)])\s+(.*)$/);
    if (li) {
      flush();
      const items = [];
      for (; i < lines.length; i++) {
        const m = lines[i].match(/^(\s*)([-*•]|\d+[.)])\s+(.*)$/);
        if (m) items.push({ depth: m[1].length >= 2 ? 1 : 0, ordered: /\d/.test(m[2]), text: m[3] });
        else if (/^\s{2,}\S/.test(lines[i]) && items.length) items[items.length - 1].text += `\n${lines[i].trim()}`;
        else break;
      }
      i--;
      let html = '';
      let open = [];
      for (const it of items) {
        const tag = it.ordered ? 'ol' : 'ul';
        while (open.length > it.depth + 1) html += `</li></${open.pop()}>`;
        if (open.length === it.depth + 1 && open[open.length - 1] !== tag) html += `</li></${open.pop()}>`;
        if (open.length < it.depth + 1) {
          html += `<${tag}>`;
          open.push(tag);
        } else html += '</li>';
        html += `<li>${it.text.split('\n').map(inline).join('<br>')}`;
      }
      while (open.length) html += `</li></${open.pop()}>`;
      out.push(html);
      continue;
    }
    if (!line.trim()) flush();
    else para.push(line);
  }
  flush();
  return out.join('');
}
