// Knock 새 탭(2026-11-06 리뉴얼): 때에 맞는 인사, 이어서 할 일(예약 · 끝난 일 — 지난 대화 카드는 2026-11-08 뺌), 자주 가는 곳.
// 문장으로 시키기는 주소창에서 한다(주소창 문장 → AI 에게).
const $ = (id) => document.getElementById(id);

const h = new Date().getHours();
$('hello').textContent = `${h < 5 ? '늦은 밤이에요' : h < 12 ? '좋은 아침이에요' : h < 18 ? '좋은 오후예요' : '좋은 저녁이에요'}. 무엇을 할까요?`;

// AI 창을 열고 그 보기로(누른 순간에만 열 수 있어 기다리지 않고 바로 연다)
async function openPanel(view) {
  const tab = await chrome.tabs.getCurrent();
  // 원격(브라우저 연동)으로 보이는 탭이면 보는 쪽 창 안 AI 창에서 연다 — 이 PC 옆 창은 보는 사람에게 안 보인다(2026-11-07)
  const { rhostTab } = await chrome.storage.session.get('rhostTab').catch(() => ({}));
  if (rhostTab === tab.id && await chrome.runtime.sendMessage({ target: 'background', type: 'rhostPanelView', view }).catch(() => false)) return;
  chrome.sidePanel.open({ tabId: tab.id }).catch(() => {});
  setTimeout(() => chrome.runtime.sendMessage({ type: 'panelView', view }).catch(() => {}), 400);
}

function card(icon, kind, text, onClick) {
  const b = Object.assign(document.createElement('button'), { className: 'card', type: 'button' });
  const k = Object.assign(document.createElement('small'), { textContent: `${icon} ${kind}` });
  const t = Object.assign(document.createElement('b'), { textContent: text });
  b.append(k, t);
  b.addEventListener('click', onClick);
  $('cards').append(b);
}

// 이어서 할 일: 가장 최근 것 하나씩
async function drawCards() {
  const r = await chrome.runtime.sendMessage({ type: 'newtabCards' }).catch(() => null);
  if (!r) return;
  if (r.next) card('⏰', '예약', r.next.title, () => openPanel('jobs'));
  if (r.done) card('✅', '끝난 일', r.done.ask || r.done.title, () => chrome.tabs.update(r.done.tabId, { active: true }).then(() => chrome.windows.update(r.done.windowId, { focused: true })).catch(() => {}));
  if (!$('cards').childElementCount) $('cards').classList.add('hidden');
}

// 자주 가는 곳: 북마크 줄의 주소 8개
async function drawFavs() {
  const bar = await chrome.bookmarks.getChildren('1').catch(() => []);
  for (const b of bar.filter((x) => x.url).slice(0, 8)) {
    const a = Object.assign(document.createElement('a'), { className: 'fav', href: b.url, title: b.url });
    const tile = Object.assign(document.createElement('div'), { className: 'tile' });
    const img = Object.assign(document.createElement('img'), { width: 22, height: 22, alt: '' });
    img.src = chrome.runtime.getURL(`/_favicon/?pageUrl=${encodeURIComponent(b.url)}&size=32`);
    tile.append(img);
    let name = b.title;
    try { name = name || new URL(b.url).hostname; } catch {}
    a.append(tile, Object.assign(document.createElement('span'), { textContent: name }));
    $('favs').append(a);
  }
}

drawCards();
drawFavs();
