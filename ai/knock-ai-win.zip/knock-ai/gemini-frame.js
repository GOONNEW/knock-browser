// Knock 옆창 안의 Gemini 화면에서만 동작한다(일반 탭의 Gemini 에서는 아무것도 하지 않는다).
// 옆창이 보내 준 "지금 보고 있는 페이지"(제목·주소·본문)를, 페이지가 바뀐 뒤 첫 질문 앞에 한 번 붙인다.
(() => {
  if (window.top === window) return;
  const ext = `chrome-extension://${chrome.runtime.id}`;
  if (![...(location.ancestorOrigins || [])].includes(ext)) return;

  let ctx = null; // { on, title, url, text }
  let sentFor = null; // 이미 붙인 페이지 주소
  let historySent = false; // Knock AI 의 최근 대화는 이 Gemini 화면에서 한 번만 붙인다
  window.addEventListener('message', (e) => {
    if (e.origin !== ext || e.data?.knock !== 'context') return;
    ctx = e.data;
    if (e.data.reset) sentFor = null;
  });

  // Gemini 글씨를 Knock 창 글씨(13px)와 비슷하게 줄인다(Gemini 기본은 16px)
  const zoom = document.createElement('style');
  zoom.textContent = 'html { zoom: 0.82 !important; }';
  document.documentElement.append(zoom);

  const MARK_PAGE = '[참고: 내가 지금 보고 있는 페이지';
  const MARK_HISTORY = '[참고: Knock AI 와 이 사이트에서 최근에 나눈 대화';

  const editor = () => document.querySelector('rich-textarea .ql-editor, .ql-editor[contenteditable="true"], div[contenteditable="true"][role="textbox"]');

  function attach() {
    const page = ctx?.on && ctx.url && sentFor !== ctx.url;
    const history = ctx?.history && !historySent;
    if (!page && !history) return;
    const ed = editor();
    if (!ed || !ed.textContent.trim()) return;
    // 사용자가 쓴 말이 질문 말풍선 맨 앞에 보이도록, 참고 내용은 뒤에 붙인다.
    // 앞에서 다른 페이지를 보냈으면, 앞 대화의 페이지(예: 이전 유튜브 영상)가 아니라 이 페이지를 보라고 적는다
    const moved = page && sentFor ? '페이지가 바뀌었어. 앞 대화의 페이지 말고 이 페이지를 기준으로 답해 줘.\n' : '';
    const note = '\n\n' + (page ? `${MARK_PAGE} — 이 내용을 참고해서 답해 줘]\n${moved}제목: ${ctx.title}\n주소: ${ctx.url}\n${ctx.text ? `---\n${ctx.text}\n---\n` : ''}` : '')
      + (history ? `\n${MARK_HISTORY} — 이어지는 이야기면 참고해 줘]\n${ctx.history}\n` : '');
    ed.focus();
    const range = document.createRange();
    range.selectNodeContents(ed.lastElementChild || ed); // 마지막 줄의 끝
    range.collapse(false);
    const sel = getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    document.execCommand('insertText', false, note);
    if (page) sentFor = ctx.url;
    if (history) historySent = true;
    if (page) parent.postMessage({ knock: 'shared', url: ctx.url }, ext);
  }

  // 보낼 때(Enter 또는 보내기 단추) 붙인다. Gemini 가 보내는 것을 잠깐 막고, 한글 조합이 끝난 뒤(마지막 글자가
  // 들어간 뒤) 머리말을 붙이고 우리가 보내기 단추를 누른다. 조합 중에 글을 넣으면 Gemini 가 보내지 않고 멈춘다.
  const needed = () => Boolean((ctx?.on && ctx.url && sentFor !== ctx.url) || (ctx?.history && !historySent));
  // 보내기 단추는 이름이 딱 맞는 것만(답 밑의 '내보내기' 단추도 '보내기'를 품고 있어 잘못 눌렀다)
  const SEND = 'button.send-button, button[aria-label="메시지 보내기"], button[aria-label="Send message"]';
  const sendButton = () => document.querySelector(SEND);
  let composing = false;
  window.addEventListener('compositionstart', () => { composing = true; }, true);
  window.addEventListener('compositionend', () => { composing = false; }, true);
  let passing = false; // 우리가 누르는 보내기 단추는 그대로 지나가게
  function sendWithContext(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    let done = false;
    const go = () => {
      if (done) return;
      done = true;
      attach();
      setTimeout(() => { passing = true; sendButton()?.click(); passing = false; }, 80);
      // 그래도 안 보내졌으면(Gemini 가 아직 준비 중이었을 때) 조금 뒤 한 번 더 누르고, 단추가 없으면 Enter 를 대신 누른다
      setTimeout(() => {
        const ed = editor();
        if (!ed?.textContent.includes(MARK_PAGE) && !ed?.textContent.includes(MARK_HISTORY)) return;
        passing = true;
        const btn = sendButton();
        if (btn) btn.click();
        else ed.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
        passing = false;
      }, 1200);
    };
    // 조합이 끝나도 Gemini 입력칸이 마지막 글자를 정리할 틈을 조금 준다(바로 넣으면 마지막 글자가 두 번 들어갔다)
    if (composing) {
      window.addEventListener('compositionend', () => setTimeout(go, 80), { once: true, capture: true });
      setTimeout(go, 500); // 조합 끝 알림이 안 오더라도
    } else setTimeout(go, 0);
  }
  window.addEventListener('keydown', (e) => {
    if (passing || e.key !== 'Enter' || e.shiftKey || e.isComposing || e.keyCode === 229) return;
    if (!e.target.closest?.('.ql-editor, [contenteditable="true"]') || !editor()?.textContent.trim() || !needed()) return;
    sendWithContext(e);
  }, true);
  window.addEventListener('click', (e) => {
    if (passing || !e.target.closest?.(SEND)) return;
    if (!editor()?.textContent.trim() || !needed()) return;
    sendWithContext(e);
  }, true);

  // 대화 한 번(질문 + 답)이 끝나면 옆창에 알려 공통 기록에 남긴다(Knock AI·다른 프로필이 볼 수 있게).
  // 답 글이 2.5초 동안 그대로면 끝난 것으로 본다. 질문 뒤에 Knock 이 붙인 참고 내용은 빼고 남긴다.
  const strip = (t) => {
    // Gemini 가 질문 앞에 붙이는 화면 읽기용 이름표(말씀하신 내용 / You said)도 뺀다
    const s = String(t || '').trim().replace(/^(말씀하신 내용|You said)\s*/, '');
    const i = [s.indexOf(MARK_PAGE), s.indexOf(MARK_HISTORY)].filter((n) => n >= 0);
    return i.length ? s.slice(0, Math.min(...i)).trim() : s;
  };
  let lastSent = '';
  let lastSeen = '';
  let stableTimer = null;
  new MutationObserver(() => {
    const answers = document.querySelectorAll('model-response');
    const questions = document.querySelectorAll('user-query');
    // 새 질문의 답이 아직 안 생겼으면 기다린다(앞 답을 새 질문에 붙여 남기지 않게)
    if (!answers.length || answers.length !== questions.length) return;
    const answer = answers[answers.length - 1].innerText.trim();
    if (!answer || answer === lastSeen) return;
    lastSeen = answer;
    clearTimeout(stableTimer);
    stableTimer = setTimeout(() => {
      const user = strip(questions[questions.length - 1].innerText);
      const key = `${questions.length}\n${answer}`;
      if (!user || key === lastSent) return;
      lastSent = key;
      parent.postMessage({ knock: 'turn', user: user.slice(0, 2000), answer: answer.slice(0, 4000) }, ext);
    }, 2500);
  }).observe(document.documentElement, { subtree: true, childList: true, characterData: true });
})();
