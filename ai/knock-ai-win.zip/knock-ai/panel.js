// 오른쪽 AI 창. 지금 보고 있는 탭의 대화를 보여 주고, 보낼 말·첨부를 백그라운드로 넘긴다.
import { apply, newChat } from './chat.js';
import { renderMarkdown } from './markdown.js';
import { watchClicksForBackground } from './bg-mode.js';
import { watchSecrets, revealSecrets, setChatMask } from './secrets.js';
// 알림(2026-11-08 "업데이트 실패 알림창이 브라우저 동작을 막아"): alert() 는 창을 멈춰 세우고 원격에서는 보이지도 않아
// 닫을 수 없었다 — 대신 위쪽에 띠로 보여 주고 저절로 사라진다(누르면 바로 닫힘)
function notice(text, ms = 12000) {
  const el = Object.assign(document.createElement('div'), { className: 'knock-notice', role: 'status', textContent: text });
  el.title = '누르면 닫혀요';
  el.addEventListener('click', () => el.remove());
  document.body.append(el);
  setTimeout(() => el.remove(), ms);
}
const COPY_ICON = '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M9 9h10v11H9zM5 15V4h10"/></svg>';
// 안내 글의 '이 맥'·'이 PC'(윈도우판도 같은 AI 창을 쓴다)
const THIS_PC = /^Win/.test(navigator.platform) ? '이 PC' : '이 맥';

const $ = (id) => document.getElementById(id);
const port = chrome.runtime.connect({ name: 'panel' });
const myWindow = await chrome.windows.getCurrent();
// 설정은 브라우저 위에 뜨는 따로 창으로 연다(2026-11-06 리뉴얼, 피그마 ② 설정 화면) — panel.html?settings=분류&tab=탭번호
const SETTINGS_ONLY = new URLSearchParams(location.search).has('settings');
if (SETTINGS_ONLY) document.body.classList.add('settings-only');
// 옆 창으로 뜬 AI 창이면 어느 브라우저 창인지 알린다(주소창 ✦ AI 알약이 열기·닫기를 고르게)
if (!SETTINGS_ONLY && window.top === window) port.postMessage({ type: 'panelWindow', windowId: myWindow.id });

let tabId = null;
let chat = newChat();
let status = { state: 'unknown' };
// 똑소리 가림표의 실제 값 — 새로 맡겨지면(조회가 끝나면) 다시 그린다
await watchSecrets(() => draw());

// ---------- 그리기 ----------
function itemEl(item, index) {
  const el = document.createElement('div');
  if (item.kind === 'user') {
    const wrap = document.createDocumentFragment();
    if (item.files?.length) {
      const box = document.createElement('div');
      box.className = 'msg-files';
      for (const f of item.files) {
        if (f.thumb) {
          const img = document.createElement('img');
          img.src = f.thumb;
          img.alt = img.title = f.name;
          box.append(img);
        } else {
          const chip = document.createElement('span');
          chip.className = 'file-chip';
          chip.textContent = `📄 ${f.name}`;
          box.append(chip);
        }
      }
      wrap.append(box);
    }
    if (item.text) {
      el.className = `msg user${item.queued ? ' queued' : ''}`;
      el.textContent = item.text;
      wrap.append(el);
    }
    if (item.queued) {
      const tag = document.createElement('div');
      tag.className = 'queued-tag';
      tag.textContent = '다음 단계에 AI에게 전달됩니다';
      wrap.append(tag);
    }
    return wrap;
  }
  if (item.kind === 'ai') {
    el.className = `msg ai${item.note ? ' note' : ''}`;
    // 똑소리 가림표([[비공개1]])는 여기서만 실제 값으로 — 대화 기록에는 가림표 그대로(secrets.js)
    el.innerHTML = renderMarkdown(revealSecrets(item.text));
    // 다 쓴 답(진행 메모 말고)에는 개선 요청 단추
    const writing = chat.open && index === chat.items.length - 1;
    if (!item.note && !writing) {
      const foot = document.createElement('div');
      foot.className = 'ai-foot';
      // 답 복사(보이는 글 그대로 — 표·목록 모양 기호 없이)
      const copy = document.createElement('button');
      copy.className = 'feedback-btn copy-btn';
      copy.innerHTML = COPY_ICON + ' 복사';
      copy.title = '이 답을 복사합니다';
      copy.addEventListener('click', async () => {
        const ok = await navigator.clipboard.writeText(el.innerText.trim()).then(() => true, () => false);
        copy.textContent = ok ? '✓ 복사함' : '복사하지 못했어요';
        setTimeout(() => { copy.innerHTML = COPY_ICON + ' 복사'; }, 1500);
      });
      foot.append(copy);
      if (item.feedback) {
        foot.append(Object.assign(document.createElement('span'), { textContent: '✓ 개선 요청 보냄', title: item.feedback }));
      } else {
        const btn = document.createElement('button');
        btn.className = 'feedback-btn';
        btn.dataset.index = index;
        btn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M4 20h4L18.5 9.5a2.1 2.1 0 0 0-3-3L5 17v3zM13.5 6.5l3 3"/></svg> 개선 요청';
        btn.title = '이 답이 마음에 들지 않으면 어떻게 바뀌면 좋을지 적어 보내 주세요';
        foot.append(btn);
      }
      const wrap = document.createDocumentFragment();
      wrap.append(el, foot);
      return wrap;
    }
  } else if (item.kind === 'secret') {
    if (!item.answer && secretEls.has(item.id)) return secretEls.get(item.id); // 입력 중인 칸을 지우지 않게
    el.className = `confirm secret${item.answer ? ' done' : ''}`;
    const p = document.createElement('p');
    p.textContent = item.text;
    el.append(p);
    if (item.answer) {
      el.append(Object.assign(document.createElement('div'), { className: 'confirm-answer', textContent: { done: '🔒 입력함(AI 에게는 보내지 않음)', saved: '🔒 입력하고 기억해 둠(맥 키체인 · ⚙︎ 설정에서 지울 수 있음)' }[item.answer] || '✕ 입력하지 않음' }));
    } else {
      const form = document.createElement('form');
      form.className = 'secret-form';
      form.dataset.secret = item.id;
      // 칸 이름이 여럿이면(카드번호·CVC 등) 이름마다 가려진 칸을 하나씩
      const names = item.fields?.length ? item.fields : [null];
      const inputs = names.map((name) => {
        const input = Object.assign(document.createElement('input'), { type: 'password', autocomplete: 'off', placeholder: name ? `${name} (화면에 보이지 않음)` : '여기에 입력 (화면에 보이지 않음)' });
        input.setAttribute('aria-label', name || '비밀번호');
        return input;
      });
      const input = inputs[0];
      const row = el.appendChild(document.createElement('div'));
      row.className = 'confirm-actions stack';
      const ok = Object.assign(document.createElement('button'), { type: 'submit', className: 'btn primary', textContent: '넣기' });
      const no = Object.assign(document.createElement('button'), { type: 'button', className: 'btn ghost', textContent: '취소' });
      no.dataset.secretCancel = item.id;
      for (const [i, x] of inputs.entries()) {
        if (names[i]) {
          const lab = document.createElement('label');
          lab.className = 'secret-label';
          lab.append(names[i], x);
          form.append(lab);
        } else form.append(x);
      }
      if (item.canSave) {
        const keep = document.createElement('label');
        keep.className = 'secret-keep';
        const box = Object.assign(document.createElement('input'), { type: 'checkbox', name: 'remember' });
        keep.append(box, ' 기억해 두기 — 로그인이 풀리면(예약 작업 중에도) Knock 이 이 사이트에만 알아서 넣음');
        form.append(keep);
      }
      row.append(ok, no); // 늘 같은 순서: 주요 단추 → 거절(글자만)
      form.append(row);
      el.append(form);
      secretEls.set(item.id, el);
      setTimeout(() => input.focus(), 0);
    }
  } else if (item.kind === 'confirm') {
    el.className = `confirm${item.answer ? ' done' : ''}`;
    const p = document.createElement('p');
    p.textContent = revealSecrets(item.text); // 가림표를 넣을지 묻는 카드: 사용자에게는 실제 값으로
    el.append(p);
    const choices = item.choices || [{ value: 'no', label: item.no || '하지 마' }, { value: 'yes', label: item.yes || '진행', primary: true }];
    if (item.answer) {
      el.append(Object.assign(document.createElement('div'), { className: 'confirm-answer', textContent: `${item.answer === 'yes' ? '✓' : '✕'} ${item.picked || (item.answer === 'yes' ? '진행' : '하지 마')}` }));
    } else {
      const row = document.createElement('div');
      // 묻는 단추는 늘 같은 순서로(2026-11-06 "항상 이 순서대로"): 한 줄에 하나씩 같은 너비로
      // 추천(주황) → 나머지(흰 단추) → 거절("하지 마"·"허용 안 함", 맨 아래 글자만). 둘뿐이어도 같다.
      row.className = 'confirm-actions stack';
      const ordered = [...choices.filter((c) => c.primary), ...choices.slice(1).filter((c) => !c.primary), choices[0]];
      for (const c of ordered) {
        const ghost = c === choices[0];
        const b = Object.assign(document.createElement('button'), { className: `btn${c.primary ? ' primary' : ''}${ghost ? ' ghost' : ''}`, textContent: c.label });
        b.dataset.confirm = item.id;
        b.dataset.value = c.value;
        row.append(b);
      }
      el.append(row);
    }
  } else if (item.kind === 'step') {
    el.className = `step${item.error ? ' err' : ''}`;
    el.textContent = item.text;
  } else {
    el.className = 'msg error';
    el.textContent = item.text;
  }
  return el;
}

let drawQueued = false;
const secretEls = new Map(); // 아직 답하지 않은 비밀번호 칸(id → 요소)
const openSteps = new Set(); // 펼쳐 둔 "확인 중" 묶음(첫 항목 번호)
function draw() {
  if (drawQueued) return;
  drawQueued = true;
  // 화면에 보일 때는 다음 그리기 때 한 번에, 숨어 있을 때(뒤 탭 등)는 바로 그린다(숨으면 그리기 신호가 오지 않음)
  (document.hidden ? (f) => setTimeout(f, 0) : requestAnimationFrame)(() => {
    drawQueued = false;
    const log = $('log');
    const atBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 40;
    const box = $('chat');
    box.textContent = '';
    // 연이은 작업 단계(와 그 사이 짧은 진행 메모)는 "확인 중" 한 줄로 접는다. 눌러야 펼쳐진다.
    const isStep = (it) => it.kind === 'step' || (it.kind === 'ai' && it.note);
    for (let i = 0; i < chat.items.length;) {
      if (!isStep(chat.items[i])) { box.append(itemEl(chat.items[i], i)); i++; continue; }
      const start = i;
      while (i < chat.items.length && isStep(chat.items[i])) i++;
      const group = chat.items.slice(start, i);
      const running = chat.busy && i === chat.items.length;
      const steps = group.filter((it) => it.kind === 'step');
      const last = steps[steps.length - 1]?.text || '';
      const det = document.createElement('details');
      det.className = `steps${steps.some((it) => it.error) ? ' err' : ''}${running ? ' running' : ''}`;
      det.open = openSteps.has(start);
      det.addEventListener('toggle', () => { if (det.open) openSteps.add(start); else openSteps.delete(start); });
      const sum = document.createElement('summary');
      // 피그마: "● 실행 중 · 2단계 · 자세히는 "실행 중" 탭" — 누르면 단계가 펼쳐진다(지금 하는 일은 마우스를 올리면)
      sum.textContent = running ? `실행 중 · ${steps.length}단계 · 자세히는 "실행 중" 탭` : `확인 완료 · ${steps.length}단계`;
      if (running) sum.title = last;
      det.append(sum);
      group.forEach((it, k) => det.append(itemEl(it, start + k)));
      box.append(det);
    }
    if (chat.busy && !chat.open) {
      const t = document.createElement('div');
      t.className = 'thinking';
      t.textContent = '생각하는 중';
      box.append(t);
    }
    $('hello').classList.toggle('hidden', chat.items.length > 0 || $('remote-asks').childElementCount > 0);
    // 일하는 중에도 보내기(덧붙이기)는 그대로 쓸 수 있다
    $('stop').classList.toggle('hidden', !chat.busy);
    $('send').disabled = status.state !== 'ready';
    $('send').title = chat.busy ? '덧붙이기 (AI가 다음 단계에 반영)' : '보내기 (Enter)';
    $('input').placeholder = chat.busy
      ? 'AI가 일하는 중에도 덧붙일 수 있어요 (Enter)'
      : privacy?.paused ? 'AI 가 꺼져 있어요 · 위에서 켜면 쓸 수 있어요' : '무엇을 맡길까요? (Enter 보내기, Shift+Enter 줄바꿈)';
    if (atBottom) log.scrollTop = log.scrollHeight;
  });
}

// ---------- 개선 요청: 답이 마음에 들지 않을 때 어떻게 바뀌면 좋을지 적어 보낸다 ----------
let feedbackIndex = null;
$('log').addEventListener('click', (e) => {
  const btn = e.target.closest('.feedback-btn:not(.copy-btn)');
  if (!btn) return;
  feedbackIndex = Number(btn.dataset.index);
  const item = chat.items[feedbackIndex];
  const plain = (item?.text || '').replace(/[*#`>|]+/g, '').replace(/\s+/g, ' ').trim();
  $('feedback-quote').textContent = plain.length > 140 ? `${plain.slice(0, 140)}…` : plain;
  $('feedback-text').value = '';
  $('feedback').classList.remove('hidden');
  $('feedback-text').focus();
});
$('feedback-cancel').addEventListener('click', () => $('feedback').classList.add('hidden'));
$('feedback-send').addEventListener('click', () => {
  const comment = $('feedback-text').value.trim();
  if (!comment) return $('feedback-text').focus();
  port.postMessage({ type: 'feedback', tabId, index: feedbackIndex, comment });
  $('feedback').classList.add('hidden');
});
$('feedback-text').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) $('feedback-send').click();
  if (e.key === 'Escape') $('feedback-cancel').click();
});

$('log').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-confirm]');
  if (!b) return;
  port.postMessage({ type: 'confirm', tabId, id: Number(b.dataset.confirm), value: b.dataset.value });
});

$('log').addEventListener('click', (e) => {
  const a = e.target.closest('a[data-href]');
  if (!a) return;
  e.preventDefault();
  // 원격 창 안의 AI 창이면 연동된 그 PC 에 새 탭으로 연다(remote-browser.js)
  if (window.parent !== window && window.parent.location?.pathname?.endsWith('/remote-browser.html')) return window.parent.postMessage({ type: 'openRemote', url: a.dataset.href }, location.origin);
  chrome.tabs.create({ url: a.dataset.href });
});

function drawStatus() {
  const text = {
    unknown: '도우미 프로그램에 연결하는 중…',
    nohost: `도우미 프로그램을 찾지 못했습니다.\n설치 폴더의 install.sh 를 한 번 실행해 주세요.${status.detail ? `\n(${status.detail})` : ''}`,
    login: '연결된 AI 가 없습니다.\n연결 설정에서 Claude·ChatGPT·Gemini 중 하나를 로그인하거나 API 키를 넣어 주세요.',
  }[status.state];
  $('setup').classList.toggle('hidden', !text || !$('settings').classList.contains('hidden'));
  $('setup-text').textContent = text || '';
  $('setup-open').classList.toggle('hidden', status.state !== 'login');
  drawSettings();
  drawModelSelect();
  draw();
}

// ---------- AI 서비스 연결 설정 ----------
const DOT = { claude: '#d97757', chatgpt: '#10a37f', gemini: '#4285f4' };
const ACCOUNT_DESC = {
  claude: '로그인한 계정의 요금제로 씀',
  chatgpt: '로그인한 계정의 요금제(Plus·Pro 등)로 씀',
  gemini: '개인 계정은 안 됨(회사용만) · 아래 API 키를 쓰세요',
};
const KEY_DESC = {
  claude: 'Anthropic API 키 · 쓴 만큼 요금',
  chatgpt: 'OpenAI API 키 · 쓴 만큼 요금',
  gemini: 'Google AI Studio 키 · 무료 사용량 있음',
};
const KEY_PAGE = {
  claude: 'https://console.anthropic.com/settings/keys',
  chatgpt: 'https://platform.openai.com/api-keys',
  gemini: 'https://aistudio.google.com/apikey',
};
const providerMsgs = {}; // 카드별 안내 글(다시 그려도 남게)
const logging = {}; // 로그인 기다리는 중인 AI → { url }
const installing = {}; // [설치] 중인 AI → true

// 지난 대화 탭: 누르면 지금 탭에서 그 대화를 이어 가고, 지우기로 목록에서 뺀다
// 지난 대화: 이 컴퓨터(지금 프로필 · 다른 프로필) / 원격 PC 로 나눠 보이고, 누르면 제자리에서 연다(2026-11-07)
//   지금 프로필 → 이 창(열려 있으면 그 탭) · 원격 PC → 그 PC 와 이은 원격용 창 · 다른 프로필 → 그 프로필 창
let pastMine = [];
let pastPeers = [];
const pastAgo = (t) => {
  const m = Math.round((Date.now() - t) / 60000);
  return m < 60 ? `${m}분 전` : m < 1440 ? `${Math.round(m / 60)}시간 전` : `${Math.round(m / 1440)}일 전`;
};
function drawPast(list) {
  if (list) pastMine = list;
  const box = $('past-view');
  box.textContent = '';
  const local = pastMine.filter((p) => !p.remote);
  const remotes = new Map();
  for (const p of pastMine.filter((x) => x.remote)) { if (!remotes.has(p.remote)) remotes.set(p.remote, []); remotes.get(p.remote).push(p); }
  if (!pastMine.length && !pastPeers.length) {
    const e = el('div', 'empty');
    e.append(el('b', '', '지난 대화가 없어요'), el('div', 'muted', '14일 동안 남아요 · 누르면 그 대화를 이어서 해요'));
    box.append(e);
    return;
  }
  // 이 컴퓨터: 지금 프로필 → 다른 프로필
  const dev = el('div', 'dev-head');
  dev.append(el('span', '', '🖥'), el('b', '', deviceName || '이 컴퓨터'), el('span', 'muted', '이 컴퓨터'));
  box.append(dev);
  if (local.length) {
    const g = profileGroup(box, profile.name || '이 프로필', profile.color, '지금 프로필');
    for (const p of local) pastRow(g, p, 'mine');
  }
  for (const peer of pastPeers) {
    const list2 = peer.list.filter((p) => !p.remote);
    if (!list2.length) continue;
    const g = profileGroup(box, peer.profile, peer.color, '다른 프로필 — 누르면 그 프로필 창에서 열려요');
    for (const p of list2) pastRow(g, p, 'peer', peer.profile);
  }
  // 원격 PC: 그 PC 마다(원격용 창에서 한 대화)
  for (const [pc, items] of remotes) {
    const h = el('div', 'dev-head remote');
    h.append(el('span', '', '🛰'), el('b', '', pc), el('span', 'muted', '원격 PC — 누르면 원격 창에서 열려요'));
    box.append(h);
    const g = el('div', 'pgroup');
    g.style.setProperty('--pc', '#0f766e');
    box.append(g);
    for (const p of items) pastRow(g, p, 'remote');
  }
}
function pastNote(text) {
  const n = el('p', 'past-note', text);
  $('past-view').prepend(n);
  setTimeout(() => n.remove(), 8000);
}
function profileGroup(box, name, color, note) {
  const g = el('div', 'pgroup');
  g.style.setProperty('--pc', color || 'var(--accent)');
  const chip = el('span', 'pchip');
  chip.append(el('span', 'pchip-av', (name || 'K').slice(0, 1)), el('span', '', name));
  const head = el('div', 'pgroup-head');
  head.append(chip, el('span', 'muted pgroup-note', note));
  g.append(head);
  box.append(g);
  return g;
}
function pastRow(g, p, kind, peerProfile) {
  {
    const row = el('div', 'past-row');
    const b = el('button', 'past-item');
    const here = kind === 'mine' && p.openTab === tabId;
    const where = kind === 'remote' ? `원격 · ${p.remote} · ` : kind === 'peer' ? `${peerProfile} 프로필 · ` : '';
    b.append(el('div', 'past-first', p.first || '(첫 질문 없음)'), el('div', 'past-meta', `${here ? '지금 이 탭 · ' : p.openTab ? '열려 있는 탭 · ' : ''}${where}${pastAgo(p.at)}${kind === 'remote' ? '' : ` · ${p.title || p.url || ''}`}`));
    b.title = kind === 'remote' ? `"${p.remote}" 원격 창에서 이어서 합니다` : kind === 'peer' ? `"${peerProfile}" 프로필 창에서 이어서 합니다` : p.openTab ? '이 대화가 열려 있는 탭으로 갑니다' : '이 대화를 새 탭에서 이어서 합니다';
    b.addEventListener('click', () => {
      if (here) return setView('chat');
      if (kind !== 'mine') {
        b.querySelector('.past-meta').textContent = kind === 'remote' ? '원격 창을 찾는 중…' : `"${peerProfile}" 프로필 창에서 여는 중…`;
        port.postMessage({ type: 'resumeElsewhere', tabId, key: p.key, ...(kind === 'remote' ? { remote: p.remote } : { profile: peerProfile }) });
        return;
      }
      if (p.openTab) {
        if (p.openWin && p.openWin !== myWindow?.id) chrome.sidePanel.open({ windowId: p.openWin }).catch(() => {});
        chrome.tabs.update(p.openTab, { active: true }).then(() => chrome.windows.update(p.openWin, { focused: true })).then(() => setView('chat')).catch(() => {});
        return;
      }
      port.postMessage({ type: 'resumeChat', tabId, key: p.key, newTab: true });
      setView('chat');
    });
    // 지우기는 한 번 더 눌러야 지운다(잘못 누름 막기) — 다른 프로필 대화는 그 프로필에서 지운다
    if (kind === 'peer') {
      row.append(b);
    } else {
      const del = el('button', 'past-del', '지우기');
      del.addEventListener('click', () => {
        if (del.classList.contains('sure')) return port.postMessage({ type: 'deletePast', tabId, key: p.key });
        del.classList.add('sure');
        del.textContent = '정말 지우기';
        setTimeout(() => { del.classList.remove('sure'); del.textContent = '지우기'; }, 3000);
      });
      row.append(b, del);
    }
    g.append(row);
  }
}

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function button(text, action, id, primary) {
  const b = el('button', `btn${primary ? ' primary' : ''}`, text);
  b.dataset.action = action;
  b.dataset.provider = id;
  return b;
}

// Gemini 칸 로그인 줄. 설정을 다시 그릴 때마다 카드가 지워지므로 처음에 잡아 두고 매번 다시 붙인다.
const gemLoginRow = document.getElementById('gem-login-row');
const AI_ICON = { claude: '✳', chatgpt: '◎', gemini: '✦' };
const AI_GROUP = { chatgpt: 'ChatGPT · Codex' };
const keyOpen = {}; // [API 키 넣기]를 눌러 키 칸을 연 AI
function drawSettings() {
  const box = $('services');
  const providers = Object.values(status.providers || {});
  if (!providers.length) return;
  box.textContent = '';
  const card = el('div', 'service');
  const gemBox = el('div', 'service');
  for (const p of providers) {
    if (!p.installed) {
      // [설치]: Knock 이 공식 설치 프로그램을 대신 돌린다(Claude=claude.ai, ChatGPT=npm @openai/codex)
      const row = el('div', 'conn');
      const m = el('div', 'conn-main');
      m.append(el('div', 'conn-title', '프로그램 설치'), el('div', 'conn-desc', p.canInstall
        ? `${THIS_PC}에 ${p.name} 프로그램이 없습니다. [설치]를 누르면 공식 설치 프로그램으로 설치합니다(1~3분).`
        : `${THIS_PC}에서 ${p.name} 프로그램을 찾지 못했습니다. ${p.install}`));
      row.append(m);
      if (p.canInstall) {
        const a = el('div', 'conn-actions');
        const b = button(installing[p.id] ? '설치하는 중…' : '설치', 'install', p.id, true);
        b.disabled = Boolean(installing[p.id]);
        a.append(b);
        row.append(a);
      }
      m.querySelector('.conn-title').textContent = `${AI_GROUP[p.id] || p.name} · 프로그램 설치`;
      card.append(row);
      if (providerMsgs[p.id]?.text) {
        const msg = el('p', 'settings-msg', providerMsgs[p.id].text);
        msg.classList.toggle('err', !providerMsgs[p.id].ok);
        card.append(msg);
      }
      continue;
    }
    // 피그마 ② 설정 › AI 사용 연동: AI 하나 = 한 줄(아이콘 · 이름 · 한 줄 설명 | 계정 상태·단추 / 키 상태·단추)
    // Gemini 에이전트는 키를 넣었을 때만 줄을 보인다(평소 Gemini 는 아래 "Gemini 연동"의 구글 로그인)
    if (p.id === 'gemini' && !p.apiKey.set && !p.ready && !keyOpen.gemini) {
      if (gemLoginRow) gemBox.append(gemLoginRow);
      const add = el('button', 'link-btn', 'Knock AI 를 Gemini 로 쓰기(API 키) ›');
      add.type = 'button';
      add.addEventListener('click', () => { keyOpen.gemini = true; drawSettings(); });
      gemBox.append(add);
      continue;
    }
    const row = el('div', 'conn ai-row');
    const icon = el('span', 'row-icon', AI_ICON[p.id] || '✦');
    icon.style.color = DOT[p.id] || 'var(--muted)';
    const main = el('div', 'conn-main');
    const keyName = { claude: 'Anthropic', chatgpt: 'OpenAI', gemini: 'Google AI Studio' }[p.id] || '';
    main.append(el('div', 'conn-title', AI_GROUP[p.id] || p.name), el('div', 'conn-desc', p.account.loggedIn
      ? `${p.account.email || `${p.name} 계정`}으로 연결됨 · 계정 대신 ${keyName} API 키로도 쓸 수 있어요`
      : p.apiKey.set ? `API 키 …${p.apiKey.tail} 로 쓰는 중 · ${KEY_DESC[p.id]}` : ACCOUNT_DESC[p.id]));
    const side = el('div', 'ai-side');
    if (p.allow?.account !== false) {
      const line = el('div', 'ai-line');
      line.append(p.account.loggedIn ? el('span', 'pill ok', '연결됨') : el('span', 'pill', '연결 안 됨'), p.account.loggedIn ? button('로그아웃', 'logout', p.id) : button('로그인', 'login', p.id, true));
      side.append(line);
    }
    if (p.allow?.apiKey !== false) {
      const line = el('div', 'ai-line');
      line.append(p.apiKey.set ? el('span', 'pill ok', `키 …${p.apiKey.tail}`) : el('span', 'pill', '키 없음'), p.apiKey.set ? button('키 지우기', 'removeKey', p.id) : button('API 키 넣기', 'openKey', p.id));
      side.append(line);
    }
    row.append(icon, main, side);
    card.append(row);
    // API 키 넣기를 누르면 그 아래에 키 칸
    if (keyOpen[p.id] && !p.apiKey.set) {
      const form = el('div', 'conn key-open');
      const km = el('div', 'conn-main');
      const f = el('div', 'row-actions inline-form');
      const input = el('input');
      Object.assign(input, { type: 'password', placeholder: p.keyHint, autocomplete: 'off', spellcheck: false });
      input.dataset.provider = p.id;
      f.append(input, button('연결', 'setKey', p.id, true));
      km.append(el('div', 'conn-desc', `${KEY_DESC[p.id]}${p.allow?.account !== false ? ' · 있으면 계정보다 먼저 씀' : ''}`), f);
      if (KEY_PAGE[p.id]) {
        const a = el('a', 'key-link', '키 만들러 가기 ↗');
        Object.assign(a, { href: KEY_PAGE[p.id], target: '_blank', rel: 'noopener' });
        km.append(a);
      }
      form.append(km);
      card.append(form);
      setTimeout(() => input.focus());
    }
    // 로그인 기다리는 중: 브라우저에서 로그인을 마치면 Knock 이 알아채고 연결한다
    if (logging[p.id]) {
      const wait = el('div', 'login-wait');
      wait.append(el('span', 'login-wait-text', '로그인을 마치면 자동으로 연결됩니다…'));
      const r = el('div', 'login-wait-actions');
      if (logging[p.id].url) r.append(button('로그인 페이지 열기', 'openLogin', p.id));
      r.append(button('취소', 'loginCancel', p.id));
      wait.append(r);
      card.append(wait);
    }
    const m = providerMsgs[p.id];
    if (m) {
      const msg = el('p', 'settings-msg', m.text);
      msg.classList.toggle('err', !m.ok);
      card.append(msg);
    }
    if (p.id === 'gemini' && gemLoginRow) gemBox.prepend(gemLoginRow);
  }
  if (gemLoginRow && !gemBox.contains(gemLoginRow)) gemBox.prepend(gemLoginRow);
  box.append(card);
  // ✦ Gemini 연동(옆 창 Gemini 의 구글 로그인)
  if (gemBox.childElementCount) {
    const h = el('div', 'settings-head sub');
    h.append(el('b', '', '✦ Gemini 연동'));
    box.append(h, gemBox);
  }
  // 왼쪽 "AI 사용 연동" 옆 숫자: 연결이 필요한 것
  const need = providers.filter((p) => p.id !== 'gemini' && p.installed && !p.ready).length;
  const badge = document.querySelector('.set-cat[data-cat="ai"] .set-badge');
  if (badge) { badge.textContent = need || ''; badge.classList.toggle('hidden', !need); }
}

function providerMsg(id, text, ok = true) {
  providerMsgs[id] = text ? { text, ok } : null;
  drawSettings();
}

$('services').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-action]');
  if (!b) return;
  const { action, provider } = b.dataset;
  const name = status.providers?.[provider]?.name || provider;
  if (action === 'openKey') { keyOpen[provider] = true; drawSettings(); return; }
  if (action === 'install') {
    installing[provider] = true;
    providerMsg(provider, '');
    port.postMessage({ type: 'install', provider });
  } else if (action === 'login') {
    logging[provider] = { url: null };
    providerMsg(provider, '');
    port.postMessage({ type: 'login', provider });
  } else if (action === 'openLogin') {
    if (logging[provider]?.url) chrome.tabs.create({ url: logging[provider].url });
  } else if (action === 'loginCancel') {
    delete logging[provider];
    port.postMessage({ type: 'loginCancel', provider });
    drawSettings();
  } else if (action === 'logout') {
    if (!confirm(`Knock 의 ${name} 계정 연결을 해제할까요?\n(${THIS_PC}의 다른 프로그램 로그인은 그대로입니다)`)) return;
    providerMsg(provider, '해제하는 중…');
    port.postMessage({ type: 'logout', provider });
  } else if (action === 'setKey') {
    const input = $('services').querySelector(`input[data-provider="${provider}"]`);
    const key = input?.value.trim();
    if (!key) return input?.focus();
    b.disabled = true;
    providerMsg(provider, '키를 확인하는 중…');
    port.postMessage({ type: 'setKey', provider, key });
  } else if (action === 'removeKey') {
    if (!confirm(`${name} API 키 연결을 해제할까요?`)) return;
    port.postMessage({ type: 'removeKey', provider });
  }
});
$('confirm-level').addEventListener('change', () => port.postMessage({ type: 'setConfirm', level: $('confirm-level').value }));

// ---------- 개인정보(AI 에게 보내는 정보) ----------
let privacy = null;
let siteHost = null;

function drawPrivacy() {
  if (!privacy) return;
  $('pv-scope').value = privacy.scope;
  $('pv-shots').value = privacy.screenshots;
  $('pv-personal').value = privacy.personal;
  $('pv-secrets').value = privacy.secrets || 'mask';
  $('pv-toksori').value = privacy.toksoriPersonal || 'ask';
  $('pv-password').value = privacy.passwordInput || 'never';
  $('pv-paused').checked = privacy.paused;
  if ($('ai-use')) $('ai-use').checked = !privacy.paused;
}

// (2026-11-09 원장님 "AI 허용 단추 없애" — AI 창 위 사이트 AI 허용·막음 단추는 다시 만들지 않는다. check-removed.sh 가 막는다)

function savePrivacy(patch) {
  port.postMessage({ type: 'privacy', patch });
}

// 프로필 이름: 저장된 이름과 같으면 "✓ 저장됨" 표시를 두고 저장 단추는 쉬게 한다. 고치면 표시가 사라지고 단추가 켜진다.
let savedProfile = null;
function drawProfileSaved() {
  const same = savedProfile !== null && $('profile-name').value.trim() === savedProfile;
  $('profile-saved').classList.toggle('hidden', !same);
  $('profile-save').disabled = same || !$('profile-name').value.trim();
}
$('profile-name').addEventListener('input', drawProfileSaved);
$('profile-save').addEventListener('click', () => {
  const name = $('profile-name').value.trim();
  if (!name) return $('profile-name').focus();
  port.postMessage({ type: 'profileName', name });
});
$('profile-name').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('profile-save').click(); });

// 프로필 칩(AI 창 맨 위)·프로필 색 — 색은 이 프로필에만 저장한다
function drawProfileChip() {
  const c = $('profile-chip');
  c.textContent = '';
  c.style.setProperty('--pc', profile.color);
  c.append(el('span', 'pchip-av', (profile.name || 'K').slice(0, 1)), el('span', '', profile.name || ''));
  for (const b of $('profile-colors').querySelectorAll('button')) {
    b.style.background = b.dataset.color;
    b.classList.toggle('on', b.dataset.color === profile.color);
  }
  if (lastJobs.length || lastScheds.length) drawJobs(lastJobs);
}
chrome.storage.local.get('profileColor').then(({ profileColor }) => {
  if (profileColor) profile.color = profileColor;
  drawProfileChip();
});
$('profile-colors').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-color]');
  if (!b) return;
  profile.color = b.dataset.color;
  chrome.storage.local.set({ profileColor: profile.color });
  drawProfileChip();
});

// 똑소리 계정 · 로그인된 장치(설정 › 장치·프로필) — 서버와 주고받는 것은 background(account.js)
let devices = null;
function drawAccount(m) {
  $('acct-out-row').classList.toggle('hidden', m.loggedIn || !$('acct-form').classList.contains('hidden'));
  if (m.loggedIn) closeAcctForm();
  $('acct-in-row').classList.toggle('hidden', !m.loggedIn);
  $('acct-dev-row').classList.toggle('hidden', !m.loggedIn);
  $('acct-remote-row').classList.toggle('hidden', !m.loggedIn);
  $('acct-remote-open-row').classList.toggle('hidden', !m.loggedIn);
  $('acct-msg').textContent = m.error || '';
  $('acct-msg').classList.toggle('error', Boolean(m.error));
  if (m.loggedIn) {
    $('acct-who').textContent = [m.account?.name, m.account?.email].filter(Boolean).join(' · ');
    port.postMessage({ type: 'accountDevices' });
    port.postMessage({ type: 'remoteState' });
  } else {
    devices = null;
    $('dev-modal').classList.add('hidden');
  }
}
function drawDevices(m) {
  $('dev-msg').textContent = m.error || '';
  $('dev-msg').classList.toggle('error', Boolean(m.error));
  if (m.error) return;
  devices = m.devices || [];
  $('acct-dev-open').textContent = `${devices.length}대 ›`;
  $('dev-title').textContent = `로그인된 장치 ${devices.length}대`;
  const row = (d) => {
    const r = el('div', 'dev-row');
    const t = el('div', 'dev-main');
    const os = d.os === 'Windows' ? 'Windows' : 'Mac';
    const seen = d.thisDevice ? '이 컴퓨터' : d.online ? '켜져 있음' : `마지막 ${new Date(d.lastSeenAt).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false })}`;
    t.append(el('b', '', d.name), el('div', 'muted', `${os} · ${seen}`));
    r.append(t);
    if (d.thisDevice) r.append(el('span', 'badge-on', '● 지금 쓰는 중'));
    else {
      const b = el('button', 'btn danger-btn', '로그아웃');
      b.addEventListener('click', () => {
        if (b.dataset.sure) return port.postMessage({ type: 'accountLogoutDevice', which: { id: d.id } });
        b.dataset.sure = '1';
        b.textContent = '정말 로그아웃';
        setTimeout(() => { delete b.dataset.sure; b.textContent = '로그아웃'; }, 3000);
      });
      r.append(b);
    }
    return r;
  };
  $('dev-this').replaceChildren(...devices.filter((d) => d.thisDevice).map(row));
  const others = devices.filter((d) => !d.thisDevice);
  $('dev-others-label').textContent = `다른 장치 ${others.length}대`;
  $('dev-others').replaceChildren(...(others.length ? others.map(row) : [el('p', 'muted', '다른 장치는 없어요')]));
  $('dev-logout-others').classList.toggle('hidden', !others.length);
}
// 로그인·간단 가입은 설정 창 안에서(2026-11-05) — 웹 탭을 열지 않는다
const af = { email: '', busy: false };
function afShow(view) {
  $('acct-out-row').classList.add('hidden');
  $('acct-form').classList.remove('hidden');
  $('af-login').classList.toggle('hidden', view !== 'login');
  $('af-signup').classList.toggle('hidden', view === 'login');
  afMsg('');
  if (view === 'login') $('af-email').focus();
  else afStep(0);
}
function afStep(n) {
  af.step = n;
  document.querySelectorAll('#af-signup .af-step').forEach((d) => d.classList.toggle('hidden', Number(d.dataset.s) !== n));
  document.querySelectorAll('.af-steps span').forEach((d) => d.classList.toggle('on', Number(d.dataset.s) === n));
  afMsg('');
  const first = document.querySelector(`#af-signup .af-step[data-s="${n}"] input`);
  if (first) first.focus();
}
function afMsg(text, error) {
  $('af-msg').textContent = text || '';
  $('af-msg').classList.toggle('error', Boolean(error));
}
function afBusy(on) {
  af.busy = on;
  $('acct-form').querySelectorAll('button.btn').forEach((b) => { b.disabled = on || (b.id === 'af-signup-go' && !$('af-terms').checked); });
}
function closeAcctForm() {
  $('acct-form').classList.add('hidden');
  ['af-pw', 'af-su-pw', 'af-su-pw2', 'af-code'].forEach((id) => { $(id).value = ''; });
  afBusy(false);
}
$('acct-login').addEventListener('click', () => afShow('login'));
$('af-to-signup').addEventListener('click', () => { $('af-su-email').value = $('af-email').value.trim(); afShow('signup'); });
$('af-back').addEventListener('click', () => {
  // 가입 중이면 한 단계 앞으로, 첫 단계·로그인 화면이면 설정으로
  if (!$('af-signup').classList.contains('hidden')) {
    if (af.step > 0) return afStep(af.step === 2 ? 0 : af.step - 1);
    return afShow('login');
  }
  closeAcctForm();
  $('acct-out-row').classList.remove('hidden');
});
document.querySelectorAll('.af-eye').forEach((b) => b.addEventListener('click', () => {
  const i = $(b.dataset.for);
  i.type = i.type === 'password' ? 'text' : 'password';
  b.classList.toggle('on', i.type === 'text');
}));
const afEmailOk = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
function afLogin() {
  const email = $('af-email').value.trim();
  const password = $('af-pw').value;
  if (!afEmailOk(email)) return afMsg('이메일을 확인해 주세요.', true);
  if (!password) return afMsg('비밀번호를 입력해 주세요.', true);
  afBusy(true);
  afMsg('로그인하는 중…');
  port.postMessage({ type: 'accountPasswordLogin', email, password });
}
$('af-login-go').addEventListener('click', afLogin);
$('af-pw').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing) afLogin(); });
$('af-email').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing) $('af-pw').focus(); });
$('af-find-id').addEventListener('click', () => port.postMessage({ type: 'accountWebPage', page: 'findId' }));
$('af-find-pw').addEventListener('click', () => port.postMessage({ type: 'accountWebPage', page: 'findPw' }));
$('af-terms-view').addEventListener('click', (e) => { e.preventDefault(); port.postMessage({ type: 'accountWebPage', page: 'terms' }); });
function afSend() {
  const email = $('af-su-email').value.trim().toLowerCase();
  if (!afEmailOk(email)) return afMsg('이메일 주소 형식이 올바르지 않아요.', true);
  af.email = email;
  afBusy(true);
  afMsg('인증번호를 보내는 중…');
  port.postMessage({ type: 'accountSignup', step: 'send-code', body: { email } });
}
$('af-send').addEventListener('click', afSend);
$('af-su-email').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing) afSend(); });
$('af-resend').addEventListener('click', afSend);
function afVerify() {
  const code = $('af-code').value.trim();
  if (!/^\d{6}$/.test(code)) return afMsg('인증번호 6자리를 입력해 주세요.', true);
  afBusy(true);
  port.postMessage({ type: 'accountSignup', step: 'verify-code', body: { email: af.email, code } });
}
$('af-verify').addEventListener('click', afVerify);
$('af-code').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing) afVerify(); });
function afPwNext() {
  const pw = $('af-su-pw').value;
  if (pw.length < 8) return afMsg('비밀번호는 8자 이상이어야 해요.', true);
  if (pw !== $('af-su-pw2').value) return afMsg('두 비밀번호가 달라요.', true);
  afStep(3);
}
$('af-pw-next').addEventListener('click', afPwNext);
$('af-su-pw2').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing) afPwNext(); });
$('af-terms').addEventListener('change', () => { $('af-signup-go').disabled = af.busy || !$('af-terms').checked; });
$('af-signup-go').addEventListener('click', () => {
  afBusy(true);
  afMsg('가입하는 중…');
  port.postMessage({ type: 'accountSignup', step: 'create', body: { email: af.email, password: $('af-su-pw').value, agreeTerms: true } });
});
function drawAccountForm(m) {
  afBusy(false);
  if (m.error) return afMsg(m.error, true);
  if (m.step === 'send-code') {
    $('af-sent-to').textContent = `${af.email} 로 인증번호를 보냈어요 · 10분 안에 넣어 주세요`;
    afStep(1);
  } else if (m.step === 'verify-code') afStep(2);
  else if (m.step === 'create') {
    // 가입이 끝나면 같은 이메일·비밀번호로 바로 로그인
    afMsg('가입됐어요 · 로그인하는 중…');
    afBusy(true);
    port.postMessage({ type: 'accountPasswordLogin', email: af.email, password: $('af-su-pw').value });
  }
}
let remoteDev = null;
$('acct-devname-save').addEventListener('click', () => {
  const name = $('acct-devname').value.trim();
  if (name) port.postMessage({ type: 'remoteSet', patch: { name }, okText: '장치 이름을 저장했어요' });
});
$('acct-pw-save').addEventListener('click', () => {
  const pw = $('acct-pw').value;
  if (pw.length < 6) { $('acct-msg').textContent = '비밀번호는 6자 이상으로 정해 주세요.'; $('acct-msg').classList.add('error'); return $('acct-pw').focus(); }
  port.postMessage({ type: 'remoteSet', patch: { remotePassword: pw }, okText: '원격 비밀번호를 바꿨어요' });
});
$('acct-remote').addEventListener('change', () => {
  // 비밀번호를 아직 안 정했으면 원격 연결 화면에서 이름·비밀번호부터
  if ($('acct-remote').checked && !remoteDev?.hasPassword) { $('acct-remote').checked = false; return chrome.tabs.create({ url: chrome.runtime.getURL('remote-connect.html?add=1') }); }
  if ($('acct-remote').checked) chrome.permissions.request({ permissions: ['background'] }).catch(() => {}); // 브라우저를 닫아도 원격 대기
  port.postMessage({ type: 'remoteSet', patch: { remoteEnabled: $('acct-remote').checked } });
});
$('acct-remote-open').addEventListener('click', () => port.postMessage({ type: 'remoteOpen' }));
$('acct-me').addEventListener('click', () => port.postMessage({ type: 'accountMyPage' }));
// 이 장치 로그아웃은 한 번에(다시 로그인하면 되므로 되묻지 않는다)
$('acct-logout').addEventListener('click', () => port.postMessage({ type: 'accountLogout' }));
$('acct-dev-open').addEventListener('click', () => { $('dev-modal').classList.remove('hidden'); port.postMessage({ type: 'accountDevices' }); });
$('dev-close').addEventListener('click', () => $('dev-modal').classList.add('hidden'));
$('dev-modal').addEventListener('click', (e) => { if (e.target === $('dev-modal')) $('dev-modal').classList.add('hidden'); });
$('dev-logout-others').addEventListener('click', () => {
  const b = $('dev-logout-others');
  if (b.dataset.sure) return port.postMessage({ type: 'accountLogoutDevice', which: { others: true } });
  b.dataset.sure = '1';
  b.textContent = '정말 모두 로그아웃';
  setTimeout(() => { delete b.dataset.sure; b.textContent = '다른 장치 모두 로그아웃'; }, 3000);
});

// 다른 컴퓨터 잇기
function drawLinks(m) {
  if (document.activeElement !== $('link-name')) $('link-name').value = m.device?.name || '';
  if (m.code !== undefined) $('link-code').textContent = m.code ? `${m.code.slice(0, 3)} ${m.code.slice(3, 6)} ${m.code.slice(6)} · 10분 동안` : '';
  $('link-msg').textContent = m.error || m.msg || '';
  $('link-msg').classList.toggle('error', Boolean(m.error));
  const list = $('link-list');
  list.replaceChildren();
  for (const l of m.links || []) {
    const li = document.createElement('li');
    const what = l.role === 'controller' ? '이 컴퓨터의 AI가 씀' : `그 컴퓨터의 AI가 이 컴퓨터를 씀 · ${l.always ? '항상 허용' : '매번 묻기'}`;
    const label = document.createElement('span');
    label.textContent = `${l.name} — ${what}${l.open ? ' · 연결됨' : ''}`;
    li.append(label);
    if (l.role === 'controlled') {
      const t = document.createElement('button');
      t.className = 'btn';
      t.textContent = l.always ? '매번 묻기로' : '항상 허용으로';
      t.addEventListener('click', () => port.postMessage({ type: 'linkAlways', id: l.id, always: !l.always }));
      li.append(t);
    }
    const del = document.createElement('button');
    del.className = 'btn';
    del.textContent = '지우기';
    del.addEventListener('click', () => port.postMessage({ type: 'linkRemove', id: l.id }));
    li.append(del);
    list.append(li);
  }
}
$('link-name-save').addEventListener('click', () => {
  const name = $('link-name').value.trim();
  if (name) port.postMessage({ type: 'linkName', name });
});
$('link-make').addEventListener('click', () => { $('link-msg').textContent = '번호를 만드는 중…'; port.postMessage({ type: 'linkMakeCode' }); });
$('link-join').addEventListener('click', () => {
  if ($('link-join-code').value.replace(/\D/g, '').length !== 9) { $('link-msg').textContent = '9자리 번호를 넣어 주세요.'; return; }
  $('link-pick').classList.remove('hidden');
});
for (const [id, always] of [['link-pick-once', false], ['link-pick-always', true]]) {
  $(id).addEventListener('click', () => {
    $('link-pick').classList.add('hidden');
    $('link-msg').textContent = '잇는 중…';
    port.postMessage({ type: 'linkJoin', code: $('link-join-code').value, always });
    $('link-join-code').value = '';
  });
}
$('link-pick-no').addEventListener('click', () => { $('link-pick').classList.add('hidden'); $('link-join-code').value = ''; $('link-msg').textContent = ''; });

$('pv-scope').addEventListener('change', () => savePrivacy({ scope: $('pv-scope').value }));
$('pv-shots').addEventListener('change', () => savePrivacy({ screenshots: $('pv-shots').value }));
// AI의 민감정보 사용(막기·묻기·허용) — 똑소리 민감정보 조회도 이것을 따른다(2026-11-04 피그마 결정: 두 줄을 하나로).
// 똑소리 조회 값은 늘 가림표로만 AI 에게 가므로 막기여도 조회는 되고, 묻기면 조회 전에 묻는다.
$('pv-personal').addEventListener('change', () => {
  const v = $('pv-personal').value;
  savePrivacy({ personal: v, toksoriPersonal: v === 'ask' ? 'ask' : 'allow' });
});
$('pv-secrets').addEventListener('change', () => savePrivacy({ secrets: $('pv-secrets').value }));
$('pv-toksori').addEventListener('change', () => savePrivacy({ toksoriPersonal: $('pv-toksori').value }));
$('pv-password').addEventListener('change', () => savePrivacy({ passwordInput: $('pv-password').value }));
$('pv-paused').addEventListener('change', () => savePrivacy({ paused: $('pv-paused').checked }));
// 사이트 요령: 기본 요령은 개수만, AI 가 배운 요령은 하나씩(지울 수 있게)
function drawTips({ learned, builtin }) {
  const list = $('tips-list');
  list.textContent = '';
  const hosts = [...new Set([...Object.keys(builtin), ...Object.keys(learned)])].sort();
  if (!hosts.length) list.append(el('li', 'muted', '아직 없어요'));
  // 접어 두고 개수만 보인다(펼치면 하나씩 보고 지울 수 있다)
  const total = hosts.reduce((n, h) => n + (learned[h]?.length || 0) + (builtin[h] ? builtin[h].total - builtin[h].off : 0), 0);
  $('tips-summary').textContent = hosts.length ? `사이트 ${hosts.length}곳 · 요령 ${total}개` : '아직 없어요';
  // 설정 › AI 작동 설정의 "사이트별 작동 설정" 줄: 사이트 이름 몇 개 · N곳
  const ld = document.getElementById('tips-link-desc');
  if (ld) ld.textContent = hosts.length ? `${hosts.slice(0, 3).join(' · ')}${hosts.length > 3 ? ` 등 ${hosts.length}곳` : ''} · 요령 ${total}개` : 'AI가 사이트를 쓰면서 익힌 요령이 여기에 쌓여요';
  for (const host of hosts) {
    const b = builtin[host];
    list.append(el('li', 'tip-host', `${host}${b ? ` · 기본 요령 ${b.total - b.off}개${b.off ? `(AI 가 틀려서 끈 것 ${b.off}개)` : ''}` : ''}`));
    for (const t of learned[host] || []) {
      const li = el('li', 'tip');
      li.append(el('span', '', `· ${t.text}`));
      const x = el('button', 'icon-btn', '✕');
      x.title = '이 요령 지우기';
      Object.assign(x.dataset, { host, at: String(t.at) });
      li.append(x);
      list.append(li);
    }
  }
}
$('tips-toggle').addEventListener('click', () => {
  const open = $('tips-list').classList.toggle('hidden') === false;
  $('tips-toggle').textContent = open ? '접기' : '자세히 보기';
});
$('tips-list').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-at]');
  if (b) port.postMessage({ type: 'forgetTip', host: b.dataset.host, at: Number(b.dataset.at) });
});
// 예약 작업 목록(취소하면 보관한 첨부도 지운다)
const REPEAT_TEXT = { none: '', daily: '매일', weekdays: '평일', weekly: '매주', every: '분마다' };
function drawSchedules(list) {
  const ul = $('schedule-list');
  ul.textContent = '';
  if (!list.length) ul.append(el('li', 'muted', '아직 없어요'));
  const time = (ms) => new Date(ms).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false });
  for (const x of list) {
    const li = el('li', 'tip');
    const when = x.repeat === 'every' ? `${x.every}분마다` : `${REPEAT_TEXT[x.repeat] || ''}`;
    li.append(el('span', '', `⏰ ${x.title}${when ? ` · ${when}` : ''} · 다음 ${x.next ? time(x.next) : '실행 중'}${x.auto ? ' · 알아서 진행' : ''}${x.files?.length ? ` · 첨부 ${x.files.join(', ')}` : ''}`));
    const b = el('button', 'icon-btn', '✕');
    b.title = '예약 취소(보관한 첨부도 지움)';
    b.dataset.schedule = x.id;
    li.append(b);
    ul.append(li);
  }
}
$('schedule-list').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-schedule]');
  if (!b) return;
  // 실수로 지우지 않게 두 번 누르게 한다
  if (b.dataset.armed) port.postMessage({ type: 'cancelSchedule', id: b.dataset.schedule });
  else Object.assign(b, { textContent: '취소하기' }).dataset.armed = '1';
});
// 계속 허용한 단추(사이트별)
function drawClickAllow(list) {
  const ul = $('click-allow-list');
  ul.textContent = '';
  const hosts = Object.keys(list).sort();
  if (!hosts.length) ul.append(el('li', 'muted', '아직 없어요'));
  for (const host of hosts) {
    ul.append(el('li', 'tip-host', host));
    for (const label of list[host]) {
      const li = el('li', 'tip');
      li.append(el('span', '', `· "${label}"`));
      const x = el('button', 'icon-btn', '✕');
      x.title = '다시 묻게 하기';
      Object.assign(x.dataset, { host, label });
      li.append(x);
      ul.append(li);
    }
  }
}
$('click-allow-list').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-label]');
  if (b) port.postMessage({ type: 'forgetClickAllow', host: b.dataset.host, label: b.dataset.label });
});
// 묻지 않고 허용할 사이트(권한 창)
function drawLocalSites(msg) {
  const ul = $('lna-list');
  ul.textContent = '';
  if (!msg.list.length) ul.append(el('li', 'muted', '아직 없어요'));
  for (const site of msg.list) {
    const li = el('li', 'tip');
    li.append(el('span', '', `· ${site}`));
    const x = el('button', 'icon-btn', '✕');
    x.title = '다시 묻게 하기';
    x.dataset.lna = site;
    li.append(x);
    ul.append(li);
  }
  $('lna-add').disabled = !msg.supported;
  if (!msg.supported) $('lna-note').textContent = 'Knock Browser 를 업데이트하면 쓸 수 있어요';
  else if (msg.note) $('lna-note').textContent = msg.note;
}
$('lna-list').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-lna]');
  if (b) port.postMessage({ type: 'forgetLocalSite', site: b.dataset.lna });
});
$('lna-add').addEventListener('click', () => port.postMessage({ type: 'addLocalSite', tabId }));
function drawVault(list) {
  const ul = $('vault-list');
  ul.textContent = '';
  if (!list.length) ul.append(el('li', 'muted', '아직 없어요'));
  for (const v of list) {
    const li = el('li', 'tip');
    li.append(el('span', '', `· ${v.site}${v.username ? ` (${v.username})` : ''}`));
    const x = el('button', 'icon-btn', '✕');
    x.title = '잊기(키체인에서도 지움)';
    x.dataset.vaultSite = v.site;
    li.append(x);
    ul.append(li);
  }
}
$('vault-list').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-vault-site]');
  if (b) port.postMessage({ type: 'vaultDelete', site: b.dataset.vaultSite });
});
$('pv-redisclose').addEventListener('click', () => {
  port.postMessage({ type: 'redisclose' });
  notice('다음에 각 AI 에게 보낼 때 다시 안내합니다.');
});

$('services').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && e.target.matches('input[data-provider]')) {
    $('services').querySelector(`button[data-action="setKey"][data-provider="${e.target.dataset.provider}"]`)?.click();
  }
});

// ---------- 쓸 AI·모델 고르기(입력칸 아래) ----------
let selectedModel = 'claude:claude-opus-5-5';

function drawModelSelect() {
  const sel = $('model');
  const providers = Object.values(status.providers || {});
  if (!providers.length) return;
  sel.textContent = '';
  // 연결된 AI 만 보여 준다. AI 가 둘 이상이면 AI 별로 묶는다.
  const ready = providers.filter((p) => p.ready);
  if (!ready.length) {
    sel.append(new Option('연결된 AI 없음 — ⚙︎ 에서 연결', ''));
    sel.disabled = true;
    return;
  }
  sel.disabled = false;
  for (const p of ready) {
    const parent = ready.length > 1 ? document.createElement('optgroup') : sel;
    if (ready.length > 1) parent.label = p.name;
    for (const m of p.models) parent.append(new Option(`${p.name} · ${m.name}`, `${p.id}:${m.id}`));
    if (parent !== sel) sel.append(parent);
  }
  sel.value = selectedModel;
  // 고른 AI 의 연결이 끊겼으면 연결된 첫 AI 로
  if (sel.selectedIndex < 0 || sel.value !== selectedModel) {
    sel.selectedIndex = 0;
    selectedModel = sel.value;
    port.postMessage({ type: 'model', model: selectedModel });
  }
}

function importMsg(text, ok = true) {
  $('import-msg').textContent = text || '';
  $('import-msg').classList.toggle('err', !ok);
}

let offerProfiles = [];
function startImport(dir) {
  $('chrome-import').disabled = true;
  $('chrome-import').textContent = '가져오는 중…';
  importMsg('');
  port.postMessage({ type: 'importChrome', dir });
}
$('chrome-import').addEventListener('click', () => {
  const sel = $('chrome-profile');
  startImport(sel.classList.contains('hidden') ? undefined : sel.value);
});
$('chrome-offer-yes').addEventListener('click', () => {
  $('chrome-offer').classList.add('hidden');
  // 프로필이 여럿이면 설정 화면에서 고르게 한다
  if (offerProfiles.length !== 1) {
    setSettingsOpen(true, 'import');
    port.postMessage({ type: 'chromeProfiles' });
  } else startImport();
});
// 설정을 연 뒤 허용됐는지 3초마다 확인하고, 허용되면 바로 가져온다(5분까지)
let privacyTimer = null;
$('open-privacy').addEventListener('click', () => {
  port.postMessage({ type: 'openPrivacy' });
  $('privacy-wait').classList.remove('hidden');
  clearInterval(privacyTimer);
  const until = Date.now() + 5 * 60 * 1000;
  privacyTimer = setInterval(() => {
    if (Date.now() > until) {
      clearInterval(privacyTimer);
      $('privacy-wait').textContent = '아직 허용되지 않았습니다. 켠 뒤 "가져오기"를 눌러 주세요.';
      return;
    }
    port.postMessage({ type: 'chromeCheck' });
  }, 3000);
});
$('open-chrome-bookmarks').addEventListener('click', () => port.postMessage({ type: 'openChromeBookmarks' }));
$('remote-share').addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('remote.html#share') }));
$('remote-view').addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('remote.html#view') }));
$('open-chrome-passwords').addEventListener('click', () => port.postMessage({ type: 'openChromePasswords' }));
$('open-knock-passwords').addEventListener('click', () => chrome.tabs.create({ url: 'chrome://password-manager/settings' }));
$('open-import-data').addEventListener('click', () => chrome.tabs.create({ url: 'chrome://settings/importData' }));
$('pick-bookmark-file').addEventListener('click', () => $('bookmark-file').click());
$('bookmark-file').addEventListener('change', async () => {
  const file = $('bookmark-file').files[0];
  $('bookmark-file').value = '';
  if (!file) return;
  try {
    const data = parseBookmarkHtml(await file.text());
    if (!data.bar.length && !data.other.length) throw new Error('북마크가 들어 있는 파일이 아닙니다.');
    importMsg('가져오는 중…');
    port.postMessage({ type: 'importFile', data });
  } catch (err) {
    importMsg(err.message, false);
  }
});

// 크롬 "북마크 내보내기" HTML(넷스케이프 형식) → { bar, other }
function parseBookmarkHtml(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const readList = (dl) => {
    const out = [];
    for (const dt of dl ? dl.querySelectorAll(':scope > dt, :scope > p > dt') : []) {
      const a = dt.querySelector(':scope > a');
      const h3 = dt.querySelector(':scope > h3');
      if (a && /^https?:/i.test(a.getAttribute('href') || '')) out.push({ title: a.textContent.trim() || a.href, url: a.getAttribute('href') });
      else if (h3) out.push({ title: h3.textContent.trim(), toolbar: h3.hasAttribute('personal_toolbar_folder'), children: readList(dt.querySelector(':scope > dl')) });
    }
    return out;
  };
  const top = readList(doc.querySelector('dl'));
  const toolbar = top.find((x) => x.toolbar);
  return {
    bar: toolbar ? toolbar.children : [],
    other: top.filter((x) => x !== toolbar).map(({ toolbar: _t, ...x }) => x),
  };
}

$('chrome-offer-no').addEventListener('click', () => {
  $('chrome-offer').classList.add('hidden');
  port.postMessage({ type: 'chromeOffer', answer: 'no' });
});

// 대화 · 실행 중 · 예약 칸
let view = 'chat';
// 맨 위에서 고르는 AI: Knock AI(대화·실행 중·예약) 또는 Gemini(옆창 안의 Gemini 사이트)
let mode = 'knock';
let knockView = 'chat';
function setMode(m) {
  mode = m;
  for (const b of $('mode').querySelectorAll('button')) b.classList.toggle('on', b.dataset.mode === m);
  document.body.classList.toggle('mode-gemini', m === 'gemini');
  try { localStorage.setItem('knockMode', m); } catch {}
  setView(m === 'gemini' ? 'gemini' : knockView);
}
$('mode').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-mode]');
  if (b) setMode(b.dataset.mode);
});
function setView(v) {
  view = v;
  if (v !== 'gemini') knockView = v;
  for (const b of $('views').querySelectorAll('button')) b.classList.toggle('on', b.dataset.view === v);
  const settings = !$('settings').classList.contains('hidden');
  $('log').classList.toggle('hidden', settings || v !== 'chat');
  $('form').classList.toggle('hidden', settings || v !== 'chat');
  $('jobs-view').classList.toggle('hidden', settings || v !== 'jobs');
  $('sched-view').classList.toggle('hidden', settings || v !== 'sched');
  $('past-view').classList.toggle('hidden', settings || v !== 'past');
  $('gemini-view').classList.toggle('hidden', settings || v !== 'gemini');
  $('model-foot').classList.toggle('hidden', settings || !(v === 'chat' || v === 'gemini'));
  document.body.classList.toggle('gem-mode', !settings && v === 'gemini');
  if (v === 'gemini') openGemini();
  if (v === 'jobs') { port.postMessage({ type: 'jobs' }); port.postMessage({ type: 'schedules' }); }
  if (v === 'sched') port.postMessage({ type: 'schedules' });
  if (v === 'past') {
    if (!$('past-view').childElementCount) $('past-view').append(el('p', 'muted', '불러오는 중…'));
    port.postMessage({ type: 'pastChats', tabId });
  }
}
// 설정의 "AI 작동 화면 보기"는 뒤에서 일하기(bgWork)의 반대: 켜면 AI 가 시킨 탭에서 보이게 일한다
$('bg-work').addEventListener('change', () => port.postMessage({ type: 'bgWork', on: !$('bg-work').checked }));
$('chrome-auto').addEventListener('change', () => port.postMessage({ type: 'chromeAuto', on: $('chrome-auto').checked }));
// 실행 중 칸 숫자·내용을 자주 새로 고친다
setInterval(() => { if (!document.hidden) port.postMessage({ type: 'jobs' }); }, 3000);
$('views').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-view]');
  if (b) setView(b.dataset.view);
});

// ---------- Gemini 칸: 옆창 안에 Gemini 사이트를 띄우고, 지금 보는 탭을 함께 보낸다 ----------
let gemFrame = null;
let gemShareOn = true; // 사용자가 "끄기"를 누르면 이 창을 닫을 때까지 보내지 않는다
let gemPage = null;
// Gemini 칸이 쓸 구글 계정 번호(여러 계정에 로그인했을 때: 0, 1, 2…)
let gemAccount = 0;
try { gemAccount = Number(localStorage.getItem('gemAccount')) || 0; } catch {}
const gemUrl = () => `https://gemini.google.com/u/${gemAccount}/app`;
function reloadGemini() {
  if (gemFrame) gemFrame.src = gemUrl();
}

// 이 프로필에 로그인된 구글 계정 목록(구글 로그인 쿠키로 확인 — 계정 번호 순서)
async function googleAccounts() {
  // 로그인 여부는 구글 로그인 쿠키로 확실히 본다(계정 목록 읽기는 구글이 자주 바꿔서 실패할 수 있음)
  let signedIn = false;
  try {
    for (const name of ['__Secure-1PSID', 'SID']) {
      if (await chrome.cookies.get({ url: 'https://accounts.google.com', name })) { signedIn = true; break; }
    }
  } catch {}
  if (!signedIn) return [];
  let emails = [];
  try {
    const res = await fetch('https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard', { credentials: 'include' });
    const text = await res.text();
    emails = [...new Set([...text.matchAll(/"([^"\s]+@[^"\s]+\.[a-z]{2,})"/gi)].map((m) => m[1]))];
  } catch {}
  return emails.length ? emails : ['구글 계정'];
}

async function drawGemLogin() {
  const list = await googleAccounts();
  const sel = $('gem-acct');
  sel.textContent = '';
  if (list === null) {
    $('gem-acct-note').textContent = '로그인 상태를 확인하지 못했어요(인터넷 확인)';
  } else if (!list.length) {
    $('gem-acct-note').textContent = '로그인 안 됨 · "구글 로그인"을 누르면 새 탭에서 로그인';
  } else {
    $('gem-acct-note').textContent = list.length > 1 ? 'Gemini 칸이 쓸 계정을 고르세요' : `로그인됨: ${list[0]}`;
    list.forEach((email, i) => sel.append(Object.assign(document.createElement('option'), { value: String(i), textContent: email })));
    if (gemAccount >= list.length) gemAccount = 0;
    sel.value = String(gemAccount);
  }
  sel.classList.toggle('hidden', !(list && list.length > 1));
  $('gem-login').classList.toggle('hidden', Boolean(list && list.length));
  $('gem-add').classList.toggle('hidden', !(list && list.length));
}

// 로그인은 일반 탭에서 한다(구글은 다른 화면 안에서의 로그인을 막는다). Gemini 화면에 도착하면 그 탭을 닫고 칸을 새로 고친다.
let gemLoginTab = null;
async function openGoogleLogin(add) {
  const cont = encodeURIComponent('https://gemini.google.com/app');
  const url = add ? `https://accounts.google.com/AddSession?continue=${cont}` : `https://accounts.google.com/ServiceLogin?continue=${cont}`;
  gemLoginTab = (await chrome.tabs.create({ url, active: true })).id;
}
let gemRefresh = null;
chrome.tabs.onUpdated.addListener((id, change, tab) => {
  if (id !== gemLoginTab || change.status !== 'complete' || !/^https:\/\/gemini\.google\.com\//.test(tab.url || '')) return;
  gemLoginTab = null;
  chrome.tabs.remove(id).catch(() => {});
  reloadGemini();
  drawGemLogin();
  $('gem-need-login').classList.add('hidden');
});
$('gem-login').addEventListener('click', () => openGoogleLogin(false));
$('gem-need-login-btn').addEventListener('click', () => openGoogleLogin(false));
$('gem-add').addEventListener('click', () => openGoogleLogin(true));
$('gem-recheck').addEventListener('click', () => { drawGemLogin(); reloadGemini(); });
$('gem-acct').addEventListener('change', () => {
  gemAccount = Number($('gem-acct').value) || 0;
  try { localStorage.setItem('gemAccount', String(gemAccount)); } catch {}
  reloadGemini();
});

function openGemini() {
  if (!gemFrame) {
    gemFrame = Object.assign(document.createElement('iframe'), { src: gemUrl(), className: 'gem-frame', allow: 'clipboard-read; clipboard-write; microphone' });
    $('gemini-view').append(gemFrame);
    gemFrame.addEventListener('load', sendGemContext);
  }
  if (tabId) port.postMessage({ type: 'pageForGemini', tabId });
  googleAccounts().then((list) => $('gem-need-login').classList.toggle('hidden', !(list && !list.length)));
}
function sendGemContext() {
  if (!gemFrame?.contentWindow) return;
  const on = Boolean(gemShareOn && gemPage?.ok && !gemPage.ask);
  gemFrame.contentWindow.postMessage({ knock: 'context', on, title: gemPage?.title || '', url: gemPage?.url || '', text: gemPage?.text || '', history: gemPage?.history || '' }, 'https://gemini.google.com');
}
function drawGemShare() {
  const p = gemPage;
  const btn = $('gem-share-btn');
  $('gem-share').classList.toggle('off', !(p?.ok && gemShareOn && !p.ask));
  if (!p?.ok) {
    $('gem-share-text').textContent = p ? `${p.title ? `${p.title} — ` : ''}${p.reason}` : '탭 정보를 읽는 중';
    btn.classList.add('hidden');
  } else if (p.ask) {
    $('gem-share-text').textContent = `${p.title} — 이 사이트 내용을 Gemini 에 보낼까요?`;
    Object.assign(btn, { textContent: '보내기' }).classList.remove('hidden');
  } else {
    $('gem-share-text').textContent = gemShareOn ? `공유 중: ${p.title}` : `공유 안 함: ${p.title}`;
    Object.assign(btn, { textContent: gemShareOn ? '끄기' : '켜기' }).classList.remove('hidden');
  }
}
$('gem-share-btn').addEventListener('click', () => {
  if (gemPage?.ask) gemPage.ask = false; // 이 페이지는 이번만 보내기
  else gemShareOn = !gemShareOn;
  drawGemShare();
  sendGemContext();
});
window.addEventListener('message', (e) => {
  if (e.origin === 'https://gemini.google.com' && e.data?.knock === 'shared') $('gem-share-text').textContent = `보냄: ${gemPage?.title || ''}`;
  // Gemini 에서 대화 한 번이 끝나면 공통 기록에 남긴다(Knock AI·다른 프로필이 볼 수 있게)
  if (e.origin === 'https://gemini.google.com' && e.data?.knock === 'turn') port.postMessage({ type: 'geminiTurn', tabId, user: e.data.user, answer: e.data.answer });
});

// 실행 중 칸: 장치 › 프로필 묶음 안에 지금 하는 일·확인 기다림·예약·끝난 일을 함께 보여 준다
// (지금은 이 장치·이 프로필 것만 알 수 있다 — 다른 장치·프로필 묶음은 계정 연결 뒤에 붙는다)
let lastJobs = [];
let lastScheds = [];
let deviceName = '';
const profile = { name: '', color: '#3B6FD8' };
function groupBox(pane) {
  const dev = el('div', 'dev-head');
  dev.append(el('span', '', '🖥'), el('b', '', deviceName || '이 컴퓨터'), el('span', 'muted', '이 컴퓨터'));
  const g = el('div', 'pgroup');
  g.style.setProperty('--pc', profile.color);
  const chip = el('span', 'pchip');
  chip.append(el('span', 'pchip-av', (profile.name || 'K').slice(0, 1)), el('span', '', profile.name || '이 프로필'));
  g.append(chip);
  pane.append(dev, g);
  return g;
}
function drawJobs(list) {
  lastJobs = list;
  const pane = $('jobs-view');
  pane.textContent = '';
  const busy = list.filter((j) => j.busy || j.waiting);
  $('jobs-count').textContent = busy.length;
  $('jobs-count').classList.toggle('hidden', !busy.length);
  if (!list.length && !lastScheds.length) {
    const e = el('div', 'empty');
    e.append(el('div', 'empty-icon', '☕'), el('b', '', '지금 실행 중인 일이 없어요'), el('div', 'muted', 'AI 에게 일을 맡기면 장치·프로필별로 여기 보여요'));
    pane.append(e);
    return;
  }
  const sum = el('div', 'run-sum');
  sum.append(el('b', '', `${busy.length}개 실행 중`), el('span', 'muted', ` · 예약 ${lastScheds.length}개`));
  pane.append(sum);
  const g = groupBox(pane);
  const card = (j) => {
    const c = el('div', `job${j.busy ? ' busy' : ''}${j.waiting ? ' wait' : ''}`);
    const row = el('div', 'row');
    row.append(el('span', 'dot'), el('span', '', j.title));
    c.append(row, el('div', 'sub', j.waiting ? '확인 필요 · AI 창의 카드를 봐 주세요' : j.busy ? (j.step || '일하는 중') : (j.ask ? `"${j.ask}"` : '끝남')));
    c.dataset.tab = j.tabId;
    c.dataset.win = j.windowId;
    c.title = '이 일을 하는 탭으로 갑니다';
    g.append(c);
  };
  list.filter((j) => j.waiting).forEach(card);
  list.filter((j) => j.busy && !j.waiting).forEach(card);
  drawSchedCards(g);
  list.filter((j) => !j.busy && !j.waiting).forEach(card);
}
$('jobs-view').addEventListener('click', (e) => {
  const card = e.target.closest('.job[data-tab]');
  if (!card) return;
  const id = Number(card.dataset.tab);
  const win = Number(card.dataset.win);
  // 다른 창의 탭이면 그 창을 앞으로 꺼내고 그 창에도 AI 창을 연다(누른 순간에 불러야 열린다)
  if (win && win !== myWindow?.id) chrome.sidePanel.open({ windowId: win }).catch(() => {});
  chrome.tabs.update(id, { active: true })
    .then(() => (win ? chrome.windows.update(win, { focused: true }) : null))
    .then(() => setView('chat')).catch(() => {});
});

function drawSchedPane(list) {
  lastScheds = list;
  drawJobs(lastJobs);
}
function drawSchedCards(g) {
  const time = (ms) => new Date(ms).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false });
  for (const x of lastScheds) {
    const card = el('div', 'job sched');
    const row = el('div', 'row');
    row.append(el('span', '', `⏰ 예약 · ${x.title}`));
    card.append(row, el('div', 'sub', `다음 ${x.next ? time(x.next) : '실행 중'}${x.auto ? ' · 알아서 진행' : ''}${x.files?.length ? ` · 첨부 ${x.files.length}개` : ''}`));
    const acts = el('div', 'acts');
    const now = el('button', 'btn', '지금 실행');
    now.dataset.runSchedule = x.id;
    const cancel = el('button', 'btn', '취소');
    cancel.dataset.cancelSchedule = x.id;
    acts.append(now, cancel);
    card.append(acts);
    g.append(card);
  }
}
$('jobs-view').addEventListener('click', (e) => {
  const run = e.target.closest('[data-run-schedule]');
  if (run) port.postMessage({ type: 'runSchedule', id: run.dataset.runSchedule });
  const c = e.target.closest('[data-cancel-schedule]');
  if (!c) return;
  if (c.dataset.armed) port.postMessage({ type: 'cancelSchedule', id: c.dataset.cancelSchedule });
  else Object.assign(c, { textContent: '정말 취소' }).dataset.armed = '1';
});

// 설정: 왼쪽은 분류, 오른쪽은 고른 분류의 항목만(한 줄로 길게 내려가지 않게).
// HTML 은 묶음 제목(settings-head sub) 순서 그대로 두고, 처음 열 때 분류마다 칸(set-pane)으로 옮겨 담는다.
const SET_CATS = [
  { key: 'ai', icon: '🤖', name: 'AI 사용 연동', heads: ['AI 연결'], about: '로그인하거나 API 키를 넣으면, 입력칸 안에서 골라 쓸 수 있어요' },
  { key: 'security', icon: '🛡', name: 'AI 동작 보안', heads: ['안전', '개인정보'], about: 'AI가 어디서 일하고, 무엇을 가리고, 언제 나에게 묻는지 정해요' },
  { key: 'work', icon: '🛠', name: 'AI 작동 설정', heads: ['일하는 방식', '자동으로 하는 일'], about: 'AI 가 어디서, 언제 일하는지' },
  { key: 'mcp', icon: '🧩', name: 'MCP 연결', heads: [], about: '피그마·노션 같은 서비스를 AI가 화면을 누르지 않고 바로 다루게 연결해요' },
  { key: 'link', icon: '🔗', name: '장치·프로필', heads: ['계정', '연결'], about: '이 컴퓨터의 계정·장치 이름·비밀번호·프로필을 관리해요' },
  { key: 'import', icon: '📥', name: '크롬에서 가져오기', heads: ['크롬에서 옮기기'], about: '쓰던 크롬의 것을 Knock Browser로 옮겨요' },
];
let setCat = null;
const rowOf = (id) => $(id)?.closest('.conn');
// 고르기(3개 이하)를 누르는 칸 묶음으로 — 고르기는 숨겨 두고 값을 같이 바꾼다(피그마: 드롭다운 → 세그먼트)
function segmentFor(sel) {
  if (sel.options.length > 3 || sel.dataset.seg) return;
  sel.dataset.seg = '1';
  const seg = el('div', 'seg');
  const draw = () => { for (const b of seg.children) b.classList.toggle('on', b.dataset.v === sel.value); };
  for (const o of sel.options) {
    const b = el('button', '', o.textContent);
    b.type = 'button';
    b.dataset.v = o.value;
    b.addEventListener('click', () => { sel.value = o.value; sel.dispatchEvent(new Event('change', { bubbles: true })); draw(); });
    seg.append(b);
  }
  sel.classList.add('hidden');
  sel.after(seg);
  // 다른 곳에서 값이 바뀌어도(설정을 받아 그릴 때) 따라간다
  new MutationObserver(draw).observe(sel, { attributes: true, childList: true });
  setInterval(draw, 1000);
  draw();
}
// 하위 화면: 줄을 누르면 그 분류 안에서 열린다(← 로 돌아감)
function subPage(pane, catName, title, desc, rows) {
  const sub = el('div', 'set-sub hidden');
  const back = el('button', 'set-back', `← ${catName} › ${title}`);
  back.type = 'button';
  back.addEventListener('click', () => { sub.classList.add('hidden'); pane.classList.remove('in-sub'); });
  const box = el('div', 'service');
  for (const r of rows) if (r) box.append(r);
  sub.append(back, el('h3', 'set-title', title), box);
  pane.append(sub);
  const row = el('button', 'conn set-link');
  row.type = 'button';
  const main = el('div', 'conn-main');
  main.append(el('div', 'conn-title', title), el('div', 'conn-desc', desc));
  row.append(main, el('span', 'set-chev', '›'));
  row.addEventListener('click', () => { pane.classList.add('in-sub'); sub.classList.remove('hidden'); $('settings').querySelector('.set-body').scrollTop = 0; });
  return row;
}
function groupHead(text) {
  const h = el('div', 'settings-head sub');
  h.append(el('b', '', text));
  return h;
}
function buildSettingsLayout() {
  const root = $('settings');
  if (root.querySelector('.set-layout')) return;
  const layout = el('div', 'set-layout');
  const nav = el('nav', 'set-nav');
  const body = el('div', 'set-body');
  const panes = {};
  // 왼쪽: 이름 · 설정 찾기 · 분류 · (새 판) · 판
  const brand = el('div', 'set-brand');
  brand.append(el('span', 'set-k', 'K'), el('b', '', 'Knock Browser 설정'));
  const find = el('input', 'set-find');
  find.type = 'search';
  find.placeholder = '⌕ 설정 찾기';
  nav.append(brand, find);
  for (const c of SET_CATS) {
    const b = el('button', 'set-cat');
    b.dataset.cat = c.key;
    b.append(el('span', 'set-cat-icon', c.icon), el('span', 'set-cat-name', c.name));
    if (c.key === 'ai') b.append(el('span', 'set-badge hidden', ''));
    b.addEventListener('click', () => { find.value = ''; filterSettings(''); showSettingsCat(c.key); });
    nav.append(b);
    panes[c.key] = el('div', 'set-pane hidden');
    panes[c.key].dataset.cat = c.key;
    const head = el('div', 'set-pane-head');
    const t = el('div', '');
    t.append(el('h3', 'set-title', c.name), el('p', 'set-about', c.about));
    const x = el('button', 'icon-btn set-x', '✕');
    x.type = 'button';
    x.title = '닫기';
    x.addEventListener('click', () => setSettingsOpen(false));
    head.append(t, x);
    panes[c.key].append(head);
    body.append(panes[c.key]);
  }
  // 맨 위 머리(설정 · ✕) 다음 것들을 묶음 제목에 따라 나눠 담는다
  const top = root.querySelector('.settings-head:not(.sub)');
  let cur = panes.ai;
  for (const node of [...root.children]) {
    if (node === top) continue;
    if (node.classList?.contains('settings-head') && node.classList.contains('sub')) {
      const title = node.textContent.trim();
      const c = SET_CATS.find((x) => x.heads.includes(title));
      if (c) cur = panes[c.key];
      if (c && c.heads[0] === title) node.classList.add('hidden');
    }
    cur.append(node);
  }
  const upd = el('div', 'set-update hidden');
  const updBtn = el('button', 'btn primary', '업데이트');
  updBtn.type = 'button';
  updBtn.addEventListener('click', () => $('update').click());
  upd.append(el('b', '', '새 버전이 있어요'), updBtn);
  nav.append(el('span', 'set-spacer'), upd, el('div', 'set-ver', ''));
  layout.append(nav, body);
  root.append(layout);
  regroupSettings(panes);
  buildMcpPane(panes.mcp);
  for (const sel of root.querySelectorAll('select.pv-select')) segmentFor(sel);
  find.addEventListener('input', () => filterSettings(find.value.trim()));
  setTimeout(drawVersion);
}
// 피그마 ② 설정 화면에 맞춰 줄을 다시 묶는다(줄 자체·이름표는 그대로 — 저장·그리기 코드는 id 로 찾는다)
function regroupSettings(panes) {
  // AI 사용 연동: 맨 위에 "AI 에이전트 사용"(= AI 접근 모두 멈춤의 반대)
  const use = el('div', 'service');
  const row = el('div', 'conn');
  const main = el('div', 'conn-main');
  main.append(el('div', 'conn-title', '⏸ AI 에이전트 사용'), el('div', 'conn-desc', '끄면 AI가 어떤 페이지·앱도 보거나 누르지 않아요 · 은행 일처럼 혼자 할 때'));
  const sw = el('input', 'switch');
  sw.type = 'checkbox';
  sw.id = 'ai-use';
  sw.addEventListener('change', () => savePrivacy({ paused: !sw.checked }));
  row.append(main, sw);
  use.append(row);
  panes.ai.querySelector('.set-pane-head').after(use, groupHead('AI 에이전트 연동'));
  rowOf('pv-paused')?.classList.add('hidden');

  // AI 동작 보안: 맡기는 정도(카드 셋) · 민감정보 사용 · 비밀번호와 민감정보(하위 화면) · AI 에게 보내는 정보
  const sec = panes.security;
  const trust = el('div', 'service');
  const tr = el('div', 'conn col');
  const tm = el('div', 'conn-main');
  tm.append(el('div', 'conn-title', '✋ AI에게 어디까지 맡길까요'), el('div', 'conn-desc', 'AI가 스스로 해도 되는 범위예요'));
  const cards = el('div', 'trust-cards');
  for (const [v, name, sub, desc] of [
    ['all', '수동', '단계마다 내가 확인해요', '페이지 이동·입력·누르기 전에 늘 물어요'],
    ['money', '필수 확인', '필수 절차만 묻습니다', '검색·입력·이동은 AI가 하고, 결제·삭제·제출·보내기 직전에 물어요'],
    ['none', '완전 자동', '묻지 않고 처음부터 끝까지 해요', '결제·보내기까지 AI가 해요 · 믿을 수 있는 사이트에만 권해요'],
  ]) {
    const b = el('button', 'trust');
    b.type = 'button';
    b.dataset.v = v;
    b.append(el('b', '', name), el('span', 'trust-sub', sub), el('small', '', desc));
    b.addEventListener('click', () => { $('confirm-level').value = v; $('confirm-level').dispatchEvent(new Event('change')); });
    cards.append(b);
  }
  const drawTrust = () => { for (const b of cards.children) b.classList.toggle('on', b.dataset.v === $('confirm-level').value); };
  $('confirm-level').addEventListener('change', drawTrust);
  setInterval(drawTrust, 1000);
  drawTrust();
  tr.append(tm, cards);
  trust.append(tr);
  const confirmRow = rowOf('confirm-level');
  confirmRow?.classList.add('hidden');
  const personal = el('div', 'service');
  const pr = rowOf('pv-personal');
  // 대화창에서 민감정보 가리기(보이는 글만 — 페이지 칸에는 진짜 값)
  const maskRow = el('div', 'conn');
  const mm = el('div', 'conn-main');
  mm.append(el('div', 'conn-title', '대화창에서 민감정보 가리기'), el('div', 'conn-desc', '대화창에서 민감정보가 110-***-**7637 처럼 가려집니다'));
  const msw = el('input', 'switch');
  msw.type = 'checkbox';
  msw.id = 'chat-mask';
  chrome.storage.local.get('chatMask').then(({ chatMask }) => { msw.checked = chatMask !== false; });
  msw.addEventListener('change', () => chrome.storage.local.set({ chatMask: msw.checked }));
  maskRow.append(mm, msw);
  if (pr) {
    // 피그마: 막기 / 묻기 / 허용
    const opts = $('pv-personal').options;
    if (opts.length === 3) { opts[0].textContent = '막기'; opts[1].textContent = '묻기'; opts[2].textContent = '허용'; }
    pr.querySelector('.conn-title').textContent = '🔒 AI의 민감정보 사용';
    pr.querySelector('.conn-desc').textContent = 'AI가 주민번호·카드·계좌를 직접 봐야 할 때 · 묻기는 내가 허락할 때만 보여 줘요 · 이체·조회 칸에는 늘 진짜 값이 들어가요 · 똑소리 조회도 이것을 따라요';
    personal.append(pr);
  }
  personal.append(maskRow);
  // 💳 저장한 카드·계좌: 직접 저장한 것만 · AI 에게는 이름표만 · 넣기 전에 물음
  const wallet = el('div', 'conn col');
  const wm = el('div', 'conn-main');
  wm.append(el('div', 'conn-title', '💳 저장한 카드·계좌'), el('div', 'conn-desc', '직접 저장한 것만 AI가 칸에 넣어요 · 넣기 전에 물어요'));
  const wl = el('ul', 'pv-sites tips-list');
  wl.id = 'wallet-list';
  const wf = el('div', 'row-actions inline-form wallet-form');
  const wk = el('select', 'pv-select');
  wk.append(new Option('카드', 'card'), new Option('계좌', 'account'));
  const wn = el('input');
  Object.assign(wn, { type: 'text', placeholder: '이름표 (예: 광주은행 카드)', maxLength: 40 });
  const wnum = el('input');
  Object.assign(wnum, { type: 'password', placeholder: '카드번호·계좌번호', inputMode: 'numeric', autocomplete: 'off' });
  const ws = el('button', 'btn primary', '저장');
  ws.type = 'button';
  ws.addEventListener('click', () => {
    if (!wn.value.trim()) return wn.focus();
    if (wnum.value.replace(/\D/g, '').length < 6) return wnum.focus();
    port.postMessage({ type: 'walletSave', kind: wk.value, label: wn.value.trim(), number: wnum.value });
    wnum.value = '';
  });
  wf.append(wk, wn, wnum, ws);
  const wmsg = el('p', 'settings-msg');
  wmsg.id = 'wallet-msg';
  const how = el('div', 'conn-desc wallet-how');
  how.append(el('b', '', '저장한 값은 이렇게 써요'), el('div', '', `· ${THIS_PC === '이 PC' ? '윈도우 보안 저장소' : '맥 키체인'}에만 보관 · AI에게는 이름표로만 보여요`), el('div', '', '· 카드번호는 저장, 카드 비밀번호·CVC는 저장하지 않고 그때마다 가려진 칸으로 받아요'), el('div', '', '· 페이지 칸에 넣기 전에 "넣을까요?"를 물어요'));
  wm.append(wl, wf, wmsg, how);
  wallet.append(wm);
  wl.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-wallet]');
    if (b && confirm(`"${b.dataset.label}"을(를) 지울까요?`)) port.postMessage({ type: 'walletDelete', id: b.dataset.wallet });
  });
  const vault = subPage(sec, '보안', '기억해 둔 로그인 · 저장한 카드·계좌', '로그인이 풀리면 이 사이트에만 다시 넣어요 · 직접 저장한 카드·계좌', [rowOf('vault-list'), wallet, rowOf('pv-password')]);
  vault.querySelector('.conn-desc').id = 'vault-link-desc';
  vault.addEventListener('click', () => port.postMessage({ type: 'walletList' }));
  setTimeout(() => port.postMessage({ type: 'walletList' }), 500);
  // 사이트마다 맡기는 정도(기본 따름 · 수동 · 필수 확인 · 완전 자동)
  const trustRow = el('div', 'conn col');
  const trm = el('div', 'conn-main');
  trm.append(el('div', 'conn-title', '사이트마다 맡기는 정도'), el('div', 'conn-desc', '"기본 따름" = 위 AI에게 어디까지 맡길까요를 그대로 써요 · 완전 자동이면 결제·예매도 묻지 않고 해요'));
  const tlist = el('div', 'trust-list');
  tlist.id = 'trust-list';
  const tadd = el('div', 'row-actions inline-form');
  const tin = el('input');
  Object.assign(tin, { type: 'text', placeholder: '사이트 주소 (예: letskorail.com)' });
  const tbtn = el('button', 'btn', '+ 사이트 추가');
  tbtn.type = 'button';
  tbtn.addEventListener('click', () => {
    const v = tin.value.trim() || siteHost || '';
    if (v) port.postMessage({ type: 'siteTrust', site: v, level: 'add' });
    tin.value = '';
  });
  tadd.append(tin, tbtn);
  trm.append(tlist, tadd);
  trustRow.append(trm);
  const sites = subPage(sec, '보안', '사이트별 보안 설정', '사이트마다 맡기는 정도 · 항상 허용한 단추 · 권한 창 없이 허용할 사이트', [trustRow, rowOf('click-allow-list'), rowOf('lna-list')]);
  // 막은 사이트·처음 쓰는 사이트 줄은 지웠다(2026-11-04 피그마 결정) — 처음 쓰는 사이트는 지금처럼 한 번 묻는다
  sites.addEventListener('click', () => port.postMessage({ type: 'siteTrust' }));
  const pw = el('div', 'service');
  pw.append(vault, sites);
  // 피그마에 없는 줄(2026-11-04 결정: "AI가 하는 일·AI가 읽는 범위" 지움, 똑소리 민감정보는 위 줄로 합침) — 값은 그대로 두고 화면에서만 뺀다
  for (const id of ['pv-scope', 'pv-shots', 'pv-secrets', 'pv-toksori', 'pv-redisclose']) rowOf(id)?.classList.add('hidden');
  sec.querySelector('.set-pane-head').after(trust, personal, groupHead('비밀번호와 민감정보'), pw);
  // 비어 버린 옛 묶음은 숨긴다
  for (const box of sec.querySelectorAll(':scope > .service')) if (![...box.children].some((c) => !c.classList.contains('hidden'))) box.classList.add('hidden');
  for (const h of sec.querySelectorAll(':scope > .settings-head.sub')) if (['안전', '개인정보'].includes(h.textContent.trim())) h.classList.add('hidden');

  // AI 작동 설정: 화면 설정 · 사이트별 작동 설정(사이트 요령, 하위 화면) · 자동으로 하는 일(예약)
  const work = panes.work;
  const tips = subPage(work, '작동 설정', '사이트별 작동 설정', 'AI가 사이트를 쓰면서 스스로 익힌 요령 · 틀린 요령은 지우면 돼요', [rowOf('tips-list')]);
  tips.querySelector('.conn-desc').id = 'tips-link-desc';
  $('tips-list').classList.remove('hidden'); // 하위 화면에서는 바로 펼쳐 보인다
  $('tips-toggle')?.closest('.row-actions')?.classList.add('hidden');
  const tipsBox = el('div', 'service');
  tipsBox.append(tips);
  const screen = rowOf('bg-work')?.parentElement;
  screen?.before(groupHead('화면 설정'));
  screen?.after(groupHead('사이트별 설정'), tipsBox);
  for (const h of work.querySelectorAll(':scope > .settings-head.sub')) if (h.textContent.trim() === '일하는 방식') h.classList.add('hidden');
  for (const box of work.querySelectorAll(':scope > .service')) if (![...box.children].some((c) => !c.classList.contains('hidden'))) box.classList.add('hidden');

  // 장치·프로필: 👤 계정 · 🖥 원격 — 이 컴퓨터 · 👥 프로필 — 이 창 · (다른 컴퓨터와 화면·AI 주고받기)
  const link = panes.link;
  const remoteBox = el('div', 'service');
  for (const id of ['acct-remote-row', 'acct-devname-row', 'acct-pw-row', 'acct-remote-open-row']) if ($(id)) remoteBox.append($(id));
  const profBox = el('div', 'service');
  for (const r of [rowOf('profile-name'), rowOf('profile-colors')]) if (r) profBox.append(r);
  // 다른 프로필: 창 열기 · 추가 · 수정 · 지우기는 브라우저 프로필 화면에서
  const others = el('button', 'conn set-link');
  others.type = 'button';
  const om = el('div', 'conn-main');
  om.append(el('div', 'conn-title', '다른 프로필'), el('div', 'conn-desc', '창 열기 · 추가 · 수정 · 지우기'));
  others.append(om, el('span', 'set-chev', '›'));
  others.addEventListener('click', () => chrome.tabs.create({ url: 'chrome://profile-picker' }));
  profBox.append(others);
  const share = el('div', 'service');
  // 피그마: 이 묶음에는 "번호로 원격"만 — "다른 컴퓨터 잇기"는 화면에서 뺀다(기능·이은 것은 그대로)
  const linkRow = rowOf('link-name'); // 옮기기 전에 잡아 둔다(아직 화면에 없는 상자 안에서는 id 로 못 찾는다)
  for (const r of [rowOf('remote-share'), linkRow]) if (r) share.append(r);
  linkRow?.classList.add('hidden');
  const acctBox = $('acct-in-row')?.parentElement;
  acctBox?.after(groupHead('🖥 원격 — 이 컴퓨터'), remoteBox, groupHead('👥 프로필 — 이 창'), profBox, groupHead('💻 다른 장치와 원격 주고받기'), share);
  // 원격 줄은 계정에 로그인했을 때만(그때 보이고 숨기는 것은 그대로) — 묶음 제목도 따라 숨긴다
  const remoteHead = remoteBox.previousElementSibling;
  // 원격 줄이 하나라도 보이면 묶음 제목과 카드를 함께 보인다(로그인 뒤에 줄이 나타난다 — 처음엔 비어 있어도 카드를 숨겨 두지 않는다)
  const syncRemote = () => {
    const any = [...remoteBox.children].some((c) => !c.classList.contains('hidden'));
    remoteHead.classList.toggle('hidden', !any);
    remoteBox.classList.toggle('hidden', !any);
  };
  new MutationObserver(syncRemote).observe(remoteBox, { attributes: true, subtree: true, attributeFilter: ['class'] });
  for (const h of link.querySelectorAll(':scope > .settings-head.sub')) {
    const t = h.textContent.trim();
    if (t === '계정') { h.classList.remove('hidden'); h.querySelector('b').textContent = '👤 계정'; }
    if (t === '연결') h.classList.add('hidden');
  }
  for (const box of link.querySelectorAll(':scope > .service')) if (box !== remoteBox && ![...box.children].some((c) => !c.classList.contains('hidden'))) box.classList.add('hidden');
  syncRemote();

  // AI 작동 설정: 예약 작업은 AI 창의 "실행 중"에서 본다(피그마에 없음)
  rowOf('schedule-list')?.closest('.service')?.previousElementSibling?.classList.add('hidden');
  rowOf('schedule-list')?.closest('.service')?.classList.add('hidden');
  // 크롬에서 가져오기: 계정 고르기를 맨 위 따로
  const imp = panes.import;
  const pick = $('chrome-profile');
  if (pick) {
    const box = el('div', 'service');
    const r = el('div', 'conn');
    const m = el('div', 'conn-main');
    m.append(el('div', 'conn-title', '크롬 계정'), el('div', 'conn-desc', '고른 계정의 북마크·방문 기록을 가져와요'));
    r.append(m, pick);
    box.append(r);
    imp.querySelector('.set-pane-head').after(groupHead('가져올 크롬 계정'), box);
    new MutationObserver(() => box.classList.toggle('hidden', pick.classList.contains('hidden'))).observe(pick, { attributes: true, attributeFilter: ['class'] });
    box.classList.toggle('hidden', pick.classList.contains('hidden'));
  }
  for (const h of imp.querySelectorAll(':scope > .settings-head.sub')) if (h.textContent.trim() === '크롬에서 옮기기') h.classList.add('hidden');
  // 크롬 계정이 하나뿐이면 고르기 줄과 그 제목을 함께 숨긴다
  const pickHead = [...imp.querySelectorAll(':scope > .settings-head.sub')].find((h) => h.textContent.trim() === '가져올 크롬 계정');
  const syncPick = () => pickHead?.classList.toggle('hidden', !pick || pick.classList.contains('hidden'));
  if (pick) new MutationObserver(syncPick).observe(pick, { attributes: true, attributeFilter: ['class'] });
  syncPick();
  // 줄 앞 아이콘(피그마)
  const iconize = (row, ic) => { if (row && !row.querySelector(':scope > .row-icon')) row.prepend(el('span', 'row-icon', ic)); };
  iconize(rowOf('chrome-import'), '★');
  iconize(rowOf('open-import-data'), '🕘');
  iconize(rowOf('open-knock-passwords'), '🔑');
  iconize($('ai-use')?.closest('.conn'), '⏸');
  $('ai-use')?.closest('.conn')?.querySelector('.conn-title')?.replaceChildren('AI 에이전트 사용');
  iconize(gemLoginRow, '✦');
  // 북마크: [지금 가져오기]는 오른쪽, 자동 체크는 설명 아래
  const bm = rowOf('chrome-import');
  if (bm) {
    const act = $('chrome-import');
    bm.append(act);
    bm.classList.add('wrap-row');
  }
  // 구글 로그인 줄: 단추를 오른쪽으로
  const ga = gemLoginRow?.querySelector('.row-actions');
  if (ga) { gemLoginRow.append(ga); ga.classList.add('side-actions'); }
  // 이 프로필 이름: 칸·저장을 오른쪽에
  const pn = rowOf('profile-name');
  const pf = $('profile-name')?.closest('.inline-form');
  if (pn && pf) { pn.append(pf); pf.classList.add('side-form'); pn.classList.remove('sites-row'); }
}
// 설정 찾기: 맞는 줄만 모든 분류에서 보인다
function filterSettings(q) {
  const root = $('settings');
  root.classList.toggle('finding', Boolean(q));
  const low = q.toLowerCase();
  // 찾을 때는 하위 화면 안의 줄도 함께 보인다(하위 화면은 닫고 시작)
  for (const p of root.querySelectorAll('.set-pane.in-sub')) p.classList.remove('in-sub');
  for (const sub of root.querySelectorAll('.set-sub')) sub.classList.add('hidden');
  for (const p of root.querySelectorAll('.set-pane')) {
    if (!q) { p.classList.toggle('hidden', p.dataset.cat !== setCat); continue; }
    let any = false;
    for (const r of p.querySelectorAll('.conn')) {
      const hit = r.textContent.toLowerCase().includes(low);
      r.classList.toggle('find-miss', !hit);
      any ||= hit;
    }
    p.classList.toggle('hidden', !any);
  }
  if (!q) for (const r of root.querySelectorAll('.find-miss')) r.classList.remove('find-miss');
}
// 설정 › MCP 연결(2026-11-07): 서비스마다 [연결](그 서비스 로그인 → 허용) · [연결 끊기] · 피그마 작업 방식
const MCP_ROWS = [
  { id: 'figma', icon: '🎨', name: '피그마', desc: '디자인 읽기·고치기·그리기를 화면을 누르지 않고 바로 해요. 피그마 요금제의 하루 사용 횟수 안에서 써요.' },
  { id: 'notion', icon: '📝', name: '노션', desc: '페이지 찾기·읽기·만들기·고치기를 바로 해요.' },
];
let mcpState = { items: [], prefs: {} };
let mcpBusy = '';
function buildMcpPane(pane) {
  if (!pane) return;
  const box = el('div', 'service mcp-list');
  pane.append(box, el('p', 'conn-desc pad', 'Knock AI 를 Claude 로 쓸 때 연결돼요. 서비스의 내용을 바꾸는 작업은 실행 전에 [항상 허용]·[이번만 허용]·허용 안 함을 물어요. 연결 열쇠는 이 컴퓨터에만 저장돼요.'));
  drawMcp();
  loadMcp('list');
}
async function loadMcp(action, id = '', prefs = null, ai = 'claude') {
  if (action === 'login' || action === 'logout') { mcpBusy = `${ai}:${id}`; drawMcp(); }
  const r = await chrome.runtime.sendMessage({ type: 'mcpAct', action, id, ai, ...(prefs ? { prefs } : {}) }).catch((err) => ({ error: err.message }));
  mcpBusy = '';
  if (r && !r.error) mcpState = { ...mcpState, ...r };
  mcpState.message = r?.error || r?.message || '';
  drawMcp();
}
function drawMcp() {
  const box = $('settings').querySelector('.mcp-list');
  if (!box) return;
  box.replaceChildren();
  if (mcpState.available === false) {
    box.append(el('p', 'conn-desc pad', 'MCP 연결은 Knock AI 를 Claude 나 ChatGPT 계정으로 쓸 때 됩니다. 먼저 AI 사용 연동에서 연결해 주세요.'));
    return;
  }
  // 서비스마다 Claude·ChatGPT 를 따로 연결한다(각 AI 프로그램이 연결 열쇠를 따로 둔다)
  const AIS = [['claude', 'Claude', mcpState.items], ['chatgpt', 'ChatGPT', mcpState.gpt?.available === false ? null : mcpState.gpt?.items]];
  for (const r of MCP_ROWS) {
    const row = el('div', 'conn');
    const main = el('div', 'conn-main');
    const title = el('div', 'conn-title');
    const anyOn = AIS.some(([, , items]) => (items || []).find((x) => x.id === r.id)?.connected);
    title.append(el('span', '', r.icon), el('span', '', r.name));
    main.append(title, el('div', 'conn-desc', r.desc));
    for (const [ai, aiName, items] of AIS) {
      if (!items) continue;
      const it = items.find((x) => x.id === r.id) || {};
      const busy = mcpBusy === `${ai}:${r.id}`;
      const line = el('div', 'mcp-ai-row');
      line.append(el('span', 'mcp-ai-name', aiName), el('span', `pill ${it.connected ? 'ok' : ''}`, busy ? '연결 중…' : it.connected ? '연결됨' : it.needsAuth ? '로그인 필요' : '연결 안 됨'));
      const btn = el('button', `btn ${it.connected ? '' : 'primary'}`, it.connected ? '연결 끊기' : '연결');
      btn.type = 'button';
      btn.disabled = Boolean(mcpBusy);
      btn.addEventListener('click', () => loadMcp(it.connected ? 'logout' : 'login', r.id, null, ai));
      line.append(btn);
      main.append(line);
    }
    if (r.id === 'figma' && anyOn) {
      // 피그마 연결 사용(2026-11-07 "항상 허용 3가지 버튼으로"): 항상 허용(연결로 하고, 막히면 화면) · 이번만 허용(작업마다 묻기) · 허용 안 함(늘 화면을 보고)
      const mode = { mcp: 'auto' }[mcpState.prefs?.figma] || mcpState.prefs?.figma || 'auto';
      const seg = el('div', 'seg mcp-mode');
      for (const [v, label] of [['auto', '항상 허용'], ['ask', '이번만 허용'], ['screen', '허용 안 함']]) {
        const b = el('button', v === mode ? 'on' : '', label);
        b.type = 'button';
        b.title = { auto: '피그마 일은 늘 연결로 해요(막히면 화면을 보고 이어서)', ask: '피그마 일을 시킬 때마다 연결로 할지 물어요', screen: '연결을 쓰지 않고 지금처럼 화면을 보고 해요(피그마 사용 횟수를 아낄 때)' }[v];
        b.addEventListener('click', () => loadMcp('prefs', '', { ...(mcpState.prefs || {}), figma: v }));
        seg.append(b);
      }
      const line = el('div', 'mcp-mode-row');
      line.append(el('span', 'conn-desc', '피그마 연결 사용'), seg);
      main.append(line);
    }
    row.append(main);
    box.append(row);
  }
  if (mcpBusy) box.append(el('p', 'conn-desc pad', '새 탭에서 그 서비스에 로그인하고 [허용]을 눌러 주세요. 끝나면 여기 저절로 "연결됨"으로 바뀌어요(5분까지 기다려요).'));
  if (mcpState.message) box.append(el('p', 'conn-desc pad err', mcpState.message));
}

function showSettingsCat(key) {
  setCat = SET_CATS.some((c) => c.key === key) ? key : 'ai';
  if (setCat === 'mcp' && !mcpBusy) loadMcp('list');
  for (const b of $('settings').querySelectorAll('.set-cat')) b.classList.toggle('on', b.dataset.cat === setCat);
  for (const p of $('settings').querySelectorAll('.set-pane')) p.classList.toggle('hidden', p.dataset.cat !== setCat);
  $('settings').querySelector('.set-body').scrollTop = 0;
  try { localStorage.setItem('knockSetCat', setCat); } catch {}
}

function setSettingsOpen(open, cat) {
  // 설정은 늘 따로 뜨는 넓은 설정 창으로(옆 창·원격 창 안의 AI 창 모두 — 2026-11-06 "설정 화면도 예전 모습이야")
  if (open && !SETTINGS_ONLY) {
    port.postMessage({ type: 'openSettings', cat: cat || '', tabId, windowId: myWindow.id });
    return;
  }
  if (!open && SETTINGS_ONLY) { window.close(); return; }
  if (open) {
    buildSettingsLayout();
    let last = null;
    try { last = localStorage.getItem('knockSetCat'); } catch {}
    showSettingsCat(cat || setCat || last || 'ai');
  }
  $('settings').classList.toggle('hidden', !open);
  $('views').classList.toggle('hidden', open);
  setView(view);
  $('settings-btn').classList.toggle('on', open);
  for (const k of Object.keys(providerMsgs)) providerMsgs[k] = null;
  if (open) {
    port.postMessage({ type: 'hello' }); // 최신 상태로
    port.postMessage({ type: 'siteTips' });
    port.postMessage({ type: 'clickAllow' });
    port.postMessage({ type: 'localSites' });
    port.postMessage({ type: 'vaultList' });
    port.postMessage({ type: 'schedules' });
    port.postMessage({ type: 'profileName' });
    port.postMessage({ type: 'linkState' });
    port.postMessage({ type: 'account' });
    port.postMessage({ type: 'chromeAuto' });
    port.postMessage({ type: 'bgWork' });
    drawGemLogin();
  }
  drawStatus();
}

$('settings-btn').addEventListener('click', () => setSettingsOpen($('settings').classList.contains('hidden')));
$('settings-close').addEventListener('click', () => setSettingsOpen(false));
$('setup-open').addEventListener('click', () => setSettingsOpen(true, 'ai'));
// 터미널에서 로그인하고 돌아오면 다시 확인
window.addEventListener('focus', () => {
  if (!$('settings').classList.contains('hidden') || status.state === 'login') port.postMessage({ type: 'hello' });
});

// ---------- 지금 보고 있는 탭 ----------
async function showTab(id) {
  tabId = id;
  chat = newChat();
  openSteps.clear();
  draw();
  const tab = await chrome.tabs.get(id).catch(() => null);
  $('chat-for').textContent = tab ? `· ${tab.title || '새 탭'}` : '';
  siteHost = tab?.url && /^https?:/.test(tab.url) ? new URL(tab.url).hostname : null;
  port.postMessage({ type: 'get', tabId: id });
  if (gemFrame) port.postMessage({ type: 'pageForGemini', tabId: id });
}

chrome.tabs.onActivated.addListener(({ tabId: id, windowId }) => {
  if (windowId === myWindow.id) showTab(id);
});
chrome.tabs.onUpdated.addListener((id, change, tab) => {
  if (id === tabId && change.title) $('chat-for').textContent = `· ${tab.title}`;
  // 보고 있는 탭의 페이지가 바뀌면 Gemini 에 보낼 내용도 새로
  // 유튜브처럼 새로 고침 없이 주소·제목만 바뀌는 사이트도 있으니 주소·제목이 바뀔 때도(잠깐 기다렸다가) 다시 읽는다
  if (id === tabId && gemFrame && (change.status === 'complete' || change.url || change.title)) {
    clearTimeout(gemRefresh);
    gemRefresh = setTimeout(() => port.postMessage({ type: 'pageForGemini', tabId }), change.status === 'complete' ? 0 : 800);
  }
  if (id === tabId && change.url) {
    siteHost = /^https?:/.test(change.url) ? new URL(change.url).hostname : null;
  }
});
const openerTab = Number(new URLSearchParams(location.search).get('tab')) || 0;
const [first] = SETTINGS_ONLY && openerTab ? [{ id: openerTab }] : await chrome.tabs.query({ active: true, windowId: myWindow.id });
if (first) showTab(first.id);
if (SETTINGS_ONLY) {
  setTimeout(() => {
    setSettingsOpen(true, new URLSearchParams(location.search).get('settings') || undefined);
    // 도구 막대 계정 창의 [로그인]·[회원가입]에서 왔으면 그 화면을 바로
    const step = new URLSearchParams(location.search).get('step');
    if (step === 'login' || step === 'signup') setTimeout(() => afShow(step === 'signup' ? 'signup' : 'login'), 300);
  });
}

// ---------- 백그라운드에서 오는 것 ----------
port.onMessage.addListener((msg) => {
  switch (msg.type) {
    case 'status':
      status = msg.status;
      if (msg.model) selectedModel = msg.model.includes(':') ? msg.model : `claude:${msg.model}`;
      drawStatus();
      break;
    case 'pastChats':
      if (msg.tabId === tabId && view === 'past') drawPast(msg.list);
      break;
    case 'pastPeers':
      if (msg.tabId === tabId) { pastPeers = msg.peers || []; if (view === 'past') drawPast(); }
      break;
    case 'resumedElsewhere':
      if (msg.tabId !== tabId) break;
      if (msg.ok && msg.viewer === tabId) { setView('chat'); break; } // 이미 그 원격 창 안: 대화를 바로 보여 준다
      if (view === 'past') port.postMessage({ type: 'pastChats', tabId });
      if (msg.needConnect) setTimeout(() => pastNote('그 PC와 원격 연결이 없어요. 원격으로 그 PC에 연결한 뒤 다시 눌러 주세요.'), 300);
      else if (msg.error) setTimeout(() => pastNote(msg.error), 300);
      break;
    case 'showChat':
      if (msg.tabId === tabId) setView('chat');
      break;
    case 'chat':
      if (msg.tabId === tabId) {
        chat = msg.chat;
        draw();
      }
      break;
    case 'update':
      knockVersion = msg.version || '';
      drawVersion();
      $('update').classList.toggle('hidden', !msg.parts.length);
      document.querySelector('.set-update')?.classList.toggle('hidden', !msg.parts.length);
      $('update').disabled = false;
      $('update').classList.remove('updating');
      $('update').textContent = '업데이트';
      $('update').title = `새 버전: ${msg.parts.join(', ')} — 누르면 설치하고 Knock 을 다시 켭니다(탭·대화는 그대로)`;
      break;
    case 'chromeProfiles': {
      // 프로필이 여럿이면 고르게 한다
      const sel = $('chrome-profile');
      sel.textContent = '';
      // 크롬은 프로필마다 구글 계정이 하나 — 프로필 이름 · 계정(없으면 로그인 안 됨) · 북마크 수
      if (msg.profiles.length > 1) sel.append(new Option('자동 · 북마크가 가장 많은 프로필', '__auto'));
      for (const p of msg.profiles) sel.append(new Option(`${p.name} · ${p.email || '로그인 안 됨'} · 북마크 ${p.count}`, p.dir));
      sel.classList.toggle('hidden', msg.profiles.length < 2);
      $('chrome-import').disabled = false;
      $('chrome-import').textContent = '지금 가져오기';
      if (msg.profiles.length > 1) importMsg('가져올 크롬 계정을 고른 뒤 "지금 가져오기"를 눌러 주세요.');
      break;
    }
    case 'chromeAccess':
      if (!msg.ok || !privacyTimer) break;
      clearInterval(privacyTimer);
      privacyTimer = null;
      $('privacy-wait').classList.add('hidden');
      $('import-blocked').classList.add('hidden');
      importMsg('허용됐습니다. 가져오는 중…');
      startImport();
      break;
    case 'importResult':
      $('chrome-import').disabled = false;
      $('chrome-import').textContent = '지금 가져오기';
      $('chrome-offer').classList.add('hidden');
      importMsg(msg.message, msg.ok);
      $('import-blocked').classList.toggle('hidden', !msg.blocked);
      // 막혔으면 설정 화면에서 방법을 보여 준다
      if (msg.blocked) {
        if ($('settings').classList.contains('hidden')) setSettingsOpen(true, 'import');
        importMsg(msg.message, false);
        break;
      }
      if (!$('settings').classList.contains('hidden')) break;
      notice(msg.message);
      break;
    case 'chromeOffer': {
      const total = msg.profiles.reduce((n, p) => n + p.count, 0);
      $('chrome-offer-text').textContent = total
        ? `크롬에 북마크가 ${total}개 있습니다. Knock 으로 가져올까요?`
        : '크롬 북마크를 Knock 으로 가져올까요?';
      $('chrome-offer').classList.remove('hidden');
      offerProfiles = msg.profiles;
      break;
    }
    case 'account':
      drawAccount(msg);
      break;
    case 'accountForm':
      drawAccountForm(msg);
      break;
    case 'accountDevices':
      drawDevices(msg);
      break;
    case 'remoteState':
      if (msg.device) {
        remoteDev = msg.device;
        $('acct-remote').checked = Boolean(msg.device.remoteEnabled);
        // 원격을 켰으면 장치 이름·비밀번호 줄(피그마 ② 장치·프로필)
        $('acct-devname-row').classList.toggle('hidden', !msg.device.remoteEnabled);
        $('acct-pw-row').classList.toggle('hidden', !msg.device.remoteEnabled);
        if (document.activeElement !== $('acct-devname')) $('acct-devname').value = msg.device.name || '';
        $('acct-pw').value = '';
      }
      if (msg.error || msg.ok) { $('acct-msg').textContent = msg.error || msg.ok; $('acct-msg').classList.toggle('error', Boolean(msg.error)); }
      if (msg.devices) drawDevices(msg);
      break;
    case 'linkState':
      deviceName = msg.device?.name || deviceName;
      drawLinks(msg);
      break;
    case 'profileName':
      savedProfile = msg.name;
      profile.name = msg.name;
      drawProfileChip();
      if (document.activeElement !== $('profile-name') || $('profile-name').value.trim() === msg.name) $('profile-name').value = msg.name;
      drawProfileSaved();
      break;
    case 'privacy':
      privacy = msg.privacy;
      drawPrivacy();
      break;
    case 'safety':
      $('confirm-level').value = msg.level || (msg.confirm ? 'all' : 'none');
      $('confirm-level').disabled = msg.forced;
      $('confirm-note').textContent = msg.forced
        ? '이 판에서는 늘 모두 묻습니다.'
        : '중요한 단추를 누르기 전에 확인';
      break;
    case 'settingsResult':
      delete logging[msg.provider || 'claude'];
      delete installing[msg.provider || 'claude'];
      providerMsg(msg.provider || 'claude', msg.message, msg.ok);
      break;
    case 'loginUrl':
      if (logging[msg.provider]) {
        logging[msg.provider].url = msg.url;
        drawSettings();
      }
      break;
    case 'siteTips':
      drawTips(msg);
      break;
    case 'clickAllow':
      drawClickAllow(msg.list);
      break;
    case 'localSites':
      drawLocalSites(msg);
      break;
    case 'vaultList':
      drawVault(msg.list);
      break;
    case 'schedules':
      drawSchedules(msg.list);
      drawSchedPane(msg.list);
      break;
    case 'jobs':
      drawJobs(msg.list);
      break;
    case 'pageForGemini':
      if (msg.tabId !== tabId) break;
      gemPage = msg;
      drawGemShare();
      sendGemContext();
      break;
    case 'bgWork':
      $('bg-work').checked = !msg.on;
      break;
    case 'chromeAuto':
      $('chrome-auto').checked = msg.on;
      if (msg.last) $('chrome-auto-note').dataset.last = `마지막: ${new Date(msg.last.at).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false })} · 크롬(${msg.last.profile})에서 ${msg.last.added}개 더함`;
      break;
    case 'updateFailed':
      $('update').disabled = false;
      $('update').classList.remove('updating');
      $('update').textContent = '업데이트';
      notice(`업데이트하지 못했습니다. ${msg.message}`);
      break;
    case 'event':
      if (msg.tabId === tabId) {
        apply(chat, msg.ev);
        draw();
      }
      break;
  }
});
port.postMessage({ type: 'hello' });
// 프로필 칩·실행 중 묶음에 쓸 프로필 이름·장치 이름
port.postMessage({ type: 'profileName' });
port.postMessage({ type: 'linkState' });
// 처음 한 번: 크롬 북마크를 가져올지 묻는다
port.postMessage({ type: 'chromeOffer' });

$('update').addEventListener('click', () => {
  $('update').disabled = true;
  $('update').classList.add('updating');
  $('update').textContent = '업데이트 중…';
  port.postMessage({ type: 'updateNow' });
  // 잘 되면 Knock 이 다시 켜지면서 이 창도 새로 뜬다. 오래 그대로면 직접 껐다 켜 달라고 한다.
  // (배포판은 새 판을 인터넷에서 내려받으므로 15분까지 기다린다)
  setTimeout(() => {
    if (!$('update').classList.contains('updating')) return;
    $('update').disabled = false;
    $('update').classList.remove('updating');
    $('update').textContent = '업데이트';
    notice('Knock Browser를 자동으로 다시 켜지 못했어요. 완전히 끈 뒤 다시 켜 주세요.');
  }, 15 * 60000);
});
$('recheck').addEventListener('click', () => {
  status = { state: 'unknown' };
  drawStatus();
  port.postMessage({ type: 'hello' });
});
$('model').addEventListener('change', () => {
  selectedModel = $('model').value;
  port.postMessage({ type: 'model', model: selectedModel });
});
$('reset').addEventListener('click', () => tabId && port.postMessage({ type: 'reset', tabId }));
$('stop').addEventListener('click', () => tabId && port.postMessage({ type: 'stop', tabId }));

// ---------- 첨부 (📎 · 끌어다 놓기 · 붙여넣기) ----------
const MAX_ATTACH_BYTES = 50 * 1024 * 1024;
const VIEW_SIDE = 1568; // AI 에게 보낼 사진의 긴 쪽 최대 크기
let pending = []; // { file, url }

function addFiles(list) {
  for (const file of list) {
    if (file.size > MAX_ATTACH_BYTES) {
      notice(`${file.name}: 50MB 보다 큰 파일은 첨부할 수 없습니다.`);
      continue;
    }
    pending.push({ file, url: file.type.startsWith('image/') ? URL.createObjectURL(file) : null });
  }
  renderTray();
}

function drawInputNote() {
  $('input-note').classList.toggle('hidden', !$('input').value.trim() && pending.length === 0);
}

function renderTray() {
  const tray = $('tray');
  tray.textContent = '';
  tray.classList.toggle('hidden', pending.length === 0);
  drawInputNote();
  pending.forEach((p, i) => {
    const item = document.createElement('div');
    item.className = `item${p.url ? ' img' : ''}`;
    item.title = p.folder ? `폴더 ${p.folder} · 파일 ${p.names.length}개` : p.file.name;
    if (p.folder) {
      // 폴더: 내용은 보내지 않고 이름·안의 파일 이름만 AI 에게 알린다(AI 가 folder_files 로 그 폴더를 다룬다)
      const name = document.createElement('span');
      name.textContent = `📁 ${p.folder} (폴더)`;
      item.append(name);
    } else if (p.url) {
      const img = document.createElement('img');
      img.src = p.url;
      item.append(img);
    } else {
      const name = document.createElement('span');
      name.textContent = `📄 ${p.file.name}`;
      item.append(name);
    }
    const x = document.createElement('button');
    x.type = 'button';
    x.textContent = '×';
    x.setAttribute('aria-label', '첨부 빼기');
    x.addEventListener('click', () => {
      if (p.url) URL.revokeObjectURL(p.url);
      pending.splice(i, 1);
      renderTray();
    });
    item.append(x);
    tray.append(item);
  });
}

function base64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1] || '');
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

// 사진을 maxSide 이하로 줄여 JPEG data URL 로
async function shrink(file, maxSide, quality) {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
  const canvas = new OffscreenCanvas(Math.round(bmp.width * scale), Math.round(bmp.height * scale));
  canvas.getContext('2d').drawImage(bmp, 0, 0, canvas.width, canvas.height);
  return canvas.convertToBlob({ type: 'image/jpeg', quality });
}

async function packFile(file) {
  const out = { name: file.name || '붙여넣은 이미지.png', type: file.type, data: await base64(file) };
  if (/^image\/(png|jpeg)$/.test(file.type)) {
    try {
      out.thumb = `data:image/jpeg;base64,${await base64(await shrink(file, 160, 0.7))}`;
      const bmp = await createImageBitmap(file);
      if (Math.max(bmp.width, bmp.height) > VIEW_SIDE || file.size > 4 * 1024 * 1024) {
        out.view = { type: 'image/jpeg', data: await base64(await shrink(file, VIEW_SIDE, 0.85)) };
      }
    } catch {}
  }
  return out;
}

$('attach').addEventListener('click', () => $('file').click());
$('file').addEventListener('change', () => {
  addFiles($('file').files);
  $('file').value = '';
});
document.addEventListener('paste', (e) => {
  const files = [...(e.clipboardData?.files || [])];
  if (files.length) {
    e.preventDefault();
    addFiles(files);
  }
});
document.addEventListener('dragover', (e) => {
  e.preventDefault();
  document.body.classList.add('drop');
});
document.addEventListener('dragleave', (e) => {
  if (!e.relatedTarget) document.body.classList.remove('drop');
});
document.addEventListener('drop', (e) => {
  e.preventDefault();
  document.body.classList.remove('drop');
  // 폴더를 끌어다 놓으면 폴더로 받는다(파일로 읽으면 실패해 보내기가 멈췄다 — 2026-11-07 "output" 폴더)
  const items = [...(e.dataTransfer.items || [])].filter((it) => it.kind === 'file');
  const entries = items.map((it) => it.webkitGetAsEntry?.() || null);
  if (!entries.some((en) => en?.isDirectory)) return addFiles(e.dataTransfer.files);
  const plain = [];
  items.forEach((it, i) => {
    if (entries[i]?.isDirectory) addFolder(entries[i]);
    else { const f = it.getAsFile(); if (f) plain.push(f); }
  });
  addFiles(plain);
});
// 폴더 안 파일 이름(바로 아래만, 300개까지)을 읽어 둔다 — 같은 이름 폴더가 여럿일 때 맞는 것을 고르는 데 쓴다
function addFolder(entry) {
  const p = { folder: entry.name, names: [] };
  pending.push(p);
  renderTray();
  const reader = entry.createReader();
  const more = () => reader.readEntries((list) => {
    for (const x of list) if (x.isFile && p.names.length < 300) p.names.push(x.name);
    if (list.length && p.names.length < 300) more();
    else renderTray();
  }, () => {});
  more();
}

// ---------- 보내기 ----------
$('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = $('input').value.trim();
  if ((!text && pending.length === 0) || !tabId || status.state !== 'ready') return;
  // 못 읽는 첨부(폴더를 파일로 받은 것 등)는 빼고 보낸다 — 하나 때문에 보내기가 통째로 멈추지 않게(2026-11-07)
  const files = (await Promise.all(pending.filter((p) => p.file).map((p) => packFile(p.file).catch(() => null)))).filter(Boolean);
  const folders = pending.filter((p) => p.folder);
  const note = folders.map((f) => `[첨부한 폴더: "${f.folder}" · 안의 파일 ${f.names.length}개${f.names.length ? `: ${f.names.slice(0, 30).join(', ')}${f.names.length > 30 ? ' …' : ''}` : ''} — folder_files 로 다룰 수 있음]`).join('\n');
  pending.forEach((p) => p.url && URL.revokeObjectURL(p.url));
  pending = [];
  renderTray();
  $('input').value = '';
  drawInputNote();
  port.postMessage({ type: 'send', tabId, text: note ? `${text}\n\n${note}` : text, files });
});
$('input').addEventListener('input', drawInputNote);
$('input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    $('form').requestSubmit();
  }
});
$('input').focus();

// 지난번에 고른 AI 로 연다
try { if (localStorage.getItem('knockMode') === 'gemini') setMode('gemini'); } catch {}

// 비밀번호 직접 넣기: 값은 AI 에게 가지 않고 그 페이지 칸에만 들어간다("기억해 두기"를 고르면 맥 키체인에도)
$('log').addEventListener('submit', (e) => {
  const form = e.target.closest('form[data-secret]');
  if (!form) return;
  e.preventDefault();
  const inputs = [...form.querySelectorAll('input[type=password]')];
  const remember = !!form.querySelector('input[name=remember]')?.checked;
  const values = inputs.map((x) => x.value);
  const empty = inputs.find((x) => !x.value);
  if (inputs.length === 1 && empty) return empty.focus();
  if (values.every((v) => !v)) return inputs[0].focus();
  for (const x of inputs) x.value = '';
  const id = Number(form.dataset.secret);
  secretEls.delete(id);
  port.postMessage({ type: 'secret', tabId, id, value: values.find((v) => v) || '', values, remember });
});
$('log').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-secret-cancel]');
  if (!b) return;
  const id = Number(b.dataset.secretCancel);
  secretEls.delete(id);
  port.postMessage({ type: 'secret', tabId, id, value: null });
});

// 지금 판 보이기: 배포판은 "판 7 · AI 9", 개발판은 AI 창 버전만
var knockVersion = ''; // eslint-disable-line no-var -- 설정을 그릴 때(먼저 불릴 수 있다)도 쓰게
function drawVersion() {
  const v = document.querySelector('.set-ver');
  if (!v) return;
  // 맥 개발판(직접 만든 것)은 판 번호가 없다
  v.textContent = `Knock Browser ver ${knockVersion || '개발판'}${profile.name ? ` · ${/^프로필/.test(profile.name) ? '' : '프로필 '}${profile.name}` : ''}`;
  v.title = `AI 창 ${chrome.runtime.getManifest().version}`;
}

// ---------- 리뉴얼(2026-11-06, 피그마 ① 브라우저 화면) ----------
// 떠 있는 메뉴(프로필·AI 고르기): 하나만 열고, 바깥을 누르면 닫는다
function openPop(menu, anchor, below) {
  const was = !menu.classList.contains('hidden');
  for (const m of document.querySelectorAll('.pop')) m.classList.add('hidden');
  if (was) return false;
  menu.classList.remove('hidden');
  const r = anchor.getBoundingClientRect();
  menu.style.left = `${Math.max(8, Math.min(r.left, innerWidth - menu.offsetWidth - 8))}px`;
  if (below) { menu.style.top = `${r.bottom + 6}px`; menu.style.bottom = ''; } else { menu.style.bottom = `${innerHeight - r.top + 6}px`; menu.style.top = ''; }
  return true;
}
document.addEventListener('click', (e) => {
  if (!e.target.closest('.pop, #profile-chip, #model-chip, #prompts-btn')) for (const m of document.querySelectorAll('.pop')) m.classList.add('hidden');
});

// ---------- 저장한 프롬프트(2026-11-07 "자주 쓰는 프롬프트를 이름 붙여 저장하고 불러와 쓰게") ----------
// 입력칸 아래 책갈피 단추: 지금 쓴 글을 이름 붙여 저장 · 누르면 입력칸에 넣기 · ✕ 두 번 눌러 지우기. 이 프로필에 저장(최근 쓴 것이 위로)
let prompts = [];
chrome.storage.local.get('savedPrompts').then(({ savedPrompts }) => { prompts = savedPrompts || []; }).catch(() => {});
chrome.storage.onChanged.addListener((c) => {
  if (!c.savedPrompts) return;
  prompts = c.savedPrompts.newValue || [];
  if (!$('prompts-pop').classList.contains('hidden') && !$('prompts-pop').querySelector('.prompt-form')) drawPrompts();
});
const savePrompts = (list) => chrome.storage.local.set({ savedPrompts: list.slice(0, 100) });
function usePrompt(p) {
  const box = $('input');
  // 입력칸이 비었으면 그대로, 쓰던 글이 있으면 커서 자리에 넣는다(쓰던 글을 지우지 않게)
  if (!box.value.trim()) box.value = p.text;
  else box.setRangeText(p.text, box.selectionStart, box.selectionEnd, 'end');
  $('prompts-pop').classList.add('hidden');
  box.focus();
  box.dispatchEvent(new Event('input'));
  savePrompts([{ ...p, used: Date.now() }, ...prompts.filter((x) => x.id !== p.id)]);
}
function drawPrompts(naming = false) {
  const m = $('prompts-pop');
  m.textContent = '';
  m.append(el('div', 'pop-head', '저장한 프롬프트'));
  const text = $('input').value.trim();
  if (naming) {
    // 이름 붙여 저장: 같은 이름이 있으면 그 내용을 바꾼다
    const f = el('form', 'prompt-form');
    const name = el('input');
    Object.assign(name, { type: 'text', maxLength: 40, placeholder: '이름 (예: 블로그 글 다듬기)', value: text.split('\n')[0].slice(0, 20) });
    const ok = el('button', 'btn primary', '저장');
    ok.type = 'submit';
    const no = el('button', 'btn ghost', '취소');
    no.type = 'button';
    no.addEventListener('click', () => drawPrompts());
    const note = el('div', 'prompt-note muted', '');
    const check = () => { note.textContent = prompts.some((p) => p.name === name.value.trim()) ? '같은 이름이 있어요 · 저장하면 내용을 바꿔요' : ''; };
    name.addEventListener('input', check);
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const n = name.value.trim();
      if (!n) return name.focus();
      const old = prompts.find((p) => p.name === n);
      const item = { id: old?.id || crypto.randomUUID(), name: n, text, used: Date.now() };
      savePrompts([item, ...prompts.filter((p) => p.id !== item.id)]);
      prompts = [item, ...prompts.filter((p) => p.id !== item.id)];
      drawPrompts();
    });
    const acts = el('div', 'prompt-acts');
    acts.append(ok, no);
    f.append(name, note, acts);
    m.append(f);
    setTimeout(() => { name.focus(); name.select(); check(); });
    return;
  }
  if (text) {
    const add = el('button', 'pop-item plain', '＋ 지금 입력한 글을 프롬프트로 저장');
    add.type = 'button';
    add.addEventListener('click', () => drawPrompts(true));
    m.append(add, el('div', 'pop-line'));
  }
  if (!prompts.length) m.append(el('div', 'prompt-empty muted', '아직 저장한 프롬프트가 없어요 · 입력칸에 자주 쓰는 글을 쓴 뒤 여기서 저장하세요'));
  for (const p of prompts) {
    const row = el('div', 'prompt-row');
    const b = el('button', 'pop-item prompt-item');
    b.type = 'button';
    b.title = p.text;
    b.append(el('b', '', p.name), el('small', '', p.text.replace(/\s+/g, ' ').slice(0, 70)));
    b.addEventListener('click', () => usePrompt(p));
    const del = el('button', 'prompt-del', '✕');
    del.type = 'button';
    del.title = '지우기';
    del.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!del.classList.contains('sure')) { del.classList.add('sure'); del.textContent = '지우기'; setTimeout(() => { del.classList.remove('sure'); del.textContent = '✕'; }, 3000); return; }
      savePrompts(prompts.filter((x) => x.id !== p.id));
    });
    row.append(b, del);
    m.append(row);
  }
}
// 창 안에서 누른 것은 창을 닫지 않는다(누른 단추가 다시 그리기로 사라져도)
$('prompts-pop').addEventListener('click', (e) => e.stopPropagation());
$('prompts-btn').addEventListener('click', (e) => {
  e.stopPropagation();
  drawPrompts();
  openPop($('prompts-pop'), $('prompts-btn'), false);
});

// 프로필 메뉴: 이 창 · 켜져 있는 다른 프로필(누르면 그 창으로) · 프로필 수정(설정 › 장치·프로필)
const avatar = (name, color) => { const a = el('span', 'pchip-av', (name || 'K').slice(0, 1)); if (color) a.style.background = color; return a; };
function drawProfilesMenu(msg) {
  const m = $('profile-menu');
  m.textContent = '';
  m.append(el('div', 'pop-head', '브라우저 프로필'));
  const row = (name, color, sub, on, onClick) => {
    const b = el('button', `pop-item${on ? ' on' : ''}`);
    b.append(avatar(name, color));
    const t = el('span', 'pop-text');
    t.append(el('b', '', name), el('small', '', sub));
    b.append(t);
    if (on) b.append(el('span', 'pop-check', '✓'));
    b.addEventListener('click', onClick);
    m.append(b);
  };
  row(msg.me || profile.name, profile.color, '지금 이 창', true, () => m.classList.add('hidden'));
  for (const o of msg.others) row(o.name, o.color, '창 열림 · 누르면 그 창으로', false, () => { port.postMessage({ type: 'focusProfile', profile: o.name }); m.classList.add('hidden'); });
  // 닫혀 있는 프로필까지 보고 열기·추가는 브라우저 프로필 고르기 화면에서
  const all = el('button', 'pop-item plain', '모든 프로필 보기 · 닫힌 프로필 열기');
  all.addEventListener('click', () => { m.classList.add('hidden'); chrome.tabs.create({ url: 'chrome://profile-picker' }); });
  const add = el('button', 'pop-item plain', '+ 프로필 추가');
  add.addEventListener('click', () => { m.classList.add('hidden'); chrome.tabs.create({ url: 'chrome://profile-picker/new-profile' }); });
  m.append(el('div', 'pop-line'), all, add);
  const edit = el('button', 'pop-item plain', '프로필 수정');
  edit.addEventListener('click', () => { m.classList.add('hidden'); setSettingsOpen(true, 'link'); });
  m.append(edit, el('div', 'pop-foot', '프로필마다 북마크·로그인·AI 대화가 따로예요'));
}
$('profile-chip').addEventListener('click', (e) => {
  e.stopPropagation();
  if (openPop($('profile-menu'), $('profile-chip'), true)) {
    drawProfilesMenu({ me: profile.name, others: [] });
    port.postMessage({ type: 'profilesMenu' });
  }
});
port.onMessage.addListener((msg) => { if (msg.type === 'profilesMenu' && !$('profile-menu').classList.contains('hidden')) drawProfilesMenu(msg); });

// AI 창 닫기
$('collapse').addEventListener('click', () => {
  if (window.top !== window) return; // 원격 창 안에 끼워 넣은 AI 창은 원격 창의 단추로 닫는다
  port.postMessage({ type: 'closePanel', windowId: myWindow?.id });
});

// 입력칸 안의 AI 고르기: AI 별 묶음(설명 붙임) + Gemini 옆 창 + 연동 설정
const AI_ABOUT = { claude: '페이지·앱을 다루는 에이전트', chatgpt: '에이전트', gemini: '에이전트' };
// 피그마의 모델 설명(없으면 도우미가 준 이름의 뒷부분)
const MODEL_ABOUT = { 'claude-opus-5-5': '가장 똑똑함 · 어려운 일', 'claude-sonnet-5-5': '빠르고 똑똑함', 'claude-haiku-5-5': '가장 빠름 · 간단한 일' };
let moreModels = false; // ChatGPT 의 다른 모델 펼침
function drawModelChip() {
  const c = $('model-chip');
  // 이름 · 화살표를 따로 — 크기는 CSS 로 고정(AI 를 바꿔도 출렁이지 않게), 긴 이름은 … 로
  const [pid, mid] = String(selectedModel).split(':');
  const p = status.providers?.[pid];
  const m = p?.models?.find((x) => x.id === mid);
  const name = mode === 'gemini' ? 'Gemini' : p ? `${p.name} · ${(m?.name || '').split(' · ')[0]}` : '연결된 AI 없음';
  c.replaceChildren(el('span', 'mc-name', name), el('span', 'mc-arrow', '⌄'));
  c.title = `쓸 AI 와 모델 고르기 · 지금: ${name}`;
}
function drawModelMenu() {
  const menu = $('model-menu');
  menu.textContent = '';
  for (const p of Object.values(status.providers || {})) {
    // Gemini 에이전트는 연결했을 때만(평소 Gemini 는 아래 옆 창)
    if (p.id === 'gemini' && !p.ready) continue;
    menu.append(el('div', 'pop-head', `${AI_GROUP[p.id] || p.name}${AI_ABOUT[p.id] ? ` · ${AI_ABOUT[p.id]}` : ''}`));
    // ChatGPT 는 "기본 모델" 한 줄 — 다른 모델은 펼쳐서
    const many = p.id === 'chatgpt' && (p.models || []).length > 1;
    const list = many && !moreModels && !String(selectedModel).startsWith('chatgpt:') ? p.models.slice(0, 1) : p.models || [];
    for (const [k, m] of list.entries()) {
      let [title, ...rest] = String(m.name).split(' · ');
      let sub = MODEL_ABOUT[m.id] || rest.join(' · ');
      if (many && k === 0) { title = 'ChatGPT 기본 모델'; sub = `${m.name} · 내 ChatGPT 계정 요금제에 맞춤`; }
      const v = `${p.id}:${m.id}`;
      const on = mode !== 'gemini' && v === selectedModel;
      const b = el('button', `pop-item${on ? ' on' : ''}`);
      const t = el('span', 'pop-text');
      t.append(el('b', '', title), el('small', '', sub || ''));
      b.append(t);
      if (!p.ready) b.append(el('span', 'pop-badge', '연결 필요'));
      else if (on) b.append(el('span', 'pop-check', '✓'));
      b.addEventListener('click', () => {
        menu.classList.add('hidden');
        if (!p.ready) return setSettingsOpen(true, 'ai');
        selectedModel = v;
        $('model').value = v;
        port.postMessage({ type: 'model', model: v });
        if (mode === 'gemini') setMode('knock');
        drawModelChip();
      });
      menu.append(b);
    }
    if (many && list.length === 1) {
      const more = el('button', 'pop-item plain more', '다른 모델 보기 ›');
      more.addEventListener('click', (e) => { e.stopPropagation(); moreModels = true; drawModelMenu(); });
      menu.append(more);
    }
    menu.append(el('div', 'pop-line'));
  }
  menu.append(el('div', 'pop-head', 'Gemini · 옆 창에서 대화(페이지를 다루지는 않아요)'));
  const g = el('button', `pop-item${mode === 'gemini' ? ' on' : ''}`);
  const gt = el('span', 'pop-text');
  gt.append(el('b', '', 'Gemini'), el('small', '', '구글 계정으로 · 내 Gemini 요금제'));
  g.append(gt);
  if (mode === 'gemini') g.append(el('span', 'pop-check', '✓'));
  g.addEventListener('click', () => { menu.classList.add('hidden'); setMode('gemini'); drawModelChip(); });
  menu.append(g, el('div', 'pop-line'));
  const set = el('button', 'pop-item plain', 'AI 사용 연동 설정 ›');
  set.addEventListener('click', () => { menu.classList.add('hidden'); setSettingsOpen(true, 'ai'); });
  menu.append(set);
}
$('model-chip').addEventListener('click', (e) => {
  e.stopPropagation();
  drawModelMenu();
  openPop($('model-menu'), $('model-chip'), false);
});

// AI 를 껐을 때 화면(설정의 "AI 멈춤")
function drawOff() {
  const off = Boolean(privacy?.paused);
  $('off-view').classList.toggle('hidden', !off);
  document.body.classList.toggle('ai-off', off);
  $('input').disabled = off;
  $('input').placeholder = off ? 'AI 가 꺼져 있어요 · 위에서 켜면 쓸 수 있어요' : '무엇을 맡길까요? (Enter 보내기, Shift+Enter 줄바꿈)';
}
$('off-on').addEventListener('click', () => savePrivacy({ paused: false }));

// 빈 대화의 카드: 누르면 입력칸에 넣는다
$('hello-cards').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-ask]');
  if (!b) return;
  $('input').value = b.dataset.ask;
  $('input').focus();
});

// 다른 곳에서 바뀌면 칩·꺼짐 화면도 따라 그린다
port.onMessage.addListener((msg) => {
  if (['status', 'privacy', 'model'].includes(msg.type)) setTimeout(() => { drawModelChip(); drawOff(); });
});
setTimeout(() => { drawModelChip(); drawOff(); });

// 새 탭 카드에서 이 AI 창의 보기로(지난 대화·실행 중)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'panelView' && ['chat', 'jobs', 'past'].includes(msg.view)) {
    setSettingsOpen(false);
    if (mode === 'gemini') setMode('knock');
    setView(msg.view);
  }
});

// 원격 창 안의 AI 창: 그 PC 의 새 탭 카드를 누르면 보는 쪽 창이 알려 준다(remote-browser.js)
window.addEventListener('message', (e) => {
  if (e.origin !== location.origin || e.data?.type !== 'panelView' || !['chat', 'jobs', 'past'].includes(e.data.view)) return;
  setSettingsOpen(false);
  if (mode === 'gemini') setMode('knock');
  setView(e.data.view);
});

// 원격 창 안의 AI 창: 그 PC 가 묻는 것(보안 프로그램 연결 허용)을 대화 카드로 묻고 답을 보는 쪽 창에 돌려준다(2026-11-08)
window.addEventListener('message', (e) => {
  if (e.origin !== location.origin || e.source !== window.parent || e.data?.type !== 'remoteAsk') return;
  const { id, text, choices } = e.data;
  if (typeof id !== 'string' || typeof text !== 'string' || !Array.isArray(choices)) return;
  const box = $('remote-asks');
  [...box.children].find((x) => x.dataset.ask === id)?.remove();
  const el = itemEl({ kind: 'confirm', id, text, choices });
  el.dataset.ask = id;
  el.querySelectorAll('button[data-value]').forEach((b) => {
    delete b.dataset.confirm; // 대화 카드 처리기(background 로 답하는 것)로 가지 않게
    b.addEventListener('click', () => {
      window.parent.postMessage({ type: 'remoteAskAnswer', id, value: b.dataset.value }, location.origin);
      const picked = choices.find((c) => c.value === b.dataset.value)?.label;
      const done = itemEl({ kind: 'confirm', id, text, choices, answer: b.dataset.value === 'no' ? 'no' : 'yes', picked });
      done.dataset.ask = id;
      el.replaceWith(done);
    });
  });
  box.append(el);
  setSettingsOpen(false);
  if (mode === 'gemini') setMode('knock');
  setView('chat');
  $('hello').classList.add('hidden');
  el.scrollIntoView({ block: 'end' });
});

// 설정 창이 이미 떠 있으면 그 분류로 옮긴다
chrome.runtime.onMessage.addListener((msg) => {
  if (SETTINGS_ONLY && msg?.type === 'settingsCat') { if (msg.tabId) showTab(msg.tabId); showSettingsCat(msg.cat || setCat || 'ai'); }
});

// 사이트마다 맡기는 정도 그리기
const TRUST_OPTS = [['', '기본 따름'], ['all', '수동'], ['money', '필수 확인'], ['none', '완전 자동']];
function drawTrustList(msg) {
  const box = $('trust-list');
  if (!box) return;
  box.textContent = '';
  const sites = [...new Set([...Object.keys(msg.list || {}), ...Object.keys(msg.clickAllow || {}).map((h) => h.replace(/^www\./, ''))])].sort();
  if (!sites.length) box.append(el('p', 'muted', '아직 따로 정한 사이트가 없어요'));
  for (const site of sites) {
    const r = el('div', 'trust-site');
    const name = el('div', 'trust-name');
    const n = Object.entries(msg.clickAllow || {}).filter(([h]) => h.replace(/^www\./, '') === site).reduce((a, [, l]) => a + l.length, 0);
    name.append(el('b', '', site), el('small', '', n ? `항상 허용한 단추 ${n}개` : '항상 허용한 단추 없음'));
    const seg = el('div', 'seg');
    for (const [v, label] of TRUST_OPTS) {
      const b = el('button', (msg.list?.[site] || '') === v ? 'on' : '', label);
      b.type = 'button';
      b.addEventListener('click', () => port.postMessage({ type: 'siteTrust', site, level: v }));
      seg.append(b);
    }
    r.append(name, seg);
    box.append(r);
  }
}
port.onMessage.addListener((msg) => { if (msg.type === 'siteTrust') drawTrustList(msg); });

// 대화창 가리기 설정을 따라 다시 그린다
chrome.storage.local.get('chatMask').then(({ chatMask }) => { setChatMask(chatMask !== false); draw(); });
chrome.storage.onChanged.addListener((c) => { if (c.chatMask) { setChatMask(c.chatMask.newValue !== false); draw(); } });

// 저장한 카드·계좌 목록
function drawWallet(msg) {
  const ul = $('wallet-list');
  if (!ul) return;
  ul.textContent = '';
  if (!msg.list.length) {
    ul.append(el('li', 'muted', '아직 저장한 카드·계좌가 없어요'));
    ul.append(el('li', 'muted small', '자주 쓰는 카드나 이체 계좌를 저장해 두면, "광주은행 카드 이용내역 조회해 줘" 할 때 다시 묻지 않아요'));
  }
  for (const x of msg.list) {
    const li = el('li', 'tip');
    li.append(el('span', '', `· ${x.kind === 'account' ? '계좌' : '카드'} · ${x.label} …${x.last4}`));
    const b = el('button', 'icon-btn', '✕');
    b.title = '지우기';
    Object.assign(b.dataset, { wallet: x.id, label: x.label });
    li.append(b);
    ul.append(li);
  }
  const m = $('wallet-msg');
  if (m) { m.textContent = msg.error || msg.note || ''; m.classList.toggle('err', Boolean(msg.error || (msg.note && msg.note !== '저장했어요'))); }
  const d = $('vault-link-desc');
  if (d) d.textContent = `${THIS_PC === '이 PC' ? '윈도우 보안 저장소' : '맥 키체인'} · 로그인 ${$('vault-list')?.querySelectorAll('li.tip').length || 0}곳 · 카드·계좌 ${msg.list.length}개`;
}
port.onMessage.addListener((msg) => { if (msg.type === 'walletList') drawWallet(msg); });

// 원격을 켠 PC 는 브라우저를 닫아도 원격 대기(누를 때 권한 확인 — bg-mode.js)
watchClicksForBackground();
