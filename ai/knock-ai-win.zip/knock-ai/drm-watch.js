// 보호 영상(Widevine) 재생이 막혔는지 살핀다 — 페이지 안(MAIN)에서 돈다(2026-11-10).
// Knock Browser 는 구글 서명(VMP)이 없어 넷플릭스 같은 곳은 재생을 거절할 수 있다.
// 막히면 drm-bar.js 에 알려 "크롬·엣지에서 열기" 단추를 띄운다. 영상·잠금 자체는 건드리지 않는다(지켜보기만).
// 영상 사이트에만 넣는다(manifest.json matches) — 은행 보안 프로그램이 바뀐 함수를 문제 삼을 수 있어서(원장님 결정 2026-11-10).
(() => {
  if (window.__knockDrmWatch) return;
  window.__knockDrmWatch = true;
  let used = false; // 이 페이지가 보호 영상을 쓰려 했는지
  let told = false;
  const fail = (reason) => {
    if (told) return;
    told = true;
    try { window.postMessage({ __knockDrm: 'fail', reason: String(reason).slice(0, 200) }, '*'); } catch {}
  };
  const isWidevine = (ks) => /widevine/i.test(String(ks || ''));

  // 1) 보호 영상 장치를 아예 못 씀
  const nav = Navigator.prototype;
  const origAccess = nav.requestMediaKeySystemAccess;
  if (origAccess) {
    nav.requestMediaKeySystemAccess = function (ks, cfg) {
      const p = origAccess.call(this, ks, cfg);
      if (isWidevine(ks)) {
        used = true;
        p.catch((e) => { setTimeout(() => { if (!session) fail('access: ' + (e?.message || e)); }, 4000); });
      }
      return p;
    };
  }

  // 2) 잠금 풀기(라이선스)가 거절됨
  let session = null;
  const S = window.MediaKeySession?.prototype;
  if (S) {
    const wrap = (name) => {
      const orig = S[name];
      if (!orig) return;
      S[name] = function (...a) {
        used = true;
        session = this;
        if (!this.__knockDrmSeen) {
          this.__knockDrmSeen = true;
          // 잠금 풀기를 요청했는데 20초가 지나도 답(update)이 없고 영상도 안 나오면 — 서버가 거절한 것(넷플릭스 등)
          this.addEventListener('message', () => {
            const s = this;
            // 앞부분이 잠금 없이 몇 초 나오다 멈추는 영상도 있어, 그때 영상이 실제로 흘러가는지 3초 동안 본다
            setTimeout(() => {
              if (s.__knockDrmOk) return;
              const vs = [...document.querySelectorAll('video')];
              const t0 = vs.map((v) => v.currentTime);
              setTimeout(() => {
                if (s.__knockDrmOk) return;
                const moving = vs.some((v, i) => v.currentTime - t0[i] > 0.5);
                if (!moving) fail('no license answer');
              }, 3000);
            }, 20000);
          });
          this.addEventListener('keystatuseschange', () => {
            try {
              for (const st of this.keyStatuses.values()) {
                if (st === 'internal-error' || st === 'output-restricted') return fail('key: ' + st);
              }
            } catch {}
          });
        }
        const p = orig.apply(this, a);
        if (name === 'update') p.then(() => { this.__knockDrmOk = true; }, () => {});
        p.catch((e) => fail(name + ': ' + (e?.message || e)));
        return p;
      };
    };
    wrap('generateRequest');
    wrap('update');
  }

  // 3) 영상이 잠금 때문에 멈춤(MEDIA_ERR_ENCRYPTED 등)
  document.addEventListener('error', (e) => {
    const v = e.target;
    if (!(v instanceof HTMLMediaElement) || !used) return;
    const code = v.error?.code;
    if (code === 3 || code === 4 || code === 5) fail('media error ' + code);
  }, true);

  // 4) 넷플릭스는 Knock Browser 에서 재생되지 않는다(서명 없음) — 영상 화면(/watch/)으로 가는 순간
  //    오류 화면을 기다리지 않고 바로 넷플릭스 창으로 넘긴다(drm-bar.js 가 받아 처리, 2026-11-10)
  if (/(^|\.)netflix\.com$/.test(location.hostname) && window === window.top) {
    let last = '';
    const check = () => {
      // 영상 화면을 벗어나면 잊는다 — 같은 영상을 다시 눌러도 다시 넘기게(2026-11-10)
      if (!/^\/watch\//.test(location.pathname)) { last = ''; return; }
      if (location.href === last) return;
      last = location.href;
      try { window.postMessage({ __knockDrm: 'netflix-watch', url: location.href }, '*'); } catch {}
    };
    for (const name of ['pushState', 'replaceState']) {
      const orig = history[name];
      history[name] = function (...a) { const r = orig.apply(this, a); check(); return r; };
    }
    window.addEventListener('popstate', check);
    check();
    setInterval(check, 1000);
  }
  // 5) 넷플릭스는 자기 오류 화면만 띄운다 — 오류 번호(M7701-1003 같은)를 본다
  if (/(^|\.)netflix\.com$/.test(location.hostname) && window === window.top) {
    const re = /\b[MF]7\d{3}-\d{4}\b|\bF7\d{3}\b|\bM7\d{3}\b/;
    const look = () => {
      if (told || (!used && !/^\/watch\//.test(location.pathname))) return; // 영상 화면에서만
      const t = document.body?.innerText || '';
      if (re.test(t)) fail('netflix code ' + (t.match(re) || [''])[0]);
    };
    setInterval(look, 3000);
  }
})();
