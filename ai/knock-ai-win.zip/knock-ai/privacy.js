// 개인정보 보호 설정(사용자가 직접 정한다). AI 에게 보내는 페이지 정보는 모두 여기를 지난다.
//
// 정보 전송 권한(무엇을 AI 에게 보여 주나)만 다룬다. 실제 작업(결제·삭제·보내기)의 승인은
// background.js 의 "실행 전 확인"이 따로 맡는다 — 여기서 허용해도 작업이 자동 승인되지는 않는다.
//
//   scope        페이지 정보 범위: full(단추·칸 + 본문 글) | elements(단추·칸 이름만) | none(주소·제목만)
//   screenshots  화면 사진: allow | ask(매번 묻기) | deny
//   personal     개인정보가 보이면: mask(자동으로 가리기) | ask(보내기 전에 묻기) | allow(그대로)
//   paused       모든 사이트에서 AI 페이지 접근 멈춤
//   newSites     처음 쓰는 사이트: ask(AI 가 처음 쓰려 할 때 묻기) | allow(묻지 않고 허용)
//   secrets      계정 보안정보(인증 토큰·API 키·주소 속 인증값): mask(가리기, 기본) | allow(그대로)
//   passwordInput 비밀번호·인증번호 칸 입력: auto(자동 입력) | ask(확인 후 입력) | never(입력 안 함, 기본)
//   toksoriPersonal 똑소리 민감정보(계좌·연락처·주민번호) 조회: ask(매번 묻기, 기본) | allow(항상 허용) | deny(허용 안 함)
//   sites        사이트별: { "host": "block" | "allow" }  (항상 허용·막기. "이번 대화만"은 저장하지 않는다)

export const DEFAULTS = { scope: 'full', screenshots: 'allow', personal: 'mask', secrets: 'mask', passwordInput: 'never', toksoriPersonal: 'ask', paused: false, newSites: 'ask', sites: {} };

// 2026-11-09 원장님: "AI 에이전트 사용" 스위치(paused) 외에는 AI 를 막지 않는다 — 켜져 있으면 모든 사이트·앱에서 AI 를 쓴다.
// 예전에 저장된 사이트·앱별 막음/허용(sites)과 "처음 쓸 때 묻기"(newSites)는 읽지도 저장하지도 않는다.
export async function getPrivacy() {
  const { privacy } = await chrome.storage.local.get('privacy');
  return { ...DEFAULTS, ...(privacy || {}), sites: {}, newSites: 'allow' };
}

export async function setPrivacy(patch) {
  const { sites, newSites, ...rest } = patch || {};
  const next = { ...(await getPrivacy()), ...rest };
  await chrome.storage.local.set({ privacy: next });
  return next;
}

export function hostOf(url) {
  try {
    const u = new URL(url);
    return /^https?:$/.test(u.protocol) ? u.hostname : null;
  } catch {
    return null;
  }
}

// 사이트 규칙: 'allow' | 'block' | null(아직 정하지 않음). 하위 도메인은 위 도메인 설정을 따른다
// (mail.naver.com → naver.com). 더 구체적인 설정이 먼저다.
export function siteRule(p, url) {
  return 'allow'; // 사이트별 막음·묻기 없음(위 getPrivacy 설명) — 멈춤은 siteBlocked 가 본다
}

// mail.naver.com → [mail.naver.com, naver.com] (끝 한 마디 "com" 은 빼고), localhost → [localhost]
export function hostAndParents(host) {
  const parts = host.split('.');
  const out = [host];
  for (let i = 1; i < parts.length - 1; i++) out.push(parts.slice(i).join('.'));
  return out;
}

export const PAUSED = '사용자가 모든 사이트에서 AI 의 페이지 접근을 멈춰 두었습니다.';

// 막힌 이유(멈춤·막은 사이트) 또는 null. "아직 정하지 않음"은 막힘이 아니다(처음 쓸 때 묻는다).
export function siteBlocked(p, url) {
  return p.paused ? PAUSED : null; // "AI 에이전트 사용"을 끈 때만 막힌다
}

// ---------- 계정 보안정보: 사용자 선택(기본은 가림) ----------
const SECRETS = [
  [/\beyJ[\w-]{10,}\.[\w-]{10,}\.[\w-]{10,}/g, '[인증 토큰 가림]'], // JWT
  [/\b(Bearer|Basic)\s+[\w.~+/=-]{16,}/gi, '$1 [인증 정보 가림]'],
  [/([?&#;](?:access_token|id_token|refresh_token|token|auth|authorization|code|session|sessionid|sid|jsessionid|key|api_key|apikey|secret|password|passwd|pw|otp|ticket|signature|sig)=)[^&#\s"'<>]+/gi, '$1[가림]'],
  [/\bsk-(?:ant-)?[A-Za-z0-9_-]{16,}/g, '[API 키 가림]'],
  [/\bAIza[\w-]{30,}/g, '[API 키 가림]'],
  [/\bgh[pousr]_[A-Za-z0-9]{20,}/g, '[토큰 가림]'],
];

export function maskSecrets(text) {
  let out = String(text);
  for (const [re, rep] of SECRETS) out = out.replace(re, rep);
  return out;
}

// ---------- 일반 개인정보: 사용자 선택(가리기·묻기·그대로) ----------
// 순서가 중요하다: 더 구체적인 것(주민번호·카드)부터 바꿔서 겹치지 않게 한다.
const PERSONAL = [
  ['주민등록번호', /\b\d{6}[- ]?[1-4]\d{6}\b/g],
  ['카드번호', /\b(?:\d{4}[- ]){3}\d{4}\b/g],
  ['전화번호', /\b(?:01[016789]|0[2-6][1-5]?)[- )]?\d{3,4}[- ]\d{4}\b/g],
  ['이메일', /[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g],
  ['여권번호', /\b[MSRODG]\d{8}\b/g],
  // 날짜(2026-01-02)는 계좌번호가 아니다 — 빼지 않으면 똑소리HR 연차 기간·사용일이 모두 "[계좌번호 가림]"이 되어
  // AI 가 날짜를 못 봤다(2026-11-03 연동 시험에서 발견). 날짜 뒤에 숫자가 더 붙으면(2012-05-123456) 그대로 계좌로 본다.
  ['계좌번호', /\b(?!(?:19|20)\d{2}-(?:0?[1-9]|1[0-2])-(?:0?[1-9]|[12]\d|3[01])\b)\d{3,6}-\d{2,6}-\d{2,7}(?:-\d{1,3})?\b/g],
];

// 화면 사진에서 검게 덮을 무늬(page.js 가 페이지 안에서 다시 만든다)
export const PERSONAL_SOURCES = PERSONAL.map(([, re]) => [re.source, re.flags]);

export function findPersonal(text) {
  const counts = {};
  let rest = String(text);
  for (const [name, re] of PERSONAL) {
    const hits = rest.match(re);
    if (hits) {
      counts[name] = hits.length;
      rest = rest.replace(re, ' ');
    }
  }
  return counts;
}

// 가림표로 바꿀 개인정보를 순서대로 떼어 낸다. 자리에는 표식(\u0000A\u0000 — 숫자가 없어 다음 규칙에 안 걸림)을 남긴다.
// 돌려준 found[i] 가 표식 i 의 값이다(이름·실제 값).
export function takePersonal(text) {
  const found = [];
  const mark = (i) => `\u0000${i.toString(26).replace(/./g, (c) => String.fromCharCode(65 + parseInt(c, 26)))}\u0000`;
  let out = String(text);
  for (const [name, re] of PERSONAL) out = out.replace(re, (value) => mark(found.push({ name, value }) - 1));
  return { text: out, found, mark };
}

export function maskPersonal(text) {
  let out = String(text);
  for (const [name, re] of PERSONAL) out = out.replace(re, `[${name} 가림]`);
  return out;
}

export function describeCounts(counts) {
  return Object.entries(counts).map(([k, v]) => `${k} ${v}건`).join(', ');
}

// 제공사별 안내(처음 연결해 쓸 때 보여 준다)
export const PROVIDER_INFO = {
  claude: { company: 'Anthropic(미국)', service: 'Claude' },
  chatgpt: { company: 'OpenAI(미국)', service: 'ChatGPT(Codex)' },
  gemini: { company: 'Google(미국)', service: 'Gemini' },
};

export function disclosureText(provider, p) {
  // 보내는 것 · 보내지 않는 것으로 나눠 보인다(2026-11-06). 설정을 바꾸면 줄이 그쪽으로 옮겨 간다.
  const info = PROVIDER_INFO[provider] || { service: provider };
  const send = ['내가 쓴 말·첨부 파일: 그대로'];
  const keep = [];
  if (p.scope === 'full') send.push('웹페이지: 단추·입력칸 이름과 페이지 본문 글');
  else if (p.scope === 'elements') { send.push('웹페이지: 단추·입력칸 이름'); keep.push('웹페이지 본문 글'); }
  else { send.push('웹페이지: 주소와 제목'); keep.push('웹페이지의 단추·입력칸·본문 글'); }
  if (p.screenshots === 'allow') send.push('화면 사진');
  else if (p.screenshots === 'ask') send.push('화면 사진: 보낼 때마다 물어요');
  else keep.push('화면 사진');
  if (p.personal === 'allow') send.push('개인정보: 그대로');
  else keep.push(p.personal === 'ask' ? '개인정보: 보내기 전에 물어요' : '개인정보: 자동으로 가려서 보내요');
  if (p.secrets === 'allow') send.push('인증 토큰·API 키');
  else keep.push('인증 토큰·API 키');
  return [
    `${info.service}에 보내는 정보`,
    '',
    '보내는 것',
    ...send.map((x) => `• ${x}`),
    '',
    '보내지 않는 것',
    ...keep.map((x) => `• ${x}`),
    '',
    '결제·삭제·보내기는 따로 물어요 · 설정에서 바꿀 수 있어요',
  ].join('\n');
}
