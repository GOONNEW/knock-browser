// Knock 원격의 연결 안내 서버(Supabase). 공개해도 되는 값(프로젝트 주소·공개 열쇠)만 둔다.
export const REMOTE_CONFIG = {
  supabaseUrl: 'https://fwcmumcgyjlirkjowkdv.supabase.co',
  supabaseKey: 'sb_publishable_OXbEvrQJOC9C_0qSkJJjCw_-KD9LIyX', // 공개용 열쇠(publishable)
  // 두 컴퓨터가 서로의 주소를 알아내는 데 쓰는 공개 서버(STUN). 영상은 지나가지 않는다.
  iceServers: [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }],
};
