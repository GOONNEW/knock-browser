// 화면에 띄우지 않고 받아 온 페이지 HTML 을 글·링크로 바꾼다(서비스 워커에는 DOMParser 가 없어 여기서 한다).
// 스크립트는 실행되지 않는다(DOMParser 는 글만 읽는다).
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.target !== 'offscreen') return;
  if (msg.type === 'cleanForPaste') return reply(cleanForPaste(msg.html));
  if (msg.type !== 'parse') return;
  const doc = new DOMParser().parseFromString(msg.html, 'text/html');
  doc.querySelectorAll('script,style,noscript,template,svg,iframe').forEach((el) => el.remove());
  // 본문으로 보이는 곳을 먼저(네이버 블로그·카페·뉴스 등)
  const main = doc.querySelector('.se-main-container, #postViewArea, #dic_area, #newsct_article, article, main, [role=main]') || doc.body;
  const text = (main?.innerText || main?.textContent || '').replace(/[ \t ]+/g, ' ').replace(/\n\s*\n+/g, '\n\n').trim();
  const base = msg.url;
  const links = [];
  const seen = new Set();
  for (const a of (main || doc).querySelectorAll('a[href]')) {
    let href;
    try { href = new URL(a.getAttribute('href'), base).href; } catch { continue; }
    if (!/^https?:/.test(href) || seen.has(href)) continue;
    const label = (a.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 60);
    if (!label) continue;
    seen.add(href);
    links.push(`${label} → ${href}`);
    if (links.length >= 40) break;
  }
  const meta = (name) => doc.querySelector(`meta[property="${name}"], meta[name="${name}"]`)?.getAttribute('content') || '';
  reply({ title: doc.title || meta('og:title'), description: meta('og:description') || meta('description'), text, links });
});

// 붙여넣기용: 구글 문서 내보내기 HTML 처럼 서식이 class 로만 적힌 글을 굵게·기울임·가운데 정렬 태그로 바꾸고
// 나머지 꾸밈(class·글꼴·색)은 뺀다. 제목(h1~h3)·목록·표는 그대로 둔다.
function cleanForPaste(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const rules = new Map();
  for (const st of doc.querySelectorAll('style')) {
    for (const m of st.textContent.matchAll(/\.([\w-]+)\s*\{([^}]*)\}/g)) rules.set(m[1], (rules.get(m[1]) || '') + ';' + m[2]);
  }
  doc.querySelectorAll('script,style,meta,link,title,noscript').forEach((el) => el.remove());
  for (const el of [...doc.body.querySelectorAll('*')]) {
    const css = [...el.classList].map((c) => rules.get(c) || '').join(';') + ';' + (el.getAttribute('style') || '');
    const bold = /font-weight:\s*(700|bold)/.test(css);
    const italic = /font-style:\s*italic/.test(css);
    const align = (css.match(/text-align:\s*(center|right)/) || [])[1];
    for (const a of [...el.attributes]) if (!['href', 'colspan', 'rowspan', 'src'].includes(a.name)) el.removeAttribute(a.name);
    if (align && /^(P|H\d|TD|TH|LI)$/.test(el.tagName)) el.setAttribute('style', `text-align:${align}`);
    if (el.tagName === 'A') {
      // 구글이 감싼 주소(google.com/url?q=...)는 원래 주소로
      try { const u = new URL(el.getAttribute('href') || ''); if (u.hostname.endsWith('google.com') && u.pathname === '/url') el.setAttribute('href', u.searchParams.get('q') || u.href); } catch {}
    }
    if (el.tagName === 'SPAN' && !/^H\d$/.test(el.parentElement?.tagName || '') && (bold || italic)) {
      let inner = el.innerHTML;
      if (italic) inner = `<i>${inner}</i>`;
      if (bold) inner = `<b>${inner}</b>`;
      el.innerHTML = inner;
    }
  }
  // 빈 span 껍데기는 벗긴다
  for (const sp of [...doc.body.querySelectorAll('span')]) sp.replaceWith(...sp.childNodes);
  // 글자만 받는 곳을 위해: 문단·제목·목록·표 줄마다 줄을 바꾼다(이 문서는 화면에 그리지 않아 innerText 가 줄을 모른다)
  const text = [...doc.body.querySelectorAll('h1,h2,h3,h4,h5,h6,p,li,tr')]
    .filter((el) => !el.parentElement.closest('li,tr,p'))
    .map((el) => (el.tagName === 'TR' ? [...el.cells].map((c) => c.textContent.trim()).join('\t') : el.textContent.trim()))
    .join('\n');
  return { html: doc.body.innerHTML, text };
}
