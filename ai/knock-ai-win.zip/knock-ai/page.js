// AI 가 웹페이지를 읽고 조작하는 도구(똑소리 브라우저 pageTools.js 를 크롬 확장용으로 옮김).
// - 읽기·요소 찾기: chrome.scripting 으로 각 프레임에서 함수를 실행한다(다른 사이트 틀(iframe) 안도 됨).
// - 클릭·입력·키: 개발자 도구 통로(chrome.debugger)로 진짜 마우스·키보드 입력을 보낸다.
//   "사람이 누른 것"만 받는 사이트(코레일 등)에서도 동작하게 하려는 것이다.
// - 페이지 알림창(alert·confirm)도 이 통로로 알아채고 답한다.

const MAX_ELEMENTS = 300;
const TEXT_CHUNK = 6000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- 페이지 안에서 실행되는 함수들 (밖의 변수를 쓰면 안 된다) ----------

// 화면에 보이는 조작 가능한 요소에 번호(프레임번호-순번)를 붙여 돌려준다.
function snapshotInPage(frame) {
  const SEL = 'a[href],button,input:not([type=hidden]),select,textarea,summary,[role=button],[role=link],[role=tab],[role=menuitem],[role=option],[role=checkbox],[role=radio],[role=combobox],[onclick],[contenteditable=""],[contenteditable=true],label[for]';
  const SENSITIVE = /pass|pwd|card|cvc|cvv|pin|jumin|rrn|ssn|주민|카드|비밀|계좌|account.?no/i;
  const clean = (s, n = 80) => (s || '').replace(/\s+/g, ' ').trim().slice(0, n);
  document.querySelectorAll('[data-knock-id]').forEach((el) => el.removeAttribute('data-knock-id'));
  const vh = innerHeight;
  const vw = innerWidth;
  const items = [];
  let n = 0;
  // 코레일처럼 span·div 에 클릭을 거는 사이트가 많아서, 손가락 커서가 뜨는 가장 바깥 요소도 넣는다.
  const candidates = new Set(document.querySelectorAll(SEL));
  for (const el of document.body ? document.body.querySelectorAll('div,span,li,p,td,img,i,em,strong,dd,dt') : []) {
    if (el.closest(SEL)) continue;
    if (getComputedStyle(el).cursor !== 'pointer') continue;
    const parent = el.parentElement;
    if (parent && getComputedStyle(parent).cursor === 'pointer') continue;
    candidates.add(el);
  }
  const ordered = [...candidates].sort((a, b) => (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
  for (const el of ordered) {
    const r = el.getBoundingClientRect();
    // 파일 올리기 칸은 보통 숨겨 두고 "사진 추가" 버튼으로 연다. 숨어 있어도 AI 에게 보여 준다(upload_file 용).
    const isFile = el.tagName === 'INPUT' && el.type === 'file';
    if (!isFile) {
      if (r.width < 1 || r.height < 1) continue;
      const cs = getComputedStyle(el);
      if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) continue;
    }
    if (el.disabled) continue;
    const id = `${frame}-${n++}`;
    el.setAttribute('data-knock-id', id);
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute('type') || '').toLowerCase();
    const label = clean(el.getAttribute('aria-label') || el.innerText || el.value || el.getAttribute('placeholder') || el.title || el.getAttribute('alt') || (el.querySelector('img') && el.querySelector('img').alt) || el.name || '');
    const sensitive = type === 'password' || /cc-|current-password|new-password/.test(el.autocomplete || '')
      || SENSITIVE.test(`${el.name || ''} ${el.id || ''} ${el.getAttribute('placeholder') || ''} ${el.getAttribute('aria-label') || ''}`);
    const inView = isFile || (r.bottom > 0 && r.top < vh && r.right > 0 && r.left < vw);
    let desc = tag;
    if (tag === 'input') desc += `[${type || 'text'}]`;
    if (el.getAttribute('role')) desc += `(${el.getAttribute('role')})`;
    let line = `[${id}] ${desc} "${label}"`;
    if (isFile) {
      const near = clean((el.closest('label') || el.parentElement || {}).innerText || '', 40);
      line = `[${id}] 파일 올리기 칸${near ? ` "${near}"` : ''}${el.accept ? ` 받는 형식=${el.accept}` : ''}${el.multiple ? ' 여러 개 가능' : ''} → upload_file 로 파일을 넣으세요(버튼을 누르지 말고)`;
      items.push({ inView, line });
      continue;
    }
    if (tag === 'input' || tag === 'textarea') {
      if (el.name) line += ` name=${clean(el.name, 30)}`;
      if (el.placeholder) line += ` placeholder="${clean(el.placeholder, 40)}"`;
      if (type === 'checkbox' || type === 'radio') line += el.checked ? ' (선택됨)' : ' (선택 안 됨)';
      else if (sensitive) line += ' value=(가려짐)';
      else if (el.value) line += ` value="${clean(el.value, 60)}"`;
    }
    if (tag === 'select') {
      const opts = [...el.options];
      const cur = opts[el.selectedIndex];
      line += ` 현재="${clean(cur ? cur.text : '', 40)}" 선택지: ${opts.slice(0, 25).map((o) => clean(o.text, 20)).join(' | ')}${opts.length > 25 ? ` …외 ${opts.length - 25}개` : ''}`;
    }
    if (tag === 'a') {
      const href = el.getAttribute('href') || '';
      if (href && !href.startsWith('javascript') && href !== '#') line += ` → ${clean(href, 80)}`;
    }
    if (sensitive) line += ' (민감 정보 칸)';
    if (!inView) line += ' (화면 밖)';
    items.push({ inView, line });
  }
  return {
    url: location.href,
    items,
    text: (document.body ? document.body.innerText : '').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim(),
    scroll: { y: Math.round(scrollY), height: document.documentElement.scrollHeight, view: vh },
  };
}

// 번호로 요소를 찾아 한 가지 일을 한다.
function opInPage(id, op, arg) {
  const el = document.querySelector(`[data-knock-id="${id}"]`);
  if (!el) return { error: '요소를 찾지 못했습니다. 페이지가 바뀌었을 수 있으니 get_page 를 다시 호출하세요.', stale: true };
  // 일부 사이트(네이버 카페 등)는 window.Event 를 덮어쓴다. 확장의 별도 공간에서 실행되지만 옛 방식으로 만들어 둔다.
  const fire = (type) => {
    const ev = document.createEvent('HTMLEvents');
    ev.initEvent(type, true, true);
    el.dispatchEvent(ev);
  };
  const SENSITIVE = /pass|pwd|card|cvc|cvv|pin|jumin|rrn|ssn|주민|카드|비밀|계좌|account.?no/i;
  switch (op) {
    case 'describe': {
      const isField = /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName);
      const tagLabel = el.id ? document.querySelector(`label[for="${CSS.escape(el.id)}"]`) : null;
      const raw = isField
        ? (el.getAttribute('aria-label') || el.placeholder || (tagLabel && tagLabel.innerText) || el.title || el.name || '입력 칸')
        : (el.getAttribute('aria-label') || el.innerText || el.value || el.title || el.getAttribute('alt') || '');
      const type = (el.getAttribute('type') || '').toLowerCase();
      const sensitive = type === 'password' || /cc-|current-password|new-password/.test(el.autocomplete || '')
        || SENSITIVE.test(`${el.name || ''} ${el.id || ''} ${el.getAttribute('placeholder') || ''} ${el.getAttribute('aria-label') || ''}`);
      // 계정 보안정보 칸: 비밀번호·일회용 인증번호
      const password = type === 'password' || /current-password|new-password|one-time-code/.test(el.autocomplete || '')
        || /pass|pwd|otp|인증\s*번호|비밀\s*번호/i.test(`${el.name || ''} ${el.id || ''} ${el.getAttribute('placeholder') || ''} ${el.getAttribute('aria-label') || ''}`);
      const submit = (el.tagName === 'BUTTON' && (el.type || 'submit') === 'submit' && Boolean(el.form)) || (el.tagName === 'INPUT' && type === 'submit');
      return {
        label: raw.replace(/\s+/g, ' ').trim().slice(0, 80),
        sensitive,
        password,
        file: el.tagName === 'INPUT' && el.type === 'file',
        multiple: Boolean(el.multiple),
        tag: el.tagName.toLowerCase(),
        editable: el.isContentEditable,
        submit, // 양식을 제출하는 단추
      };
    }
    case 'point': {
      el.scrollIntoView({ block: 'center', inline: 'center' });
      const r = el.getBoundingClientRect();
      const x = r.left + r.width / 2;
      const y = r.top + r.height / 2;
      const hit = document.elementFromPoint(x, y);
      return { x, y, clear: Boolean(hit && (hit === el || el.contains(hit) || hit.contains(el))) };
    }
    case 'click':
      el.click();
      return {};
    case 'focus':
      el.scrollIntoView({ block: 'center' });
      el.focus();
      if (typeof el.select === 'function') el.select();
      else if (el.isContentEditable) {
        const range = document.createRange();
        range.selectNodeContents(el);
        const sel = getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
      }
      return {};
    case 'change':
      fire('change');
      return {};
    case 'value':
      return { value: 'value' in el ? String(el.value ?? '') : String(el.textContent || '') };
    case 'setValue': {
      // 키 입력이 안 먹는 칸(사이트 스크립트가 막음 등): 칸 값을 직접 넣고, 사람이 친 것처럼 알린다
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const set = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (set && 'value' in el) set.call(el, String(arg)); else el.textContent = String(arg);
      for (const t of ['input', 'keyup', 'change']) fire(t);
      return {};
    }
    case 'select': {
      if (el.tagName !== 'SELECT') return { error: '선택 상자(select)가 아닙니다. click 을 쓰세요.' };
      const want = String(arg);
      const opts = [...el.options];
      const o = opts.find((x) => x.value === want) || opts.find((x) => x.text.trim() === want) || opts.find((x) => x.text.includes(want));
      if (!o) return { error: `그런 선택지가 없습니다. 선택지: ${opts.map((x) => x.text.trim()).join(' | ').slice(0, 500)}` };
      el.value = o.value;
      fire('input');
      fire('change');
      return { chosen: o.text.trim() };
    }
    case 'reveal':
      el.scrollIntoView({ block: 'center' });
      return {};
    default:
      return { error: `알 수 없는 동작 ${op}` };
  }
}

// 지금 글자를 받고 있는 칸(Enter 를 누르기 전에 무엇을 보내는지 보려고)
function activeInPage() {
  const el = document.activeElement;
  if (!el || el === document.body) return null;
  return {
    tag: el.tagName.toLowerCase(),
    editable: el.isContentEditable,
    password: el.type === 'password' || el.autocomplete === 'one-time-code',
    label: (el.getAttribute('aria-label') || el.placeholder || el.name || el.title || '').replace(/\s+/g, ' ').trim().slice(0, 60),
  };
}

function scrollInPage(direction) {
  if (direction === 'up') scrollBy(0, -innerHeight * 0.8);
  else if (direction === 'down') scrollBy(0, innerHeight * 0.8);
  else if (direction === 'top') scrollTo(0, 0);
  else scrollTo(0, document.documentElement.scrollHeight);
}

// ---------- 개발자 도구 통로(chrome.debugger) ----------

const attached = new Set();
const dialogs = new Map(); // tabId → { type, message }
const dialogLog = new Map(); // tabId → [{ type, message, at }]

async function attach(tabId) {
  if (!attached.has(tabId)) {
    try {
      await chrome.debugger.attach({ tabId }, '1.3');
    } catch (err) {
      if (!/already attached/i.test(err.message)) throw err;
    }
    attached.add(tabId);
    await cdp(tabId, 'Page.enable');
  }
  keepDrawing(tabId);
}

// AI 가 일하는 동안은 창이 가려지거나 작아져도(뒤 탭이어도) 페이지가 그림을 계속 그리게 한다(2026-11-06 개선 요청 —
// 코레일: 가려진 창에서 '휴대폰 번호' 탭을 눌러도 바뀌지 않았다). 숨은 페이지는 그림 차례(requestAnimationFrame)가 오지 않아,
// 누르기는 들어가도 그다음 화면 바꾸기가 멈춘다. 포커스 흉내를 켜면 브라우저가 이 탭을 "보이는 중"으로 둔다.
// 1분 동안 AI 가 손대지 않으면 끈다(뒤 탭이 계속 그리느라 전기를 쓰지 않게).
const drawing = new Map(); // tabId → 끄기 타이머
function keepDrawing(tabId) {
  if (!drawing.has(tabId)) cdp(tabId, 'Emulation.setFocusEmulationEnabled', { enabled: true }).catch(() => {});
  clearTimeout(drawing.get(tabId));
  drawing.set(tabId, setTimeout(() => {
    drawing.delete(tabId);
    if (attached.has(tabId)) cdp(tabId, 'Emulation.setFocusEmulationEnabled', { enabled: false }).catch(() => {});
  }, 60000));
}

function cdp(tabId, method, params = {}) {
  return chrome.debugger.sendCommand({ tabId }, method, params);
}

chrome.debugger.onEvent.addListener(({ tabId }, method, params) => {
  if (method === 'Page.javascriptDialogOpening') {
    dialogs.set(tabId, { type: params.type, message: params.message });
    const list = dialogLog.get(tabId) || [];
    list.push({ type: params.type, message: params.message, at: Date.now() });
    dialogLog.set(tabId, list.slice(-5));
  } else if (method === 'Page.javascriptDialogClosed') {
    dialogs.delete(tabId);
  }
});
chrome.debugger.onDetach.addListener(({ tabId }) => {
  attached.delete(tabId);
  clearTimeout(drawing.get(tabId));
  drawing.delete(tabId);
  dialogs.delete(tabId);
});

// ---------- 도우미 ----------

function withTimeout(promise, ms, label) {
  return Promise.race([promise, new Promise((_, rej) => setTimeout(() => rej(new Error(`${label} 시간 초과`)), ms))]);
}

function staleError(message) {
  return Object.assign(new Error(message), { stale: true });
}

async function run(tabId, frameId, func, args) {
  const [res] = await withTimeout(
    chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, func, args }),
    5000,
    '페이지 스크립트',
  ).catch((err) => {
    if (/No frame|frame.*removed|Frame with ID/i.test(err.message)) throw staleError('그 요소가 있던 프레임이 사라졌습니다. get_page 를 다시 호출하세요.');
    throw err;
  });
  return res?.result;
}

async function op(tabId, id, name, arg) {
  if (!/^\d+-\d+$/.test(String(id))) throw new Error(`요소 번호 형식이 틀렸습니다: ${id} (예: 0-12)`);
  await attach(tabId).catch(() => {}); // 그림을 계속 그리게(keepDrawing)
  const frameId = Number(String(id).split('-')[0]);
  const res = await run(tabId, frameId, opInPage, [String(id), name, arg ?? null]);
  if (res?.error) throw Object.assign(new Error(res.error), { stale: Boolean(res.stale) });
  return res || {};
}

async function waitForIdle(tabId, timeout = 10000) {
  await sleep(300);
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!tab || tab.status !== 'loading') break;
    await sleep(200);
  }
  await sleep(400);
}

const KEY_CODES = {
  Enter: [13, 'Enter', '\r'], Tab: [9, 'Tab'], Escape: [27, 'Escape'], Backspace: [8, 'Backspace'],
  ArrowUp: [38, 'ArrowUp'], ArrowDown: [40, 'ArrowDown'], ArrowLeft: [37, 'ArrowLeft'], ArrowRight: [39, 'ArrowRight'],
  PageUp: [33, 'PageUp'], PageDown: [34, 'PageDown'], Home: [36, 'Home'], End: [35, 'End'], Space: [32, 'Space', ' '],
  Delete: [46, 'Delete'],
};
const MOD_BITS = { alt: 1, option: 1, ctrl: 2, control: 2, cmd: 4, meta: 4, command: 4, shift: 8 };
// 맥에서 단축키·선택 이동은 키 신호만으로는 편집기에 먹지 않아 브라우저 편집 명령을 함께 보낸다
const EDIT_COMMANDS = {
  'cmd+a': 'selectAll', 'cmd+c': 'copy', 'cmd+x': 'cut', 'cmd+v': 'paste', 'cmd+z': 'undo', 'cmd+shift+z': 'redo',
  'shift+ArrowLeft': 'moveLeftAndModifySelection', 'shift+ArrowRight': 'moveRightAndModifySelection',
  'shift+ArrowUp': 'moveUpAndModifySelection', 'shift+ArrowDown': 'moveDownAndModifySelection',
  'shift+Home': 'moveToBeginningOfLineAndModifySelection', 'shift+End': 'moveToEndOfLineAndModifySelection',
  'cmd+ArrowUp': 'moveToBeginningOfDocument', 'cmd+ArrowDown': 'moveToEndOfDocument',
  'cmd+ArrowLeft': 'moveToBeginningOfLine', 'cmd+ArrowRight': 'moveToEndOfLine',
  'cmd+shift+ArrowUp': 'moveToBeginningOfDocumentAndModifySelection', 'cmd+shift+ArrowDown': 'moveToEndOfDocumentAndModifySelection',
  'cmd+shift+ArrowLeft': 'moveToBeginningOfLineAndModifySelection', 'cmd+shift+ArrowRight': 'moveToEndOfLineAndModifySelection',
  'alt+ArrowLeft': 'moveWordLeft', 'alt+ArrowRight': 'moveWordRight',
  'alt+shift+ArrowLeft': 'moveWordLeftAndModifySelection', 'alt+shift+ArrowRight': 'moveWordRightAndModifySelection',
  'alt+Backspace': 'deleteWordBackward', 'cmd+Backspace': 'deleteToBeginningOfLine',
};


// 한 글자씩 키를 누르고 뗀다(사람이 치듯 사이를 조금씩 둔다). 매크로 막는 보안 프로그램(DynaPath 등)은 키 누름이 없이
// 칸에 글만 들어오면 로그인을 거부한다(2026-11-12 여신금융협회 "400 오류"). 영문 자판에 없는 글자는 그 글자만 그대로 넣는다.
const SHIFTED = { '!': '1', '@': '2', '#': '3', $: '4', '%': '5', '^': '6', '&': '7', '*': '8', '(': '9', ')': '0',
  _: '-', '+': '=', '{': '[', '}': ']', '|': '\\', ':': ';', '"': "'", '<': ',', '>': '.', '?': '/', '~': '`' };
const PUNCT = { '-': ['Minus', 189], '=': ['Equal', 187], '[': ['BracketLeft', 219], ']': ['BracketRight', 221], '\\': ['Backslash', 220],
  ';': ['Semicolon', 186], "'": ['Quote', 222], ',': ['Comma', 188], '.': ['Period', 190], '/': ['Slash', 191], '`': ['Backquote', 192], ' ': ['Space', 32] };
function keyOf(ch) {
  if (/^[a-z]$/.test(ch)) return { code: `Key${ch.toUpperCase()}`, vk: ch.toUpperCase().charCodeAt(0), shift: false };
  if (/^[A-Z]$/.test(ch)) return { code: `Key${ch}`, vk: ch.charCodeAt(0), shift: true };
  if (/^\d$/.test(ch)) return { code: `Digit${ch}`, vk: ch.charCodeAt(0), shift: false };
  const base = SHIFTED[ch];
  if (base) return { ...(/\d/.test(base) ? { code: `Digit${base}`, vk: base.charCodeAt(0) } : { code: PUNCT[base][0], vk: PUNCT[base][1] }), shift: true };
  if (PUNCT[ch]) return { code: PUNCT[ch][0], vk: PUNCT[ch][1], shift: false };
  return null;
}
async function typeKeys(tabId, text) {
  const SHIFT = { key: 'Shift', code: 'ShiftLeft', windowsVirtualKeyCode: 16, nativeVirtualKeyCode: 16 };
  for (const ch of String(text)) {
    const k = keyOf(ch);
    if (!k) {
      await cdp(tabId, 'Input.insertText', { text: ch });
    } else {
      const mods = k.shift ? 8 : 0;
      if (k.shift) await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'rawKeyDown', ...SHIFT, modifiers: 8 });
      const base = { key: ch, code: k.code, windowsVirtualKeyCode: k.vk, nativeVirtualKeyCode: k.vk, modifiers: mods };
      await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyDown', ...base, text: ch, unmodifiedText: ch });
      await sleep(25 + Math.random() * 45);
      await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', ...base });
      if (k.shift) await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', ...SHIFT, modifiers: 0 });
    }
    await sleep(50 + Math.random() * 110);
  }
}

// ---------- 도구 ----------

// 마우스 옮기기: 화면에 그리지 않는 탭에서는 브라우저가 다음 그림을 기다리느라 5초씩 멈춘다.
// 누르기에는 필요 없으니 잠깐만 기다리고 넘어간다(메뉴가 마우스를 올려야 열리는 경우를 위해 보내기는 한다).
// AI 가 누르는 동안은 화면 위 "멈추기" 단추(일하는 중 표시)를 누름이 그대로 지나가게 한다.
// (2026-11-09 ChatGPT: 보내기 단추가 멈추기 단추 밑에 있어, AI 가 보내기를 누르려다 자기를 멈췄다 — "종료 코드 143")
function overlayPass() {
  const host = document.getElementById('__knock_ai_overlay');
  const b = host?.__root?.querySelector('button');
  if (!b) return;
  b.style.pointerEvents = 'none';
  clearTimeout(host.__passTimer);
  host.__passTimer = setTimeout(() => { b.style.pointerEvents = ''; }, 2000);
}
async function moveMouse(tabId, x, y) {
  await Promise.race([chrome.scripting.executeScript({ target: { tabId }, func: overlayPass }).catch(() => {}), sleep(300)]);
  return Promise.race([cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x, y }).catch(() => {}), sleep(300)]);
}

const shotScale = new Map(); // tabId → 마지막 화면 사진의 줄인 비율

// 페이지 안에서 실행: 무늬에 맞는 글자·입력 칸 위에 검은 상자를 덮는다(사진을 찍는 동안만, 누르기는 그대로 통과).
// 다른 사이트의 iframe 안은 덮지 못한다.
function coverInPage(list) {
  const ID = '__knock_cover';
  document.getElementById(ID)?.remove();
  const box = document.createElement('div');
  box.id = ID;
  box.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147483647';
  const res = list.map(([src, flags]) => new RegExp(src, flags.includes('g') ? flags : `${flags}g`));
  const add = (r) => {
    if (r.width < 1 || r.height < 1 || r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) return;
    const d = document.createElement('div');
    d.style.cssText = `position:fixed;left:${r.left - 2}px;top:${r.top - 2}px;width:${r.width + 4}px;height:${r.height + 4}px;background:#222;border-radius:3px`;
    box.appendChild(d);
  };
  const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    const t = n.nodeValue;
    if (!t || t.length < 4 || !/\d|@/.test(t)) continue;
    for (const re of res) {
      re.lastIndex = 0;
      for (let m = re.exec(t); m; m = re.exec(t)) {
        if (!m[0].length) { re.lastIndex++; continue; }
        const range = document.createRange();
        range.setStart(n, m.index);
        range.setEnd(n, m.index + m[0].length);
        for (const r of range.getClientRects()) add(r);
      }
    }
  }
  for (const el of document.querySelectorAll('input, textarea')) {
    const v = el.value;
    if (v && res.some((re) => { re.lastIndex = 0; return re.test(v); })) add(el.getBoundingClientRect());
  }
  document.documentElement.appendChild(box);
  // 화면에 그려진 뒤 찍게 두 번 기다린다. 뒤에 숨은 탭은 그리기 신호가 오지 않으니 0.15초면 넘어간다.
  return new Promise((done) => {
    const finish = () => done(box.childElementCount);
    setTimeout(finish, 150);
    requestAnimationFrame(() => requestAnimationFrame(finish));
  });
}

const page = {
  dialogNotice(tabId) {
    const d = dialogs.get(tabId);
    if (!d) return null;
    const kind = { alert: '알림(확인만 있음)', confirm: '확인/취소', prompt: '글 입력', beforeunload: '페이지 떠나기 확인' }[d.type] || d.type;
    return `페이지에 알림창이 떠 있어서 다른 조작을 할 수 없습니다.\n종류: ${kind}\n내용: "${d.message}"\nanswer_dialog 로 답하세요.`;
  },

  recentDialogs(tabId) {
    const recent = (dialogLog.get(tabId) || []).filter((d) => Date.now() - d.at < 120000);
    return recent.length ? `\n\n## 최근 뜬 알림창\n${recent.map((d) => `- (${d.type}) "${d.message}"`).join('\n')}` : '';
  },

  attach,

  // 떼기: 직접 chrome.debugger.detach 하면 onDetach 가 오지 않아 '붙어 있음'으로 남고, 다음 attach 가 붙이지 않았다(2026-11-08 원격 은행 탭)
  async detach(tabId) {
    attached.delete(tabId);
    clearTimeout(drawing.get(tabId));
    drawing.delete(tabId);
    await chrome.debugger.detach({ tabId }).catch(() => {});
  },

  // scope(사용자 설정): full(단추·칸 + 본문 글) | elements(단추·칸만) | none(주소·제목만)
  async getPage(tabId, textOffset = 0, scope = 'full') {
    await attach(tabId).catch(() => {}); // 가려진 창이어도 페이지가 그리게(keepDrawing)
    if (scope === 'none') {
      const t = await chrome.tabs.get(tabId);
      return `URL: ${t.url}\n제목: ${t.title}\n\n(사용자 설정에 따라 페이지 내용은 AI 에게 보내지 않습니다. 이 페이지는 읽거나 조작할 수 없으니 사용자에게 알리세요.)`;
    }
    const tab = await chrome.tabs.get(tabId);
    const frames = (await chrome.webNavigation.getAllFrames({ tabId })) || [];
    frames.sort((a, b) => a.frameId - b.frameId);
    const results = await Promise.all(frames.map((f) => run(tabId, f.frameId, snapshotInPage, [f.frameId])
      .then((r) => ({ ...r, frameId: f.frameId }))
      .catch((err) => ({ error: err.message, frameId: f.frameId }))));
    const main = results.find((r) => r.frameId === 0) || {};
    const all = [];
    let failed = 0;
    let text = '';
    for (const r of results) {
      if (r.error || !r.items) { failed++; continue; }
      all.push(...r.items);
      if (r.text) text += (r.frameId === 0 ? '' : `\n\n[프레임 ${r.frameId}: ${r.url}]\n`) + r.text;
    }
    // 화면에 보이는 것을 먼저 보여 준다
    all.sort((a, b) => Number(b.inView) - Number(a.inView));
    const shown = all.slice(0, MAX_ELEMENTS);
    const chunk = text.slice(textOffset, textOffset + TEXT_CHUNK);
    const s = main.scroll || { y: 0, height: 0, view: 0 };
    return [
      `URL: ${tab.url}`,
      `제목: ${tab.title}`,
      `로딩 중: ${tab.status === 'loading' ? '예' : '아니오'}`,
      `스크롤: ${s.y}px / 전체 ${s.height}px (화면 높이 ${s.view}px)`,
      failed ? `읽지 못한 프레임: ${failed}개` : null,
      '',
      `## 조작 가능한 요소 (${shown.length}개${all.length > shown.length ? `, 화면 밖 ${all.length - shown.length}개는 생략 — 스크롤 후 다시 읽으세요` : ''})`,
      ...shown.map((x) => x.line),
      '',
      ...(scope === 'elements' ? ['(사용자 설정에 따라 페이지 본문 글은 보내지 않습니다)'] : [
        `## 페이지 글 (${textOffset}–${textOffset + chunk.length}자 / 전체 ${text.length}자)`,
        chunk,
        textOffset + chunk.length < text.length ? `\n(뒷부분이 더 있습니다. get_page 에 text_offset=${textOffset + chunk.length} 로 이어 읽을 수 있습니다)` : '',
      ]),
    ].filter((l) => l !== null).join('\n');
  },

  describe: (tabId, id) => op(tabId, id, 'describe'),

  // right: 오른쪽 단추(메뉴 열기 — 구글 캘린더 일정의 색 바꾸기·삭제 등)
  async click(tabId, id, right = false) {
    const info = await op(tabId, id, 'point');
    if ((id.startsWith('0-') && info.clear) || (right && id.startsWith('0-'))) {
      await attach(tabId);
      const base = { x: info.x, y: info.y, button: right ? 'right' : 'left', clickCount: 1 };
      await moveMouse(tabId, info.x, info.y);
      await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', ...base });
      await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', ...base });
    } else {
      // 프레임 안이거나 다른 요소에 가려져 있으면 스크립트로 누른다
      await op(tabId, id, 'click');
    }
    await waitForIdle(tabId);
  },

  // keys: 한 글자씩 진짜 키보드처럼 누른다(비밀번호 칸·매크로 막는 보안 프로그램이 있는 화면)
  async type(tabId, id, text, submit, keys = false) {
    if (keys && text && id.startsWith('0-')) {
      const info = await op(tabId, id, 'point');
      if (info.clear) {
        await attach(tabId);
        const base = { x: info.x, y: info.y, button: 'left', clickCount: 1 };
        await moveMouse(tabId, info.x, info.y);
        await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', ...base });
        await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', ...base });
        await sleep(150);
      }
    }
    await op(tabId, id, 'focus');
    await attach(tabId);
    if (text && keys) await typeKeys(tabId, text);
    else if (text) await cdp(tabId, 'Input.insertText', { text });
    else await page.key(tabId, 'Backspace');
    await op(tabId, id, 'change').catch(() => {});
    // 정말 들어갔나 확인(2026-11-06 4대보험: "입력했습니다"라고 했는데 칸이 그대로였다) — 안 들어갔으면 칸 값을 직접 넣는다
    let fallback = false;
    if (text) {
      // 숫자는 쉼표·원·띄어쓰기를 빼고 같은지, 글은 같은지(앞에 남은 글자가 붙어 "135568137"이 되는 것도 잡는다)
      const digits = /^[\d,\s.-]+$/.test(text);
      const norm = (v) => (digits ? String(v || '').replace(/[^\d.-]/g, '') : String(v || '').replace(/\s+/g, ' ').trim());
      const same = (v) => norm(v) === norm(text);
      const now = await op(tabId, id, 'value').catch(() => null);
      if (now && !same(now.value)) {
        // 한 번에 통째로 넣고 알림을 한 번만 보낸다(한 글자씩 넣으면 "보수 총액 30만 원 미만" 같은 확인 창이 첫 글자에서 뜬다)
        await op(tabId, id, 'setValue', text);
        const after = await op(tabId, id, 'value').catch(() => null);
        if (after && !same(after.value)) {
          throw new Error(`칸에 글이 들어가지 않았습니다(지금 칸 값: "${String(after.value).slice(0, 40)}"). 이 칸은 사이트가 입력을 막고 있을 수 있으니, 앞의 다른 칸을 먼저 채워야 하는지 확인하거나 사용자에게 직접 넣어 달라고 하세요.`);
        }
        fallback = true;
      }
    }
    if (submit) {
      await page.key(tabId, 'Enter');
      await waitForIdle(tabId);
    }
    return { fallback };
  },

  async select(tabId, id, option) {
    const res = await op(tabId, id, 'select', option);
    await waitForIdle(tabId);
    return res.chosen;
  },

  async scroll(tabId, direction, id) {
    if (id) await op(tabId, id, 'reveal');
    else await run(tabId, 0, scrollInPage, [direction]);
    await sleep(300);
  },

  // 키 누르기. modifiers: ['cmd','shift','alt','ctrl'], repeat: 같은 키를 여러 번(한 번의 도구 호출로)
  async key(tabId, key, modifiers = [], repeat = 1) {
    const mods = [...new Set(modifiers.map((m) => String(m).toLowerCase()))].filter((m) => MOD_BITS[m]);
    const bits = mods.reduce((b, m) => b | MOD_BITS[m], 0);
    let code; let name; let text;
    if (KEY_CODES[key]) [code, name, text] = KEY_CODES[key];
    else if (/^[a-z0-9]$/i.test(key)) {
      const ch = key.toLowerCase();
      code = ch.toUpperCase().charCodeAt(0);
      name = /\d/.test(ch) ? `Digit${ch}` : `Key${ch.toUpperCase()}`;
      text = bits & 8 ? ch.toUpperCase() : ch;
      key = text;
    } else throw new Error(`누를 수 없는 키입니다: ${key}`);
    if (bits & (4 | 2 | 1)) text = undefined; // 단축키는 글자를 넣지 않는다
    const order = ['cmd', 'ctrl', 'alt', 'shift'].filter((m) => mods.some((x) => MOD_BITS[x] === MOD_BITS[m]));
    const command = EDIT_COMMANDS[[...order, KEY_CODES[key] ? name : key.toLowerCase()].join('+')];
    await attach(tabId);
    const base = { windowsVirtualKeyCode: code, nativeVirtualKeyCode: code, key: name === 'Space' ? ' ' : (KEY_CODES[key] ? name : key), code: name, modifiers: bits };
    const times = Math.min(200, Math.max(1, repeat || 1));
    for (let i = 0; i < times; i++) {
      await cdp(tabId, 'Input.dispatchKeyEvent', { type: text ? 'keyDown' : 'rawKeyDown', ...base, ...(text ? { text, unmodifiedText: text } : {}), ...(command ? { commands: [command] } : {}) });
      await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', ...base });
    }
  },

  // 파일 올리기 칸(input[type=file])에 이 컴퓨터의 파일을 넣는다. 진짜 사용자가 고른 것처럼 받는다(change 도 일어남).
  async upload(tabId, id, paths) {
    const info = await op(tabId, id, 'describe');
    if (!info.file) return page.uploadByChooser(tabId, id, paths);
    if (paths.length > 1 && !info.multiple) throw new Error('이 칸은 파일을 하나만 받습니다. 하나씩 올리세요.');
    await attach(tabId);
    await cdp(tabId, 'DOM.getDocument', { depth: -1, pierce: true });
    const { searchId, resultCount } = await cdp(tabId, 'DOM.performSearch', { query: `[data-knock-id="${id}"]` });
    try {
      if (!resultCount) throw new Error('그 칸이 다른 사이트 틀(iframe) 안에 있어 아직 파일을 넣을 수 없습니다.');
      const { nodeIds } = await cdp(tabId, 'DOM.getSearchResults', { searchId, fromIndex: 0, toIndex: 1 });
      await cdp(tabId, 'DOM.setFileInputFiles', { files: paths, nodeId: nodeIds[0] });
    } finally {
      cdp(tabId, 'DOM.discardSearchResults', { searchId }).catch(() => {});
    }
    await waitForIdle(tabId);
  },

  // [사진] 같은 단추를 누르면 파일 선택 창이 뜨는 사이트(네이버 블로그 편집기 등 — 파일 칸이 처음엔 없음):
  // 그 창을 가로채(화면에 띄우지 않고) 그 자리에 파일을 넣는다(2026-11-07)
  aiChoosing: new Set(), // AI 가 [사진] 단추로 넣는 중인 탭
  keepChooser: new Set(), // 원격으로 보는 탭(파일 선택 창을 늘 가로채 보는 쪽에서 고르게)
  // trigger = { key, modifiers } 이면 단추 대신 그 단축키로 선택 창을 연다(피그마 "이미지 넣기" ⇧⌘K 처럼 단추가 없는 곳)
  async uploadByChooser(tabId, id, paths, trigger = null) {
    await attach(tabId);
    await cdp(tabId, 'Page.enable').catch(() => {});
    await cdp(tabId, 'Page.setInterceptFileChooserDialog', { enabled: true });
    page.aiChoosing.add(tabId); // 원격으로 보는 탭이면 이 선택 창은 AI 가 받는다(보는 쪽에 묻지 않게)
    let off = () => {};
    const opened = new Promise((resolve) => {
      const h = ({ tabId: t }, method, params) => { if (t === tabId && method === 'Page.fileChooserOpened') resolve(params); };
      chrome.debugger.onEvent.addListener(h);
      const timer = setTimeout(() => resolve(null), 8000);
      off = () => { clearTimeout(timer); chrome.debugger.onEvent.removeListener(h); };
    });
    try {
      if (trigger) await page.key(tabId, trigger.key, trigger.modifiers || []);
      else await page.click(tabId, id);
      const p = await opened;
      if (!p) throw new Error(trigger ? '그 단축키를 눌러도 파일 선택 창이 뜨지 않았습니다. 페이지(캔버스)를 한 번 눌러 둔 뒤 다시 하거나, 사진·파일 단추 번호를 쓰세요.' : '이 단추를 눌러도 파일 선택 창이 뜨지 않았습니다. get_page 의 "파일 올리기 칸"이나 다른 사진·파일 단추를 쓰세요.');
      if (paths.length > 1 && p.mode === 'selectSingle') throw new Error('이 단추는 파일을 하나만 받습니다. 하나씩 올리세요.');
      await cdp(tabId, 'DOM.setFileInputFiles', { files: paths, backendNodeId: p.backendNodeId });
    } finally {
      off();
      page.aiChoosing.delete(tabId);
      // 원격으로 보는 탭은 사람이 누른 선택 창도 보는 쪽으로 넘기므로 가로채기를 그대로 둔다
      if (!page.keepChooser.has(tabId)) cdp(tabId, 'Page.setInterceptFileChooserDialog', { enabled: false }).catch(() => {});
    }
    await waitForIdle(tabId);
  },

  async answerDialog(tabId, accept, text) {
    await attach(tabId);
    await cdp(tabId, 'Page.handleJavaScriptDialog', { accept, ...(text != null ? { promptText: text } : {}) });
    dialogs.delete(tabId);
    await waitForIdle(tabId);
  },

  dialog: (tabId) => dialogs.get(tabId) || null,

  active: (tabId) => run(tabId, 0, activeInPage, []).catch(() => null),

  // 화면 사진(너비 1280 이하로 줄여서). 사진의 점 하나 = 화면 좌표 1/scale — click_at 이 이 비율로 되돌린다.
  // cover: 찍기 전에 검게 덮을 글의 무늬 [[source, flags], …](개인정보·가림표로 넣은 값). 덮은 곳 수를 covered 로 알려 준다.
  async screenshot(tabId, cover = []) {
    await attach(tabId);
    const { cssVisualViewport: v } = await cdp(tabId, 'Page.getLayoutMetrics');
    const fit = Math.min(1, 1280 / v.clientWidth);
    shotScale.set(tabId, fit);
    // 레티나 화면은 2배로 찍히므로 그만큼 줄인다(사진 좌표 = 화면 좌표 × fit)
    const { result } = await cdp(tabId, 'Runtime.evaluate', { expression: 'devicePixelRatio', returnByValue: true }).catch(() => ({ result: { value: 1 } }));
    const scale = fit / (result?.value || 1);
    let covered = 0;
    try {
      if (cover.length) {
        const { result: r } = await withTimeout(cdp(tabId, 'Runtime.evaluate', { expression: `(${coverInPage})(${JSON.stringify(cover)})`, awaitPromise: true, returnByValue: true }), 5000, '개인정보 가리기');
        // 덮지 못했으면 찍지 않는다(가리지 않은 사진이 나가지 않게)
        if (typeof r?.value !== 'number') throw new Error('화면의 개인정보를 가리지 못해 화면 사진을 찍지 않았습니다. get_page 로 읽으세요.');
        covered = r.value;
      }
      // 뒤에 숨은 탭은 화면을 그리지 않아 사진이 끝나지 않을 수 있다
      const { data } = await withTimeout(cdp(tabId, 'Page.captureScreenshot', {
        format: 'jpeg',
        quality: 70,
        clip: { x: v.pageX, y: v.pageY, width: v.clientWidth, height: v.clientHeight, scale },
      }), 15000, '화면 사진(탭이 뒤에 숨어 있으면 찍히지 않습니다)');
      return { data, covered };
    } finally {
      if (cover.length) await cdp(tabId, 'Runtime.evaluate', { expression: "document.getElementById('__knock_cover')?.remove()" }).catch(() => {});
    }
  },

  // 화면 사진의 좌표(x, y)를 누른다. 입력칸으로 잡히지 않는 편집기(네이버 블로그·구글 문서 등)에서 쓴다.
  async clickAt(tabId, x, y, right = false) {
    await attach(tabId);
    const s = shotScale.get(tabId) || 1;
    const px = x / s;
    const py = y / s;
    const base = { x: px, y: py, button: right ? 'right' : 'left', clickCount: 1 };
    await moveMouse(tabId, px, py);
    await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', ...base });
    await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', ...base });
    await waitForIdle(tabId);
  },

  // 끌어다 놓기(2026-11-07 "사진을 끌어 001 오른쪽에 놓기"): screenshot 좌표 (x1,y1) 에서 눌러 (x2,y2) 로 옮겨 놓는다.
  // 페이지가 진짜 끌기(HTML 드래그)를 쓰면 그 끌기를 받아 놓을 자리에 떨어뜨리고, 마우스 움직임으로 끄는 편집기면 그대로 마우스를 옮긴다.
  async drag(tabId, x1, y1, x2, y2) {
    await attach(tabId);
    const s = shotScale.get(tabId) || 1;
    const a = { x: x1 / s, y: y1 / s };
    const b = { x: x2 / s, y: y2 / s };
    let dragData = null;
    const h = ({ tabId: t }, method, params) => { if (t === tabId && method === 'Input.dragIntercepted') dragData = params.data; };
    chrome.debugger.onEvent.addListener(h);
    await cdp(tabId, 'Input.setInterceptDrags', { enabled: true }).catch(() => {});
    try {
      await moveMouse(tabId, a.x, a.y);
      await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', x: a.x, y: a.y, button: 'left', buttons: 1, clickCount: 1 });
      await new Promise((r) => setTimeout(r, 150));
      // 조금씩 옮긴다(편집기가 끌기를 알아차리고 놓을 자리 표시를 그리게)
      const steps = 16;
      for (let i = 1; i <= steps; i++) {
        const x = a.x + ((b.x - a.x) * i) / steps;
        const y = a.y + ((b.y - a.y) * i) / steps;
        await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'left', buttons: 1 });
        await new Promise((r) => setTimeout(r, 30));
        if (dragData) break;
      }
      if (dragData) {
        // HTML 드래그: 놓을 자리에서 들어감 → 위에 있음(몇 번) → 놓기
        await cdp(tabId, 'Input.dispatchDragEvent', { type: 'dragEnter', x: b.x, y: b.y, data: dragData });
        for (let i = 0; i < 4; i++) {
          await cdp(tabId, 'Input.dispatchDragEvent', { type: 'dragOver', x: b.x, y: b.y, data: dragData });
          await new Promise((r) => setTimeout(r, 80));
        }
        await cdp(tabId, 'Input.dispatchDragEvent', { type: 'drop', x: b.x, y: b.y, data: dragData });
      } else {
        await new Promise((r) => setTimeout(r, 200)); // 놓을 자리 표시(초록 선 등)가 뜰 시간
      }
      await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', x: b.x, y: b.y, button: 'left', buttons: 0, clickCount: 1 });
    } finally {
      chrome.debugger.onEvent.removeListener(h);
      cdp(tabId, 'Input.setInterceptDrags', { enabled: false }).catch(() => {});
    }
    await waitForIdle(tabId);
    return { html: Boolean(dragData) };
  },

  // 지금 커서가 있는 곳에 글을 넣는다(진짜 키보드 입력처럼)
  async typeHere(tabId, text, submit, keys = false) {
    await attach(tabId);
    if (text && keys) await typeKeys(tabId, text);
    else if (text) await cdp(tabId, 'Input.insertText', { text });
    if (submit) {
      await page.key(tabId, 'Enter');
      await waitForIdle(tabId);
    }
  },

  // ⌘V(붙여넣기) — 클립보드에 넣어 둔 서식 있는 글을 커서 자리에 붙인다
  async paste(tabId) {
    await attach(tabId);
    const base = { key: 'v', code: 'KeyV', windowsVirtualKeyCode: 86, nativeVirtualKeyCode: 86, modifiers: 4 };
    await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'rawKeyDown', ...base, commands: ['paste'] });
    await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', ...base });
    await sleep(800);
    await waitForIdle(tabId);
  },

  waitForIdle,
};

export { page };
