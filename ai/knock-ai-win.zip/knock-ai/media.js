// 영상·문서 페이지 읽기(read_media, 2026-11-11): 화면 글(get_page)로는 안 보이는 것을 읽는다.
//   영상: 설명·올린 날짜·올린 사람·자막(음성 글) — 틱톡·유튜브·페이스북·인스타그램·<track> 자막
//   문서: Scribd 처럼 쪽마다 따로 받는 문서 본문·올린 날짜
// 읽지 못한 항목은 "찾지 못함"으로 분명히 돌려준다 — AI 가 짐작으로 채우지 않게.

// 페이지 안(MAIN)에서 돈다: 페이지 자료(JSON)·<track> 자막·문서 쪽 주소를 모은다. 바깥 변수 쓰지 않음.
export function mediaInPage() {
  const out = { url: location.href, title: document.title, meta: {}, ld: [], items: [], subs: [], tracks: [], docPages: [], docText: '', videos: document.querySelectorAll('video').length };
  const meta = (k) => document.querySelector(`meta[property="${k}"],meta[name="${k}"],meta[itemprop="${k}"]`)?.content || '';
  out.meta = {
    title: meta('og:title'), description: meta('og:description') || meta('description'),
    published: meta('article:published_time') || meta('og:video:release_date') || meta('uploadDate') || meta('datePublished'),
    author: meta('author') || meta('og:site_name'),
  };
  // 구조화 자료(JSON-LD): 영상·문서의 이름·설명·날짜·자막
  const flat = (j) => (Array.isArray(j) ? j.flatMap(flat) : j && typeof j === 'object' ? [j, ...(j['@graph'] ? flat(j['@graph']) : [])] : []);
  for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
    try {
      for (const j of flat(JSON.parse(s.textContent))) {
        const pick = {};
        for (const k of ['@type', 'name', 'headline', 'description', 'uploadDate', 'datePublished', 'dateCreated', 'dateModified', 'duration', 'transcript']) if (j[k]) pick[k] = typeof j[k] === 'string' ? j[k].slice(0, 2000) : j[k];
        const a = j.author || j.creator;
        if (a) pick.author = (Array.isArray(a) ? a : [a]).map((x) => x?.name || x).filter((x) => typeof x === 'string').join(', ');
        if (Object.keys(pick).length > 1) out.ld.push(pick);
      }
    } catch {}
  }
  const iso = (sec) => { const n = Number(sec); return n > 1e9 ? new Date(n * 1000).toISOString() : ''; };
  // 틱톡: 페이지 자료에 설명·올린 시각·자막(webvtt) 주소가 있다
  try {
    const el = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
    const it = el && JSON.parse(el.textContent).__DEFAULT_SCOPE__?.['webapp.video-detail']?.itemInfo?.itemStruct;
    if (it) {
      out.items.push({ site: '틱톡', description: it.desc || '', published: iso(it.createTime), author: it.author?.nickname || it.author?.uniqueId || '',
        stats: it.stats ? `조회 ${it.stats.playCount ?? '?'} · 좋아요 ${it.stats.diggCount ?? '?'} · 댓글 ${it.stats.commentCount ?? '?'}` : '' });
      const seen = new Set();
      for (const s of [...(it.video?.subtitleInfos || []), ...(it.video?.claInfo?.captionInfos || [])]) {
        const url = s.Url || s.url;
        const lang = s.LanguageCodeName || s.language || '';
        if (url && !seen.has(lang)) { seen.add(lang); out.subs.push({ lang, url, kind: 'vtt' }); }
      }
    }
  } catch {}
  // 유튜브: 플레이어 자료에 설명·올린 날짜·자막 주소
  try {
    const pr = window.ytInitialPlayerResponse;
    if (pr?.videoDetails) {
      out.items.push({ site: '유튜브', description: pr.videoDetails.shortDescription || '', published: pr.microformat?.playerMicroformatRenderer?.publishDate || '',
        author: pr.videoDetails.author || '', stats: pr.videoDetails.viewCount ? `조회 ${pr.videoDetails.viewCount}` : '' });
      for (const t of pr.captions?.playerCaptionsTracklistRenderer?.captionTracks || []) {
        out.subs.push({ lang: t.name?.simpleText || t.languageCode || '', url: t.baseUrl + (t.baseUrl.includes('fmt=') ? '' : '&fmt=vtt'), kind: 'vtt' });
      }
    }
  } catch {}
  // 페이스북·인스타그램: 페이지 안 자료에서 자막 주소·글·올린 시각을 찾는다(로그인해야 보이는 것이 많다)
  if (/(^|\.)(facebook|instagram)\.com$/.test(location.hostname)) {
    const html = [...document.querySelectorAll('script[type="application/json"]')].map((s) => s.textContent).join('\n').slice(0, 8e6);
    const un = (s) => { try { return JSON.parse(`"${s}"`); } catch { return s; } };
    const caps = [...html.matchAll(/"(?:captions_url|caption_url|sd_captions_url)"\s*:\s*"(https:[^"]+)"/g)].map((m) => un(m[1]));
    for (const url of [...new Set(caps)].slice(0, 3)) out.subs.push({ lang: '', url, kind: 'srt' });
    const msgs = [...html.matchAll(/"(?:message|caption|accessibility_caption)"\s*:\s*\{\s*"text"\s*:\s*"((?:[^"\\]|\\.){10,2000})"/g)].map((m) => un(m[1]));
    const times = [...html.matchAll(/"(?:creation_time|publish_time|taken_at)"\s*:\s*(\d{10})/g)].map((m) => iso(m[1]));
    if (msgs.length || times.length) out.items.push({ site: /instagram/.test(location.hostname) ? '인스타그램' : '페이스북', description: [...new Set(msgs)].slice(0, 3).join('\n---\n'), published: times[0] || '', author: '', stats: '' });
  }
  // 일반 영상의 <track> 자막(이미 받은 것은 바로 읽고, 아니면 주소)
  for (const v of document.querySelectorAll('video')) {
    for (const t of v.textTracks || []) {
      if (!/captions|subtitles/.test(t.kind)) continue;
      const cues = t.cues ? [...t.cues].map((c) => c.text).join(' ') : '';
      out.tracks.push({ lang: t.label || t.language || '', text: cues.slice(0, 50000) });
    }
    for (const tr of v.querySelectorAll('track[src]')) out.subs.push({ lang: tr.label || tr.srclang || '', url: tr.src, kind: 'vtt' });
  }
  // 문서: Scribd 는 쪽마다 글 파일(jsonp)을 따로 받는다 / pdf.js·Scribd 의 글 층
  const html = document.documentElement.innerHTML;
  out.docPages = [...new Set((html.match(/https:\/\/html\.scribdassets\.com\/[^"'\\\s]+?\.jsonp/g) || []))].slice(0, 60);
  out.docText = [...document.querySelectorAll('.text_layer, .textLayer')].map((e) => e.innerText).join('\n').slice(0, 200000);
  return out;
}

// 자막 파일(webvtt·srt·유튜브 xml) → 글
export function subsToText(raw) {
  const s = String(raw || '');
  if (/^\s*<\?xml|<transcript|<timedtext/.test(s)) {
    return s.replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
  }
  const lines = s.replace(/\r/g, '').split('\n').filter((l) => l.trim() && !/^WEBVTT|^NOTE|^STYLE|^\d+$|-->/.test(l.trim()));
  const out = [];
  for (const l of lines.map((x) => x.replace(/<[^>]+>/g, '').trim())) if (l && out[out.length - 1] !== l) out.push(l);
  return out.join(' ');
}

// Scribd 쪽 글 파일(jsonp: window.pageN_callback(["<div…>…</div>"])) → 글
export function scribdPageText(raw) {
  const m = String(raw || '').match(/\(\s*\[\s*("(?:[^"\\]|\\.)*")\s*\]\s*\)/);
  let html = '';
  try { html = m ? JSON.parse(m[1]) : ''; } catch {}
  // 낱말 묶음(span)마다 띄어 표 칸이 붙지 않게(예: "Item NameNPPA Ceiling Price")
  return html.replace(/<\/span>/g, ' </span>').replace(/<\/(div|p|br)>/g, '\n').replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n').trim();
}

const dateOnly = (s) => (String(s || '').match(/\d{4}-\d{2}-\d{2}/) || [String(s || '')])[0];

// 모은 것 + 받아 온 자막·문서 글 → AI 에게 줄 글. 못 찾은 것은 "찾지 못함"으로 적는다.
export function mediaReport(p, subs, docText) {
  const ld = p.ld.find((x) => /Video|Media|Article|Digital|Book|Creative/i.test(x['@type'] || '')) || p.ld[0] || {};
  const item = p.items[0] || {};
  const desc = item.description || ld.description || p.meta.description || '';
  const published = item.published || ld.uploadDate || ld.datePublished || ld.dateCreated || p.meta.published || '';
  const author = item.author || ld.author || p.meta.author || '';
  const NF = '찾지 못함';
  const lines = [
    `URL: ${p.url}`,
    `제목: ${ld.name || ld.headline || p.meta.title || p.title}`,
    `올린 날짜: ${published ? dateOnly(published) : `${NF} — 날짜를 짐작해 적지 마세요`}`,
    `올린 사람: ${author || NF}`,
    item.stats ? `반응: ${item.stats}` : null,
    '',
    `## 설명`,
    desc || NF,
    '',
  ];
  const capTexts = [...p.tracks.filter((t) => t.text).map((t) => ({ lang: t.lang, text: t.text })), ...subs.filter((s) => s.text)];
  const isVideo = p.videos || p.items.length || p.subs.length || p.tracks.length || /Video/i.test(ld['@type'] || '');
  if (isVideo) lines.push('## 자막·음성 글');
  if (!isVideo) {
    // 영상이 아닌 페이지(문서 등)
  } else if (capTexts.length) {
    for (const c of capTexts.slice(0, 2)) lines.push(`(${c.lang || '언어 모름'}) ${c.text}`);
  } else {
    const why = subs.length ? '자막 파일을 받지 못했습니다' : '이 영상에 읽을 수 있는 자막이 없습니다';
    lines.push(`${NF}(${why}). 영상에서 말한 내용(가격 등)은 확인하지 못했으니 짐작해 적지 마세요.`);
    if (/youtube\.com|youtu\.be/.test(p.url)) lines.push('유튜브는 영상 아래 설명의 [스크립트 표시]를 누른 뒤 get_page 로 읽을 수 있습니다.');
  }
  if (p.docPages.length || p.docText || docText) {
    lines.push('', '## 문서 본문');
    lines.push((docText || p.docText) || `${NF}(문서 글을 받지 못했습니다). 문서 내용은 확인하지 못했으니 검색 결과의 숫자를 옮겨 적지 마세요.`);
  }
  return lines.filter((l) => l !== null).join('\n');
}
