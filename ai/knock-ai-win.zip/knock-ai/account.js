// 똑소리툴즈 계정으로 Knock Browser 로그인 · 로그인된 장치(2026-11-05 — knock-hr/docs/Knock-계정-장치-원격-설계.md 3장).
// 계정은 HR·TR 과 함께 쓰지만, 로그인은 따로다: 브라우저 전용 로그인 화면(/knock/login)은 웹 로그인 쿠키를 만들지 않는다.
//
// 쿠키를 빌려 쓰지 않는다. 연결 시작 → 똑소리 연결 화면 탭에서 사람이 로그인하고 [연결] → 그동안 기다리다 이 장치의 열쇠를 받는다.
// 이후 똑소리 서버는 이 열쇠(Authorization: Bearer)로만 부른다. 열쇠는 이 프로필의 storage.local 에만 둔다.
// 시험할 때는 storage.local.accountOrigin 으로 서버 주소를 바꿀 수 있다(기본: 운영).
const DEFAULT_ORIGIN = 'https://hr.knocktools.com';

async function origin() {
  const { accountOrigin } = await chrome.storage.local.get('accountOrigin');
  return accountOrigin || DEFAULT_ORIGIN;
}

export async function accountState() {
  const { knockAccount } = await chrome.storage.local.get('knockAccount');
  return knockAccount ? { loggedIn: true, account: knockAccount.account, device: knockAccount.device, origin: knockAccount.origin } : { loggedIn: false, waiting: Boolean(logging) };
}

async function call(path, { method = 'GET', body } = {}) {
  const { knockAccount } = await chrome.storage.local.get('knockAccount');
  if (!knockAccount) throw Object.assign(new Error('로그인하지 않았어요.'), { loggedOut: true });
  const r = await fetch(`${knockAccount.origin}${path}`, {
    method,
    headers: { authorization: `Bearer ${knockAccount.token}`, ...(body ? { 'content-type': 'application/json' } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}),
    credentials: 'omit',
    cache: 'no-store',
  });
  const d = await r.json().catch(() => ({}));
  // 다른 장치에서 이 장치를 로그아웃했으면 열쇠를 지운다
  if (r.status === 401 && d.loggedOut) {
    await chrome.storage.local.remove(['knockAccount', 'pastUp']);
    forgetChatKey();
    throw Object.assign(new Error(d.error || '로그인이 끊겼어요. 다시 로그인해 주세요.'), { loggedOut: true });
  }
  if (!r.ok) throw Object.assign(new Error(d.error || `똑소리 서버 오류 ${r.status}`), { reason: d.reason });
  return d;
}

// 로그아웃하면 [항상 허용]으로 이 PC 에 둔 지난 대화 열쇠도 지운다(다른 계정으로 로그인해도 남지 않게)
const forgetChatKey = () => { try { indexedDB.deleteDatabase('knock-chat-key'); } catch {} };

/** 다른 모듈(지난 대화 함께 보기 cloud-chats.js)도 같은 장치 열쇠·로그아웃 처리로 부른다 */
export const accountApi = call;

let logging = null; // 진행 중인 로그인(두 번 누르지 않게)
let cancelled = false; // [취소]를 눌렀다

/** 기다리던 로그인을 멈춘다(설정의 [취소]) */
export function accountCancel() {
  cancelled = Boolean(logging);
}

// 연결 화면에서 거쳐 갈 수 있는 곳(로그인·간단 가입·비밀번호 찾기). 이 밖으로 나가면 로그인을 그만 기다린다.
const CONNECT_PAGES = /^\/(knock\/login|knock\/connect|signup|find-id|forgot-password|reset-password)(\/|$)/;

/** 로그인: 연결 화면 탭을 열고, [연결]을 누를 때까지(최대 10분) 기다린다. name·os 는 이 장치 이름·종류. */
export function accountLogin(name, os, appVersion) {
  if (logging) return logging;
  cancelled = false;
  logging = (async () => {
    const base = await origin();
    const s = await fetch(`${base}/api/knock/connect/start`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, credentials: 'omit',
      body: JSON.stringify({ name, os, appVersion }),
    }).then((r) => (r.ok ? r.json() : Promise.reject(new Error(`연결을 시작하지 못했어요(${r.status})`))));
    const tab = await chrome.tabs.create({ url: `${base}${s.connectPath}`, active: true });
    const until = Date.now() + s.expiresIn * 1000;
    while (Date.now() < until) {
      await new Promise((r) => setTimeout(r, (s.interval || 2) * 1000));
      const r = await fetch(`${base}/api/knock/connect/poll`, {
        method: 'POST', headers: { 'content-type': 'application/json' }, credentials: 'omit', body: JSON.stringify({ deviceCode: s.deviceCode }),
      });
      const d = await r.json().catch(() => ({}));
      if (d.status === 'ok') {
        await chrome.storage.local.set({ knockAccount: { origin: base, token: d.token, device: d.device, account: d.account } });
        // 연결 화면 탭은 "연결됐어요"를 잠깐 보여 준 뒤 닫는다
        setTimeout(() => chrome.tabs.remove(tab.id).catch(() => {}), 2500);
        return await accountState();
      }
      if (d.status === 'expired') throw new Error('연결 시간이 지났어요. 다시 로그인을 눌러 주세요.');
      if (cancelled) throw new Error('로그인을 취소했어요.');
      // 연결 화면 탭을 닫았거나 다른 곳으로 옮겼으면 그만 기다린다
      const t = await chrome.tabs.get(tab.id).catch(() => null);
      if (!t) throw new Error('연결 화면을 닫아서 로그인을 멈췄어요.');
      let path = '';
      try { const u = new URL(t.url || t.pendingUrl || ''); path = u.origin === base ? u.pathname : ''; } catch {}
      if (!CONNECT_PAGES.test(path)) {
        // 웹(HR·TR) 로그인 화면으로 옮겼으면 그 탭을 Knock Browser 로그인 화면으로 되돌린다(웹 로그인과는 따로다)
        if (/^\/login(\/|$)/.test(path)) { await chrome.tabs.update(tab.id, { url: `${base}${s.connectPath}` }).catch(() => {}); continue; }
        throw new Error('연결 화면을 벗어나서 로그인을 멈췄어요.');
      }
    }
    throw new Error('연결 시간이 지났어요. 다시 로그인을 눌러 주세요.');
  })().finally(() => { logging = null; });
  return logging;
}

// ---------- 설정 창 안에서 로그인·간단 가입(2026-11-05) — 웹 탭 없이 바로 ----------
async function post(path, body) {
  const r = await fetch(`${await origin()}${path}`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, credentials: 'omit', cache: 'no-store', body: JSON.stringify(body),
  }).catch(() => null);
  if (!r) throw new Error('똑소리 서버에 연결하지 못했어요. 인터넷을 확인해 주세요.');
  const d = await r.json().catch(() => ({}));
  if (r.status === 429) throw new Error('너무 여러 번 시도했어요. 10분 뒤에 다시 해 주세요.');
  // 404: 서버에 아직 이 창구가 없다(서버를 새로 올리기 전)
  if (r.status === 404) throw new Error('똑소리 서버가 아직 준비되지 않았어요. 잠시 뒤 다시 해 주세요.');
  if (!r.ok) throw new Error(d.error || `똑소리 서버 오류 ${r.status}`);
  return d;
}

/** 이메일·비밀번호로 바로 로그인하고 이 장치의 열쇠를 받는다 */
export async function accountPasswordLogin({ email, password, name, os, appVersion }) {
  const base = await origin();
  const d = await post('/api/knock/login', { email, password, name, os, appVersion });
  await chrome.storage.local.set({ knockAccount: { origin: base, token: d.token, device: d.device, account: d.account } });
  return accountState();
}

/** 간단 가입 단계: 'send-code' {email} · 'verify-code' {email, code} · 'create' {email, password, agreeTerms} */
export function accountSignup(step, body) {
  return post(step === 'create' ? '/api/knock/signup' : `/api/knock/signup/${step === 'verify-code' ? 'verify-code' : 'send-code'}`, body);
}

/** 아이디·비밀번호 찾기·약관은 웹 화면으로(드물게 쓴다) */
export async function accountWebPage(page) {
  const path = { findId: '/find-id', findPw: '/forgot-password', terms: '/terms' }[page];
  if (path) await chrome.tabs.create({ url: `${await origin()}${path}` });
}

export async function accountLogout() {
  await call('/api/knock/devices/logout', { method: 'POST', body: { self: true } }).catch(() => {});
  await chrome.storage.local.remove(['knockAccount', 'pastUp']);
  forgetChatKey();
  return { loggedIn: false };
}

/** 로그인된 장치 목록(이 장치 포함). 부를 때마다 이 장치가 켜져 있음도 서버에 알려진다. */
export async function accountDevices() {
  const d = await call('/api/knock/devices');
  const { knockAccount } = await chrome.storage.local.get('knockAccount');
  if (knockAccount && d.account) await chrome.storage.local.set({ knockAccount: { ...knockAccount, account: d.account } });
  return d;
}

/** { id } 다른 장치 하나 · { others: true } 이 장치 빼고 모두 */
export async function accountLogoutDevice(which) {
  return call('/api/knock/devices/logout', { method: 'POST', body: which });
}

export async function accountRename(name) {
  const d = await call('/api/knock/device', { method: 'PATCH', body: { name } });
  const { knockAccount } = await chrome.storage.local.get('knockAccount');
  if (knockAccount) await chrome.storage.local.set({ knockAccount: { ...knockAccount, device: d.device } });
  return d;
}

export async function accountMyPage() {
  const s = await accountState();
  await chrome.tabs.create({ url: `${s.origin || (await origin())}/me` });
}

// ---------- 원격(2단계) ----------
// 이 장치의 원격 상태 { remoteEnabled, hasPassword, inboxId }
export async function accountRemoteState() {
  const d = await call('/api/knock/device');
  const { knockAccount } = await chrome.storage.local.get('knockAccount');
  if (knockAccount) await chrome.storage.local.set({ knockAccount: { ...knockAccount, remote: d.device } });
  return d.device;
}

/** { name?, remotePassword?, remoteEnabled? } */
export async function accountSetRemote(patch) {
  const d = await call('/api/knock/device', { method: 'PATCH', body: patch });
  const { knockAccount } = await chrome.storage.local.get('knockAccount');
  if (knockAccount) await chrome.storage.local.set({ knockAccount: { ...knockAccount, remote: d.device, device: { ...knockAccount.device, name: d.device.name } } });
  return d.device;
}

// "이 PC에서는 다시 묻지 않음" 기억 열쇠 — 받는 장치마다 하나(storage.local.remoteTrust). 서버에는 해시만 있다.
async function trusts() {
  return (await chrome.storage.local.get('remoteTrust')).remoteTrust || {};
}
export async function accountRemoteTrusted(toDeviceId) {
  return Boolean((await trusts())[toDeviceId]);
}

/** 연결 요청 → { sessionId, roomId, inboxId, to } — 비밀번호를 안 주면 기억 열쇠로 */
export async function accountRemoteConnect({ toDeviceId, mode, password, remember }) {
  const t = await trusts();
  const body = { toDeviceId, mode, ...(password ? { password, remember: Boolean(remember) } : { trustToken: t[toDeviceId] }) };
  const r = await call('/api/knock/remote/connect', { method: 'POST', body }).catch(async (err) => {
    // 기억 열쇠가 끝났으면(그 PC 비밀번호를 바꿈) 지우고 비밀번호를 묻게 한다
    if (!password && t[toDeviceId]) { delete t[toDeviceId]; await chrome.storage.local.set({ remoteTrust: t }); }
    throw err;
  });
  if (r.trustToken) { t[toDeviceId] = r.trustToken; await chrome.storage.local.set({ remoteTrust: t }); }
  return r;
}

/** 원격 중계(TURN) 열쇠 — 똑소리 서버가 12시간짜리를 만들어 준다. 11시간 동안 다시 쓴다(2026-11-07) */
export async function accountTurn() {
  const { remoteTurn } = await chrome.storage.session.get('remoteTurn').catch(() => ({}));
  if (remoteTurn?.until > Date.now()) return remoteTurn.servers;
  const r = await call('/api/knock/remote/turn', { method: 'POST', body: {} }).catch(() => null);
  const servers = Array.isArray(r?.iceServers) ? r.iceServers.filter((s) => s && s.urls && String(s.urls).includes('turn')) : null;
  if (servers?.length) await chrome.storage.session.set({ remoteTurn: { servers, until: Date.now() + 11 * 3600 * 1000 } }).catch(() => {});
  return servers;
}

/** 업데이트 여부만 묻는 짧은 연결(원격 목록 — 2026-11-07). 기억 열쇠가 있을 때만, 실패해도 열쇠는 지우지 않는다 */
export async function accountRemoteProbe(toDeviceId, password = '') {
  if (password) return accountRemoteConnect({ toDeviceId, mode: 'browser', password, remember: true }).catch((err) => ({ error: err.message, reason: err.reason || '' }));
  const t = await trusts();
  if (!t[toDeviceId]) return { reason: 'notrust' };
  return call('/api/knock/remote/connect', { method: 'POST', body: { toDeviceId, mode: 'browser', trustToken: t[toDeviceId] } }).catch(() => null);
}

/** 원격 목록 PC 그룹(계정에 저장 — 2026-11-07) { groups: [{ id, name, locked }] } */
export async function accountGroups() {
  return call('/api/knock/remote/groups');
}
/** { action: create|open|rename|lock|delete|move, ... } — 잠긴 그룹은 password 를 함께 */
export async function accountGroupAct(body) {
  return call('/api/knock/remote/groups', { method: 'POST', body });
}

export async function accountRemoteClaim(sessionId) {
  return call('/api/knock/remote/claim', { method: 'POST', body: { sessionId } });
}
export async function accountRemoteEnd(sessionId) {
  return call('/api/knock/remote/end', { method: 'POST', body: { sessionId } }).catch(() => {});
}
