// 도구 막대 계정 작은 창: 로그인 안 함 → [로그인]·[회원가입] / 로그인 함 → 계정 · 내 PC · 계정 관리 · 로그아웃
import { pinBoxes, lockIcon } from './pin.js';
const box = document.getElementById('box');
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

function button(text, cls, onClick) {
  const b = el('button', `btn ${cls || ''}`, text);
  b.type = 'button';
  b.addEventListener('click', onClick);
  return b;
}
// 설정 창의 장치·프로필에서 로그인·가입(웹 탭 없이)
const toSettings = (step) => { chrome.runtime.sendMessage({ type: 'toolbarOpenSettings', cat: 'link', step }); window.close(); };

async function draw() {
  const st = await chrome.runtime.sendMessage({ type: 'toolbarAccount' }).catch(() => null);
  box.textContent = '';
  if (!st?.loggedIn) {
    box.append(el('b', 'title', '똑소리 계정으로 Knock Browser에 로그인'), el('p', 'line', '🖥 Knock Browser에 로그인된 다른 PC를 쓸 수 있어요'));
    box.append(button('로그인', 'primary wide', () => toSettings('login')), button('회원가입', 'wide', () => toSettings('signup')));
    return;
  }
  const name = st.account?.name || st.account?.email?.split('@')[0] || '내 계정';
  const who = el('div', 'who');
  who.append(el('span', 'av', name.slice(0, 1)));
  const t = el('div', '');
  t.append(el('b', '', name), el('small', '', `${st.account?.email || ''} · 똑소리 계정`));
  who.append(t);
  box.append(who, el('div', 'line-sep'));
  const devs = st.devices || [];
  box.append(el('div', 'head', `내 PC ${devs.length}대`));
  for (const d of devs) {
    const r = el('div', 'dev');
    r.append(el('span', 'dev-name', d.name || 'PC'));
    if (d.thisDevice) r.append(el('span', 'tag', '이 컴퓨터'));
    if (d.remoteEnabled) r.append(el('span', 'tag on', 'ON'));
    box.append(r);
  }
  box.append(el('div', 'line-sep'));
  box.append(button('똑소리 계정 관리 ›', 'plain', () => { toSettings(''); }));
  box.append(button('로그아웃', 'plain', async () => { await chrome.runtime.sendMessage({ type: 'toolbarLogout' }).catch(() => {}); window.close(); }));
}
// 탭 줄 맨 앞 프로필 칩(toolbar.html#prof — 2026-11-10 피그마 ④ 화면 7~9):
// 이 PC 에서 쓰는 프로필 · 잠긴 프로필은 자물쇠와 "잠김"(이 PC 에서 묻지 않게 한 것은 "이 PC에서 묻지 않음")
// 잠긴 프로필을 누르면 메뉴 자리에 PIN 창 → 맞으면 그 프로필 창이 열린다. 틀리면 칸이 빨갛게, 남은 횟수.
const prof = (op, d = {}) => chrome.runtime.sendMessage({ type: 'prof', op, ...d }).catch((e) => ({ error: e.message }));
async function drawProfiles() {
  const st = await prof('menu');
  box.textContent = '';
  box.classList.add('menu');
  // 지금 창의 프로필을 맨 위에(피그마 ✓ 내 Knock)
  for (const p of [...(st?.items || [])].sort((x, y) => Number(y.current) - Number(x.current))) {
    const b = el('button', 'btn plain prof-item');
    b.append(el('span', 'chk', p.current ? '✓' : ''), el('span', 'pname', p.name));
    if (p.locked) {
      const tag = el('span', 'ptag');
      tag.append(lockIcon(), document.createTextNode(p.noAsk ? '이 PC에서 묻지 않음' : '잠김'));
      b.append(tag);
    }
    b.addEventListener('click', async () => {
      if (p.current) return window.close();
      if (!st.account) { await prof('openLocal', { dir: p.dir }); return window.close(); }
      if (p.locked && !p.noAsk) return pinFor(p, st.touch);
      openIt(p, '');
    });
    box.append(b);
  }
  box.append(el('div', 'line-sep'));
  // + 프로필 추가: 계정 목록이 있으면 설정의 새 프로필, 없으면 브라우저 프로필 만들기
  box.append(button('+ 프로필 추가', 'plain prof-item add', () => {
    if (st?.account) return toSettings('newProfile');
    chrome.tabs.create({ url: 'chrome://profile-picker/new-profile' });
    window.close();
  }));
}
const dotOf = (c) => { const d = el('span', 'pdot'); d.style.background = c || '#FF6A3D'; return d; };
async function openIt(p, pin, noAsk = false, msgEl = null, pins = null) {
  const r = await prof('openProfile', { id: p.id, pin, noAsk });
  if (r?.ok) return window.close();
  if (msgEl) {
    msgEl.className = 'pin-msg bad';
    msgEl.textContent = r?.error || 'PIN이 맞지 않습니다.';
    pins?.bad(true);
    pins?.clear();
    pins?.focus();
  } else {
    box.append(el('p', 'pin-msg bad', r?.error || '열지 못했어요.'));
  }
}
// 화면 8·9: 메뉴가 닫히고 그 자리에 PIN 창
function pinFor(p, touch) {
  box.textContent = '';
  box.classList.remove('menu');
  box.classList.add('pinpop');
  const head = el('div', 'pin-head');
  head.append(dotOf(p.color), el('b', '', p.name), lockIcon(16));
  const msg = el('p', 'pin-msg');
  const no = el('label', 'chk-row');
  const nb = el('input');
  nb.type = 'checkbox';
  no.append(nb, el('span', '', '이 PC에서는 더 묻지 않음'));
  const pins = pinBoxes({ small: true, onFull: (pin) => { msg.className = 'pin-msg'; msg.textContent = '확인하는 중…'; openIt(p, pin, nb.checked, msg, pins); } });
  const acts = el('div', 'pin-acts');
  if (touch && /Mac/.test(navigator.platform)) {
    const t = el('button', 'touch-btn', '👆 지문으로 열기');
    t.type = 'button';
    t.addEventListener('click', async () => {
      t.disabled = true;
      const r = await prof('openTouch', { id: p.id, name: p.name, noAsk: nb.checked });
      t.disabled = false;
      if (r?.ok) return window.close();
      msg.className = 'pin-msg bad';
      msg.textContent = r?.error || '지문을 확인하지 못했어요.';
    });
    acts.append(t);
  }
  acts.append(el('span', 'grow'), button('취소', 'small', () => window.close()));
  box.append(head, el('p', 'line', `잠긴 프로필입니다. PIN 6자리를 넣으면 ${p.name} 창이 열려요.`), pins.el, msg, no, acts);
  pins.focus();
}
if (location.hash === '#prof') drawProfiles();
else draw();
