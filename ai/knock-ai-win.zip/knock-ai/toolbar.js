// 도구 막대 계정 작은 창: 로그인 안 함 → [로그인]·[회원가입] / 로그인 함 → 계정 · 내 PC · 계정 관리 · 로그아웃
const box = document.getElementById('box');
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

function button(text, cls, onClick) {
  const b = el('button', `btn ${cls || ''}`, text);
  b.type = 'button';
  b.addEventListener('click', onClick);
  return b;
}
// 설정 창의 장치·프로필에서 로그인·가입(웹 탭 없이)
const toSettings = (step) => { chrome.runtime.sendMessage({ type: 'toolbarOpenSettings', cat: 'link', step }); window.close(); };

async function draw() {
  const st = await chrome.runtime.sendMessage({ type: 'toolbarAccount' }).catch(() => null);
  box.textContent = '';
  if (!st?.loggedIn) {
    box.append(el('b', 'title', '똑소리 계정으로 Knock Browser에 로그인'), el('p', 'line', '🖥 Knock Browser에 로그인된 다른 PC를 쓸 수 있어요'));
    box.append(button('로그인', 'primary wide', () => toSettings('login')), button('회원가입', 'wide', () => toSettings('signup')));
    return;
  }
  const name = st.account?.name || st.account?.email?.split('@')[0] || '내 계정';
  const who = el('div', 'who');
  who.append(el('span', 'av', name.slice(0, 1)));
  const t = el('div', '');
  t.append(el('b', '', name), el('small', '', `${st.account?.email || ''} · 똑소리 계정`));
  who.append(t);
  box.append(who, el('div', 'line-sep'));
  const devs = st.devices || [];
  box.append(el('div', 'head', `내 PC ${devs.length}대`));
  for (const d of devs) {
    const r = el('div', 'dev');
    r.append(el('span', 'dev-name', d.name || 'PC'));
    if (d.thisDevice) r.append(el('span', 'tag', '이 컴퓨터'));
    if (d.remoteEnabled) r.append(el('span', 'tag on', 'ON'));
    box.append(r);
  }
  box.append(el('div', 'line-sep'));
  box.append(button('똑소리 계정 관리 ›', 'plain', () => { toSettings(''); }));
  box.append(button('로그아웃', 'plain', async () => { await chrome.runtime.sendMessage({ type: 'toolbarLogout' }).catch(() => {}); window.close(); }));
}
// 탭 줄 맨 앞 프로필 칩(toolbar.html#prof): 이 창 · 켜져 있는 다른 프로필(누르면 그 창으로) · 모든 프로필 · 추가 · 수정
async function drawProfiles() {
  const st = await chrome.runtime.sendMessage({ type: 'toolbarProfiles' }).catch(() => null);
  box.textContent = '';
  box.append(el('div', 'head', '브라우저 프로필'));
  const row = (name, color, sub, onClick) => {
    const b = el('button', 'btn plain prof');
    const av = el('span', 'av sm', (name || 'K').slice(0, 1));
    if (color) av.style.background = color;
    const t = el('span', 'prof-text');
    t.append(el('b', '', name), el('small', '', sub));
    b.append(av, t);
    b.addEventListener('click', onClick);
    box.append(b);
  };
  row(st?.me || '이 프로필', st?.color, '지금 이 창 ✓', () => window.close());
  for (const o of st?.others || []) row(o.name, o.color, '창 열림 · 누르면 그 창으로', () => { chrome.runtime.sendMessage({ type: 'toolbarFocusProfile', profile: o.name }); window.close(); });
  box.append(el('div', 'line-sep'));
  box.append(button('모든 프로필 보기 · 닫힌 프로필 열기', 'plain', () => { chrome.tabs.create({ url: 'chrome://profile-picker' }); window.close(); }));
  box.append(button('+ 프로필 추가', 'plain', () => { chrome.tabs.create({ url: 'chrome://profile-picker/new-profile' }); window.close(); }));
  box.append(button('프로필 수정', 'plain', () => toSettings('')));
}
if (location.hash === '#prof') drawProfiles();
else draw();
