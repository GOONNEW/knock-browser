// 저장한 프롬프트를 같은 계정의 모든 PC·프로필이 함께 쓴다(2026-11-14 원장님 "저장된 대화처럼 관리").
// 이 장치 목록(storage.local savedPrompts)이 늘 바탕이고, 서버(/api/knock/prompts)와 5분마다·고칠 때마다 맞춘다.
//   - 이름·내용·별표·쓴 횟수는 지난 대화와 같은 계정 열쇠로 잠가 올린다(서버는 풀지 못함).
//   - 받기는 잠금이 풀린 장치에서만(지난 대화 [잠금 풀기]). 지운 표시는 잠겨 있어도 받는다.
//   - 고친 시각(at)이 더 새것이 이긴다. 같은 이름이 둘이면 새것만 남긴다.
//   - 다른 계정으로 로그인한 프로필이면 예전 목록은 savedPromptsPrev 로 옮겨 두고 새 계정 것만 쓴다(계정끼리 섞지 않음).
// savedPrompts: [{ id, name, text, star, uses, used, at }] · promptsGone: { id: 지운 시각 } · promptsUp: { id: 올린 at } · promptsAcc: 계정 이메일
import { accountApi } from './account.js';
import { sealWith, openSealed, keyReady } from './cloud-chats.js';

export const PROMPTS_MAX = 500;
const GONE_KEEP_MS = 30 * 86400000;
const KEYS = ['savedPrompts', 'promptsGone', 'promptsUp', 'promptsAcc', 'knockAccount'];

let running = null;
export function syncPrompts() {
  running ||= doSync().catch((e) => ({ error: String(e?.message || e) })).then(async (r) => {
    await chrome.storage.local.set({ promptsSyncState: { at: Date.now(), ...r } }).catch(() => {});
    return r;
  }).finally(() => { running = null; });
  return running;
}

const norm = (p) => ({ id: p.id, name: String(p.name || '').slice(0, 40), text: String(p.text || ''), star: Boolean(p.star), uses: Math.max(0, Number(p.uses) || 0), used: Number(p.used) || 0, at: Number(p.at) || Number(p.used) || 1 });

async function doSync() {
  let { savedPrompts = [], promptsGone = {}, promptsUp = {}, promptsAcc = null, knockAccount } = await chrome.storage.local.get(KEYS);
  if (!knockAccount?.token) return { local: true };
  const acc = String(knockAccount.account?.email || '');
  if (!acc) return { local: true };
  if (promptsAcc && promptsAcc !== acc) {
    // 이 프로필이 다른 계정으로 바뀜: 예전 계정 목록은 올리지 않고 옆에 둔다
    await chrome.storage.local.set({ savedPromptsPrev: { acc: promptsAcc, list: savedPrompts, at: Date.now() }, savedPrompts: [], promptsGone: {}, promptsUp: {}, promptsAcc: acc });
    savedPrompts = []; promptsGone = {}; promptsUp = {};
  } else if (!promptsAcc) {
    // 처음 맞추기: 이 장치에 있던 것은 이 계정으로 합친다
    await chrome.storage.local.set({ promptsAcc: acc });
  }

  const d = await accountApi('/api/knock/prompts');
  const pub = d.key?.publicKey || null;
  const unlocked = await keyReady();
  const incoming = new Map(); // 서버에서 받은 더 새것
  const removed = new Map(); // 지울 것: id → 지운 시각
  const local = new Map(savedPrompts.map((p) => [p.id, norm(p)]));
  const server = new Map(d.prompts.map((r) => [r.key, r]));
  const goneAdd = {}; // 이번에 새로 지울 것(같은 이름 정리)
  const goneDone = new Set(); // 서버에서 지운 것이 확인된 것

  for (const r of d.prompts) {
    const mine = local.get(r.key);
    if (r.deleted) {
      if (mine && mine.at <= r.at) removed.set(r.key, r.at);
      if (promptsGone[r.key]) goneDone.add(r.key); // 서버도 지웠음
      continue;
    }
    if (promptsGone[r.key] && promptsGone[r.key] >= r.at) continue; // 여기서 더 나중에 지움 → 아래에서 지우기를 보냄
    if (mine && mine.at >= r.at) continue;
    if (!unlocked) continue;
    const b = await openSealed(r.body);
    if (!b || typeof b.text !== 'string') continue;
    incoming.set(r.key, norm({ ...b, id: r.key, at: r.at }));
    promptsUp[r.key] = r.at;
    if (promptsGone[r.key]) goneDone.add(r.key); // 지운 뒤에 다른 PC 에서 고친 것 → 되살림
  }

  // 받은 것을 합친 뒤 같은 이름이 둘이면 새것만
  const merged = new Map(local);
  for (const [id, p] of incoming) merged.set(id, p);
  for (const id of removed.keys()) merged.delete(id);
  const byName = new Map();
  for (const p of merged.values()) {
    const o = byName.get(p.name);
    if (!o) { byName.set(p.name, p); continue; }
    const [keep, drop] = o.at >= p.at ? [o, p] : [p, o];
    byName.set(p.name, keep);
    merged.delete(drop.id);
    removed.set(drop.id, Date.now());
    goneAdd[drop.id] = Date.now();
  }

  // 올리기: 고친 것(올린 뒤 at 이 바뀐 것) · 지운 것
  let up = 0;
  let fail = '';
  if (pub) {
    for (const p of merged.values()) {
      if (promptsUp[p.id] === p.at) continue;
      const r = server.get(p.id);
      if (r && r.at >= p.at) { if (!r.deleted) promptsUp[p.id] = p.at; continue; } // 서버가 더 새것(잠겨 있어 못 받음)
      const res = await accountApi('/api/knock/prompts', { method: 'POST', body: { action: 'put', key: p.id, at: p.at, body: await sealWith(pub, { name: p.name, text: p.text, star: p.star, uses: p.uses, used: p.used }) } }).catch((e) => ({ error: e.message }));
      if (res?.ok) { promptsUp[p.id] = p.at; up++; } else { fail = res?.error || '올리지 못했어요'; break; }
    }
  }
  for (const [id, at] of Object.entries({ ...promptsGone, ...goneAdd })) {
    if (goneDone.has(id)) continue;
    const r = server.get(id);
    if (!r || r.deleted) { goneDone.add(id); continue; } // 서버에 없거나 이미 지움
    const res = await accountApi('/api/knock/prompts', { method: 'POST', body: { action: 'delete', key: id, at } }).catch(() => null);
    if (res?.ok) goneDone.add(id);
    else if (Date.now() - at > GONE_KEEP_MS) goneDone.add(id);
  }
  for (const id of Object.keys(promptsUp)) if (!merged.has(id) && !server.has(id)) delete promptsUp[id];

  // 쓰기: 그 사이 이 장치에서 고친 것(더 새 at)은 지키며 합친다
  const fresh = await chrome.storage.local.get(['savedPrompts', 'promptsGone']);
  const now = new Map((fresh.savedPrompts || []).map((p) => [p.id, norm(p)]));
  const gone = { ...(fresh.promptsGone || {}), ...goneAdd };
  for (const id of goneDone) delete gone[id];
  const out = new Map(now);
  for (const [id, p] of incoming) { const o = now.get(id); if (!o || o.at < p.at) out.set(id, p); }
  for (const [id, at] of removed) { const o = out.get(id); if (o && o.at <= at) out.delete(id); }
  // 이 장치에서 그 사이 새로 만든 것은 now 에 있어 그대로 남는다
  const list = [...out.values()].sort((a, b) => (b.used || b.at) - (a.used || a.at)).slice(0, PROMPTS_MAX);
  const changed = JSON.stringify(list) !== JSON.stringify([...now.values()].sort((a, b) => (b.used || b.at) - (a.used || a.at)).slice(0, PROMPTS_MAX));
  await chrome.storage.local.set({ ...(changed ? { savedPrompts: list } : {}), promptsGone: gone, promptsUp });
  return { ok: !fail, unlocked, keyMissing: !pub, up, got: incoming.size, error: fail || undefined };
}
