// 묻지 않고 허용할 사이트(2026-11-06) — 4대보험·홈택스·은행의 보안 프로그램이 이 PC 안의 프로그램과 이야기하려 하면
// 브라우저가 "이 기기의 다른 앱 및 서비스에 액세스" 권한 창을 띄운다. 원격 창에는 이 창이 안 보여서 페이지가 멈추므로,
// 원장님이 정한 사이트만 묻지 않고 허용한다(모든 사이트를 허용하지는 않는다).
// 본체 고침 0014 가 chrome.contentSettings 에 localNetworkAccess·localNetwork·loopbackNetwork 를 열어 둔다(옛 본체에는 없음).
// 목록은 storage.local.lnaSites = ['4insure.or.kr', ...] — 사이트 이름(www 뺌). 하위 주소까지 함께 허용한다.
const DEFAULT_SITES = ['4insure.or.kr', 'hometax.go.kr'];
const KINDS = ['localNetworkAccess', 'localNetwork', 'loopbackNetwork'];

export async function localSites() {
  const { lnaSites } = await chrome.storage.local.get('lnaSites');
  return Array.isArray(lnaSites) ? lnaSites : DEFAULT_SITES;
}

/** 이 본체가 사이트별 허용을 할 수 있는지(고침 0014) */
export function localSitesSupported() {
  return KINDS.some((k) => chrome.contentSettings?.[k]);
}

/** 주소나 사이트 이름 → 'example.co.kr' (http(s) 가 아니면 '') */
export function siteOf(text) {
  let host = String(text || '').trim().toLowerCase();
  try { if (/^[a-z]+:\/\//.test(host)) { const u = new URL(host); host = /^https?:$/.test(u.protocol) ? u.hostname : ''; } } catch { host = ''; }
  host = host.replace(/\/.*$/, '').replace(/^www\./, '');
  return /^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(host) ? host : '';
}

/** 저장한 목록을 브라우저에 넣는다(시작할 때·목록을 바꿀 때) */
export async function applyLocalSites() {
  if (!localSitesSupported()) return false;
  const sites = await localSites();
  for (const k of KINDS) {
    const api = chrome.contentSettings[k];
    if (!api) continue;
    await api.clear({ scope: 'regular' }).catch(() => {});
    for (const s of sites) await api.set({ primaryPattern: `*://*.${s}/*`, setting: 'allow', scope: 'regular' }).catch(() => {});
  }
  return true;
}

export async function addLocalSite(text) {
  const site = siteOf(text);
  if (!site) return { error: '사이트 주소를 알아보지 못했어요.' };
  const sites = await localSites();
  if (!sites.includes(site)) await chrome.storage.local.set({ lnaSites: [...sites, site].sort() });
  await applyLocalSites();
  return { site };
}

export async function forgetLocalSite(site) {
  await chrome.storage.local.set({ lnaSites: (await localSites()).filter((s) => s !== site) });
  await applyLocalSites();
}
