// 피그마에서 내보낸 파일을 받았을 때 묻는 창(2026-11-13 원장님 "폴더 선택도 없고 여러 프레임은 묻지 않고 압축파일로 내보내버려 — 사용자가 선택하게").
// 압축이면 [폴더 골라 압축 풀기]·[폴더 골라 저장하기(압축 그대로)]·[그대로 두기], 한 파일이면 [폴더 골라 저장하기]·[그대로 두기].
const q = new URLSearchParams(location.search);
const id = Number(q.get('id'));
const zip = q.get('zip') === '1';
document.getElementById('ask').textContent = zip ? '피그마에서 여러 개를 압축 파일로 받았어요. 어떻게 저장할까요?' : '피그마에서 받은 파일을 어디에 저장할까요?';
document.getElementById('file').textContent = q.get('name') || '';
if (zip) {
  document.getElementById('unzip').classList.remove('hidden');
  const move = document.getElementById('move');
  move.classList.remove('primary');
  move.textContent = '폴더 골라 압축 파일 그대로 저장';
}
const status = document.getElementById('status');
let busy = false;
async function pick(value) {
  if (busy) return;
  busy = true;
  for (const b of document.querySelectorAll('button')) b.disabled = true;
  if (value !== 'keep') status.textContent = '폴더 고르기 창에서 저장할 폴더를 골라 주세요.';
  const r = await chrome.runtime.sendMessage({ type: 'exportAnswer', id, pick: value, never: document.getElementById('never').checked }).catch((err) => ({ error: err.message }));
  if (r?.cancelled) {
    status.textContent = '폴더를 고르지 않았어요. 파일은 다운로드 폴더에 그대로 있습니다.';
    busy = false;
    for (const b of document.querySelectorAll('button')) b.disabled = false;
    return;
  }
  if (r?.error) { status.textContent = `옮기지 못했습니다: ${r.error}`; busy = false; for (const b of document.querySelectorAll('button')) b.disabled = false; return; }
  window.close();
}
for (const v of ['unzip', 'move', 'keep']) document.getElementById(v).addEventListener('click', () => pick(v));
