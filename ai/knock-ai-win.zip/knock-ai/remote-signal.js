// Knock 원격: 두 컴퓨터가 서로를 찾도록 짧은 쪽지를 주고받는 곳(연결 안내).
// - 'supabase': Supabase 실시간 쪽지(Realtime broadcast). 공개 열쇠(anon key)만 쓴다.
// - 'local'   : 같은 브라우저 안 시험용(BroadcastChannel).
// 방 이름은 연결 번호를 그대로 쓰지 않고 SHA-256 으로 바꾼 값을 쓴다(쪽지 서버에도 번호가 드러나지 않게).
import { REMOTE_CONFIG } from './remote-config.js';

export async function roomOf(code) {
  const bytes = new TextEncoder().encode(`knock-remote:${code}`);
  const hash = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(hash)].map((b) => b.toString(16).padStart(2, '0')).join('').slice(0, 40);
}

export function signalReady() {
  return Boolean(REMOTE_CONFIG.supabaseUrl && REMOTE_CONFIG.supabaseKey);
}

// onMessage(msg) 로 받고, send(msg) 로 보낸다. close() 로 나간다. alive() 는 아직 이어져 있는지,
// onClose 는 인터넷이 끊기는 등으로 서버와의 연결이 끊겼을 때 부른다(2026-11-06 "인터넷이 끊긴 뒤 다시 연결이 안 돼").
export async function openSignal(code, onMessage, { local = false, onClose } = {}) {
  const room = await roomOf(code);
  if (local || !signalReady()) {
    if (!local) throw new Error('연결 안내 서버(Supabase)가 아직 설정되지 않았습니다.');
    const bc = new BroadcastChannel(`knock-remote-${room}`);
    bc.onmessage = (e) => onMessage(e.data);
    return { send: (msg) => bc.postMessage(msg), close: () => bc.close(), alive: () => true };
  }
  return supabaseChannel(room, onMessage, onClose);
}

// Supabase Realtime(피닉스 채널) 최소 구현: 들어가기 · 쪽지 보내기 · 받기 · 살아 있음 알리기
function supabaseChannel(room, onMessage, onClose) {
  const { supabaseUrl, supabaseKey } = REMOTE_CONFIG;
  const wsUrl = `${supabaseUrl.replace(/^http/, 'ws')}/realtime/v1/websocket?apikey=${encodeURIComponent(supabaseKey)}&vsn=1.0.0`;
  const topic = `realtime:knock-remote-${room}`;
  let ref = 0;
  let joined = false;
  let dead = false;
  let closedByUs = false;
  const queue = [];
  const ws = new WebSocket(wsUrl);
  const raw = (event, payload, t = topic) => ws.send(JSON.stringify({ topic: t, event, payload, ref: String(++ref) }));
  // 살아 있음 알리기에 서버가 답하는지 본다. 잠자기·인터넷 바뀜 뒤에는 연결이 "열림"으로 남은 채 아무것도 오지 않을 수 있어
  // (2026-11-08 "원격 PC 브라우저를 다시 켜니 원격이 되기 시작") 70초 넘게 답이 없으면 닫고 다시 잇게 한다
  let heard = Date.now();
  const stale = () => Date.now() - heard > 70000;
  const beat = setInterval(() => {
    if (joined && stale()) { try { ws.close(); } catch {} died(); return; }
    if (ws.readyState === 1) raw('heartbeat', {}, 'phoenix');
  }, 25000);
  const died = () => {
    if (dead) return;
    dead = true;
    clearInterval(beat);
    if (joined && !closedByUs) onClose?.();
  };
  ws.addEventListener('close', died);
  return new Promise((resolve, reject) => {
    const fail = setTimeout(() => reject(new Error('연결 안내 서버에 들어가지 못했습니다.')), 10000);
    // 옛 anon 열쇠(JWT)만 access_token 으로도 보낸다. 새 공개용 열쇠(sb_publishable_…)는 주소의 apikey 로 충분하다.
    const join = { config: { broadcast: { self: false, ack: false }, presence: { key: '' }, private: false } };
    if (supabaseKey.startsWith('eyJ')) join.access_token = supabaseKey;
    ws.onopen = () => raw('phx_join', join);
    ws.onerror = () => reject(new Error('연결 안내 서버에 닿지 않습니다.'));
    ws.onmessage = (e) => {
      let m;
      try { m = JSON.parse(e.data); } catch { return; }
      heard = Date.now();
      if (m.topic !== topic) return;
      if (m.event === 'phx_reply' && !joined) {
        if (m.payload?.status !== 'ok') { clearTimeout(fail); reject(new Error('연결 안내 서버가 들어가기를 거절했습니다.')); return; }
        joined = true;
        clearTimeout(fail);
        for (const q of queue.splice(0)) raw('broadcast', { type: 'broadcast', event: 'msg', payload: q });
        resolve({
          send: (msg) => raw('broadcast', { type: 'broadcast', event: 'msg', payload: msg }),
          close: () => { closedByUs = true; dead = true; clearInterval(beat); try { raw('phx_leave', {}); ws.close(); } catch {} },
          alive: () => !dead && ws.readyState === 1 && !stale(),
        });
      } else if (joined && (m.event === 'phx_error' || m.event === 'phx_close')) {
        try { ws.close(); } catch {}
        died();
      } else if (m.event === 'broadcast' && m.payload?.event === 'msg') {
        onMessage(m.payload.payload);
      }
    };
  });
}
