// 영상 소리 녹음(watch_video, 2026-11-24): 탭 소리를 16kHz 모노로 모아 도우미에게 넘긴다(받아쓰기는 도우미가 이 컴퓨터 안에서).
// 잡는 동안 그 탭 소리는 사용자에게 들리지 않는다(탭 소리 잡기의 기본 동작).
let rec = null;
const MAX_SEC = 15 * 60;

// rate: 영상을 몇 배로 빨리 틀었는지(소리 높이 그대로 빨리 튼 것). 48kHz 로 받아 두었다가 끝날 때 그만큼 늦춰 16kHz 로 바꾼다
async function start(streamId, rate = 1) {
  stop();
  const stream = await navigator.mediaDevices.getUserMedia({ audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId } }, video: false });
  const ctx = new AudioContext(rate > 1 ? { sampleRate: 48000 } : { sampleRate: 16000 });
  const src = ctx.createMediaStreamSource(stream);
  const proc = ctx.createScriptProcessor(4096, 1, 1);
  const mute = ctx.createGain();
  mute.gain.value = 0; // 녹음만 하고 소리는 내지 않는다
  const chunks = [];
  let n = 0;
  proc.onaudioprocess = (e) => {
    if (n >= MAX_SEC * ctx.sampleRate) return;
    const d = new Float32Array(e.inputBuffer.getChannelData(0));
    chunks.push(d);
    n += d.length;
  };
  src.connect(proc);
  proc.connect(mute);
  mute.connect(ctx.destination);
  rec = { stream, ctx, chunks, count: () => n, rate, sr: ctx.sampleRate };
}

function stop() {
  if (!rec) return null;
  const r = rec;
  rec = null;
  r.stream.getTracks().forEach((t) => t.stop());
  r.ctx.close().catch(() => {});
  const total = r.count();
  const raw = new Float32Array(total);
  let i = 0;
  for (const c of r.chunks) { raw.set(c, i); i += c.length; }
  // 받은 소리는 (sr / rate) Hz 로 녹음된 원래 소리와 같다 → 16kHz 로 고르게 뽑는다(사이 값은 이어 붙여 계산)
  const step = r.sr / (r.rate || 1) / 16000;
  const n = Math.floor(total / step);
  const pcm = new Int16Array(n);
  for (let k = 0; k < n; k++) {
    const x = k * step;
    const a = Math.floor(x);
    let v;
    if (step > 1.5) { // 줄일 때는 그 구간 평균(높은 잡음이 섞이지 않게)
      const b = Math.min(total, Math.floor(x + step));
      let sum = 0;
      for (let j = a; j < b; j++) sum += raw[j];
      v = sum / Math.max(1, b - a);
    } else v = raw[a] + (raw[Math.min(total - 1, a + 1)] - raw[a]) * (x - a);
    pcm[k] = Math.max(-32768, Math.min(32767, Math.round(v * 32767)));
  }
  const u = new Uint8Array(pcm.buffer);
  let s = '';
  for (let k = 0; k < u.length; k += 0x8000) s += String.fromCharCode(...u.subarray(k, k + 0x8000));
  return { pcm: btoa(s), seconds: n / 16000 };
}

// ---- 영상 파일 바로 읽기(틀지 않음): 파일을 받아 소리는 16kHz 로 풀고, 장면은 숨은 영상에서 시각을 옮겨 가며 찍는다 ----
function toB64(u8) {
  let s = '';
  for (let k = 0; k < u8.length; k += 0x8000) s += String.fromCharCode(...u8.subarray(k, k + 0x8000));
  return btoa(s);
}
async function grab(url, max) {
  if (/^data:/.test(url)) { // 페이지 안에서 받아 넘긴 파일
    const m = url.match(/^data:([^;,]*)(?:;base64)?,(.*)$/s);
    const bin = atob(m[2]);
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return { buf: u.buffer, type: m[1] || 'video/mp4' };
  }
  const res = await fetch(url, { credentials: 'include', signal: AbortSignal.timeout(90000) });
  if (!res.ok) throw new Error(`영상 파일을 받지 못했습니다(${res.status})`);
  const len = Number(res.headers.get('content-length') || 0);
  if (len > max) throw new Error('영상 파일이 너무 큽니다');
  const buf = await res.arrayBuffer();
  if (buf.byteLength > max) throw new Error('영상 파일이 너무 큽니다');
  return { buf, type: res.headers.get('content-type') || 'video/mp4' };
}
async function decodePcm(buf, from, maxSec) {
  const ctx = new OfflineAudioContext(1, 16000, 16000);
  const ab = await ctx.decodeAudioData(buf); // 16kHz 로 바꿔 준다
  const n = ab.numberOfChannels;
  const a = Math.floor(from * 16000);
  const b = Math.min(ab.length, a + maxSec * 16000);
  const pcm = new Int16Array(Math.max(0, b - a));
  const chans = Array.from({ length: n }, (_, c) => ab.getChannelData(c));
  for (let i = a; i < b; i++) {
    let v = 0;
    for (const ch of chans) v += ch[i];
    pcm[i - a] = Math.max(-32768, Math.min(32767, Math.round((v / n) * 32767)));
  }
  return { pcm: toB64(new Uint8Array(pcm.buffer)), seconds: pcm.length / 16000, duration: ab.duration };
}
function lumaOf(canvas) {
  const c = document.createElement('canvas');
  c.width = 32; c.height = 18;
  const g = c.getContext('2d');
  g.drawImage(canvas, 0, 0, 32, 18);
  const d = g.getImageData(0, 0, 32, 18).data;
  const o = new Uint8Array(576);
  for (let k = 0; k < 576; k++) o[k] = d[k * 4] * 0.299 + d[k * 4 + 1] * 0.587 + d[k * 4 + 2] * 0.114;
  return o;
}
async function framesOf(blob, from, maxSec, deadline) {
  const v = document.createElement('video');
  v.muted = true;
  v.preload = 'auto';
  const url = URL.createObjectURL(blob);
  v.src = url;
  const once = (ev, ms) => new Promise((ok, no) => {
    const t = setTimeout(() => no(new Error(`${ev} 시간 초과`)), ms);
    v.addEventListener(ev, () => { clearTimeout(t); ok(); }, { once: true });
    v.addEventListener('error', () => { clearTimeout(t); no(new Error('영상을 풀지 못했습니다')); }, { once: true });
  });
  try {
    await once('loadeddata', 20000);
    const dur = v.duration || 0;
    const end = Math.min(dur, from + maxSec);
    const step = Math.max(2, (end - from) / 60);
    const canvas = document.createElement('canvas');
    const scale = Math.min(1, 640 / Math.max(v.videoWidth, v.videoHeight));
    canvas.width = Math.round(v.videoWidth * scale);
    canvas.height = Math.round(v.videoHeight * scale);
    const g = canvas.getContext('2d');
    const out = [];
    let last = null;
    let lastAt = -1e9;
    for (let t = from + 0.5; t < end && Date.now() < deadline; t += step) {
      v.currentTime = t;
      await once('seeked', 8000);
      g.drawImage(v, 0, 0, canvas.width, canvas.height);
      const h = lumaOf(canvas);
      let diff = 255;
      if (last) { diff = 0; for (let i = 0; i < 576; i++) diff += Math.abs(h[i] - last[i]); diff /= 576; }
      if (diff > 2.5 || t - lastAt >= 15) {
        out.push({ t, data: canvas.toDataURL('image/jpeg', 0.7).split(',')[1] });
        last = h;
        lastAt = t;
      }
    }
    return { frames: out, duration: dur };
  } finally {
    v.removeAttribute('src');
    v.load();
    URL.revokeObjectURL(url);
  }
}
// mp4 안에 소리 칸(hdlr … soun)이 있는지 — 소리 없는 영상과 풀지 못한 소리를 가른다
function hasSound(buf) {
  const u = new Uint8Array(buf);
  for (let i = 0; i + 16 < u.length; i++) {
    if (u[i] === 0x68 && u[i + 1] === 0x64 && u[i + 2] === 0x6c && u[i + 3] === 0x72 && u[i + 12] === 0x73 && u[i + 13] === 0x6f && u[i + 14] === 0x75 && u[i + 15] === 0x6e) return true;
  }
  return false;
}
async function readFile({ url, audioUrl, from = 0, maxSec = 900, shots = true, audio = true }) {
  const MAX = 400 * 1024 * 1024;
  const deadline = Date.now() + 120000;
  const main = await grab(url, MAX);
  const audioBuf = audio && audioUrl ? (await grab(audioUrl, MAX).catch(() => null))?.buf : null;
  const blob = new Blob([main.buf], { type: main.type.startsWith('video') || main.type.startsWith('audio') ? main.type : 'video/mp4' });
  const out = { pcm: '', seconds: 0, frames: [], duration: 0, audioError: '', frameError: '' };
  // 소리 먼저(decodeAudioData 는 버퍼를 넘겨받으므로 사본으로)
  if (audio) try {
    Object.assign(out, await decodePcm((audioBuf || main.buf).slice(0), from, maxSec));
  } catch (err) {
    if (audioBuf) { try { Object.assign(out, await decodePcm(main.buf.slice(0), from, maxSec)); } catch { out.audioError = err.message || String(err); } }
    else out.audioError = err.message || String(err);
    if (out.audioError && !hasSound(audioBuf || main.buf) && /mp4|quicktime/.test(main.type + url)) { out.noAudio = true; out.audioError = ''; }
  }
  if (shots) {
    try {
      const f = await framesOf(blob, from, maxSec, deadline);
      out.frames = f.frames;
      out.duration = out.duration || f.duration;
    } catch (err) { out.frameError = err.message || String(err); }
  }
  return out;
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.target !== 'offscreen' || msg.type !== 'listen') return;
  if (msg.cmd === 'file') {
    readFile(msg).then((r) => reply({ ok: true, ...r }), (err) => reply({ ok: false, error: err.message || String(err) }));
    return true;
  }
  if (msg.cmd === 'start') {
    start(msg.streamId, msg.rate || 1).then(() => reply({ ok: true }), (err) => reply({ ok: false, error: err.message || String(err) }));
    return true;
  }
  if (msg.cmd === 'stop') reply(stop() || { pcm: '', seconds: 0 });
});
