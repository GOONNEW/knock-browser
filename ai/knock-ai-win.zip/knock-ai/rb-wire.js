// 브라우저 연동(2026-11-05) — 두 Knock 사이 통로(WebRTC 데이터 통로)로 주고받는 쪽지. 크롬 한도(256KB)보다 크면 나눠 보낸다.
const PART = 60000;
let seq = 0;

export function sendWire(dc, obj) {
  if (!dc || dc.readyState !== 'open') return false;
  const s = JSON.stringify(obj);
  if (s.length <= PART) { dc.send(s); return true; }
  const id = `${Date.now()}-${++seq}`;
  const n = Math.ceil(s.length / PART);
  for (let i = 0; i < n; i++) dc.send(JSON.stringify({ t: 'part', id, i, n, s: s.slice(i * PART, (i + 1) * PART) }));
  return true;
}

/** onObj(obj) 로 온전한 쪽지만 넘긴다 */
export function wireReader(onObj) {
  const parts = new Map();
  return (data) => {
    let m;
    try { m = JSON.parse(data); } catch { return; }
    if (m?.t !== 'part') return onObj(m);
    if (!parts.has(m.id)) parts.set(m.id, []);
    const p = parts.get(m.id);
    p[m.i] = m.s;
    if (p.filter((x) => x !== undefined).length === m.n) { parts.delete(m.id); try { onObj(JSON.parse(p.join(''))); } catch {} }
    if (parts.size > 20) parts.delete(parts.keys().next().value);
  };
}

// 주소 찾기(STUN) + 중계(TURN, 2026-11-07): 두 PC 가 직접 이어지지 못하는 인터넷(병원·회사 공유기)에서는 Cloudflare 중계로 잇는다.
// 중계 열쇠는 똑소리 서버가 짧게(12시간) 만들어 준다(배경이 받아 둠). 못 받으면 지금처럼 직접 연결만.
export async function iceServers() {
  const base = (await import('./remote-config.js')).REMOTE_CONFIG.iceServers;
  const turn = await Promise.race([
    chrome.runtime.sendMessage({ type: 'remoteTurn' }).catch(() => null),
    new Promise((r) => setTimeout(() => r(null), 5000)),
  ]);
  return Array.isArray(turn) && turn.length ? [...base, ...turn] : base;
}
