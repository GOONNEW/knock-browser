// 예약 작업: 정한 시각(한 번·매일·평일·매주·몇 분마다)에 AI 에게 미리 맡겨 둔 일을 시킨다.
// chrome.storage.local schedules = [{ id, title, prompt, at, repeat, every, files, url, tabId, auto, next, created }]
//   at      처음(또는 한 번) 실행 시각(ms)      repeat  none | daily | weekdays | weekly | every
//   every   repeat=every 일 때 간격(분)          files   보관한 첨부 이름(파일은 도우미가 ~/.knock/schedules/<id> 에 보관)
//   auto    실행 중 확인 카드 없이 진행(결제·삭제는 그래도 묻는다)
// 첨부 파일은 사용자가 예약을 취소할 때까지 보관한다(한 번짜리는 실행이 끝나면 지운다).

export const REPEATS = { none: '한 번', daily: '매일', weekdays: '평일(월~금)', weekly: '매주', every: '몇 분마다' };
export const LATE_MS = 15 * 60 * 1000; // 이보다 늦게 깨어나면(컴퓨터가 꺼져 있었음) 그 회차는 건너뛴다
const DAY = 24 * 60 * 60 * 1000;

// "2026-11-04T08:30" 같은 이 컴퓨터 시각 → ms
export function parseAt(text) {
  const m = String(text || '').trim().match(/^(\d{4})-(\d{1,2})-(\d{1,2})[T ](\d{1,2}):(\d{2})(?::(\d{2}))?$/);
  if (!m) return null;
  const d = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
  return Number.isNaN(d.getTime()) ? null : d.getTime();
}

// from 보다 뒤의 다음 실행 시각(ms). 없으면 null
export function nextRun(s, from = Date.now()) {
  if (s.repeat === 'none' || !s.repeat) return s.at > from ? s.at : null;
  if (s.at > from) return s.at;
  if (s.repeat === 'every') {
    const step = Math.max(5, s.every || 60) * 60 * 1000;
    return s.at + (Math.floor((from - s.at) / step) + 1) * step;
  }
  const base = new Date(s.at);
  const day = new Date(from);
  day.setHours(base.getHours(), base.getMinutes(), base.getSeconds(), 0);
  for (let i = 0; i < 9; i++, day.setTime(day.getTime() + DAY)) {
    // 서머타임이 없는 한국 기준이지만, 시각이 밀리지 않도록 매번 맞춘다
    day.setHours(base.getHours(), base.getMinutes(), base.getSeconds(), 0);
    if (day.getTime() <= from) continue;
    const w = day.getDay();
    if (s.repeat === 'weekdays' && (w === 0 || w === 6)) continue;
    if (s.repeat === 'weekly' && w !== base.getDay()) continue;
    return day.getTime();
  }
  return null;
}

export function fmtTime(ms) {
  return new Date(ms).toLocaleString('ko-KR', { month: 'long', day: 'numeric', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false });
}

export function describeWhen(s) {
  const t = new Date(s.at).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', hour12: false });
  if (s.repeat === 'every') return `${fmtTime(s.at)}부터 ${s.every}분마다`;
  if (s.repeat === 'daily') return `매일 ${t}`;
  if (s.repeat === 'weekdays') return `평일 ${t}`;
  if (s.repeat === 'weekly') return `매주 ${new Date(s.at).toLocaleDateString('ko-KR', { weekday: 'long' })} ${t}`;
  return fmtTime(s.at);
}

export async function loadSchedules() {
  const { schedules } = await chrome.storage.local.get('schedules');
  return schedules || [];
}

export async function saveSchedules(list) {
  await chrome.storage.local.set({ schedules: list });
}
