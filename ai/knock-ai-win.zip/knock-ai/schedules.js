// 예약 작업: 정한 시각(한 번·매일·평일·매주·몇 분마다)에 AI 에게 미리 맡겨 둔 일을 시킨다.
// chrome.storage.local schedules = [{ id, title, prompt, at, repeat, every, files, url, tabId, auto, next, created }]
//   at      처음(또는 한 번) 실행 시각(ms)      repeat  none | daily | weekdays | weekly | every | monthly | rule
//   rule    repeat=rule 일 때 사용자가 말한 규칙 { weekdays:[0~6], days:[1~31, -1=말일], months:[1~12], nth:[1~5, -1=마지막] }
//           (예: 매월 1일 → days [1] · 매주 월·목 → weekdays [1,4] · 매월 첫째 월요일 → weekdays [1], nth [1] · 분기 말일 → months [3,6,9,12], days [-1])
//   times   하루에 여러 번이면 ["09:00","15:00"](없으면 at 의 시각) · catchUp 컴퓨터가 꺼져 놓친 회차를 켜지면 바로 한 번 실행
//   every   repeat=every 일 때 간격(분)          files   보관한 첨부 이름(파일은 도우미가 ~/.knock/schedules/<id> 에 보관)
//   auto    실행 중 확인 카드 없이 진행(결제·삭제는 그래도 묻는다)
// 첨부 파일은 사용자가 예약을 취소할 때까지 보관한다(한 번짜리는 실행이 끝나면 지운다).

export const REPEATS = { none: '한 번', daily: '매일', weekdays: '평일(월~금)', weekly: '매주', every: '몇 분마다', monthly: '매월', rule: '정한 규칙' };
export const LATE_MS = 15 * 60 * 1000; // 이보다 늦게 깨어나면(컴퓨터가 꺼져 있었음) 그 회차는 건너뛴다
const DAY = 24 * 60 * 60 * 1000;

// "2026-11-04T08:30" 같은 이 컴퓨터 시각 → ms
export function parseAt(text) {
  const m = String(text || '').trim().match(/^(\d{4})-(\d{1,2})-(\d{1,2})[T ](\d{1,2}):(\d{2})(?::(\d{2}))?$/);
  if (!m) return null;
  const d = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
  return Number.isNaN(d.getTime()) ? null : d.getTime();
}

// 사용자가 말한 규칙에 그날이 맞는지(2026-11-18 원장님 "사용자가 명령한 스케줄대로")
const lastDay = (d) => new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
function dayMatches(s, d) {
  const base = new Date(s.at);
  const r = s.repeat === 'monthly' ? { days: [base.getDate()] } : (s.rule || {});
  const dd = d.getDate();
  const last = lastDay(d);
  if (r.months?.length && !r.months.includes(d.getMonth() + 1)) return false;
  if (r.days?.length) {
    // 31일처럼 그달에 없는 날은 그달 말일에(매월 31일 → 2월 28일)
    const ok = r.days.some((x) => (x === -1 ? dd === last : x === dd || (x > last && dd === last)));
    if (!ok) return false;
  }
  if (r.weekdays?.length && !r.weekdays.includes(d.getDay())) return false;
  if (r.nth?.length) {
    const n = Math.floor((dd - 1) / 7) + 1;
    const isLast = dd + 7 > last;
    if (!r.nth.some((x) => (x === -1 ? isLast : x === n))) return false;
  }
  return true;
}
function timesOf(s) {
  const base = new Date(s.at);
  const list = (s.times || []).map((t) => /^(\d{1,2}):(\d{2})$/.exec(String(t))).filter(Boolean).map((m) => [+m[1], +m[2]]);
  return (list.length ? list : [[base.getHours(), base.getMinutes()]]).sort((a, b) => a[0] - b[0] || a[1] - b[1]);
}

// from 보다 뒤의 다음 실행 시각(ms). 없으면 null
export function nextRun(s, from = Date.now()) {
  if (s.repeat === 'none' || !s.repeat) return s.at > from ? s.at : null;
  if (s.repeat === 'monthly' || s.repeat === 'rule') {
    // 하루씩 넘기며 규칙에 맞는 날·시각을 찾는다(처음 시각 at 보다 앞은 아님 — 최대 4년 뒤까지)
    const start = Math.max(from, s.at - 1);
    const day = new Date(start);
    day.setHours(0, 0, 0, 0);
    for (let i = 0; i < 1500; i++, day.setDate(day.getDate() + 1)) {
      if (!dayMatches(s, day)) continue;
      for (const [h, m] of timesOf(s)) {
        const t = new Date(day.getFullYear(), day.getMonth(), day.getDate(), h, m, 0).getTime();
        if (t > from && t >= s.at) return t;
      }
    }
    return null;
  }
  if (s.at > from) return s.at;
  if (s.repeat === 'every') {
    const step = Math.max(5, s.every || 60) * 60 * 1000;
    return s.at + (Math.floor((from - s.at) / step) + 1) * step;
  }
  const base = new Date(s.at);
  const day = new Date(from);
  day.setHours(base.getHours(), base.getMinutes(), base.getSeconds(), 0);
  for (let i = 0; i < 9; i++, day.setTime(day.getTime() + DAY)) {
    // 서머타임이 없는 한국 기준이지만, 시각이 밀리지 않도록 매번 맞춘다
    day.setHours(base.getHours(), base.getMinutes(), base.getSeconds(), 0);
    if (day.getTime() <= from) continue;
    const w = day.getDay();
    if (s.repeat === 'weekdays' && (w === 0 || w === 6)) continue;
    if (s.repeat === 'weekly' && w !== base.getDay()) continue;
    return day.getTime();
  }
  return null;
}

export function fmtTime(ms) {
  return new Date(ms).toLocaleString('ko-KR', { month: 'long', day: 'numeric', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false });
}

const WD = ['일', '월', '화', '수', '목', '금', '토'];
const NTH = { 1: '첫째', 2: '둘째', 3: '셋째', 4: '넷째', 5: '다섯째', '-1': '마지막' };
export function describeWhen(s) {
  const t = new Date(s.at).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', hour12: false });
  const tt = (s.times?.length ? s.times.join('·') : t) + (s.catchUp ? '(놓치면 켜질 때)' : '');
  if (s.repeat === 'monthly') return `매월 ${new Date(s.at).getDate()}일 ${tt}`;
  if (s.repeat === 'rule') {
    const r = s.rule || {};
    const months = r.months?.length ? `${r.months.join('·')}월` : '매월';
    const days = r.days?.length ? r.days.map((x) => (x === -1 ? '말일' : `${x}일`)).join('·') : '';
    const wds = r.weekdays?.length ? r.weekdays.map((x) => WD[x]).join('·') : '';
    let what;
    if (r.nth?.length && wds) what = `${months} ${r.nth.map((x) => NTH[x] || `${x}째`).join('·')} ${wds}요일`;
    else if (days) what = `${months} ${days}${wds ? `(${wds}요일만)` : ''}`;
    else if (wds) what = `${r.months?.length ? `${months} ` : '매주 '}${wds}`;
    else what = r.months?.length ? `${months} 매일` : '매일';
    return `${what} ${tt}`;
  }
  if (s.repeat === 'every') return `${fmtTime(s.at)}부터 ${s.every}분마다${s.jitter ? `(회차마다 0~${s.jitter}초 늦게)` : ''}`;
  if (s.repeat === 'daily') return `매일 ${t}`;
  if (s.repeat === 'weekdays') return `평일 ${t}`;
  if (s.repeat === 'weekly') return `매주 ${new Date(s.at).toLocaleDateString('ko-KR', { weekday: 'long' })} ${t}`;
  return fmtTime(s.at);
}

export async function loadSchedules() {
  const { schedules } = await chrome.storage.local.get('schedules');
  return schedules || [];
}

export async function saveSchedules(list) {
  await chrome.storage.local.set({ schedules: list });
}
