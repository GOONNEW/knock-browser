// 계정·프로필 창(2026-11-10 피그마 ④ — 화면 2·5·6). 배경(background.js → profiles.js)에 { type: 'prof', op } 로 묻는다.
import { el, lockIcon, dot, pinBoxes, checkRow, PROFILE_COLORS } from './pin.js';

const box = document.getElementById('box');
const ask = (op, data = {}) => chrome.runtime.sendMessage({ type: 'prof', op, ...data }).catch((e) => ({ error: e.message }));
const [mode, rest] = location.hash.slice(1).split(/[=?](.*)/s);
const q = new URLSearchParams(location.hash.includes('?') ? location.hash.slice(location.hash.indexOf('?') + 1) : '');
const btn = (text, cls, onClick) => { const b = el('button', `btn ${cls || ''}`, text); b.type = 'button'; b.addEventListener('click', onClick); return b; };
const isMac = /Mac/.test(navigator.platform);

// ---------- 새로 만든 프로필이 처음 켜질 때(만든 쪽이 넘긴 로그인을 받는다) ----------
async function setup() {
  document.title = 'Knock Browser 프로필 준비';
  box.replaceChildren(el('h1', '', '프로필을 준비하는 중이에요…'));
  const r = await ask('claimSetup', { nonce: rest || '' });
  if (r?.ok) {
    box.replaceChildren(el('h1', '', `${r.name || '새 프로필'} 프로필이 준비됐어요`), el('p', 'lead', '계정에 로그인된 채로 이 프로필을 쓸 수 있어요.'));
    setTimeout(() => location.replace('newtab.html'), 1200);
  } else {
    box.replaceChildren(el('h1', '', '프로필을 준비하지 못했어요'), el('p', 'lead', '설정 › 장치·프로필에서 로그인해 주세요.'));
  }
}

// ---------- 화면 2: 로그인 다음 "이 PC에서 쓸 프로필을 고르세요" ----------
async function pick() {
  document.title = '이 PC에서 쓸 프로필';
  const st = await ask('state');
  if (!st?.loggedIn) { box.replaceChildren(el('h1', '', '먼저 로그인해 주세요')); return; }
  const chosen = new Map(st.list.map((p) => [p.id, p.use]));
  const localPick = new Map();
  const draw = () => {
    box.replaceChildren();
    box.append(el('h1', '', '이 PC에서 쓸 프로필을 고르세요'),
      el('p', 'lead', `계정에 프로필이 ${st.list.length}개 있습니다. 고른 프로필만 이 PC에서 열 수 있어요. 나중에 설정에서 바꿀 수 있어요.`));
    const list = el('div', 'plist');
    for (const p of st.list) {
      const row = el('label', 'prow');
      const c = el('input');
      c.type = 'checkbox';
      c.checked = Boolean(chosen.get(p.id));
      // 지금 쓰는 프로필은 끌 수 없다(체크된 채로 둔다)
      c.addEventListener('change', () => { if (p.current) c.checked = true; chosen.set(p.id, c.checked); });
      const t = el('span', 'ptext');
      const name = el('b', '', p.name);
      if (p.locked) name.append(lockIcon());
      t.append(name, el('small', '', `${p.locked ? 'PIN 잠금 · 열 때 PIN을 물어요' : '잠금 없음'}${p.current ? ' · 지금 쓰는 중' : ''}`));
      row.append(c, dot(p.color), t);
      list.append(row);
    }
    // 이 PC 에만 있고 계정에 없는 프로필(로그인하지 않은 프로필) — 고르면 계정에 올린다
    for (const l of st.localOnly || []) {
      const row = el('label', 'prow');
      const c = el('input');
      c.type = 'checkbox';
      c.checked = Boolean(localPick.get(l.dir));
      c.addEventListener('change', () => localPick.set(l.dir, c.checked));
      const t = el('span', 'ptext');
      t.append(el('b', '', l.name), el('small', '', '이 PC에만 있는 프로필 · 고르면 계정에 올려요'));
      row.append(c, dot('#6B7280'), t);
      list.append(row);
    }
    box.append(list);
    const add = btn('+ 새 프로필 만들기', 'small', () => { add.replaceWith(newForm()); });
    add.style.alignSelf = 'flex-start';
    const msg = el('p', 'err');
    const go = btn('시작하기', 'primary', async () => {
      go.disabled = true;
      msg.textContent = '';
      for (const l of st.localOnly || []) if (localPick.get(l.dir)) await ask('adoptLocal', { dir: l.dir, name: l.name });
      const r = await ask('pickDone', { use: Object.fromEntries(st.list.filter((p) => !p.current).map((p) => [p.id, Boolean(chosen.get(p.id))])) });
      if (r?.error) { msg.textContent = r.error; go.disabled = false; return; }
      window.close();
    });
    const acts = el('div', 'acts');
    acts.append(go);
    box.append(add, msg, acts);
  };
  // 새 프로필: 이름 · 색(PIN 은 만든 뒤 설정 › 프로필 수정에서)
  const newForm = () => {
    const f = el('div', 'newp');
    const name = el('input');
    Object.assign(name, { type: 'text', maxLength: 20, placeholder: '프로필 이름' });
    let color = PROFILE_COLORS[0];
    const colors = el('div', 'colors');
    for (const c of PROFILE_COLORS) {
      const b = el('button');
      b.type = 'button';
      b.style.background = c;
      b.title = c;
      b.classList.toggle('on', c === color);
      b.addEventListener('click', () => { color = c; for (const x of colors.children) x.classList.toggle('on', x === b); });
      colors.append(b);
    }
    const err = el('p', 'err');
    const make = btn('만들기', 'primary small', async () => {
      if (!name.value.trim()) return name.focus();
      make.disabled = true;
      const r = await ask('create', { name: name.value.trim(), color, use: false });
      if (r?.error) { err.textContent = r.error; make.disabled = false; return; }
      st.list.push({ ...r, use: true, here: false });
      chosen.set(r.id, true);
      draw();
    });
    const acts = el('div', 'acts');
    acts.append(btn('취소', 'small', draw), make);
    f.append(name, colors, err, acts);
    setTimeout(() => name.focus(), 0);
    return f;
  };
  draw();
}

// ---------- 화면 5: 잠긴 프로필 열기(이 프로필 창이 뜰 때) ----------
async function openSelf() {
  const st = await ask('selfState');
  document.title = `${st.name} 프로필 잠김`;
  if (st.mode === 'open') { window.close(); return; }
  const msg = el('p', 'pin-msg');
  const no = checkRow('이 PC에서는 더 묻지 않음', '이 PC에서 이 프로필을 열 때 PIN을 묻지 않아요. 설정에서 되돌릴 수 있어요.');
  const send = async (pin) => {
    pins.disable(true);
    msg.className = 'pin-msg';
    msg.textContent = '확인하는 중…';
    const r = await ask('selfUnlock', { pin, noAsk: no.box.checked });
    if (r?.ok) { window.close(); return; }
    pins.disable(false);
    pins.clear();
    pins.bad(true);
    msg.className = 'pin-msg bad';
    msg.textContent = r?.error || 'PIN이 맞지 않습니다.';
    pins.focus();
  };
  const pins = pinBoxes({ onFull: send });
  box.replaceChildren(el('div', 'big-lock', '🔒'), el('h1', '', `${st.name} 프로필은 잠겨 있습니다`), el('p', 'lead', '이 프로필의 PIN 6자리를 넣어 주세요.'), pins.el, msg, no.el);
  if (isMac && st.touch) {
    const t = btn('👆 지문으로 열기 (맥)', 'touch-btn wide', async () => {
      t.disabled = true;
      const r = await ask('selfTouch', { noAsk: no.box.checked });
      t.disabled = false;
      if (r?.ok) { window.close(); return; }
      msg.className = 'pin-msg bad';
      msg.textContent = r?.error || '지문을 확인하지 못했어요.';
    });
    t.className = 'touch-btn wide';
    box.append(t);
  }
  box.append(forgot(st.pid, () => openSelf()));
  pins.focus();
}

// "PIN을 잊었어요 (계정 비밀번호로 다시 정하기)"
function forgot(pid, done) {
  const l = btn('PIN을 잊었어요 (계정 비밀번호로 다시 정하기)', 'link', () => {
    const f = el('div', 'newp');
    const pw = el('input', 'field');
    Object.assign(pw, { type: 'password', placeholder: '똑소리툴즈 계정 비밀번호', autocomplete: 'off' });
    const np = pinBoxes({ label: '새 PIN 6자리' });
    const err = el('p', 'err');
    const save = btn('새 PIN으로 바꾸기', 'primary small', async () => {
      if (!pw.value || np.value().length !== 6) { err.textContent = '계정 비밀번호와 새 PIN 6자리를 넣어 주세요.'; return; }
      save.disabled = true;
      const r = await ask('reset', { id: pid, password: pw.value, pin: np.value() });
      pw.value = '';
      if (r?.error) { err.textContent = r.error; save.disabled = false; return; }
      err.textContent = '';
      f.replaceWith(el('p', 'muted', '새 PIN으로 바꿨어요. 새 PIN을 넣어 주세요.'));
      done?.();
    });
    const acts = el('div', 'acts');
    acts.append(save);
    f.append(el('b', '', 'PIN 다시 정하기'), pw, el('small', 'muted', '새 PIN 6자리'), np.el, err, acts);
    l.replaceWith(f);
    pw.focus();
  });
  return l;
}

// ---------- 이 PC 에서 쓰지 않는 프로필 ----------
async function unused() {
  const st = await ask('selfState');
  document.title = '이 PC에서 쓰지 않는 프로필';
  if (st.mode !== 'unused') { window.close(); return; }
  const err = el('p', 'err');
  const acts = el('div', 'acts');
  acts.append(btn('이 PC에서 쓰기', '', async () => { const r = await ask('useHere'); if (r?.error) err.textContent = r.error; }), btn('닫기', 'primary', () => ask('closeProfile')));
  box.replaceChildren(el('h1', '', `${st.name} 프로필은 이 PC에서 쓰지 않습니다`), el('p', 'lead', '설정 › 장치·프로필에서 이 PC에서 쓸 프로필을 고를 수 있어요.'), err, acts);
}

// ---------- 화면 6: 다른 프로필 내용 가져오기 ----------
async function peer() {
  const id = q.get('id'), pid = q.get('pid'), name = q.get('name') || '잠긴', color = q.get('color') || '';
  document.title = `${name} 프로필의 내용을 쓸까요?`;
  let keep = 'once';
  const msg = el('p', 'pin-msg');
  const send = async (pin, viaTouch = false) => {
    pins.disable(true);
    msg.className = 'pin-msg';
    msg.textContent = '확인하는 중…';
    const r = viaTouch ? await ask('peerTouch', { id, pid, name, keep }) : await ask('peerAnswer', { id, pid, pin, keep });
    if (r?.ok) { msg.textContent = '열었어요'; return; } // 배경이 이 창을 닫는다
    pins.disable(false);
    pins.clear();
    if (!viaTouch) pins.bad(true);
    msg.className = 'pin-msg bad';
    msg.textContent = r?.error || 'PIN이 맞지 않습니다.';
    pins.focus();
  };
  const pins = pinBoxes({});
  const from = el('div', 'from');
  const who = el('div', 'who');
  who.append(dot(q.get('mecolor')), el('b', '', q.get('me') || '이 프로필'), el('small', '', '창에서'), dot(color), el('b', '', name), el('small', '', '의 내용을 가져와요'));
  from.append(who);
  if (q.get('what')) from.append(el('span', '', q.get('what')));
  const line = el('div', 'pin-line');
  line.append(pins.el);
  const st = await ask('state');
  if (isMac && st?.touch) {
    const t = btn('👆 지문', 'touch-btn', () => send('', true));
    t.className = 'touch-btn';
    line.append(el('span', 'muted', '또는'), t);
  }
  const choices = el('div', '');
  choices.style.cssText = 'display:flex;flex-direction:column;gap:10px';
  const opts = [
    ['once', '이번만', '이 한 번만 쓰고 바로 다시 잠가요.'],
    ['session', '브라우저를 닫을 때까지', '창을 닫거나 10분 동안 쓰지 않으면 다시 잠깁니다.'],
    ['pc', '이 PC에서는 더 묻지 않음', `이 PC에서 ${q.get('me') || '이 프로필'} → ${name}은 다시 묻지 않아요. 다른 PC에서는 계속 묻습니다.`],
  ];
  for (const [v, t, s] of opts) {
    if (v === 'pc' && !q.get('asker')) continue; // 로그인하지 않은 프로필은 "이 PC" 허락을 둘 수 없다
    const c = el('label', `choice${v === keep ? ' on' : ''}`);
    const r = el('input');
    Object.assign(r, { type: 'radio', name: 'keep', value: v, checked: v === keep });
    r.addEventListener('change', () => { keep = v; for (const x of choices.children) x.classList.toggle('on', x === c); });
    const tx = el('span', '');
    tx.append(el('b', '', t), el('small', '', s));
    c.append(r, tx);
    choices.append(c);
  }
  const acts = el('div', 'acts');
  acts.append(btn('쓰지 않기', '', () => { ask('peerCancel', { id }); window.close(); }), btn('열기', 'primary', () => {
    if (pins.value().length !== 6) { pins.bad(true); msg.className = 'pin-msg bad'; msg.textContent = 'PIN 6자리를 넣어 주세요.'; return pins.focus(); }
    send(pins.value());
  }));
  box.replaceChildren(el('h1', '', `${name} 프로필의 내용을 쓸까요?`), el('p', 'lead', `${q.get('why') || '다른 프로필이 이 내용을 쓰려고 합니다.'} 이 프로필은 잠겨 있어 PIN이 필요합니다.`), from, line, msg, el('b', '', '얼마 동안 열어 둘까요?'), choices, acts);
  pins.focus();
}

({ setup, pick, open: openSelf, unused, peer }[mode] || pick)();
