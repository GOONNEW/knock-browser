// 다른 컴퓨터 잇기(2026-11-04 원장님 — "맥에서 일하다가 윈도우에서만 되는 홈택스·은행을 PC 에 시키기").
// 화면에 안 보이는 문서(offscreen)에서 돈다 — 서비스 워커는 WebRTC 를 못 쓰고 수시로 꺼지기 때문.
//
// 처음 한 번 잇기: 시키는 컴퓨터(맥)가 9자리 번호를 보이고, 쓰일 컴퓨터(PC)가 그 번호를 넣는다.
//   두 컴퓨터는 번호로 정한 방에서 서로의 공개 열쇠(ECDH)를 주고받아 둘만 아는 비밀을 만든다. 번호는 그때 한 번만 쓴다.
// 그 뒤 연결: 비밀로 정한 방에서, 비밀로 서명한 쪽지만 받는다(남이 끼어든 쪽지·10분 지난 쪽지는 버림).
//   쓰일 쪽이 허락하면(배경이 정함: 항상 허용·이번만 허용·취소) WebRTC 로 직접 잇고(암호화), 요청·답은 그 통로로만 오간다.
//   페이지 내용은 연결 안내 서버(remote-signal.js)를 지나지 않는다.
// 쓰일 쪽은 10분 동안 요청이 없으면 끊는다("이번만 허용"은 그 연결 동안만).
import { openSignal, roomOf } from './remote-signal.js';
import { REMOTE_CONFIG } from './remote-config.js';

const IDLE_MS = 10 * 60 * 1000;
// 최근 단계 기록(개발자 도구에서 __linkLog 로 본다 — 값·비밀은 적지 않는다)
const trail = [];
globalThis.__linkLog = trail;
const dbg = (...a) => { trail.push(`${new Date().toISOString().slice(11, 19)} ${a.join(' ')}`); if (trail.length > 200) trail.shift(); };
const PART = 60000; // 통로 한 번에 보내는 글 길이(크롬 한도 256KB 보다 작게)
const enc = new TextEncoder();
const b64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

function toBackground(msg) {
  return chrome.runtime.sendMessage({ target: 'background', ...msg });
}

// ---------- 열쇠 ----------
async function newKeyPair() {
  const kp = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
  return { kp, pub: b64(await crypto.subtle.exportKey('raw', kp.publicKey)) };
}
async function sharedSecret(kp, otherPub, code) {
  const other = await crypto.subtle.importKey('raw', unb64(otherPub), { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const bits = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: other }, kp.privateKey, 256));
  const mixed = new Uint8Array([...bits, ...enc.encode(`knock-link:${code}`)]);
  return b64(await crypto.subtle.digest('SHA-256', mixed));
}
// 서명할 글: 안내 서버가 쪽지 안 항목 순서를 이름순으로 바꿔 돌려주므로, 양쪽 다 이름순으로 펴서 서명한다
function stable(v) {
  if (Array.isArray(v)) return `[${v.map(stable).join(',')}]`;
  if (v && typeof v === 'object') return `{${Object.keys(v).filter((k) => v[k] !== undefined).sort().map((k) => `${JSON.stringify(k)}:${stable(v[k])}`).join(',')}}`;
  return JSON.stringify(v ?? null);
}
const hmacKeys = new Map();
async function hmacKey(secret) {
  if (!hmacKeys.has(secret)) hmacKeys.set(secret, crypto.subtle.importKey('raw', unb64(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']));
  return hmacKeys.get(secret);
}
async function sign(secret, t, from, body) {
  const ts = Date.now();
  const mac = b64(await crypto.subtle.sign('HMAC', await hmacKey(secret), enc.encode(stable([t, from, ts, body]))));
  return { t, from, ts, body, mac };
}
async function verified(secret, m) {
  if (!m || typeof m.mac !== 'string' || Math.abs(Date.now() - m.ts) > IDLE_MS) return false;
  try {
    return await crypto.subtle.verify('HMAC', await hmacKey(secret), unb64(m.mac), enc.encode(stable([m.t, m.from, m.ts, m.body])));
  } catch {
    return false;
  }
}
const linkRoom = (secret) => roomOf(`link:${secret}`);

// ---------- 처음 한 번 잇기 ----------
const pairing = new Map(); // code → signal(번호를 보인 쪽이 기다리는 중)

// 시키는 쪽(맥): 번호 방에서 기다리다 쓰일 쪽이 들어오면 비밀을 만들고 배경에 알린다
async function pairShow(code, me) {
  pairing.get(code)?.close();
  const { kp, pub } = await newKeyPair();
  const signal = await openSignal(`pair:${code}`, async (m) => {
    if (m?.t !== 'pairHello' || !m.pub || !m.id) return;
    signal.send({ t: 'pairWelcome', id: me.id, name: me.name, pub });
    const secret = await sharedSecret(kp, m.pub, code);
    pairing.delete(code);
    setTimeout(() => signal.close(), 2000);
    toBackground({ type: 'linkPaired', link: { peerId: m.id, name: String(m.name || '다른 컴퓨터').slice(0, 30), role: 'controller', secret } });
  });
  pairing.set(code, signal);
  setTimeout(() => { if (pairing.get(code) === signal) { pairing.delete(code); signal.close(); } }, IDLE_MS);
  return { ok: true };
}

// 쓰일 쪽(PC): 번호 방에 들어가 인사하고, 답이 오면 비밀을 만든다
async function pairJoin(code, me) {
  const { kp, pub } = await newKeyPair();
  let signal;
  const got = new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('번호를 만든 컴퓨터를 찾지 못했습니다. 번호가 맞는지, 그 컴퓨터의 Knock 이 켜져 있는지 확인해 주세요(번호는 10분 동안만 씁니다).')), 15000);
    openSignal(`pair:${code}`, async (m) => {
      if (m?.t !== 'pairWelcome' || !m.pub || !m.id) return;
      clearTimeout(timer);
      resolve({ peerId: m.id, name: String(m.name || '다른 컴퓨터').slice(0, 30), secret: await sharedSecret(kp, m.pub, code) });
    }).then((s) => {
      signal = s;
      s.send({ t: 'pairHello', id: me.id, name: me.name, pub });
    }, reject);
  });
  try {
    return { ok: true, link: { ...(await got), role: 'controlled' } };
  } finally {
    setTimeout(() => signal?.close(), 1000);
  }
}

// ---------- 연결 ----------
// links: id → { link, signal, pc, dc, open, waiting(Map), parts(Map), idle, connecting }
const conns = new Map();
let me = { id: '', name: '' };
let seq = 1;

function sendOn(c, obj) {
  const s = JSON.stringify(obj);
  if (s.length <= PART) return c.dc.send(s);
  const mid = `${me.id}-${seq++}`;
  const n = Math.ceil(s.length / PART);
  for (let i = 0; i < n; i++) c.dc.send(JSON.stringify({ k: 'part', mid, i, n, s: s.slice(i * PART, (i + 1) * PART) }));
}
async function sendSafe(c, obj) {
  // 받는 쪽이 못 따라오면 잠깐 기다린다(큰 파일)
  while (c.dc.bufferedAmount > 4 * 1024 * 1024) await new Promise((r) => setTimeout(r, 50));
  sendOn(c, obj);
}

function onData(c, raw) {
  let m;
  try { m = JSON.parse(raw); } catch { return; }
  if (m.k === 'part') {
    const buf = c.parts.get(m.mid) || [];
    buf[m.i] = m.s;
    c.parts.set(m.mid, buf);
    if (buf.filter((x) => x !== undefined).length < m.n) return;
    c.parts.delete(m.mid);
    return onData(c, buf.join(''));
  }
  touch(c);
  if (m.k === 'res') {
    c.waiting.get(m.id)?.(m);
    c.waiting.delete(m.id);
  } else if (m.k === 'req' && c.link.role === 'controlled') {
    toBackground({ type: 'linkReq', linkId: c.link.id, op: m.op, args: m.args || {} })
      .then((result) => sendSafe(c, { k: 'res', id: m.id, result }))
      .catch((err) => sendSafe(c, { k: 'res', id: m.id, error: err?.message || '답하지 못했습니다' }));
  } else if (m.k === 'bye') {
    close(c.link.id, m.reason || '');
  }
}

function touch(c) {
  clearTimeout(c.idle);
  c.idle = setTimeout(() => close(c.link.id, '10분 동안 쓰지 않아 연결을 끊었습니다.'), IDLE_MS);
}

function close(linkId, reason) {
  const c = conns.get(linkId);
  if (!c) return;
  clearTimeout(c.idle);
  try { if (c.dc?.readyState === 'open') c.dc.send(JSON.stringify({ k: 'bye', reason })); } catch {}
  try { c.pc?.close(); } catch {}
  for (const done of c.waiting.values()) done({ error: reason || '연결이 끊겼습니다.' });
  c.waiting.clear();
  const wasOpen = c.open;
  c.pc = null;
  c.dc = null;
  c.open = false;
  c.connecting = null;
  if (c.link.role === 'controller') { c.signal?.close(); conns.delete(linkId); }
  if (wasOpen) toBackground({ type: 'linkClosed', linkId, reason }).catch(() => {});
}

function newPeer(c) {
  const pc = new RTCPeerConnection({ iceServers: REMOTE_CONFIG.iceServers });
  pc.onicecandidate = async (e) => {
    if (e.candidate) c.signal?.send(await sign(c.link.secret, 'ice', me.id, e.candidate.toJSON()));
  };
  pc.onconnectionstatechange = () => {
    if (['failed', 'closed', 'disconnected'].includes(pc.connectionState) && c.pc === pc) close(c.link.id, '연결이 끊겼습니다.');
  };
  return pc;
}

function useChannel(c, dc, resolve) {
  c.dc = dc;
  dc.onopen = () => {
    dbg('open');
    c.open = true;
    touch(c);
    resolve?.({ ok: true });
    if (c.link.role === 'controlled') toBackground({ type: 'linkOpen', linkId: c.link.id }).catch(() => {});
  };
  dc.onmessage = (e) => onData(c, e.data);
  dc.onclose = () => { if (c.dc === dc) close(c.link.id, ''); };
}

// 받은 쪽지(서명 확인 뒤). 시키는 쪽·쓰일 쪽이 같은 방을 쓴다.
async function onSignal(c, m) {
  if (!m || m.from === me.id) return;
  const ok = await verified(c.link.secret, m);
  dbg('signal', c.link.role, m.t, ok ? 'ok' : 'bad');
  if (!ok) return;
  const { link } = c;
  if (link.role === 'controlled') {
    if (m.t === 'hello') {
      if (c.asking) return; // 시키는 쪽은 몇 번 인사한다 — 허락 창은 한 번만
      // 허락은 배경이 정한다(항상 허용이면 바로, 아니면 이 컴퓨터에 묻는다)
      c.asking = true;
      const { ok, reason } = await toBackground({ type: 'linkAsk', linkId: link.id }).catch((err) => { dbg('ask fail', err?.message); return { ok: false }; });
      dbg('ask', ok);
      setTimeout(() => { c.asking = false; }, 5000);
      if (!ok) return c.signal.send(await sign(link.secret, 'deny', me.id, { reason: reason || '이 컴퓨터에서 허락하지 않았습니다.' }));
      try { c.pc?.close(); } catch {}
      c.pc = newPeer(c);
      c.pc.ondatachannel = (e) => useChannel(c, e.channel);
      c.signal.send(await sign(link.secret, 'accept', me.id, { name: me.name }));
    } else if (m.t === 'offer' && c.pc) {
      await c.pc.setRemoteDescription(m.body);
      await c.pc.setLocalDescription(await c.pc.createAnswer());
      c.signal.send(await sign(link.secret, 'answer', me.id, c.pc.localDescription.toJSON()));
    } else if (m.t === 'ice' && c.pc) {
      await c.pc.addIceCandidate(m.body).catch(() => {});
    }
  } else {
    c.onSignal?.(m);
    if (m.t === 'ice' && c.pc) await c.pc.addIceCandidate(m.body).catch(() => {});
  }
}

// 쓰일 쪽: 이은 컴퓨터마다 방에서 기다린다
async function listen(link) {
  const old = conns.get(link.id);
  if (old && old.link.secret === link.secret) { old.link = link; return; }
  if (old) close(link.id, '');
  old?.signal?.close();
  const c = { link, waiting: new Map(), parts: new Map() };
  conns.set(link.id, c);
  c.signal = await openSignal(await linkRoom(link.secret), (m) => onSignal(c, m)).catch((err) => { dbg('listen fail', err?.message); return null; });
  dbg('listen', link.name, c.signal ? 'ok' : 'no');
  if (!c.signal) { conns.delete(link.id); setTimeout(() => listen(link), 30000); } // 안내 서버에 못 닿으면 30초 뒤 다시
}

// 시키는 쪽: 필요할 때 잇는다(허락을 기다리는 동안 최대 3분)
function connect(link) {
  const have = conns.get(link.id);
  if (have?.open) return Promise.resolve({ ok: true });
  if (have?.connecting) return have.connecting;
  const c = have || { link, waiting: new Map(), parts: new Map() };
  conns.set(link.id, c);
  c.connecting = (async () => {
    c.signal ||= await openSignal(await linkRoom(link.secret), (m) => onSignal(c, m));
    return new Promise((resolve) => {
      const timer = setTimeout(() => { c.onSignal = null; c.connecting = null; resolve({ ok: false, error: `"${link.name}"이(가) 답하지 않습니다. 그 컴퓨터가 켜져 있고 Knock 이 열려 있는지, 허락 창이 떠 있는지 확인해 주세요.` }); }, 3 * 60 * 1000);
      const done = (r) => { clearTimeout(timer); c.onSignal = null; c.connecting = null; resolve(r); };
      c.onSignal = async (m) => {
        if (m.t === 'deny') return done({ ok: false, error: `"${link.name}"에서 허락하지 않았습니다. ${m.body?.reason || ''}`.trim() });
        if (m.t === 'accept') {
          try { c.pc?.close(); } catch {}
          c.pc = newPeer(c);
          useChannel(c, c.pc.createDataChannel('rpc', { ordered: true }), done);
          await c.pc.setLocalDescription(await c.pc.createOffer());
          c.signal.send(await sign(link.secret, 'offer', me.id, c.pc.localDescription.toJSON()));
        } else if (m.t === 'answer' && c.pc) {
          await c.pc.setRemoteDescription(m.body);
        }
      };
      // 쓰일 쪽이 방에 있는지 몰라 몇 번 인사한다(허락 창이 뜬 뒤에는 기다린다)
      const hello = async () => { dbg('hello'); c.signal.send(await sign(link.secret, 'hello', me.id, { name: me.name })); };
      hello();
      const again = setInterval(() => (c.onSignal && !c.pc ? hello() : clearInterval(again)), 4000);
      setTimeout(() => clearInterval(again), 20000);
    });
  })();
  return c.connecting;
}

async function request(link, op, args, timeoutMs = 7 * 60 * 1000) {
  const r = await connect(link);
  if (!r.ok) return { error: r.error };
  const c = conns.get(link.id);
  const id = seq++;
  return new Promise((resolve) => {
    const timer = setTimeout(() => { c.waiting.delete(id); resolve({ error: `"${link.name}"이(가) 제때 답하지 않았습니다.` }); }, timeoutMs);
    c.waiting.set(id, (m) => { clearTimeout(timer); resolve(m.error ? { error: m.error } : { result: m.result }); });
    sendSafe(c, { k: 'req', id, op, args });
  });
}

// ---------- 배경과 주고받기 ----------
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.target !== 'offscreen' || msg.type !== 'link') return;
  (async () => {
    if (msg.me) me = msg.me;
    switch (msg.cmd) {
      case 'sync': {
        const keep = new Set(msg.links.map((l) => l.id));
        for (const id of [...conns.keys()]) if (!keep.has(id)) { close(id, '이은 것을 지웠습니다.'); conns.get(id)?.signal?.close(); conns.delete(id); }
        for (const l of msg.links) if (l.role === 'controlled') await listen(l);
        return { ok: true };
      }
      case 'pairShow': return pairShow(msg.code, me);
      case 'pairJoin': return pairJoin(msg.code, me);
      case 'request': return request(msg.link, msg.op, msg.args, msg.timeoutMs);
      case 'close': close(msg.linkId, msg.reason || '연결을 끊었습니다.'); return { ok: true };
      case 'state': return { open: [...conns.values()].filter((c) => c.open).map((c) => c.link.id) };
      default: return { error: '모르는 명령' };
    }
  })().then(reply, (err) => reply({ error: err?.message || String(err) }));
  return true;
});
