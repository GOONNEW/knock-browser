// 똑소리HR·TR 연결(2026-11-03 원장님 지시 — 똑소리 브라우저 에이전트가 로그인한 사람 권한 안의 일을 빠르게).
// 설계: ~/dev/knocktools/knock-hr/docs/똑소리-브라우저-연동-설계.md
//
// 똑소리 일은 화면을 읽고 누르지 않는다. 똑소리HR 탭 **안에서** HR 서버의 에이전트 창구를 부른다.
// - 그 탭의 로그인 쿠키·출처 검사를 그대로 받는다(서버에 예외를 열지 않는다). 권한도 서버가 화면과 똑같이 거른다.
// - 확장 백그라운드에서 바로 부르면 출처가 chrome-extension:// 이라 HR 이 막는다(다른 사이트 요청 차단 — 일부러 그렇게 둔 것).
// 1단계는 HR 조회만(서버가 조회 도구만 준다). TR·등록은 다음 단계.
// 민감한 값(계좌·주민번호·연락처)은 가림표로만 AI 에게 간다 — secrets.js.
import { keepSecrets } from './secrets.js';

// 이 Knock 이 할 줄 아는 것 — 서버는 이것을 보고 도구를 준다(secrets: 가림표를 사용자 화면에서 바꿔 끼움,
// fill: 사용자에게 물은 뒤 다른 사이트·앱 칸에 실제 값을 넣음, mail: 급여 서류 메일 제안을 확인받고 급여관리로 넘김,
// color: 일정표 색 제안을 확인받고 그 똑소리HR 탭에서 화면과 같은 창구로 저장,
// apply: 등록·취소·교부 등 쓰기 도구의 미리보기를 사용자에게 카드로 묻고 confirm 으로 저장(2026-11-13 원장님 "권한 범위 내에서 모두 실행")).
const CAPS = ['secrets', 'fill', 'mail', 'color', 'apply'];

// 운영 주소가 먼저. 개발판(policy.build=dev)에서는 이 맥의 개발 서버도 쓴다.
const SERVICES = {
  hr: { name: '똑소리HR', origins: ['https://hr.knocktools.com'], devOrigins: ['http://localhost:3100'] },
};

function originsOf(service, policy) {
  const s = SERVICES[service];
  if (!s) throw new Error(`모르는 똑소리 서비스: ${service}`);
  return policy?.build === 'dev' ? [...s.origins, ...s.devOrigins] : s.origins;
}

function originOfUrl(url) {
  try { return new URL(url).origin; } catch { return ''; }
}

/** 이미 열려 있는 똑소리 탭(사용자가 보고 있는 것 먼저). 없으면 null. */
async function openTabOf(service, policy) {
  const origins = originsOf(service, policy);
  const tabs = (await chrome.tabs.query({})).filter((t) => origins.includes(originOfUrl(t.url || '')));
  if (!tabs.length) return null;
  return tabs.find((t) => t.active) || tabs[0];
}

/** 이 서비스를 부를 주소 — 열린 탭이 있으면 그 주소(개발 서버로 연 것도), 없으면 운영 주소. sourceOf(사이트 허용) 에 쓴다. */
export async function toksoriOrigin(service, policy) {
  const tab = await openTabOf(service, policy);
  return tab ? originOfUrl(tab.url) : originsOf(service, policy)[0];
}

/**
 * 똑소리 탭 안에서 창구를 부른다. 탭이 없으면 뒤에 하나 열고(onOpened 로 알려 작업용 탭 정리에 넣게 한다) 그 안에서 부른다.
 * 돌려주는 것: { status, data } — data 는 JSON(못 읽으면 { error }).
 */
async function callInTab(service, policy, path, body, onOpened) {
  let tab = await openTabOf(service, policy);
  if (!tab) {
    tab = await chrome.tabs.create({ url: `${originsOf(service, policy)[0]}/`, active: false });
    onOpened?.(tab.id);
    // 페이지가 다 뜰 때까지 기다린다(출처가 정해져야 그 탭의 쿠키로 부를 수 있다)
    for (let i = 0; i < 75; i++) {
      const t = await chrome.tabs.get(tab.id).catch(() => null);
      if (!t) throw new Error(`${SERVICES[service].name} 탭이 닫혔습니다.`);
      if (t.status === 'complete' && originOfUrl(t.url || '')) break;
      await new Promise((r) => setTimeout(r, 200));
    }
  }
  const [res] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: 'MAIN',
    args: [path, body === undefined ? null : JSON.stringify(body)],
    func: async (p, b) => {
      try {
        const r = await fetch(p, b === null
          ? { credentials: 'same-origin', cache: 'no-store' }
          : { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' }, body: b });
        return { status: r.status, text: await r.text() };
      } catch (e) {
        return { status: 0, text: String(e && e.message || e) };
      }
    },
  });
  const out = res?.result || { status: 0, text: '응답 없음' };
  let data;
  try { data = JSON.parse(out.text); } catch { data = { error: out.text.slice(0, 200) }; }
  return { status: out.status, data, origin: originOfUrl(tab.url || ''), tabId: tab.id };
}

function failText(service, status, data) {
  const name = SERVICES[service].name;
  if (status === 401 || (status === 403 && /권한이 없습니다/.test(data?.error || ''))) {
    return `${name}에 로그인돼 있지 않거나, 이 계정에 똑소리 에이전트를 쓸 권한이 없습니다. 사용자에게 ${name}에 로그인해 달라고 하세요(로그인은 사람이 직접 합니다). 권한이 없으면 원장님께 멤버 관리 → [권한 설정]에서 요청하라고 안내하세요.`;
  }
  if (status === 423) return `${name}이 잠겨 있습니다(서비스 잠금·미사용 자동잠금). 사용자에게 ${name} 화면에서 잠금을 풀어 달라고 하세요.`;
  // 창구가 없는 판(배포 전)이면 HR 의 오류 페이지(HTML)가 온다 — 그 글을 AI 에게 그대로 넘기지 않는다.
  // 그때는 예전처럼 화면을 읽어 하게 한다(연결 전보다 못해지면 안 된다).
  if (status === 404) return `${name}이 아직 브라우저 연결을 지원하지 않는 판입니다. 이번에는 ${name} 탭을 get_page 로 읽어 처리하세요(누르기·입력은 평소처럼 확인을 거칩니다).`;
  if (status === 0) return `${name}에 연결하지 못했습니다: ${data?.error || ''}`;
  return (data?.error && !/^\s*</.test(data.error) ? data.error : '') || `${name} 응답 오류 ${status}`;
}

// 꾸러미는 내용이 같으면 다시 받을 까닭이 없다 — 서버가 매번 같은 것을 주더라도 AI 에게 보낼 글은 그대로다.
const kitCache = new Map(); // `${service}|${origin}` → kit

/** toksori_kit: 쓸 수 있는 도구와 쓰는 법을 글로. */
export async function toksoriKit(service, policy, onOpened) {
  const { status, data, origin } = await callInTab(service, policy, `/api/agent/kit?caps=${CAPS.join(',')}`, undefined, onOpened);
  if (status !== 200 || !Array.isArray(data?.tools)) throw new Error(failText(service, status, data));
  kitCache.set(`${service}|${origin}`, data);
  const tools = data.tools.map((t) => `### ${t.name}\n${t.description}\n입력: ${JSON.stringify(t.input_schema?.properties || {})}`).join('\n\n');
  return [
    `[${SERVICES[service].name} 꾸러미 ${data.version} — ${origin}]`,
    data.guide,
    '',
    `## 쓸 수 있는 도구(이 계정 권한 기준, ${data.tools.length}개)`,
    tools,
    '',
    '## 화면 사용법(사용자가 직접 할 때 안내용)',
    data.howTo,
  ].join('\n');
}

/** toksori_call: 도구 하나. 결과는 서버가 준 글(JSON) 그대로 + 열어 볼 주소.
 *  confirm(text) → true/false: 서버가 제안(급여 서류 메일)을 주면 사용자에게 묻는다(늘 묻는다 — "항상 허용" 없음). */
export async function toksoriCall(service, policy, tool, input, onOpened, confirm) {
  const { status, data, origin, tabId } = await callInTab(service, policy, '/api/agent/call', { tool, input: input || {}, caps: CAPS }, onOpened);
  if (status !== 200) throw new Error(failText(service, status, data));
  // 쓰기 미리보기(확인 표): 사용자에게 카드로 묻고, [저장]이면 서명된 그 내용 그대로 저장한다 — 늘 묻는다("항상 허용" 없음)
  if (typeof data.confirm === 'string' && data.confirm) return saveAfterAsk(service, policy, tool, input, data, onOpened, confirm);
  if (data.proposal?.kind === 'payroll_mail') return payrollMail(data, tabId, confirm);
  if (data.proposal?.kind === 'badge_color' || data.proposal?.kind === 'day_color_batch') return scheduleColor(data, tabId, confirm);
  // 열어 볼 주소는 서버가 화면 링크와 같은 함수로 만들어 준다(/로 시작하는 이 서비스 안 주소만 받는다)
  const open = typeof data.open?.href === 'string' && data.open.href.startsWith('/') && !data.open.href.startsWith('//') ? `\n(${SERVICES[service].name}에서 열어 보기: ${origin}${data.open.href})` : '';
  // 실제 값(secrets)은 여기서 떼어 맡긴다 — AI 에게 가는 글에는 가림표만 남는다.
  const content = await keepSecrets(data.content || '(결과 없음)', data.secrets);
  return `${content}${open}`;
}

async function saveAfterAsk(service, policy, tool, input, data, onOpened, confirm) {
  const name = SERVICES[service].name;
  if (!confirm) return `${data.content}\n\n원격 연결로는 ${name}에 저장하지 않습니다. 저장은 그 PC 에서 직접 하라고 사용자에게 알리세요.`;
  const ok = await confirm(`${name}에 저장할까요?\n${data.content}`.trim(), 'save');
  if (!ok) return '사용자가 저장하지 않기로 했습니다. 저장하지 않았습니다. 다시 시도하지 마세요.';
  const r = await callInTab(service, policy, '/api/agent/call', { tool, input: { ...(input || {}), confirm: data.confirm }, caps: CAPS }, onOpened);
  if (r.status !== 200) throw new Error(failText(service, r.status, r.data));
  const open = typeof r.data.open?.href === 'string' && r.data.open.href.startsWith('/') && !r.data.open.href.startsWith('//') ? `\n(${name}에서 열어 보기: ${r.origin}${r.data.open.href})` : '';
  // 저장했으면 열려 있는 똑소리HR 화면(근태표·급여)이 새로고침 없이 따라오게 화면과 같은 알림을 보낸다
  if (r.data.saved && r.tabId != null) {
    chrome.scripting.executeScript({ target: { tabId: r.tabId }, world: 'MAIN', func: () => {
      for (const n of ['knockhr:attendance-changed', 'knockhr:payroll-changed', 'knockhr:documents-changed', 'knockhr:members-changed']) window.dispatchEvent(new CustomEvent(n));
    } }).catch(() => {});
  }
  return `${r.data.content || '(결과 없음)'}${open}`;
}

// 급여 서류 메일 — 화면 똑소리 창의 [확인 후 보내기]와 같은 길: 똑소리HR 탭에 일감(knockhr:payroll-mail)을 남기고
// 급여관리를 연다. 급여관리 화면이 그 달 파일을 내려받기와 같은 코드로 만들어 주소록의 받는 곳으로 보낸다(knock-hr payrollMailJob).
// 받는 곳은 서버가 주소록에서 찾은 것만 온다 — AI 가 주소를 지어낼 수 없다.
async function payrollMail(data, tabId, confirm) {
  const job = data.proposal.job;
  const lines = Array.isArray(data.proposal.lines) ? data.proposal.lines.join('\n') : '';
  const ok = confirm ? await confirm(`${data.content}\n${lines}`.trim()) : false;
  if (!ok) return '사용자가 급여 서류 메일을 보내지 않기로 했습니다. 보내지 않았습니다.';
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    args: [JSON.stringify(job), job.yearMonth],
    func: (j, ym) => {
      try {
        sessionStorage.setItem('knockhr:payroll-mail', j);
        if (location.pathname.startsWith('/payroll')) window.dispatchEvent(new CustomEvent('knockhr:payroll-mail'));
        else location.href = `/payroll?ym=${ym}`;
        return true;
      } catch { return false; }
    },
  });
  if (!res?.result) return '급여관리 화면에 일감을 넘기지 못했습니다. 사용자에게 똑소리HR 급여관리 → [이메일 발송]에서 직접 보내 달라고 하세요.';
  await chrome.tabs.update(tabId, { active: true }).catch(() => {});
  const [y, m] = String(job.yearMonth).split('-');
  return `급여관리에서 ${Number(y)}년 ${Number(m)}월 서류를 만들어 ${job.recipients.map((r) => r.name).join(', ')}에게 보내는 중입니다. 결과는 그 화면의 메일 창에 뜹니다(사용자에게 확인하라고 안내).`;
}

// 일정표 색(2026-11-11) — 화면 똑소리 창의 [확인 후 바꾸기]와 같은 창구로, 그 똑소리HR 탭 안에서 저장한다(쿠키·권한 그대로).
// 저장한 뒤 열려 있는 일정표가 새로고침 없이 따라 바뀌게 화면과 같은 알림을 보낸다.
async function scheduleColor(data, tabId, confirm) {
  const p = data.proposal;
  const md = (d) => `${Number(String(d).slice(5, 7))}/${Number(String(d).slice(8, 10))}`;
  const detail = p.kind === 'day_color_batch'
    ? `날짜: ${p.dates.map(md).join(', ')}${p.replaced?.length ? `\n이미 칠한 색이 바뀌는 날: ${p.replaced.map((r) => `${md(r.date)}(${r.label || r.colorName})`).join(', ')}` : ''}`
    : '';
  const ok = confirm ? await confirm(`${data.content}\n${detail}`.trim()) : false;
  if (!ok) return '사용자가 일정표 색을 바꾸지 않기로 했습니다. 바꾸지 않았습니다.';
  const req = p.kind === 'badge_color'
    ? { path: '/api/schedule-colors', method: 'PUT', body: { key: p.key, color: p.to } }
    : { path: '/api/day-memos/colors', method: 'POST', body: { dates: p.dates, color: p.color, label: p.label ?? null } };
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    args: [req.path, req.method, JSON.stringify(req.body), p.kind],
    func: async (path, method, body, kind) => {
      try {
        const r = await fetch(path, { method, credentials: 'same-origin', headers: { 'content-type': 'application/json' }, body });
        const d = await r.json().catch(() => ({}));
        if (r.ok) {
          if (kind === 'badge_color' && d.colors) window.dispatchEvent(new CustomEvent('knock-schedule-colors', { detail: { colors: d.colors, overrides: d.overrides || {} } }));
          window.dispatchEvent(new CustomEvent('knockhr:attendance-changed'));
        }
        return { ok: r.ok, error: d && d.error };
      } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
    },
  });
  const out = res?.result || { ok: false, error: '응답 없음' };
  if (!out.ok) return `일정표 색을 바꾸지 못했습니다: ${out.error || '실패'}`;
  return p.kind === 'badge_color'
    ? `${p.label} 배지를 ${p.toName}으로 바꿨습니다.`
    : (p.color ? `${p.dates.length}일(${p.dates.map(md).join(', ')}) 칸을 ${p.colorName}으로 칠했습니다.` : `${p.dates.length}일 칸 색을 지웠습니다.`);
}

export const TOKSORI_SERVICES = Object.keys(SERVICES);
