// 브라우저 연동 — 들어와지는 쪽(2026-11-05 2단계, knock-hr/docs/Knock-계정-장치-원격-설계.md 5장).
// 화면에 안 보이는 문서(offscreen)에서 돈다: 알림 채널(inbox)에서 "연결하려 함"을 듣고, 서버에 진짜인지 확인한 뒤
// 연결 방에서 WebRTC 로 직접 잇는다. 탭 목록·화면은 배경(background.js)이 만들어 이 통로로 보낸다.
// 알림 채널은 누구나 쪽지를 보낼 수 있어서, 서버 확인(claim)을 통과한 연결만 받는다.
import { openSignal } from './remote-signal.js';
import { sendWire, wireReader, iceServers } from './rb-wire.js';

const me = crypto.randomUUID();
const host = { inbox: null, inboxId: '', room: null, pc: null, dc: null, ctl: null, viewer: null, sessionId: '', name: '' };
// 통로 둘(2026-11-05 "화면 움직임 지연이 너무 심해"): rb = 화면 그림, ctl = 누르기·입력·탭 목록 같은 작은 쪽지.
// 그림이 밀려도 작은 쪽지는 기다리지 않는다. 옛 판(ctl 없음)과도 되게 ctl 이 없으면 rb 로 보낸다.
const ctlOrRb = () => (host.ctl?.readyState === 'open' ? host.ctl : host.dc);
const LOW = 64 * 1024;
// 영상(2026-11-05 "원격 데스크톱처럼"): 보는 탭을 영상으로 보낸다 — 바뀐 부분만·인터넷 속도에 맞춰 알아서(화상 통화와 같은 방식).
// 연결할 때 영상 자리(video sender)를 미리 만들어 두고, 탭이 바뀌면 그 탭 영상으로 갈아 끼운다.
let videoSender = null;
let videoTrack = null;
async function setVideo(streamId, w, h) {
  if (!videoSender) return { ok: false, error: 'no sender' };
  try {
    // 같은 탭을 두 번 잡을 수 없어 옛 영상을 먼저 끈다
    videoTrack?.stop();
    videoTrack = null;
    const s = await navigator.mediaDevices.getUserMedia({ audio: false, video: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId, maxWidth: w, maxHeight: h, maxFrameRate: 30 } } });
    const track = s.getVideoTracks()[0];
    track.contentHint = 'text'; // 글자가 뭉개지지 않게(움직임보다 또렷함)
    await videoSender.replaceTrack(track);
    const p = videoSender.getParameters();
    p.degradationPreference = 'maintain-resolution'; // 인터넷이 느리면 화질 대신 장 수를 줄인다(글자는 또렷하게)
    if (p.encodings?.[0]) p.encodings[0].maxFramerate = 30;
    await videoSender.setParameters(p).catch(() => {});
    videoTrack = track;
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}
function stopVideo() {
  videoTrack?.stop();
  videoTrack = null;
  videoSender?.replaceTrack(null).catch(() => {});
}
// 화면 한 장을 보내고, 통로에 쌓인 것이 다 빠질 때까지 기다린다 — 다음 장은 그 뒤에(쌓여서 지연이 커지지 않게)
function sendFrame(data) {
  const dc = host.dc;
  if (!dc || dc.readyState !== 'open') return Promise.resolve({ ok: false });
  const t0 = performance.now();
  const bytes = JSON.stringify(data).length;
  sendWire(dc, data);
  if (dc.bufferedAmount <= LOW) return Promise.resolve({ ok: true, bytes, ms: performance.now() - t0 });
  return new Promise((resolve) => {
    const done = () => { clearTimeout(timer); dc.removeEventListener('bufferedamountlow', done); resolve({ ok: true, bytes, ms: performance.now() - t0 }); };
    const timer = setTimeout(done, 8000);
    dc.addEventListener('bufferedamountlow', done);
  });
}
const toBackground = (msg) => chrome.runtime.sendMessage({ target: 'background', ...msg });

// 알림 채널(받는 쪽 우편함). 인터넷이 끊겨 서버와의 연결이 죽으면 다시 들어간다(5초 뒤부터, 안 되면 30초마다)
let relisten = null;
async function listen(inboxId) {
  if (host.inboxId === inboxId && host.inbox && host.inbox.alive?.() !== false) return;
  host.inbox?.close();
  host.inbox = null;
  host.inboxId = inboxId;
  clearTimeout(relisten);
  if (!inboxId) return;
  const again = (ms) => { clearTimeout(relisten); relisten = setTimeout(() => { if (host.inboxId === inboxId) { host.inbox = null; listen(inboxId); } }, ms); };
  host.inbox = await openSignal(`inbox:${inboxId}`, onRing, { onClose: () => again(5000) }).catch(() => null);
  if (!host.inbox) again(30000);
}

async function onRing(msg) {
  if (msg?.kind === 'probe' && msg.sessionId && msg.from) return onProbe(msg);
  if (msg?.kind !== 'ring' || !msg.sessionId || !msg.from) return;
  // 이미 연결이 있으면: 끊긴 채 남은 것이면 정리하고 받는다. 살아 있어도 같은 PC 가 다시 연결한 것이면(같은 계정만
  // 서버가 넘겨주므로 장치 이름으로 알아본다) 예전 것을 끝내고 받는다 — 2026-11-06 "연결 끊은 후에도 기존 연결이 살아있어 다시 안돼"
  if (host.pc && (host.dc?.readyState !== 'open' || host.pc.connectionState !== 'connected')) end('');
  if (host.pc) {
    const again = await toBackground({ type: 'rhostClaim', sessionId: msg.sessionId }).catch(() => null);
    if (again?.roomId && again.mode === 'pc') return acceptPc(msg, again); // PC 원격제어는 브라우저 연동과 따로 받는다
    if (!again?.roomId || (again.from?.name || '다른 PC') !== host.name) { host.inbox?.send({ kind: 'busy', to: msg.from }); return; }
    end('');
    return accept(msg, again);
  }
  const ok = await toBackground({ type: 'rhostClaim', sessionId: msg.sessionId }).catch(() => null);
  if (!ok?.roomId) return; // 서버가 확인하지 않은 연결은 받지 않는다
  return accept(msg, ok);
}

// 원격 목록이 "받을 업데이트 있나?"만 묻는다 — 화면·알림 없이 답하고 바로 닫는다(서버가 확인한 것만)
const probed = new Set();
async function onProbe(msg) {
  if (probed.has(msg.sessionId)) return; // 3초마다 다시 묻는 것은 한 번만 답한다
  probed.add(msg.sessionId);
  setTimeout(() => probed.delete(msg.sessionId), 60000);
  const ok = await toBackground({ type: 'rhostClaim', sessionId: msg.sessionId }).catch(() => null);
  if (!ok?.roomId) return;
  const room = await openSignal(`room:${ok.roomId}`, () => {}).catch(() => null);
  if (!room) return;
  const update = await toBackground({ type: 'rhostUpdateInfo' }).catch(() => null);
  // 원격 목록의 [업데이트]: 창 없이 이 PC 만 업데이트하고 다시 켠다(다시 켜지면 원격 대기는 저절로)
  const updating = msg.op === 'update' ? Boolean((await toBackground({ type: 'rhostUpdateRun' }).catch(() => null))?.ok) : undefined;
  for (const ms of [0, 1500, 4000]) setTimeout(() => room.send({ kind: 'info', to: msg.from, from: me, update, ...(updating !== undefined ? { updating } : {}) }), ms);
  setTimeout(() => { room.close(); toBackground({ type: 'rhostPcDone', sessionId: msg.sessionId }); }, 6000);
}

async function accept(msg, ok) {
  if (ok.mode === 'pc') return acceptPc(msg, ok);
  host.sessionId = msg.sessionId;
  host.roomId = ok.roomId;
  host.account = ok.account?.name || '';
  host.name = ok.from?.name || '다른 PC';
  host.viewer = msg.from;
  host.room = await openSignal(`room:${ok.roomId}`, onRoom).catch(() => null);
  if (!host.room) return end('연결 방에 들어가지 못했어요.');
  const pc = (host.pc = new RTCPeerConnection({ iceServers: await iceServers() }));
  const dc = (host.dc = pc.createDataChannel('rb', { ordered: true }));
  dc.bufferedAmountLowThreshold = LOW;
  const ctl = (host.ctl = pc.createDataChannel('ctl', { ordered: true }));
  videoSender = pc.addTransceiver('video', { direction: 'sendonly' }).sender;
  const onIn = (ev) => {
    // 응답 시간 재기는 여기서 바로 답한다(배경을 거치면 그만큼 늦게 잰다)
    if (ev?.t === 'ping') return sendWire(ctlOrRb(), { t: 'pong', at: ev.at });
    // 보는 쪽이 "이 PC 업데이트"를 눌렀다 — 받을 업데이트가 있으면 설치하고 다시 켠다(다시 켜지면 원격 대기는 저절로)
    if (ev?.t === 'update') return toBackground({ type: 'rhostUpdateRun' }).then((r) => sendWire(ctlOrRb(), { t: 'updating', ok: Boolean(r?.ok) })).catch(() => {});
    // 연결 정보를 함께 보낸다 — 배경이 잠들었다 깨면 연결 중인 줄 모르고 입력을 버렸다(2026-11-13 이든치과 "브라우저 연동 먹통"). 배경이 이것으로 되살린다
    toBackground({ type: 'rhostIn', ev, live: { name: host.name, sessionId: host.sessionId, account: host.account || '' } });
  };
  const read = wireReader(onIn);
  dc.onmessage = (e) => read(e.data);
  const readCtl = wireReader(onIn);
  ctl.onmessage = (e) => readCtl(e.data);
  dc.onopen = () => toBackground({ type: 'rhostLive', on: true, name: host.name, sessionId: host.sessionId, account: ok.account?.name || '' });
  pc.onicecandidate = (e) => e.candidate && host.room?.send({ kind: 'ice', to: host.viewer, from: me, candidate: e.candidate.toJSON() });
  pc.onconnectionstatechange = () => ['failed', 'closed', 'disconnected'].includes(pc.connectionState) && end('연결이 끊겼어요.');
  // 이 PC 에 받을 업데이트가 있는지도 알린다(보는 쪽 창·원격 목록에 "업데이트 있음")
  const update = await toBackground({ type: 'rhostUpdateInfo' }).catch(() => null);
  host.room.send({ kind: 'welcome', to: host.viewer, from: me, update });
  await pc.setLocalDescription(await pc.createOffer());
  host.room.send({ kind: 'offer', to: host.viewer, from: me, sdp: pc.localDescription.toJSON() });
}

// "PC 원격제어" 연결: 브라우저 연동(탭 화면)은 열지 않는다. 연결 방은 번호를 건네는 데만 쓰고 닫는다.
const pcRooms = new Map(); // ticket → { room, viewer, sessionId, timer }
async function acceptPc(msg, ok) {
  const ticket = crypto.randomUUID();
  const viewer = msg.from;
  const room = await openSignal(`room:${ok.roomId}`, (m) => {
    if (m?.kind === 'pcGot' && m.to === me && m.from === viewer) closePc(ticket);
  }).catch(() => null);
  if (!room) return;
  const p = { room, viewer, sessionId: msg.sessionId, timer: setTimeout(() => closePc(ticket), 2 * 60 * 1000) };
  pcRooms.set(ticket, p);
  room.send({ kind: 'welcome', to: viewer, from: me, pc: true });
  toBackground({ type: 'rhostPcOpen', ticket, sessionId: msg.sessionId });
}
function sendPcCode(ticket, code) {
  const p = pcRooms.get(ticket);
  if (!p) return false;
  // 번호를 받았다는 답(pcGot)이 올 때까지 2초마다 다시 보낸다
  const once = () => p.room.send({ kind: 'pcCode', to: p.viewer, from: me, ticket, code });
  once();
  p.resend = setInterval(once, 2000);
  return true;
}
function closePc(ticket) {
  const p = pcRooms.get(ticket);
  if (!p) return;
  pcRooms.delete(ticket);
  clearTimeout(p.timer);
  clearInterval(p.resend);
  p.room.close();
  toBackground({ type: 'rhostPcDone', sessionId: p.sessionId });
}

// 창 없이 뒤에서 PC 화면 보내기(2026-11-06 "작업표시줄 아이콘 표시 되지 않게"): 공유 화면(remote.html?ticket)을
// 이 보이지 않는 문서 안에 넣어 돌린다. 끝나면 그 화면이 알려 주고(knockPcShareDone) 여기서 뺀다.
// 본체(ver 12~)가 이 문서에서는 화면 고르기 없이 전체 화면을 준다.
function startPcShareFrame(ticket) {
  if (!/^[0-9a-f-]{36}$/.test(ticket)) return false;
  // 새 PC 원격제어가 시작되면 앞서 남은 화면 보내기는 닫는다(둘이 겹쳐 조작이 끊기던 것 — 2026-11-07)
  for (const old of document.querySelectorAll('iframe[data-ticket]')) old.remove();
  const f = document.createElement('iframe');
  f.allow = 'display-capture';
  f.dataset.ticket = ticket;
  f.src = chrome.runtime.getURL(`remote.html?ticket=${ticket}&bg=1#share`);
  document.body.append(f);
  setTimeout(() => f.remove(), 3 * 60 * 60 * 1000); // 아무리 길어도 3시간
  return true;
}
window.addEventListener('message', (e) => {
  if (e.origin !== location.origin) return;
  const ticket = e.data?.knockPcShareDone || e.data?.knockPcShareFallback;
  if (!ticket) return;
  for (const f of document.querySelectorAll('iframe[data-ticket]')) if (f.dataset.ticket === ticket) f.remove();
  // 이 본체에서는 창 없이 화면을 못 받았다 — 예전처럼 작은 창으로
  if (e.data.knockPcShareFallback) toBackground({ type: 'rhostPcWindow', ticket });
});

function onRoom(msg) {
  if (!msg || msg.to !== me || msg.from !== host.viewer) return;
  if (msg.kind === 'answer') host.pc?.setRemoteDescription(msg.sdp);
  else if (msg.kind === 'ice' && msg.candidate) host.pc?.addIceCandidate(msg.candidate).catch(() => {});
  else if (msg.kind === 'bye') end('상대가 연결을 끊었어요.');
}

function handoffInfo() {
  return { sessionId: host.sessionId, roomId: host.roomId || '', viewer: host.viewer || '', name: host.name, account: host.account || '' };
}
function quietEnd() {
  stopVideo();
  videoSender = null;
  if (host.pc) { host.pc.onconnectionstatechange = null; host.pc.close(); }
  host.room?.close();
  Object.assign(host, { room: null, pc: null, dc: null, ctl: null, viewer: null, sessionId: '', roomId: '' });
  toBackground({ type: 'rhostLive', on: false, note: '', sessionId: '' });
}
function end(note) {
  if (!host.pc && !host.room) return;
  if (host.viewer) host.room?.send({ kind: 'bye', to: host.viewer, from: me });
  stopVideo();
  videoSender = null;
  host.pc?.close();
  host.room?.close();
  const sessionId = host.sessionId;
  Object.assign(host, { room: null, pc: null, dc: null, ctl: null, viewer: null, sessionId: '' });
  toBackground({ type: 'rhostLive', on: false, note, sessionId });
}

chrome.runtime.onMessage.addListener((msg, _s, reply) => {
  if (msg?.target !== 'offscreen' || msg.type !== 'rhost') return;
  if (msg.cmd === 'listen') listen(msg.inboxId || '').then(() => reply({ ok: true }));
  else if (msg.cmd === 'out') reply({ ok: sendWire(ctlOrRb(), msg.data) });
  else if (msg.cmd === 'frame') sendFrame(msg.data).then(reply);
  else if (msg.cmd === 'video') setVideo(msg.streamId, msg.w, msg.h).then(reply);
  else if (msg.cmd === 'videoOff') { stopVideo(); reply({ ok: true }); }
  else if (msg.cmd === 'end') { end(msg.note || '연결을 끊었어요.'); reply({ ok: true }); }
  else if (msg.cmd === 'pcCode') reply({ ok: sendPcCode(msg.ticket, msg.code) });
  else if (msg.cmd === 'pcShareStart') reply({ ok: startPcShareFrame(String(msg.ticket || '')) });
  else if (msg.cmd === 'state') reply({ listening: Boolean(host.inbox), live: Boolean(host.dc), sessionId: host.sessionId });
  // 원격 프로필 바꾸기(2026-11-10): 같은 PC 의 다른 프로필이 이미 확인된 연결을 넘겨받는다(서버 확인 없이 — 같은 PC·같은 사용자 안 통로로만 온다)
  // 같은 연결을 또 넘겨받으라는 것(넘겨준 쪽이 답을 못 받고 다시 물음)은 이미 받은 것으로 답한다 — 끝내고 다시 받으면 보는 쪽에 '끊김'이 갔다
  else if (msg.cmd === 'takeover' && host.pc && host.sessionId === msg.sessionId && host.viewer === msg.viewer) reply({ ok: true });
  else if (msg.cmd === 'takeover') { if (host.pc) end(''); accept({ sessionId: msg.sessionId, from: msg.viewer }, { roomId: msg.roomId, mode: 'browser', from: { name: msg.name }, account: { name: msg.account || '' } }).then(() => reply({ ok: true }), (e) => reply({ ok: false, error: e.message })); }
  // 넘겨준 쪽: 보는 쪽에 '끊김'을 알리지 않고, 서버 연결(세션)도 끝내지 않고 조용히 닫는다
  else if (msg.cmd === 'handoff') { reply({ ok: true, ...handoffInfo() }); }
  else if (msg.cmd === 'handoffClose') { quietEnd(); reply({ ok: true }); }
  return true;
});
