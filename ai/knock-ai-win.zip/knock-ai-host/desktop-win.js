// 윈도우 앱 다루기(2026-11-09 원장님 "윈도우 원격 PC의 다른 프로그램도 맥처럼"): UI Automation 으로 창의 단추·칸을 이름으로 읽고 누른다.
// 맥 desktop.js(knock-desktop.swift)와 같은 약속이다 — apps · open · snapshot([w3-12] 번호) · press · read · setText · key.
// 칸이 안 읽히는 창(그림으로 그리는 프로그램)은 shot(창 사진) · tap(사진 자리 누르기) · screenType(글자 치기) — 이때만 진짜 마우스·키를 쓴다.
// 읽기·누르기·값 넣기는 마우스를 움직이지 않고 창을 앞으로 가져오지 않는다. 키 보내기와 "값을 못 받는 칸"에 글자 치기만
// 그 창을 잠깐 앞으로 가져왔다가 원래 창으로 되돌린다.
// AI 부분 업데이트는 도우미의 .js 만 바꾸므로(새 부품 없이) PowerShell 글을 여기 담아 두고 쓸 때 임시 폴더에 .ps1 로 적어 띄운다(input-win.js 와 같은 방식).
const fs = require('fs');
const os = require('os');
const path = require('path');
const readline = require('readline');
const { spawn } = require('child_process');

const PS = String.raw`# Knock 윈도우 앱 다루기(UI Automation). 한 줄에 JSON 하나를 받고 한 줄로 답한다.
$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding $false
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
Add-Type -ReferencedAssemblies UIAutomationClient, UIAutomationTypes, WindowsBase, System.Drawing -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Automation;

public static class KnockUia {
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
  [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool f);
  [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  [StructLayout(LayoutKind.Sequential)] struct KEYBDINPUT { public ushort wVk, wScan; public uint dwFlags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Sequential)] struct MOUSEINPUT { public int dx, dy; public int mouseData; public uint dwFlags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Explicit)] struct UNION { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
  [StructLayout(LayoutKind.Sequential)] struct INPUT { public uint type; public UNION u; }
  [DllImport("user32.dll", SetLastError = true)] static extern uint SendInput(uint n, INPUT[] inputs, int size);

  static readonly Dictionary<string, AutomationElement> refs = new Dictionary<string, AutomationElement>();
  static readonly Dictionary<string, string> refApp = new Dictionary<string, string>();
  static int seq = 0;

  // ── JSON 글 만들기(작게) ──
  public static string J(string s) {
    if (s == null) return "\"\"";
    var b = new StringBuilder("\"");
    foreach (char c in s) {
      if (c == '"') b.Append("\\\""); else if (c == '\\') b.Append("\\\\");
      else if (c == '\n') b.Append("\\n"); else if (c == '\r') b.Append("\\r"); else if (c == '\t') b.Append("\\t");
      else if (c < 32) b.Append("\\u" + ((int)c).ToString("x4")); else b.Append(c);
    }
    return b.Append('"').ToString();
  }
  public static string Err(string msg) { return "{\"ok\":false,\"error\":" + J(msg) + "}"; }

  static string ProcName(int pid) { try { return Process.GetProcessById(pid).ProcessName; } catch { return ""; } }

  // 한국어로 부르는 앱 이름 → 프로그램 이름
  static readonly Dictionary<string, string> alias = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) {
    { "엑셀", "EXCEL" }, { "excel", "EXCEL" }, { "워드", "WINWORD" }, { "word", "WINWORD" }, { "파워포인트", "POWERPNT" }, { "powerpoint", "POWERPNT" },
    { "메모장", "notepad" }, { "한글", "Hwp" }, { "한컴", "Hwp" }, { "계산기", "CalculatorApp" }, { "탐색기", "explorer" }, { "파일 탐색기", "explorer" },
    { "카카오톡", "KakaoTalk" }, { "아웃룩", "OUTLOOK" }, { "그림판", "mspaint" },
  };

  static bool SkipWindow(AutomationElement w) {
    try {
      var cls = w.Current.ClassName ?? "";
      if (cls == "Shell_TrayWnd" || cls == "Progman" || cls == "WorkerW" || cls == "Shell_SecondaryTrayWnd") return true;
      return string.IsNullOrEmpty(w.Current.Name);
    } catch { return true; }
  }

  public static string Apps() {
    var b = new StringBuilder("{\"ok\":true,\"apps\":[");
    IntPtr fg = GetForegroundWindow();
    bool first = true;
    foreach (AutomationElement w in AutomationElement.RootElement.FindAll(TreeScope.Children, Condition.TrueCondition)) {
      try {
        if (SkipWindow(w)) continue;
        var h = new IntPtr(w.Current.NativeWindowHandle);
        if (!first) b.Append(','); first = false;
        b.Append("{\"name\":" + J(w.Current.Name) + ",\"bundle\":" + J(ProcName(w.Current.ProcessId)) + ",\"active\":" + (h == fg ? "true" : "false") + ",\"hidden\":" + (IsIconic(h) ? "true" : "false") + "}");
      } catch { }
    }
    return b.Append("]}").ToString();
  }

  // 앱 찾기: 비면 맨 앞 창, 아니면 프로그램 이름 → 창 제목에 든 글자
  public static AutomationElement FindWindow(string app) {
    if (string.IsNullOrEmpty(app)) {
      var fg = GetForegroundWindow();
      return fg == IntPtr.Zero ? null : AutomationElement.FromHandle(fg);
    }
    string want = app.Trim();
    if (want.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) want = want.Substring(0, want.Length - 4);
    string proc;
    if (alias.TryGetValue(want, out proc)) want = proc;
    AutomationElement byTitle = null, byProcPart = null;
    foreach (AutomationElement w in AutomationElement.RootElement.FindAll(TreeScope.Children, Condition.TrueCondition)) {
      try {
        if (SkipWindow(w)) continue;
        var p = ProcName(w.Current.ProcessId);
        if (string.Equals(p, want, StringComparison.OrdinalIgnoreCase)) return w;
        if (byTitle == null && w.Current.Name.IndexOf(app, StringComparison.OrdinalIgnoreCase) >= 0) byTitle = w;
        if (byProcPart == null && p.IndexOf(want, StringComparison.OrdinalIgnoreCase) >= 0) byProcPart = w;
      } catch { }
    }
    return byTitle ?? byProcPart;
  }

  static string KindOf(AutomationElement e, ControlType ct) {
    if (ct == ControlType.Button) return "단추";
    if (ct == ControlType.SplitButton) return "메뉴 단추";
    if (ct == ControlType.ComboBox) return "입력·고르기";
    if (ct == ControlType.CheckBox) return "체크";
    if (ct == ControlType.RadioButton) return "선택";
    if (ct == ControlType.Edit) {
      bool pw = false; try { pw = (bool)e.GetCachedPropertyValue(AutomationElement.IsPasswordProperty); } catch { }
      return pw ? "비밀번호칸" : "입력칸";
    }
    if (ct == ControlType.Document) return "글칸";
    if (ct == ControlType.Hyperlink) return "링크";
    if (ct == ControlType.MenuItem) return "메뉴";
    if (ct == ControlType.Slider) return "조절";
    if (ct == ControlType.ListItem || ct == ControlType.TreeItem) return "줄";
    if (ct == ControlType.DataItem) return "칸";
    if (ct == ControlType.TabItem) return "탭";
    if (ct == ControlType.Spinner) return "늘리기";
    return null;
  }
  static readonly HashSet<ControlType> heads = new HashSet<ControlType> { ControlType.Window, ControlType.ToolBar, ControlType.Tab, ControlType.List, ControlType.Table, ControlType.Tree, ControlType.DataGrid, ControlType.MenuBar, ControlType.Group, ControlType.Pane };

  static object Cached(AutomationElement e, AutomationProperty p) {
    try { var v = e.GetCachedPropertyValue(p, true); return v == AutomationElement.NotSupported ? null : v; } catch { return null; }
  }

  public static string Snapshot(string app, int limit) {
    var win = FindWindow(app);
    if (win == null) return Err(string.IsNullOrEmpty(app) ? "앞에 있는 창이 없습니다." : "그 앱 창을 찾지 못했습니다. win_apps 로 켜져 있는 창을 보거나 win_open 으로 켜세요.");
    seq++;
    string prefix = "w" + seq + "-";
    var old = new List<string>();
    foreach (var k in refs.Keys) if (k.StartsWith("w" + (seq - 3) + "-")) old.Add(k);
    foreach (var k in old) { refs.Remove(k); refApp.Remove(k); }
    var cr = new CacheRequest();
    cr.Add(AutomationElement.NameProperty); cr.Add(AutomationElement.ControlTypeProperty); cr.Add(AutomationElement.IsEnabledProperty);
    cr.Add(AutomationElement.HasKeyboardFocusProperty); cr.Add(AutomationElement.IsOffscreenProperty); cr.Add(AutomationElement.IsPasswordProperty);
    cr.Add(ValuePattern.ValueProperty); cr.Add(TogglePattern.ToggleStateProperty); cr.Add(SelectionItemPattern.IsSelectedProperty);
    var walker = TreeWalker.ControlViewWalker;
    var lines = new List<string>();
    int n = 0, count = 0;
    bool truncated = false;
    var watch = Stopwatch.StartNew();
    string procName = "", title = "";
    try { procName = ProcName(win.Current.ProcessId); title = win.Current.Name; } catch { }
    AutomationElement root;
    try { root = win.GetUpdatedCache(cr); } catch { return Err("그 창을 읽지 못했습니다(닫혔거나 응답 없음)."); }

    Action<AutomationElement, int> walk = null;
    walk = (el, depth) => {
      if (count >= limit || watch.ElapsedMilliseconds > 12000) { truncated = true; return; }
      ControlType ct = Cached(el, AutomationElement.ControlTypeProperty) as ControlType;
      string name = ((Cached(el, AutomationElement.NameProperty) as string) ?? "").Trim();
      if (name.Length > 80) name = name.Substring(0, 80);
      bool off = (Cached(el, AutomationElement.IsOffscreenProperty) as bool?) ?? false;
      string indent = new string(' ', Math.Min(depth, 12));
      string line = "";
      string kind = ct == null ? null : KindOf(el, ct);
      if (kind != null && !off) {
        n++;
        string r = prefix + n;
        refs[r] = el; refApp[r] = procName;
        string value = "";
        if (kind == "비밀번호칸") { value = ((Cached(el, ValuePattern.ValueProperty) as string) ?? "") == "" ? "" : "(가려짐)"; }
        else if (kind == "체크") { var t = Cached(el, TogglePattern.ToggleStateProperty); if (t != null) value = ((ToggleState)t) == ToggleState.On ? "켜짐" : "꺼짐"; }
        else { value = (Cached(el, ValuePattern.ValueProperty) as string) ?? ""; }
        value = value.Replace("\r\n", " ⏎ ").Replace("\n", " ⏎ ");
        if (value.Length > 200) value = value.Substring(0, 200) + "…(read 로 전체)";
        line = indent + "[" + r + "] " + kind;
        if (name != "") line += " \"" + name.Replace("\"", "'") + "\"";
        if (value != "" && value != name) line += " = " + value;
        if (!((Cached(el, AutomationElement.IsEnabledProperty) as bool?) ?? true)) line += " (꺼짐)";
        if ((Cached(el, AutomationElement.HasKeyboardFocusProperty) as bool?) ?? false) line += " (커서)";
        if ((Cached(el, SelectionItemPattern.IsSelectedProperty) as bool?) ?? false) line += " (선택됨)";
        count++;
      } else if (ct == ControlType.Text && name != "" && !off) {
        line = indent + name; count++;
      } else if (ct != null && heads.Contains(ct) && name != "" && depth > 0 && ct != ControlType.Pane && ct != ControlType.Group) {
        line = indent + "# " + name;
      } else if (ct != null && (ct == ControlType.Group || ct == ControlType.Pane) && name != "" && depth > 0 && name.Length < 40) {
        line = indent + "# " + name;
      }
      if (line != "") lines.Add(line);
      if (ct == ControlType.Text) return;
      int kids = 0;
      AutomationElement c = null;
      try { c = walker.GetFirstChild(el, cr); } catch { }
      while (c != null && kids < 400) {
        walk(c, depth + (line == "" ? 0 : 1));
        if (truncated) return;
        kids++;
        try { c = walker.GetNextSibling(c, cr); } catch { c = null; }
      }
    };
    walk(root, 0);
    bool minimized = false;
    try { minimized = IsIconic(new IntPtr(win.Current.NativeWindowHandle)); } catch { }
    if (lines.Count == 0) lines.Add(minimized ? "(창이 작업 표시줄로 접혀 있어 칸이 안 보입니다. 창을 펼친 뒤 다시 읽으세요)" : "(읽을 수 있는 칸이 없습니다 — 화면을 직접 그리는 프로그램일 수 있습니다)");
    return "{\"ok\":true,\"app\":" + J(procName) + ",\"bundle\":" + J(procName) + ",\"window\":" + J(title) + ",\"text\":" + J(string.Join("\n", lines)) + ",\"menus\":[],\"truncated\":" + (truncated ? "true" : "false") + "}";
  }

  static AutomationElement Ref(string r) {
    AutomationElement e;
    if (r == null || !refs.TryGetValue(r, out e)) return null;
    try { var t = e.Current.ControlType; return e; } catch { return null; } // 사라진 칸
  }
  const string STALE = "{\"ok\":false,\"stale\":true,\"error\":\"그 번호의 칸이 없습니다(화면이 바뀜). 다시 읽으세요.\"}";

  // 단추 누르기: 어떤 프로그램은 누른 뒤 뜨는 창이 닫힐 때까지 답하지 않아, 따로 돌리고 3초만 기다린다
  static bool Run(Action a, int ms) {
    Exception err = null;
    var t = new Thread(() => { try { a(); } catch (Exception x) { err = x; } });
    t.IsBackground = true; t.Start();
    if (!t.Join(ms)) return true;
    if (err != null) throw err;
    return true;
  }

  public static string Press(string r, bool open) {
    var e = Ref(r);
    if (e == null) return STALE;
    object p;
    try {
      if (e.TryGetCurrentPattern(InvokePattern.Pattern, out p)) { var inv = (InvokePattern)p; Run(() => inv.Invoke(), 3000); return "{\"ok\":true}"; }
      if (e.TryGetCurrentPattern(TogglePattern.Pattern, out p)) { ((TogglePattern)p).Toggle(); return "{\"ok\":true}"; }
      if (e.TryGetCurrentPattern(SelectionItemPattern.Pattern, out p)) {
        ((SelectionItemPattern)p).Select();
        if (open) { Thread.Sleep(200); KeysTo(e, "Enter", new string[0]); return "{\"ok\":true,\"opened\":true}"; }
        return "{\"ok\":true,\"selected\":true}";
      }
      if (e.TryGetCurrentPattern(ExpandCollapsePattern.Pattern, out p)) {
        var ec = (ExpandCollapsePattern)p;
        if (ec.Current.ExpandCollapseState == ExpandCollapseState.Expanded) ec.Collapse(); else ec.Expand();
        return "{\"ok\":true}";
      }
    } catch (Exception x) { return Err("누르지 못했습니다: " + x.Message); }
    return Err("이 칸은 이름으로 누를 수 없습니다.");
  }

  public static string Read(string r) {
    var e = Ref(r);
    if (e == null) return STALE;
    object p;
    try {
      if (e.Current.IsPassword) return "{\"ok\":true,\"text\":\"(비밀번호 칸이라 읽지 않습니다)\"}";
      if (e.TryGetCurrentPattern(TextPattern.Pattern, out p)) return "{\"ok\":true,\"text\":" + J(((TextPattern)p).DocumentRange.GetText(20000)) + "}";
      if (e.TryGetCurrentPattern(ValuePattern.Pattern, out p)) { var v = ((ValuePattern)p).Current.Value ?? ""; return "{\"ok\":true,\"text\":" + J(v.Length > 20000 ? v.Substring(0, 20000) : v) + "}"; }
      return "{\"ok\":true,\"text\":" + J(e.Current.Name) + "}";
    } catch (Exception x) { return Err(x.Message); }
  }

  public static string SetText(string r, string text, bool submit, bool allowSecure) {
    var e = Ref(r);
    if (e == null) return STALE;
    try {
      if (e.Current.IsPassword && !allowSecure) return "{\"ok\":false,\"secure\":true,\"error\":\"비밀번호 칸입니다.\"}";
      string how = "값";
      object p;
      bool done = false;
      if (e.TryGetCurrentPattern(ValuePattern.Pattern, out p) && !((ValuePattern)p).Current.IsReadOnly) {
        try { ((ValuePattern)p).SetValue(text); done = true; } catch { }
      }
      if (!done) { how = "글자"; TypeInto(e, text); }
      if (submit) KeysTo(e, "Enter", new string[0]);
      return "{\"ok\":true,\"how\":" + J(how) + "}";
    } catch (Exception x) { return Err("넣지 못했습니다: " + x.Message); }
  }

  // ── 그 창을 잠깐 앞으로 가져와 키를 보내고 원래 창으로 되돌린다 ──
  static IntPtr TopHandle(AutomationElement e) {
    var walker = TreeWalker.ControlViewWalker;
    AutomationElement cur = e, top = e;
    try {
      while (cur != null && cur != AutomationElement.RootElement) { top = cur; cur = walker.GetParent(cur); }
      return new IntPtr(top.Current.NativeWindowHandle);
    } catch { return IntPtr.Zero; }
  }
  static bool Front(IntPtr h) {
    if (h == IntPtr.Zero) return false;
    if (IsIconic(h)) ShowWindow(h, 9);
    IntPtr fg = GetForegroundWindow();
    if (fg == h) return true;
    uint me = GetCurrentThreadId(), other = GetWindowThreadProcessId(fg, IntPtr.Zero);
    AttachThreadInput(me, other, true);
    BringWindowToTop(h); SetForegroundWindow(h);
    AttachThreadInput(me, other, false);
    return GetForegroundWindow() == h;
  }
  static void Key(ushort vk, bool down) {
    var i = new INPUT { type = 1 };
    i.u.ki = new KEYBDINPUT { wVk = vk, dwFlags = down ? 0u : 2u };
    SendInput(1, new[] { i }, Marshal.SizeOf(typeof(INPUT)));
  }
  static void Uni(char ch) {
    foreach (bool down in new[] { true, false }) {
      var i = new INPUT { type = 1 };
      i.u.ki = new KEYBDINPUT { wScan = ch, dwFlags = 4u | (down ? 0u : 2u) };
      SendInput(1, new[] { i }, Marshal.SizeOf(typeof(INPUT)));
    }
  }
  static ushort Vk(string key) {
    switch (key) {
      case "Enter": return 0x0D; case "Tab": return 0x09; case "Escape": return 0x1B; case "Backspace": return 0x08; case "Delete": return 0x2E;
      case "ArrowLeft": return 0x25; case "ArrowUp": return 0x26; case "ArrowRight": return 0x27; case "ArrowDown": return 0x28;
      case "Space": return 0x20; case "Home": return 0x24; case "End": return 0x23; case "PageUp": return 0x21; case "PageDown": return 0x22;
    }
    if (key.Length >= 2 && key[0] == 'F') { int f; if (int.TryParse(key.Substring(1), out f) && f >= 1 && f <= 12) return (ushort)(0x6F + f); }
    if (key.Length == 1) { char c = char.ToUpperInvariant(key[0]); if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) return c; }
    return 0;
  }
  static string Restore(IntPtr before) { Thread.Sleep(150); if (before != IntPtr.Zero) Front(before); return ""; }
  static void Combo(string key, string[] mods) {
    ushort vk = Vk(key);
    if (vk == 0) throw new Exception("모르는 키: " + key);
    var held = new List<ushort>();
    foreach (var m in mods) {
      ushort mv = m == "shift" ? (ushort)0x10 : (m == "ctrl" || m == "cmd") ? (ushort)0x11 : m == "alt" ? (ushort)0x12 : (ushort)0;
      if (mv != 0) { Key(mv, true); held.Add(mv); }
    }
    Key(vk, true); Key(vk, false);
    held.Reverse();
    foreach (var mv in held) Key(mv, false);
  }
  static void KeysTo(AutomationElement e, string key, string[] mods) {
    IntPtr before = GetForegroundWindow();
    IntPtr h = TopHandle(e);
    if (!Front(h)) throw new Exception("그 창을 앞으로 가져오지 못해 키를 보내지 못했습니다.");
    try { e.SetFocus(); } catch { }
    Thread.Sleep(80);
    Combo(key, mods);
    if (before != h) Restore(before);
  }
  static void TypeInto(AutomationElement e, string text) {
    IntPtr before = GetForegroundWindow();
    IntPtr h = TopHandle(e);
    if (!Front(h)) throw new Exception("그 창을 앞으로 가져오지 못해 글을 넣지 못했습니다.");
    e.SetFocus();
    Thread.Sleep(80);
    Combo("a", new[] { "ctrl" }); // 칸의 글을 바꾼다(맥 setText 와 같게)
    foreach (char ch in text) Uni(ch == '\n' ? '\r' : ch);
    if (before != h) Restore(before);
  }

  // 클립보드에 담은 파일을 그 칸에 붙여넣기(Ctrl+V) — 카카오톡 등에 사진 보내기(2026-11-11). 그 창을 잠깐 앞으로 가져왔다가 되돌린다
  public static string PasteRef(string r) {
    var e = Ref(r);
    if (e == null) return STALE;
    try { KeysTo(e, "V", new[] { "ctrl" }); return "{\"ok\":true}"; } catch (Exception x) { return Err(x.Message); }
  }

  public static string KeyApp(string app, string key, string[] mods) {
    var w = FindWindow(app);
    if (w == null) return Err("그 앱 창을 찾지 못했습니다.");
    try { KeysTo(w, key, mods); return "{\"ok\":true}"; } catch (Exception x) { return Err(x.Message); }
  }

  // 앱 켜기: 프로그램 이름(excel·notepad 등) → 시작 메뉴 바로 가기 이름
  public static string Open(string app) {
    string want = app.Trim(), proc;
    if (alias.TryGetValue(want, out proc)) want = proc;
    var dirs = new[] { Environment.GetFolderPath(Environment.SpecialFolder.CommonStartMenu), Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), Environment.GetFolderPath(Environment.SpecialFolder.Desktop), Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory) };
    foreach (var d in dirs) {
      try {
        foreach (var f in Directory.GetFiles(d, "*.lnk", SearchOption.AllDirectories)) {
          var n = Path.GetFileNameWithoutExtension(f);
          if (n.IndexOf(app.Trim(), StringComparison.OrdinalIgnoreCase) >= 0 || n.IndexOf(want, StringComparison.OrdinalIgnoreCase) >= 0) {
            Process.Start(new ProcessStartInfo(f) { UseShellExecute = true });
            return "{\"ok\":true,\"app\":" + J(n) + "}";
          }
        }
      } catch { }
    }
    try { Process.Start(new ProcessStartInfo(want) { UseShellExecute = true }); return "{\"ok\":true,\"app\":" + J(want) + "}"; }
    catch { return Err("\"" + app + "\" 프로그램을 찾지 못했습니다. 시작 메뉴에 보이는 이름으로 다시 해 보세요."); }
  }

  // ── 나. 그림으로만 보이는 창(칸이 안 읽힐 때): 창 사진 · 사진 자리 누르기 · 글자 치기 ──
  [StructLayout(LayoutKind.Sequential)] public struct WRECT { public int left, top, right, bottom; }
  [StructLayout(LayoutKind.Sequential)] public struct WPOINT { public int x, y; }
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out WRECT r);
  [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
  [DllImport("user32.dll")] static extern bool GetCursorPos(out WPOINT p);
  [DllImport("user32.dll")] static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] static extern IntPtr GetWindowDpiAwarenessContext(IntPtr h);
  [DllImport("user32.dll")] static extern int GetAwarenessFromDpiAwarenessContext(IntPtr c);
  [DllImport("user32.dll")] static extern uint GetDpiForSystem();
  // 화면 배율을 모르는 옛 프로그램은 PrintWindow 가 배율 전 크기로 찍는다 → 찍힌 만큼만 잘라 창 자리와 맞춘다
  static double UnawareScale(IntPtr h) {
    try {
      if (GetAwarenessFromDpiAwarenessContext(GetWindowDpiAwarenessContext(h)) != 0) return 1.0;
      uint dpi = GetDpiForSystem();
      return dpi > 96 ? 96.0 / dpi : 1.0;
    } catch { return 1.0; }
  }

  static IntPtr Handle(string app, out string proc, out string title) {
    proc = ""; title = "";
    var w = FindWindow(app);
    if (w == null) return IntPtr.Zero;
    try { proc = ProcName(w.Current.ProcessId); title = w.Current.Name; return new IntPtr(w.Current.NativeWindowHandle); } catch { return IntPtr.Zero; }
  }
  static bool MostlyBlack(Bitmap b) {
    int dark = 0, n = 0;
    for (int i = 1; i <= 10; i++) for (int j = 1; j <= 10; j++) {
      var c = b.GetPixel(b.Width * i / 11, b.Height * j / 11); n++;
      if (c.R < 8 && c.G < 8 && c.B < 8) dark++;
    }
    return dark > n * 9 / 10;
  }
  public static string Shot(string app) {
    string proc, title;
    IntPtr h = Handle(app, out proc, out title);
    if (h == IntPtr.Zero) return Err("그 앱 창을 찾지 못했습니다. win_apps 로 켜져 있는 창을 보세요.");
    if (IsIconic(h)) { ShowWindow(h, 4); Thread.Sleep(300); } // 접힌 창은 앞으로 가져오지 않고 펼친다
    WRECT r; GetWindowRect(h, out r);
    int W = r.right - r.left, H = r.bottom - r.top;
    if (W <= 0 || H <= 0) return Err("창 크기를 알 수 없습니다.");
    using (var bmp = new Bitmap(W, H)) {
      using (var g = Graphics.FromImage(bmp)) {
        IntPtr dc = g.GetHdc();
        bool ok = PrintWindow(h, dc, 2); // 뒤에 가려진 창도 찍는다(PW_RENDERFULLCONTENT)
        g.ReleaseHdc(dc);
        double us = ok ? UnawareScale(h) : 1.0;
        if (ok && us < 1.0) {
          int cw = Math.Max(1, (int)Math.Round(W * us)), ch = Math.Max(1, (int)Math.Round(H * us));
          using (var part = bmp.Clone(new Rectangle(0, 0, cw, ch), bmp.PixelFormat)) { g.Clear(Color.Black); g.DrawImage(part, new Rectangle(0, 0, W, H)); }
        }
        if (!ok || MostlyBlack(bmp)) g.CopyFromScreen(r.left, r.top, 0, 0, new Size(W, H)); // 못 찍는 창은 화면에 보이는 그대로
      }
      var enc = Array.Find(ImageCodecInfo.GetImageEncoders(), e => e.MimeType == "image/jpeg");
      // 도우미 통로는 한 번에 1MB 까지 — 크면 작게·흐리게 다시
      foreach (var t in new[] { new[] { 1280, 70 }, new[] { 1000, 55 }, new[] { 800, 45 } }) {
        double sc = Math.Min(1.0, (double)t[0] / Math.Max(W, H));
        int iw = Math.Max(1, (int)(W * sc)), ih = Math.Max(1, (int)(H * sc));
        using (var small = new Bitmap(bmp, iw, ih))
        using (var ms = new MemoryStream()) {
          var ps = new EncoderParameters(1); ps.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, (long)t[1]);
          small.Save(ms, enc, ps);
          string b64 = Convert.ToBase64String(ms.ToArray());
          if (b64.Length < 700000 || t[0] == 800)
            return "{\"ok\":true,\"app\":" + J(proc) + ",\"window\":" + J(title) + ",\"image\":\"" + b64 + "\",\"w\":" + iw + ",\"h\":" + ih + "}";
        }
      }
      return Err("사진을 만들지 못했습니다.");
    }
  }
  static void Mouse(uint flags, int data) {
    var i = new INPUT { type = 0 };
    i.u.mi = new MOUSEINPUT { dwFlags = flags, mouseData = data };
    SendInput(1, new[] { i }, Marshal.SizeOf(typeof(INPUT)));
  }
  public static string Tap(string app, double x, double y, double iw, double ih, double hold, double scroll) {
    string proc, title;
    IntPtr h = Handle(app, out proc, out title);
    if (h == IntPtr.Zero) return Err("그 앱 창을 찾지 못했습니다.");
    if (iw <= 0 || ih <= 0 || x < 0 || y < 0 || x > iw || y > ih) return Err("자리가 사진 밖입니다. win_look 으로 다시 보고 그 사진의 자리를 주세요.");
    WRECT r; GetWindowRect(h, out r);
    int px = r.left + (int)Math.Round(x * (r.right - r.left) / iw), py = r.top + (int)Math.Round(y * (r.bottom - r.top) / ih);
    IntPtr before = GetForegroundWindow();
    WPOINT old; GetCursorPos(out old);
    if (!Front(h)) return Err("그 창을 앞으로 가져오지 못해 누르지 못했습니다.");
    Thread.Sleep(120);
    SetCursorPos(px, py); Thread.Sleep(40);
    if (scroll != 0) {
      int left = (int)Math.Round(-scroll * 1.2); // 100픽셀 ≈ 바퀴 한 칸(120)
      while (left != 0) { int d = Math.Max(-360, Math.Min(360, left)); Mouse(0x0800, d); left -= d; Thread.Sleep(30); }
    } else {
      Mouse(0x0002, 0); Thread.Sleep(hold > 0 ? (int)Math.Min(hold * 1000, 5000) : 50); Mouse(0x0004, 0);
    }
    Thread.Sleep(150);
    SetCursorPos(old.x, old.y); // 마우스 자리 되돌림
    if (before != h && before != IntPtr.Zero) Front(before);
    return "{\"ok\":true}";
  }
  public static string ScreenType(string app, string text, string key, string[] mods) {
    string proc, title;
    IntPtr h = Handle(app, out proc, out title);
    if (h == IntPtr.Zero) return Err("그 앱 창을 찾지 못했습니다.");
    IntPtr before = GetForegroundWindow();
    if (!Front(h)) return Err("그 창을 앞으로 가져오지 못해 글을 넣지 못했습니다.");
    Thread.Sleep(120);
    try {
      if (!string.IsNullOrEmpty(key)) Combo(key, mods);
      if (!string.IsNullOrEmpty(text)) { Thread.Sleep(50); foreach (char ch in text) Uni(ch == '\n' ? '\r' : ch); }
    } catch (Exception x) { return Err(x.Message); }
    Thread.Sleep(150);
    if (before != h && before != IntPtr.Zero) Front(before);
    return "{\"ok\":true}";
  }

  public static void Init() { try { SetProcessDPIAware(); } catch { } }
}
'@
[KnockUia]::Init()
$out = [Console]::Out
$out.WriteLine('{"ok":true,"ready":true}'); $out.Flush()
while ($null -ne ($line = [Console]::In.ReadLine())) {
  $r = ''
  try {
    $m = $line | ConvertFrom-Json
    $mods = @(); if ($m.mods) { $mods = @($m.mods | ForEach-Object { [string]$_ }) }
    switch ([string]$m.op) {
      'apps' { $r = [KnockUia]::Apps() }
      'open' { $r = [KnockUia]::Open([string]$m.app) }
      'snapshot' { $lim = 300; if ($m.limit) { $lim = [int]$m.limit }; $r = [KnockUia]::Snapshot([string]$m.app, $lim) }
      'press' { $r = [KnockUia]::Press([string]$m.ref, [bool]$m.open) }
      'read' { $r = [KnockUia]::Read([string]$m.ref) }
      'setText' { $r = [KnockUia]::SetText([string]$m.ref, [string]$m.text, [bool]$m.submit, [bool]$m.allowSecure) }
      'pasteFiles' {
        $paths = @($m.paths | ForEach-Object { [string]$_ } | Where-Object { Test-Path -LiteralPath $_ })
        if ($paths.Count -eq 0) { $r = [KnockUia]::Err('붙여 넣을 파일이 없습니다.') }
        else {
          $old = $null; try { $old = Get-Clipboard -Raw -ErrorAction Stop } catch { }
          Set-Clipboard -LiteralPath $paths
          $r = [KnockUia]::PasteRef([string]$m.ref)
          Start-Sleep -Milliseconds 1500
          if ($old) { Set-Clipboard -Value $old }
        }
      }
      'key' { $r = [KnockUia]::KeyApp([string]$m.app, [string]$m.key, [string[]]$mods) }
      'shot' { $r = [KnockUia]::Shot([string]$m.app) }
      'tap' { $r = [KnockUia]::Tap([string]$m.app, [double]$m.x, [double]$m.y, [double]$m.iw, [double]$m.ih, [double]$m.hold, [double]$m.scroll) }
      'screenType' { $r = [KnockUia]::ScreenType([string]$m.app, [string]$m.text, [string]$m.key, [string[]]$mods) }
      default { $r = [KnockUia]::Err('모르는 명령') }
    }
  } catch { $r = [KnockUia]::Err([string]$_.Exception.Message) }
  $out.WriteLine($r); $out.Flush()
}
`;

const PS1 = path.join(os.tmpdir(), 'knock-desktop-win.ps1');
let proc = null;
let waiting = [];
let chain = Promise.resolve();
let ready = null;

function start() {
  if (proc) return ready;
  if (process.platform !== 'win32') throw new Error('윈도우 PC 가 아닙니다. 윈도우 앱은 윈도우 PC(원격 PC 탭)에서만 다룹니다.');
  fs.writeFileSync(PS1, `﻿${PS}`); // UTF-8(BOM) 이어야 PowerShell 이 한글을 깨뜨리지 않는다
  proc = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', PS1], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
  let errText = '';
  proc.stderr.on('data', (d) => { errText = `${errText}${d}`.slice(-2000); });
  ready = new Promise((resolve) => {
    let first = true;
    readline.createInterface({ input: proc.stdout }).on('line', (line) => {
      let r;
      try { r = JSON.parse(line.replace(/^﻿/, '')); } catch { r = { ok: false, error: '답을 읽지 못했습니다.' }; }
      if (first) { first = false; resolve(r.ok ? null : r.error); return; }
      waiting.shift()?.(r);
    });
    proc.on('exit', () => {
      if (first) resolve(`윈도우 앱 다루기 도구를 켜지 못했습니다: ${errText.trim().split('\n').slice(-3).join(' ') || '알 수 없음'}`);
      proc = null;
      for (const w of waiting.splice(0)) w({ ok: false, error: '윈도우 앱 다루기 도구가 멈췄습니다.' });
    });
  });
  return ready;
}

// 글은 \uXXXX 로 보낸다(콘솔 글자표가 달라도 한글이 깨지지 않게)
const ascii = (s) => s.replace(/[\u007f-￿]/g, (c) => `\\u${c.charCodeAt(0).toString(16).padStart(4, '0')}`);

function call(req, timeoutMs = 25000) {
  const run = () => new Promise((resolve) => {
    let startErr;
    try { startErr = start(); } catch (err) { resolve({ ok: false, error: err.message }); return; }
    Promise.resolve(startErr).then((bad) => {
      if (bad) { stop(); resolve({ ok: false, error: bad }); return; }
      const timer = setTimeout(() => {
        resolve({ ok: false, error: '앱이 답하지 않습니다(바쁘거나 멈춤).' });
        stop();
      }, timeoutMs);
      waiting.push((r) => { clearTimeout(timer); resolve(r); });
      proc.stdin.write(`${ascii(JSON.stringify(req))}\n`);
    });
  });
  const next = chain.then(run, run);
  chain = next.catch(() => {});
  return next;
}

function stop() {
  proc?.kill();
  proc = null;
}

module.exports = { call, stop, PS };
