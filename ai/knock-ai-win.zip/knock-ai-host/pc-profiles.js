// 이 PC 의 프로필 설정(2026-11-10 계정·프로필 기준안 — 피그마 ④).
// 프로필 목록(이름·색·PIN 잠금 여부)은 똑소리 계정(서버)에 있다. 여기는 이 PC 에만 해당하는 것만 둔다:
//   use        { 프로필번호: true|false }   이 PC 에서 쓸 프로필(체크)
//   noAsk      { 프로필번호: true }         잠긴 프로필이라도 이 PC 에서는 열 때 PIN 을 묻지 않음
//   peerNoAsk  { "가져가는번호>잠긴번호": true } 이 PC 에서 그 프로필 → 잠긴 프로필 내용 가져오기는 다시 묻지 않음
//   dirs       { 프로필번호: 브라우저 프로필 폴더 이름 }(예: "Profile 2")
//   picked     로그인 다음 "이 PC 에서 쓸 프로필"을 골랐음
// 모든 프로필의 도우미가 같은 파일(~/.knock/pc-profiles.json, 계정 이메일마다)을 함께 쓴다.
// 시험할 때는 KNOCK_PC_HOME 으로 ~/.knock 대신 다른 폴더를 써서 한 맥에서 PC 두 대처럼 돌린다(프로필 잇기 통로도 같이 — peers.js).
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

const IS_WIN = process.platform === 'win32';
const BASE = process.env.KNOCK_PC_HOME || path.join(os.homedir(), '.knock');
const FILE = path.join(BASE, 'pc-profiles.json');
const HANDOFF = path.join(BASE, 'handoff');
const UNLOCK = path.join(BASE, 'unlock');

const clean = (s) => String(s || '').toLowerCase().trim().slice(0, 200);
function readAll() {
  try { return JSON.parse(fs.readFileSync(FILE, 'utf8')) || {}; } catch { return {}; }
}
function writeAll(all) {
  fs.mkdirSync(BASE, { recursive: true, mode: 0o700 });
  const tmp = `${FILE}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(all, null, 1), { mode: 0o600 });
  fs.renameSync(tmp, FILE);
}
const empty = () => ({ use: {}, noAsk: {}, peerNoAsk: {}, dirs: {}, picked: false });

/** 계정(이메일)의 이 PC 설정 */
function get(account) {
  return { ...empty(), ...(readAll()[clean(account)] || {}) };
}
/** patch 의 칸만 덮어쓴다(use·noAsk·peerNoAsk·dirs 는 안의 값 하나씩 — null 이면 지움) */
function set(account, patch = {}) {
  const all = readAll();
  const key = clean(account);
  if (!key) throw new Error('로그인한 계정이 없습니다.');
  const cur = { ...empty(), ...(all[key] || {}) };
  for (const k of ['use', 'noAsk', 'peerNoAsk', 'dirs']) {
    if (!patch[k] || typeof patch[k] !== 'object') continue;
    for (const [id, v] of Object.entries(patch[k])) {
      if (!/^[\w>-]{1,80}$/.test(id)) continue;
      if (v === null || v === undefined || v === false && k !== 'use') delete cur[k][id];
      else cur[k][id] = k === 'dirs' ? String(v).slice(0, 80) : Boolean(v);
    }
  }
  if (typeof patch.picked === 'boolean') cur.picked = patch.picked;
  all[key] = cur;
  writeAll(all);
  return cur;
}

// ---------- 지금 이 브라우저(도우미를 띄운 Knock) ----------
// 도우미는 브라우저가 띄운다 — 위로 올라가며 Knock(크롬) 실행 파일과 --user-data-dir 를 찾는다.
let infoCache = null;
function processLine(pid) {
  if (IS_WIN) {
    const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command',
      `$p=Get-CimInstance Win32_Process -Filter "ProcessId=${Number(pid)}"; if($p){[Console]::Out.Write(\"$($p.ParentProcessId)\`n$($p.ExecutablePath)\`n$($p.CommandLine)\")}`],
    { encoding: 'utf8', timeout: 15000, windowsHide: true });
    const [ppid, exe, ...rest] = String(r.stdout || '').split('\n');
    return ppid ? { ppid: Number(ppid), exe: exe.trim(), cmd: rest.join('\n').trim() } : null;
  }
  const r = spawnSync('ps', ['-o', 'ppid=', '-o', 'command=', '-p', String(pid)], { encoding: 'utf8' });
  const m = /^\s*(\d+)\s+(.*)$/.exec(String(r.stdout || '').trim());
  if (!m) return null;
  const c = spawnSync('ps', ['-o', 'comm=', '-p', String(pid)], { encoding: 'utf8' });
  return { ppid: Number(m[1]), exe: String(c.stdout || '').trim(), cmd: m[2] };
}
function browserInfo() {
  if (infoCache) return infoCache;
  let pid = process.ppid;
  for (let i = 0; i < 4 && pid > 1; i++) {
    const p = processLine(pid);
    if (!p) break;
    const base = path.basename(p.exe).toLowerCase();
    if (/^(knock|chrome|chromium)(\.exe)?$/.test(base) && !/--type=/.test(p.cmd)) {
      // --user-data-dir=값(빈칸이 있을 수 있다 — 다음 " --" 앞까지)
      const m = /--user-data-dir=("([^"]+)"|(.+?))(?=\s--|\s*$)/.exec(p.cmd);
      const dataDir = m ? (m[2] || m[3]).trim() : '';
      infoCache = { exe: p.exe, dataDir, headless: /--headless/.test(p.cmd) };
      return infoCache;
    }
    pid = p.ppid;
  }
  return { exe: '', dataDir: '', headless: false };
}
function defaultDataDir() {
  if (IS_WIN) {
    // 윈도우 Knock 은 크롬 원본의 폴더 이름(Chromium)을 그대로 쓸 수 있다 — Local State 가 있는 쪽
    const base = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    const tries = ['Knock', 'Chromium'].map((n) => path.join(base, n, 'User Data'));
    return tries.find((d) => fs.existsSync(path.join(d, 'Local State'))) || tries[0];
  }
  return path.join(os.homedir(), 'Library', 'Application Support', 'Knock');
}
const dataDir = () => browserInfo().dataDir || defaultDataDir();

/** 이 PC 의 브라우저 프로필 [{ dir, name }] (Local State) */
function local() {
  try {
    const st = JSON.parse(fs.readFileSync(path.join(dataDir(), 'Local State'), 'utf8'));
    return Object.entries(st?.profile?.info_cache || {}).map(([dir, v]) => ({ dir, name: String(v?.name || '') }));
  } catch {
    return [];
  }
}
/** 이 확장이 자기 저장소에 적은 표(marker)를 찾아 그 프로필 폴더를 알아낸다(이름이 바뀌어도 맞다) */
function whereAmI(extId, marker) {
  if (!/^[a-p]{32}$/.test(String(extId)) || !/^[\w-]{16,64}$/.test(String(marker))) return { dir: '' };
  // Local State 에 아직 없는 새 프로필 폴더도 본다(처음 켜질 때는 목록에 늦게 들어간다)
  let dirs = local().map((l) => l.dir);
  try { dirs = [...new Set([...dirs, ...fs.readdirSync(dataDir()).filter((d) => fs.existsSync(path.join(dataDir(), d, 'Local Extension Settings')))])]; } catch {}
  for (const dir of dirs) {
    const folder = path.join(dataDir(), dir, 'Local Extension Settings', extId);
    let files = [];
    try { files = fs.readdirSync(folder).filter((f) => f.endsWith('.log')); } catch { continue; }
    for (const f of files) {
      try { if (fs.readFileSync(path.join(folder, f)).includes(marker)) return { dir }; } catch {}
    }
  }
  return { dir: '' };
}
/** 새 프로필 폴더 이름(겹치지 않게) */
function newDir() {
  const have = new Set(local().map((p) => p.dir));
  let n = 1;
  let dir;
  do dir = `Knock ${n++}`; while (have.has(dir) || fs.existsSync(path.join(dataDir(), dir)));
  return dir;
}

/** 그 프로필의 창을 연다(없는 폴더면 브라우저가 새 프로필로 만든다). 이미 켜진 Knock 에 넘겨져 새 창만 열린다. */
function open(dir, url) {
  if (!/^[\w .-]{1,80}$/.test(String(dir || ''))) throw new Error('프로필 폴더 이름이 맞지 않습니다.');
  const info = browserInfo();
  if (!info.exe) throw new Error('Knock Browser 실행 파일을 찾지 못했습니다.');
  const args = [];
  if (info.dataDir) args.push(`--user-data-dir=${info.dataDir}`);
  if (info.headless) args.push('--headless=new');
  args.push(`--profile-directory=${dir}`);
  if (url) args.push(String(url));
  const child = spawn(info.exe, args, { detached: true, stdio: 'ignore', windowsHide: false });
  child.on('error', () => {});
  child.unref();
  return { dir };
}

// ---------- 새로 만든 프로필에 로그인 넘기기 ----------
// 만든 쪽이 장치 열쇠를 받아 파일(이 사용자만 읽음)에 두고, 새 프로필이 처음 켜질 때 한 번 가져간다(10분 안).
function rmOld(dir, ms) {
  try {
    for (const f of fs.readdirSync(dir)) {
      const p = path.join(dir, f);
      if (Date.now() - fs.statSync(p).mtimeMs > ms) fs.rmSync(p, { force: true });
    }
  } catch {}
}
function handoffPut(data) {
  fs.mkdirSync(HANDOFF, { recursive: true, mode: 0o700 });
  rmOld(HANDOFF, 10 * 60 * 1000);
  const nonce = crypto.randomBytes(18).toString('base64url');
  fs.writeFileSync(path.join(HANDOFF, `${nonce}.json`), JSON.stringify(data), { mode: 0o600 });
  return { nonce };
}
/** nonce 로, 또는 프로필 폴더(dir)·이름이 같은 것으로 가져간다(가져가면 지운다) */
function handoffTake({ nonce, name, dir }) {
  rmOld(HANDOFF, 10 * 60 * 1000);
  let files = [];
  try { files = fs.readdirSync(HANDOFF); } catch { return null; }
  for (const f of files) {
    const p = path.join(HANDOFF, f);
    let d = null;
    try { d = JSON.parse(fs.readFileSync(p, 'utf8')); } catch { continue; }
    if ((nonce && f === `${String(nonce).replace(/[^\w-]/g, '')}.json`) || (!nonce && dir && d.dir === dir) || (!nonce && !dir && name && d.name === name)) {
      fs.rmSync(p, { force: true });
      return d;
    }
  }
  return null;
}

// ---------- 다른 프로필에서 PIN 을 넣고 연 프로필: 그 프로필이 켜질 때 한 번 "열림"으로 ----------
function unlockPut(pid) {
  fs.mkdirSync(UNLOCK, { recursive: true, mode: 0o700 });
  fs.writeFileSync(path.join(UNLOCK, `${String(pid).replace(/[^\w-]/g, '')}.json`), JSON.stringify({ at: Date.now() }), { mode: 0o600 });
  return { ok: true };
}
function unlockTake(pid) {
  const p = path.join(UNLOCK, `${String(pid).replace(/[^\w-]/g, '')}.json`);
  try {
    const d = JSON.parse(fs.readFileSync(p, 'utf8'));
    fs.rmSync(p, { force: true });
    return Date.now() - d.at < 2 * 60 * 1000;
  } catch {
    return false;
  }
}

module.exports = { get, set, local, whereAmI, newDir, open, browserInfo, handoffPut, handoffTake, unlockPut, unlockTake, BASE };
