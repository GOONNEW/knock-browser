// 맥 키체인 넣기·꺼내기(2026-11-18 원장님 "키체인 허락은 그렇게 해"): Knock 서명 도우미(bin/knock-desktop)가 맡는다.
// 맥 기본 도구(security)로 넣은 항목은 같은 사용자의 어떤 프로그램이든 묻지 않고 꺼낼 수 있었다. 도우미가 만든 항목은
// 허락 목록에 도우미만 있어, 다른 프로그램이 꺼내려 하면 맥이 "허용할까요?"를 묻는다.
// 예전 항목(security 로 넣은 것)은 처음 꺼낼 때 security 로 읽어 지운 뒤 도우미로 다시 넣는다(옮기기). 값은 base64 로 담는다.
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const desktop = require('./desktop');

// 도우미로 옮긴 항목 목록(값 없음, 이름만) — 옮긴 항목을 security 로 읽으려 하면 맥이 사용자에게 물으므로 다시 보지 않는다
const MOVED = process.env.KNOCK_TEST_KEYCHAIN ? `${process.env.KNOCK_TEST_KEYCHAIN}.moved.json` : path.join(os.homedir(), '.knock', 'kc-moved.json');
function moved() { try { return JSON.parse(fs.readFileSync(MOVED, 'utf8')); } catch { return {}; } }
function mark(key, on) {
  const m = moved();
  if (on) m[key] = 1; else delete m[key];
  fs.mkdirSync(path.dirname(MOVED), { recursive: true, mode: 0o700 });
  fs.writeFileSync(MOVED, JSON.stringify(m), { mode: 0o600 });
}

// 시험할 때만: 따로 만든 키체인 파일(사용자 키체인을 건드리지 않게)
const TEST_KC = process.env.KNOCK_TEST_KEYCHAIN || '';
const kcArgs = TEST_KC ? [TEST_KC] : [];

function why(status, stderr) {
  return /interaction is not allowed|locked/i.test(stderr || '') ? '맥 키체인이 잠겨 있음(화면 잠금 중일 수 있음)' : `키체인 오류 ${status ?? '시간 초과'}`;
}

// 예전 방식(security) — 옮기기에만 쓴다
function legacyGet(service, account) {
  const r = spawnSync('security', ['find-generic-password', '-s', service, '-a', account, '-w', ...kcArgs], { encoding: 'utf8', timeout: 10000 });
  if (r.status === 44) return null;
  if (r.status !== 0) throw new Error(why(r.status, r.stderr));
  return r.stdout.trim();
}
function legacyDel(service, account) {
  spawnSync('security', ['delete-generic-password', '-s', service, '-a', account, ...kcArgs], { encoding: 'utf8' });
}

function set(service, account, b64) {
  if (!moved()[`${service}|${account}`]) legacyDel(service, account); // 예전 항목이 남아 있으면 지운다
  const r = desktop.callSync({ op: 'kcSet', service, account, value: b64, keychain: TEST_KC });
  if (!r.ok) throw new Error(r.error || '키체인에 저장하지 못했습니다.');
  mark(`${service}|${account}`, true);
}

/** base64 값 또는 null. 아직 옮기지 않은 항목은 예전 방식으로 읽어 도우미로 옮긴다 */
function get(service, account) {
  const key = `${service}|${account}`;
  if (!moved()[key]) {
    const old = legacyGet(service, account);
    if (old) {
      legacyDel(service, account);
      set(service, account, old);
      return old;
    }
  }
  const r = desktop.callSync({ op: 'kcGet', service, account, keychain: TEST_KC });
  if (!r.ok) throw new Error(r.error || '키체인 오류');
  return r.found ? r.value : null;
}

function remove(service, account) {
  const key = `${service}|${account}`;
  if (!moved()[key]) legacyDel(service, account);
  desktop.callSync({ op: 'kcDel', service, account, keychain: TEST_KC });
  mark(key, false);
}

module.exports = { set, get, remove };
