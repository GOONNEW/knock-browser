// 윈도우 원격 PC 제어 — 관리자 권한 통로(2026-11-13 이든치과: 경리스퀘어처럼 관리자 권한으로 도는 프로그램이 맨 앞에 있으면
// 윈도우가 보통 권한인 조작 프로그램의 마우스·키보드를 조용히 버렸다. 보통 권한으로는 맨 앞 창을 바꾸지도 못했다(11.20.66 "바꾸지 못함")).
// 그래서 그 PC 에서 한 번만 관리자 허락을 받아, 관리자 권한으로 도는 작은 통로(RELAY)를 윈도우 예약 작업으로 등록한다.
// 조작 프로그램(input-win.js)은 그 통로에 "이 입력을 일으켜 줘"만 보내고, 통로는 받은 그대로 SendInput 만 한다.
// - 통로 파일은 C:\ProgramData\KnockBrowserRemote 에 두고 관리자만 고칠 수 있게 한다(보통 권한 프로그램이 바꿔 치기 못하게).
// - 통로는 일을 거의 하지 않으므로 바뀔 일이 적다. 바꾸면 RELAY_VER 를 올린다 — 조작 프로그램이 옛 판을 보면 허락을 다시 묻는다.
const RELAY_VER = 1;

const RELAY = String.raw`# Knock Browser 원격 PC 제어 — 관리자 권한 통로(ver ${RELAY_VER}). 받은 입력을 그대로 일으키기만 한다.
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class KnockRelay {
  [StructLayout(LayoutKind.Sequential)] struct MOUSEINPUT { public int dx, dy; public int mouseData; public uint dwFlags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Sequential)] struct KEYBDINPUT { public ushort wVk, wScan; public uint dwFlags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Explicit)] struct UNION { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
  [StructLayout(LayoutKind.Sequential)] struct INPUT { public uint type; public UNION u; }
  [DllImport("user32.dll", SetLastError = true)] static extern uint SendInput(uint n, INPUT[] inputs, int size);
  [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr c);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  public static void Init() { try { if (!SetProcessDpiAwarenessContext(new IntPtr(-4))) SetProcessDPIAware(); } catch { SetProcessDPIAware(); } }
  // 한 줄: "m,dx,dy,data,flags" 또는 "k,vk,scan,flags" 를 ; 로 이은 것 — 한 번에 SendInput
  public static uint Do(string line) {
    var parts = line.Split(';');
    var a = new INPUT[parts.Length]; int n = 0;
    foreach (var p in parts) {
      var f = p.Split(',');
      if (f[0] == "m" && f.Length == 5) { a[n].type = 0; a[n].u.mi.dx = int.Parse(f[1]); a[n].u.mi.dy = int.Parse(f[2]); a[n].u.mi.mouseData = int.Parse(f[3]); a[n].u.mi.dwFlags = uint.Parse(f[4]); n++; }
      else if (f[0] == "k" && f.Length == 4) { a[n].type = 1; a[n].u.ki.wVk = ushort.Parse(f[1]); a[n].u.ki.wScan = ushort.Parse(f[2]); a[n].u.ki.dwFlags = uint.Parse(f[3]); n++; }
    }
    if (n == 0) return 0;
    if (n < a.Length) Array.Resize(ref a, n);
    return SendInput((uint)n, a, Marshal.SizeOf(typeof(INPUT)));
  }
}
'@
[KnockRelay]::Init()
$me = [Security.Principal.WindowsIdentity]::GetCurrent()
$sid = $me.User.Value
$high = ([Security.Principal.WindowsPrincipal]$me).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
# 통로 이름에 사용자 번호를 넣어 다른 사용자와 섞이지 않게. 그 사용자와 시스템만 쓸 수 있게.
# (권한 표시는 따로 달지 않는다 — 다는 데 특별 권한이 들고, 안 달면 윈도우가 보통 권한으로 여겨 조작 프로그램이 쓸 수 있다)
$name = "knock-input-$sid"
while ($true) {
  $sec = New-Object System.IO.Pipes.PipeSecurity
  $sec.SetSecurityDescriptorSddlForm("D:(A;;GA;;;$sid)(A;;GA;;;SY)")
  try { $srv = New-Object System.IO.Pipes.NamedPipeServerStream($name, [System.IO.Pipes.PipeDirection]::InOut, 1, [System.IO.Pipes.PipeTransmissionMode]::Byte, [System.IO.Pipes.PipeOptions]::None, 4096, 4096, $sec) }
  catch { exit 2 } # 이미 다른 통로가 떠 있다
  try {
    $srv.WaitForConnection()
    $w = New-Object System.IO.StreamWriter($srv); $w.AutoFlush = $true
    $w.WriteLine("knock-relay ${RELAY_VER} " + $(if ($high) { 'admin' } else { 'user' }))
    $r = New-Object System.IO.StreamReader($srv)
    while ($null -ne ($line = $r.ReadLine())) { try { [void][KnockRelay]::Do($line) } catch { } }
  } catch { } finally { try { $srv.Dispose() } catch { } }
}
`;

// 관리자 허락을 받은 뒤 한 번 도는 설치(관리자 권한). -Sid: 원격 조작을 받는 사용자, -Src: 통로 글이 적힌 임시 파일, -Out: 결과 적을 곳
const SETUP = String.raw`param([string]$Sid, [string]$Src, [string]$Out)
$ErrorActionPreference = 'Stop'
function Done($t) { try { Set-Content -LiteralPath $Out -Value $t -Encoding UTF8 } catch { } }
try {
  $dir = Join-Path $env:ProgramData 'KnockBrowserRemote'
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  # 관리자·시스템만 고칠 수 있고 사용자는 읽기만(상속 끊음)
  $acl = New-Object System.Security.AccessControl.DirectorySecurity
  $acl.SetSecurityDescriptorSddlForm('O:BAG:BAD:PAI(A;OICI;FA;;;BA)(A;OICI;FA;;;SY)(A;OICI;0x1200a9;;;BU)')
  Set-Acl -LiteralPath $dir -AclObject $acl
  $dst = Join-Path $dir 'relay.ps1'
  Copy-Item -LiteralPath $Src -Destination $dst -Force
  $facl = New-Object System.Security.AccessControl.FileSecurity
  $facl.SetSecurityDescriptorSddlForm('O:BAG:BAD:PAI(A;;FA;;;BA)(A;;FA;;;SY)(A;;0x1200a9;;;BU)')
  Set-Acl -LiteralPath $dst -AclObject $facl
  $user = (New-Object System.Security.Principal.SecurityIdentifier($Sid)).Translate([System.Security.Principal.NTAccount]).Value
  $svc = New-Object -ComObject Schedule.Service; $svc.Connect()
  $root = $svc.GetFolder('\')
  try { $folder = $root.GetFolder('KnockBrowser') } catch { $folder = $root.CreateFolder('KnockBrowser') }
  $def = $svc.NewTask(0)
  $def.RegistrationInfo.Description = 'Knock Browser 원격 PC 제어: 관리자 권한 창에도 원격 마우스·키보드가 닿게 합니다.'
  $def.Principal.UserId = $user
  $def.Principal.LogonType = 3   # 로그인한 그 사용자 화면에서
  $def.Principal.RunLevel = 1    # 관리자 권한
  $def.Settings.Enabled = $true
  $def.Settings.Hidden = $true
  $def.Settings.ExecutionTimeLimit = 'PT0S'
  $def.Settings.DisallowStartIfOnBatteries = $false
  $def.Settings.StopIfGoingOnBatteries = $false
  $def.Settings.MultipleInstances = 2   # 이미 돌면 또 켜지 않음
  $def.Settings.Priority = 4
  $t = $def.Triggers.Create(9); $t.UserId = $user   # 로그인할 때 켬
  $a = $def.Actions.Create(0)
  $a.Path = Join-Path $env:SystemRoot 'System32\conhost.exe'
  $a.Arguments = '--headless "' + (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') + '" -NoProfile -ExecutionPolicy Bypass -File "' + $dst + '"'
  # 그 사용자는 읽고 켜기만(보통 권한 조작 프로그램이 켤 수 있게)
  $task = $folder.RegisterTaskDefinition('RemoteInput', $def, 6, $null, $null, 3, "D:(A;;FA;;;BA)(A;;FA;;;SY)(A;;GRGX;;;$Sid)")
  try { $task.Stop(0) } catch { }
  [void]$task.Run($null)
  Done ('ok ' + $user)
} catch { Done ('fail ' + (($_.Exception.Message) -replace '\s+', ' ')) }
`;

module.exports = { RELAY, SETUP, RELAY_VER };
