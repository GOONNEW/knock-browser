#!/usr/bin/env node
// Knock 브라우저의 AI 도우미(확장 프로그램)와 이 컴퓨터의 Claude Code 를 잇는 도우미 프로그램.
// 브라우저가 "네이티브 메시징"으로 이 프로그램을 띄우고, 표준 입출력으로 이야기한다(4바이트 길이 + JSON).
//
//   확장 → 여기: send(대화 보내기) · add(일하는 중에 덧붙이기) · stop · forget · status · login · toolResult
//               updateCheck · updateInstall(설치하고 다시 켜기 — 확장이 탭·대화를 저장한 뒤 보낸다)
//               login · logout · setKey · removeKey (AI 서비스 연결 설정 — provider: claude·chatgpt·gemini) · init(확장이 실행할 수 있는 도구 목록)
//               chromeProfiles · chromeBookmarks (크롬 북마크 읽기 — reqId 로 답한다) · feedback(개선 요청 저장)
//               peerAsk(다른 프로필에 묻기 — reqId 로 답한다) · peerRes(다른 프로필이 물은 것에 대한 이 확장의 답)
//               readFileChunk · saveDownloadChunk(다른 컴퓨터 잇기 — 받은 파일 보내기·가져온 파일 쓰기)
//               scheduleDrop(예약 취소 — 보관한 첨부 지우기) · scheduleSync(남은 예약 번호 — 나머지 보관 파일 지우기)
//   여기 → 확장: peerReq(다른 프로필이 이 프로필에 묻는 것)
//   여기 → 확장: started · text · delivered · done · error · status · tool(페이지 조작 요청)
//               update(바뀐 부분 목록) · updateFailed · settingsResult
//
// Claude Code 는 MCP 서버(mcp.js)로 페이지 도구를 쓴다. mcp.js 는 이 프로그램의 작은 HTTP 서버로 요청을 보내고,
// 이 프로그램이 확장에 넘겨 실제 탭에서 실행한 결과를 돌려준다.
// 개인용: 사용자가 직접 로그인한 Claude Code(본인 플랜)를 쓴다. 다른 사람에게 배포하려면 따로 승인·방식이 필요하다.
const { spawn, spawnSync, execFile } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const http = require('http');
const os = require('os');
const path = require('path');
const { toBlocks, cleanOldAttachments } = require('./attachments');
const { SYSTEM } = require('./prompt');
const { IS_WIN, winSetClipboard, winGetClipboard, winChrome, winEdge, downloadsDir } = require('./platform');
// 보호 영상 넘기기용 브라우저(2026-11-10)
const EXTERNAL = {
  chrome: { mac: 'Google Chrome', win: () => winChrome() },
  edge: { mac: 'Microsoft Edge', win: () => winEdge() },
};
// 넷플릭스 창(Knock Browser Video, castlabs Electron + EVS 서명) 실행 파일 — 앱 안(설치판) → 설치된 Knock → 개발 폴더 순
// 윈도우의 실제 CPU(x64·arm64). Knock 윈도우는 x64 하나라 ARM PC 에서는 흉내 내기로 돌고,
// 이 도우미(node x64)도 process.arch·PROCESSOR_ARCHITECTURE 가 x64(AMD64)로 속는다 → 시스템 설정(레지스트리)을 본다.
let winArchCache = null;
function winArch() {
  if (winArchCache) return winArchCache;
  let a = '';
  try {
    const r = require('child_process').spawnSync('reg', ['query', 'HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment', '/v', 'PROCESSOR_ARCHITECTURE'], { encoding: 'utf8', windowsHide: true, timeout: 5000 });
    a = (String(r.stdout || '').match(/PROCESSOR_ARCHITECTURE\s+REG_SZ\s+(\S+)/i) || [])[1] || '';
  } catch {}
  a = a || process.env.PROCESSOR_ARCHITEW6432 || process.env.PROCESSOR_ARCHITECTURE || process.arch;
  winArchCache = /arm64|aarch64/i.test(a) ? 'arm64' : /amd64|x64/i.test(a) ? 'x64' : 'other';
  return winArchCache;
}
// 넷플릭스 창(Knock Browser Video, castlabs Electron + EVS 서명) 실행 파일 — 앱 안(설치판) → 설치된 Knock → 개발 폴더 순.
// 윈도우는 컴퓨터 방식에 맞는 창만 넷플릭스가 받아 준다(2026-11-10): knock-video\x64 · knock-video\arm64. 맞는 것이 없으면 null(넷플릭스는 Knock 안에서).
function videoApp() {
  if (IS_WIN) {
    const arch = winArch();
    if (arch !== 'x64' && arch !== 'arm64') return null;
    const exe = 'Knock Browser Video.exe';
    const dirs = [path.join(__dirname, '..', 'knock-video', arch),
      path.join(__dirname, '..', '..', 'knock-video', 'dist', arch === 'arm64' ? 'win-arm64-unpacked' : 'win-unpacked')];
    return dirs.map((d) => path.join(d, exe)).find((p) => fs.existsSync(p)) || null;
  }
  const exe = path.join('Knock Browser Video.app', 'Contents', 'MacOS', 'Knock Browser Video');
  const dirs = [path.join(__dirname, '..', 'knock-video'), '/Applications/Knock.app/Contents/Resources/knock-video', path.join(__dirname, '..', '..', 'knock-video', 'dist', 'mac-arm64')];
  return dirs.map((d) => path.join(d, exe)).find((p) => fs.existsSync(p)) || null;
}
function openVideo(url, cookies) {
  const exe = videoApp();
  if (!exe) return false;
  const args = [`--url=${url}`];
  if (Array.isArray(cookies) && cookies.length) {
    // 로그인 정보는 나만 읽을 수 있는 임시 파일로 넘기고, 넷플릭스 창이 읽자마자 지운다(1분 뒤 남아 있으면 여기서 지운다)
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'knock-video-'));
    const file = path.join(dir, 'c.json');
    fs.writeFileSync(file, JSON.stringify(cookies.slice(0, 200)), { mode: 0o600 });
    args.push(`--cookies=${file}`);
    setTimeout(() => fs.rmSync(dir, { recursive: true, force: true }), 60000).unref?.();
  }
  // 넷플릭스 창의 출력은 ~/.knock/video.log 에(안 열릴 때 까닭 찾기)
  let out = 'ignore';
  try { out = fs.openSync(path.join(HOME, 'video.log'), 'a'); } catch {}
  const child = require('child_process').spawn(exe, args, { detached: true, stdio: ['ignore', out, out] });
  if (typeof out === 'number') fs.closeSync(out);
  log('넷플릭스 창 띄움', exe, 'pid', child.pid);
  child.on('error', (e) => log('넷플릭스 창 못 엶', e.message));
  child.on('exit', (code, sig) => log('넷플릭스 창 꺼짐', code, sig || ''));
  child.unref();
  return true;
}
function externalBrowsers() {
  return (videoApp() ? ['video'] : []).concat(Object.keys(EXTERNAL).filter((k) => {
    if (IS_WIN) return Boolean(EXTERNAL[k].win());
    const name = EXTERNAL[k].mac + '.app';
    return [path.join('/Applications', name), path.join(os.homedir(), 'Applications', name)].some((p) => fs.existsSync(p));
  }));
}
// 윈도우판은 설치판일 때(knock-release.json 이 있을 때)만 GitHub 의 새 판으로 업데이트한다 — release-update-win.js
const winRelease = IS_WIN ? require('./release-update-win') : null;
const updater = IS_WIN
  ? { check: () => winRelease.parts(), isRelease: () => winRelease.isRelease(), install() { throw new Error('윈도우 개발판은 업데이트하지 않습니다.'); }, relaunch() {} }
  : require('./update');
const releaseUpdate = () => (IS_WIN ? winRelease : require('./release-update'));
const { PROVIDERS, statusOf, setKey, install, keychain, loginInBackground, setPolicy, allowed, mcpLinks, codexLinks } = require('./providers');
const chromeImport = require('./chromeImport');
const peers = require('./peers');
const shared = require('./shared-chats');
const vault = require('./vault');
const wallet = require('./wallet');
const remoteInput = require('./remote-input');
let remoteSeen = false; // 이번 원격 연결에서 조작을 받기 시작했는지(기록 한 번만)
// 원격 조작 프로그램의 기록·알림은 도우미가 켜질 때 한 번 걸어 둔다 — 예전엔 첫 조작 때 걸어서
// 그보다 먼저(화면 고르기 때) 켜진 프로그램의 시작·실패 기록이 버려졌다(2026-11-13)
function hookRemoteInput() {
  remoteInput.setOnDiag?.((text) => { log('원격 비밀번호 칸', text); post({ type: 'remoteDiag', text: String(text).slice(0, 300) }); });
  remoteInput.setOnBlocked?.((code) => {
    log('원격 조작 입력이 막힘(윈도우)', code);
    post({ type: 'remoteInputBlocked', code });
  });
  // 조작 프로그램이 꺼짐 — 기록하고 보는 쪽에 알린다(-2: 켜지지 못함)
  remoteInput.setOnExit?.((code, err, ms) => {
    if (++remoteExits > 3) return; // 계속 꺼지면 처음 몇 번만
    log('원격 조작 프로그램 꺼짐', `코드 ${code}`, `${ms}ms`, err || '');
    post({ type: 'remoteInputBlocked', code: -2 });
  });
  remoteInput.setOnNote?.((text) => log('원격 조작 확인', String(text).slice(0, 400)));
}
hookRemoteInput();
let remoteExits = 0; // 이번 원격 연결에서 조작 프로그램이 꺼진 횟수(기록은 처음 몇 번만)
const desktop = require('./desktop');
const pcProfiles = require('./pc-profiles');

const HOME = path.join(os.homedir(), '.knock');
const WORKSPACE = path.join(HOME, 'claude-workspace');
const LOG_FILE = path.join(HOME, 'host.log');
const MCP_SERVER = path.join(__dirname, 'mcp.js');
// 도구 하나를 기다리는 한도. 사용자에게 묻는 카드(허락·확인)는 5분까지 기다리므로 그보다 길게 둔다
// (2분이면 사용자가 허락을 누르기 전에 끊겨 '브라우저가 답하지 않았습니다'가 됐다 — 2026-11-04 민감정보 조회 시험).
const TOOL_TIMEOUT_MS = 7 * 60 * 1000;
const WAIT_TIMEOUT_MS = 270000; // wait until(최대 4분)
// 예약 작업의 첨부 파일: 예약을 취소할 때까지 여기 보관한다(일반 첨부는 일주일 뒤 지운다)
const SCHEDULE_DIR = path.join(HOME, 'schedules');
const MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', pdf: 'application/pdf', txt: 'text/plain', csv: 'text/csv', md: 'text/markdown', json: 'application/json', html: 'text/html', htm: 'text/html' };

function scheduleDirOf(id) {
  if (!/^[\w-]{1,40}$/.test(String(id))) throw new Error('예약 번호가 이상합니다.');
  return path.join(SCHEDULE_DIR, String(id));
}

// 보관한 첨부를 확장이 보내는 첨부와 같은 모양으로 읽는다
function scheduleFiles(id) {
  let names = [];
  try { names = fs.readdirSync(scheduleDirOf(id)); } catch { return []; }
  return names.map((name) => ({
    name,
    type: MIME[(name.split('.').pop() || '').toLowerCase()] || '',
    data: fs.readFileSync(path.join(scheduleDirOf(id), name)).toString('base64'),
  }));
}
// 확장이 init 으로 알려 주는, 실행할 수 있는 도구. init 을 안 보내는 옛 확장(0.3.x)은 read_url 이 없다.
// 똑소리 TR MCP(2026-11-11): 확장이 준 이 프로필의 Knock Browser 로그인 열쇠 → Claude 에 TR MCP 서버로 붙인다
let knockAcct = { token: '', origin: '', tr: true, hr: true };
// 똑소리 TR·HR MCP 주소(정해진 주소에만 열쇠를 보낸다). 시험 때만 KNOCK_TR_MCP_URL·KNOCK_HR_MCP_URL
function toksoriMcp(app) {
  // 2026-11-11 원장님: "똑소리 로그인하는 계정과 연결해야지, 똑소리 브라우저 계정을 연결하면 안 돼" — Knock Browser 계정 열쇠로는 붙이지 않는다.
  // 똑소리 사이트 계정으로 [연결]한 열쇠(grant)가 생기기 전까지 끈다.
  if (!knockAcct.grants?.[app]) return null;
  if (!knockAcct[app] || !/^[\w.-]{20,}$/.test(knockAcct.grants[app] || '')) return null;
  let url = process.env[`KNOCK_${app.toUpperCase()}_MCP_URL`] || '';
  if (!url) {
    try { const u = new URL(knockAcct.origin || 'https://hr.knocktools.com'); url = `${u.protocol}//${u.host.replace(/^(hr|tr)\./, `${app}.`)}/api/mcp`; } catch { return null; }
    if (url !== `https://${app}.knocktools.com/api/mcp`) return null;
  }
  return { url, token: knockAcct.grants[app] };
}
const trMcp = () => toksoriMcp('tr');
let extensionVersion = null; // init 을 보내지 않는 옛 확장이면 null
let extensionTools = ['get_page', 'screenshot', 'click', 'type_text', 'select_option', 'scroll', 'press_key', 'navigate',
  'go_back', 'list_tabs', 'open_tab', 'upload_file', 'answer_dialog', 'wait'];

fs.mkdirSync(HOME, { recursive: true });
function log(...args) {
  fs.appendFileSync(LOG_FILE, `[${new Date().toISOString()}] ${args.join(' ')}\n`);
}
process.on('uncaughtException', (err) => log('오류', err.stack || err));

// ---------- 확장과 주고받기 ----------
// 브라우저는 도우미가 보내는 글 한 개가 1MB 를 넘으면 도우미를 끊어 버린다(2026-11-11 맥 엑셀 창 사진 → "도우미 프로그램이 꺼졌습니다").
// 넘으면 끊기지 않게 그 답 대신 "너무 큼"을 보낸다.
const MAX_POST = 1000 * 1000;
function post(msg) {
  let body = Buffer.from(JSON.stringify(msg));
  if (body.length > MAX_POST) {
    log('보낼 글이 너무 큼', msg.type, body.length);
    if (msg.type !== 'reply' || !msg.reqId) return;
    body = Buffer.from(JSON.stringify({ type: 'reply', reqId: msg.reqId, error: `결과가 너무 커서(${Math.round(body.length / 1024)}KB) 보내지 못했습니다. 범위를 좁혀(사진은 작은 창, 표는 range·find) 다시 해 주세요.` }));
  }
  const head = Buffer.alloc(4);
  head.writeUInt32LE(body.length, 0);
  process.stdout.write(Buffer.concat([head, body]));
}

let inbox = Buffer.alloc(0);
process.stdin.on('data', (chunk) => {
  inbox = Buffer.concat([inbox, chunk]);
  while (inbox.length >= 4) {
    const len = inbox.readUInt32LE(0);
    if (inbox.length < 4 + len) break;
    const raw = inbox.subarray(4, 4 + len).toString('utf8');
    inbox = inbox.subarray(4 + len);
    let msg;
    try { msg = JSON.parse(raw); } catch { continue; }
    handle(msg).catch((err) => log('처리 오류', err.stack || err));
  }
});
// 브라우저가 닫히면 입력이 끊긴다. 돌고 있던 Claude 도 같이 끈다.
process.stdin.on('end', () => {
  for (const c of chats.values()) c.runner?.stop();
  for (const id of [...logins.keys()]) stopLogin(id);
  process.exit(0);
});

// ---------- AI 서비스 상태 ----------
async function allStatus() {
  const list = await Promise.all(Object.values(PROVIDERS).map(statusOf));
  return Object.fromEntries(list.map((x) => [x.id, x]));
}

// 확장에 보내는 상태. state: 하나라도 연결돼 있으면 ready
async function postStatus() {
  const providers = await allStatus();
  const ready = Object.values(providers).some((p) => p.ready);
  post({ type: 'status', state: ready ? 'ready' : 'login', providers });
}

// ---------- 페이지 도구 중계(mcp.js → 여기 → 확장) ----------
const TOKEN = crypto.randomBytes(24).toString('hex');
const waiting = new Map(); // callId → resolve
let callSeq = 1;

const control = http.createServer((req, res) => {
  const reply = (code, obj) => {
    res.writeHead(code, { 'content-type': 'application/json' });
    res.end(JSON.stringify(obj));
  };
  if (req.headers.authorization !== `Bearer ${TOKEN}` || req.method !== 'POST' || !['/call', '/ext'].includes(req.url)) {
    return reply(403, { error: 'forbidden' });
  }
  let body = '';
  req.on('data', (d) => { body += d; });
  req.on('end', async () => {
    try {
      const msg = JSON.parse(body);
      if (req.url === '/ext') {
        // 클로드 앱(바깥 MCP, mcp-ext.js): 이 브라우저의 AI 도구를 쓴다 — 탭은 확장이 대화마다 만든 작업 묶음에서
        if (msg.op === 'tools') return reply(200, { tools: extensionTools });
        const session = String(msg.session || '').slice(0, 80);
        if (!session) return reply(200, { content: '연결 번호가 없습니다.', isError: true });
        if (msg.op === 'task') { post({ type: 'extTask', session, title: String(msg.title || '').slice(0, 40) }); return reply(200, { content: '새 작업 묶음을 준비했습니다. 이제 navigate 로 사이트를 여세요.' }); }
        if (msg.op === 'bye') { post({ type: 'extBye', session }); return reply(200, { ok: true }); }
        return reply(200, await callTool(null, String(msg.name || ''), msg.input || {}, session));
      }
      const { owner, name, input } = msg;
      reply(200, await callTool(Number(owner), name, input || {}));
    } catch (err) {
      reply(200, { content: String(err.message || err), isError: true });
    }
  });
});
// 클로드 데스크톱 앱 설정 파일(맥 · 윈도우 — 스토어판은 Packages 아래)
function claudeDesktopConfig() {
  if (process.platform === 'darwin') return path.join(os.homedir(), 'Library', 'Application Support', 'Claude', 'claude_desktop_config.json');
  const plain = path.join(process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), 'Claude');
  if (fs.existsSync(plain)) return path.join(plain, 'claude_desktop_config.json');
  try {
    const pk = path.join(process.env.LOCALAPPDATA || '', 'Packages');
    const d = fs.readdirSync(pk).find((n) => /^Claude_/i.test(n));
    if (d) return path.join(pk, d, 'LocalCache', 'Roaming', 'Claude', 'claude_desktop_config.json');
  } catch {}
  return path.join(plain, 'claude_desktop_config.json');
}
const CLAUDE_APP_KEY = 'knock-browser';
function claudeAppLink(action) {
  const file = claudeDesktopConfig();
  const installed = fs.existsSync(path.dirname(file));
  let cfg = {};
  try { cfg = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (err) { if (err.code !== 'ENOENT') throw new Error('클로드 앱 설정 파일을 읽지 못했습니다.'); }
  const want = { command: process.execPath, args: [path.join(__dirname, 'mcp-ext.js')] };
  const cur = cfg.mcpServers?.[CLAUDE_APP_KEY];
  const linked = Boolean(cur && cur.args?.[0] === want.args[0]);
  if (action === 'status') return { installed, linked };
  if (!installed) return { installed, linked: false, error: '이 PC 에 클로드 앱이 없습니다. 클로드 앱을 먼저 설치해 주세요.' };
  if (action === 'connect') cfg.mcpServers = { ...(cfg.mcpServers || {}), [CLAUDE_APP_KEY]: want };
  else if (action === 'disconnect') { if (cfg.mcpServers) delete cfg.mcpServers[CLAUDE_APP_KEY]; }
  else return { installed, linked };
  if (fs.existsSync(file)) fs.copyFileSync(file, `${file}.knock-backup`);
  fs.writeFileSync(file, `${JSON.stringify(cfg, null, 2)}\n`);
  log('클로드 앱 연결', action);
  return { installed, linked: action === 'connect' };
}

// 클로드 앱 연결(2026-11-12): 바깥 MCP(mcp-ext.js)가 이 도우미를 찾도록 주소·열쇠를 이 사용자만 읽는 파일에 적는다.
// 프로필마다 도우미가 하나씩 뜨므로 파일도 하나씩 — 바깥 MCP 는 가장 최근에 쓴 프로필(창에 초점이 간 것)을 고른다.
const LINK_DIR = path.join(HOME, 'link');
const LINK_FILE = path.join(LINK_DIR, `${process.pid}.json`);
let linkProfile = '';
function writeLink() {
  if (!control.address()) return;
  try {
    fs.mkdirSync(LINK_DIR, { recursive: true, mode: 0o700 });
    fs.writeFileSync(LINK_FILE, JSON.stringify({ port: control.address().port, token: TOKEN, pid: process.pid, profile: linkProfile, at: Date.now() }), { mode: 0o600 });
  } catch (err) { log('클로드 앱 연결 파일 실패', err.message); }
}
function dropLink() { try { fs.unlinkSync(LINK_FILE); } catch {} }
control.listen(0, '127.0.0.1', writeLink);
process.on('exit', dropLink);

function callTool(tabId, name, input, ext = null) {
  const chat = ext ? null : chats.get(tabId);
  // 첨부 파일 이름 → 이 컴퓨터의 저장 경로(확장은 경로를 모른다)
  if ((name === 'upload_file' && !(input.device_files || []).length) || name === 'mac_paste_files' || name === 'win_paste_files') {
    const files = chat?.files || [];
    if (files.length === 0) return { content: '이 대화에서 첨부한 파일이 없습니다. 사용자에게 AI 창에 파일을 첨부해 달라고 하세요.', isError: true };
    const picked = [];
    for (const want of input.files || []) {
      const f = files.findLast((x) => x.name === want) || files.findLast((x) => x.name.toLowerCase() === String(want).toLowerCase());
      if (!f) return { content: `첨부 파일 중 "${want}" 가 없습니다. 있는 파일: ${[...new Set(files.map((x) => x.name))].join(', ')}`, isError: true };
      picked.push(f);
    }
    input = { ...input, files: picked.map((f) => f.name), paths: picked.map((f) => f.path) };
  }
  // 첨부한 HTML(보안메일 등)을 탭에 열기 — 이 대화에서 첨부한 파일만(확장은 경로를 모른다)
  if (name === 'open_attachment') {
    const files = chat?.files || [];
    const want = String(input.file || '');
    const f = files.findLast((x) => x.name === want) || files.findLast((x) => x.name.toLowerCase() === want.toLowerCase());
    if (!f) return { content: `첨부 파일 중 "${want}" 가 없습니다. 있는 파일: ${[...new Set(files.map((x) => x.name))].join(', ') || '없음'}`, isError: true };
    if (!/\.html?$/i.test(f.name)) return { content: 'HTML 파일(.html)만 탭에 열 수 있습니다.', isError: true };
    input = { file: f.name, url: require('url').pathToFileURL(f.path).href };
  }
  // 다른 대화(다른 탭·다른 프로필의 Knock AI, 옆창 Gemini) 찾아보기 — 도우미가 바로 답한다
  if (name === 'recall_conversations') {
    const list = shared.recent({ limit: input.limit || 5, query: input.query || '' });
    return { content: list.length ? `최근 대화(최근 것부터):\n${shared.describe(list, 1500)}` : '찾는 대화가 없습니다.' };
  }
  // 예약 작업: 고른 첨부를 예약 폴더에 복사해 둔다(확장은 파일 경로를 모른다)
  if (name === 'schedule_task') {
    const id = `${Date.now().toString(36)}${crypto.randomBytes(2).toString('hex')}`;
    const files = chat?.files || [];
    const kept = [];
    for (const want of input.files || []) {
      const f = files.findLast((x) => x.name === want) || files.findLast((x) => x.name.toLowerCase() === String(want).toLowerCase());
      if (!f) return { content: `첨부 파일 중 "${want}" 가 없습니다. 있는 파일: ${[...new Set(files.map((x) => x.name))].join(', ') || '없음'}`, isError: true };
      fs.mkdirSync(scheduleDirOf(id), { recursive: true, mode: 0o700 });
      fs.copyFileSync(f.path, path.join(scheduleDirOf(id), f.name));
      kept.push(f.name);
    }
    input = { ...input, id, files: [...new Set(kept)] };
  }
  const callId = callSeq++;
  post(ext ? { type: 'tool', callId, ext, name, input } : { type: 'tool', callId, tabId, name, input });
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      waiting.delete(callId);
      resolve({ content: `브라우저가 ${name === 'wait' ? Math.round(WAIT_TIMEOUT_MS / 60000) : 7}분 동안 답하지 않았습니다.`, isError: true });
    }, name === 'wait' ? WAIT_TIMEOUT_MS : TOOL_TIMEOUT_MS);
    waiting.set(callId, (result) => {
      clearTimeout(timer);
      resolve(result);
    });
  });
}

// 첨부를 Claude 가 읽을 형태로 바꾸고, 저장한 파일은 upload_file 용으로 기억한다.
async function prepare(tabId, text, files) {
  const chat = chatOf(tabId);
  const { blocks, saved, notes } = await toBlocks(files || []);
  for (const n of notes) post({ type: 'note', tabId, text: n });
  chat.files.push(...saved);
  const fileList = saved.length
    ? `\n\n[이번에 첨부한 파일: ${saved.map((f) => `${f.name}${f.secure ? '(잠긴 보안메일 — open_attachment 로 탭에 열기)' : f.readable ? '' : '(내용은 못 읽음)'}`).join(', ')} — 웹페이지에 올릴 때는 upload_file 에 이 이름을 씁니다]`
    : '';
  return { blocks, saved, text: `${text || '첨부한 자료를 봐 주세요.'}${fileList}` };
}

// ---------- 대화(탭마다 하나) ----------
// runner: 돌고 있는 AI(멈추기·덧붙이기). sessions: AI 서비스별 대화 번호(이어 말하기용).
// queue: 덧붙이기를 바로 넣을 수 없는 AI(ChatGPT·Gemini)일 때, 끝난 뒤 이어서 보낼 말.
const chats = new Map(); // tabId → { busy, runner, sessions, files, model, provider, queue }

function chatOf(tabId) {
  if (!chats.has(tabId)) chats.set(tabId, { busy: false, runner: null, sessions: {}, files: [], model: null, provider: 'claude', queue: [] });
  return chats.get(tabId);
}

async function send({ tabId, text, files, context, model, provider, sessions, sessionId, scheduleId }) {
  const chat = chatOf(tabId);
  if (scheduleId) files = [...(files || []), ...scheduleFiles(scheduleId)]; // 예약 작업: 보관한 첨부를 다시 붙인다
  if (chat.busy) return add({ tabId, text, files });  // (scheduleId 첨부는 위에서 이미 붙였다)
  chat.busy = true; // 첨부를 준비하는 사이에 온 말은 덧붙이기로
  // 확장이 기억해 둔 대화(도우미가 다시 켜졌을 때)
  if (sessions) chat.sessions = { ...sessions, ...chat.sessions };
  else if (sessionId && !chat.sessions.claude) chat.sessions.claude = sessionId;
  chat.provider = PROVIDERS[provider] ? provider : 'claude';
  chat.model = model || null;
  const prepared = await prepare(tabId, text, files);
  return start(tabId, [...prepared.blocks, { type: 'text', text: `${context || ''}${prepared.text}` }], prepared.saved);
}

// AI 가 일하는 중에 덧붙인 말: Claude 는 돌고 있는 대화에 진짜 사용자 말로 바로 넣고(다음 단계에 반영),
// 그렇게 못 하는 AI 는 지금 일이 끝나면 이어서 새 요청으로 보낸다.
async function add({ tabId, text, files, scheduleId }) {
  const chat = chatOf(tabId);
  if (scheduleId) files = [...(files || []), ...scheduleFiles(scheduleId)];
  const prepared = await prepare(tabId, text, files);
  const content = [...prepared.blocks, { type: 'text', text: prepared.text }];
  // 일하는 중에 넣는 말에는 이어서 하라는 메모를 붙인다(2026-11-05: 9개 중 8개를 공감한 뒤 "했어?"에
  // "아직 안 했어요"라며 처음부터 다시 했다). 진행을 묻는 말이면 지금까지 한 것을 알리고 남은 일을 이어 간다.
  const live = [...prepared.blocks, { type: 'text', text: `[사용자가 당신이 일하는 중에 덧붙인 말입니다. 지금까지 이 대화에서 한 일(도구 결과)을 그대로 이어 가세요 — 처음부터 다시 하지 마세요. "했어?"처럼 진행을 묻는 말이면 지금까지 한 것과 남은 것을 한두 줄로 알리고 남은 일을 계속합니다]\n${prepared.text}` }];
  if (chat.runner?.inject?.(live)) return;
  if (chat.busy) {
    chat.queue.push({ content, saved: prepared.saved });
    return;
  }
  chat.busy = true;
  return start(tabId, content, prepared.saved);
}

async function start(tabId, content, saved = []) {
  const chat = chatOf(tabId);
  const p = PROVIDERS[chat.provider];
  post({ type: 'started', tabId });
  const status = await statusOf(p);
  if (!status.ready) {
    postStatus();
    post({ type: 'error', tabId, message: !status.installed
      ? `${p.name} 프로그램을 찾지 못했습니다. ${p.install}`
      : `${p.name} 가 연결돼 있지 않습니다. AI 창 위의 ⚙︎ 설정에서 계정 로그인이나 API 키를 연결해 주세요.` });
    chat.busy = false;
    post({ type: 'done', tabId, sessions: chat.sessions });
    return;
  }
  fs.mkdirSync(WORKSPACE, { recursive: true });
  const key = status.via === 'api' ? await keychain.get(p.keyService) : null;
  const mcp = {
    command: process.execPath,
    args: [MCP_SERVER],
    env: { KNOCK_CONTROL: `http://127.0.0.1:${control.address().port}`, KNOCK_TOKEN: TOKEN, KNOCK_OWNER: String(tabId), KNOCK_TOOLS: extensionTools.join(',') },
  };
  const finish = (error, stopped) => {
    chat.runner = null;
    if (stopped) post({ type: 'note', tabId, text: '멈췄습니다.' });
    else if (error) post({ type: 'error', tabId, message: error });
    // 끝나기 전에 덧붙인 말이 남아 있으면 이어서 보낸다
    if (chat.queue.length && chats.get(tabId) === chat) {
      const queued = chat.queue.splice(0);
      post({ type: 'delivered', tabId });
      start(tabId, queued.flatMap((q) => q.content), queued.flatMap((q) => q.saved));
      return;
    }
    chat.busy = false;
    post({ type: 'done', tabId, sessions: chat.sessions });
  };
  // MCP 연결(피그마·노션 — Claude · ChatGPT): 연결된 것만 넘긴다
  const linker = { claude: mcpLinks, chatgpt: codexLinks }[p.id];
  const { links, hide } = linker ? await linker.forRun().catch(() => ({ links: [], hide: [] })) : { links: [], hide: [] };
  try {
    chat.runner = p.run({
      tabId, content, files: saved, key, mcp, cwd: WORKSPACE, system: SYSTEM,
      sessionId: chat.sessions[p.id] || null,
      model: chat.model,
      links, hide, tr: trMcp(), hr: toksoriMcp('hr'),
    }, {
      note: (text) => post({ type: 'note', tabId, text }),
      // ChatGPT 가 연결 서비스 도구를 쓰기 전에 묻는 것 → Claude 와 같은 Knock 확인 카드
      approve: (toolName, input) => callTool(tabId, 'approve_remote', { tool_name: toolName, input }),
      text: (delta, fresh) => post({ type: 'text', tabId, delta, fresh }),
      session: (id) => { chat.sessions[p.id] = id; },
      delivered: () => post({ type: 'delivered', tabId }),
      done: finish,
    });
  } catch (err) {
    finish(err.message);
  }
}

// ---------- 로그인(터미널 창 없이) ----------
// 로그인 명령을 뒤에서 돌리고(로그인 페이지는 브라우저로 열림), 2초마다 로그인됐는지 보다가 되면 닫는다. 5분까지.
const logins = new Map(); // provider → { child, timer }

function stopLogin(id) {
  const l = logins.get(id);
  if (!l) return;
  clearInterval(l.timer);
  l.child.kill('SIGTERM');
  logins.delete(id);
}

function startLogin(p) {
  stopLogin(p.id);
  const command = p.loginCommand();
  if (!command) {
    post({ type: 'settingsResult', provider: p.id, ok: false, message: `${p.name} 프로그램을 찾지 못했습니다. ${p.install}` });
    return;
  }
  const child = loginInBackground(command, {
    // loginInKnock: Knock 탭에서 열고, 로그인 뒤 넘어오는 코드 주소(codeUrl)를 확장이 지켜본다
    url: (url) => post({ type: 'loginUrl', provider: p.id, url, openInKnock: Boolean(p.loginInKnock), codeUrl: p.codeUrl || null }),
  });
  const until = Date.now() + 5 * 60 * 1000;
  const timer = setInterval(async () => {
    const account = await p.account().catch(() => ({}));
    if (account.loggedIn) {
      stopLogin(p.id);
      post({ type: 'settingsResult', provider: p.id, ok: true, message: `${p.name} 에 ${account.email || ''} 계정으로 연결됐습니다.`.replace('  ', ' ') });
      postStatus();
    } else if (Date.now() > until) {
      stopLogin(p.id);
      post({ type: 'settingsResult', provider: p.id, ok: false, message: '5분 안에 로그인이 끝나지 않아 멈췄습니다. 다시 "로그인"을 눌러 주세요.' });
    }
  }, 2000);
  logins.set(p.id, { child, timer });
  child.on('close', () => {
    // 로그인 프로그램이 먼저 끝났으면 한 번 더 확인하고 정리
    setTimeout(async () => {
      if (!logins.has(p.id) || logins.get(p.id).child !== child) return;
      const account = await p.account().catch(() => ({}));
      stopLogin(p.id);
      post({ type: 'settingsResult', provider: p.id, ok: Boolean(account.loggedIn), message: account.loggedIn ? `${p.name} 에 연결됐습니다.` : '로그인이 끝나지 않았습니다. 다시 "로그인"을 눌러 주세요.' });
      postStatus();
    }, 1500);
  });
}

// 맥 앱 창 사진이 크면 맥 기본 도구(sips)로 줄이고 흐리게 다시 만든다(자리 계산은 사진 크기 비율이라 그대로 맞음)
function shrinkShot(r) {
  if (IS_WIN || r.image.length < 700 * 1024) return;
  const tmp = path.join(os.tmpdir(), `knock-shot-${process.pid}-${Date.now()}`);
  try {
    fs.writeFileSync(`${tmp}.jpg`, Buffer.from(r.image, 'base64'));
    for (const [dim, q] of [[1600, 60], [1280, 50], [960, 45]]) {
      spawnSync('sips', ['-Z', String(dim), '-s', 'format', 'jpeg', '-s', 'formatOptions', String(q), `${tmp}.jpg`, '--out', `${tmp}-s.jpg`], { stdio: 'ignore' });
      const b = fs.readFileSync(`${tmp}-s.jpg`).toString('base64');
      const info = spawnSync('sips', ['-g', 'pixelWidth', '-g', 'pixelHeight', `${tmp}-s.jpg`], { encoding: 'utf8' }).stdout || '';
      const w = Number(/pixelWidth:\s*(\d+)/.exec(info)?.[1]);
      const h = Number(/pixelHeight:\s*(\d+)/.exec(info)?.[1]);
      if (w && h) { r.image = b; r.w = w; r.h = h; }
      if (b.length < 700 * 1024) break;
    }
  } catch (err) {
    log('창 사진 줄이기 실패', err.message);
  } finally {
    for (const f of [`${tmp}.jpg`, `${tmp}-s.jpg`]) try { fs.unlinkSync(f); } catch {}
  }
}

async function handle(msg) {
  switch (msg.type) {
    case 'knockAccount':
      knockAcct = { token: '', origin: String(msg.origin || ''), tr: msg.tr !== false, hr: msg.hr !== false, grants: msg.grants && typeof msg.grants === 'object' ? { tr: String(msg.grants.tr || ''), hr: String(msg.grants.hr || '') } : {} };
      return;
    case 'send':
      return send(msg);
    case 'add':
      return add(msg);
    case 'loginCancel':
      stopLogin(msg.provider);
      return;
    case 'loginCode': {
      // 확장이 로그인 탭 주소에서 읽어 온 인증 코드를 기다리고 있는 로그인 프로그램에 넣는다
      const l = logins.get(msg.provider);
      if (l && /^[\w./~-]+$/.test(String(msg.code))) l.child.stdin.write(`${msg.code}\r`);
      return;
    }
    case 'stop':
      if (chats.get(msg.tabId)?.runner) log('멈춤 요청', msg.tabId, msg.by || '?');
      chats.get(msg.tabId)?.runner?.stop();
      return;
    case 'scheduleDrop':
      try { fs.rmSync(scheduleDirOf(msg.id), { recursive: true, force: true }); } catch {}
      return;
    case 'scheduleSync': { // 확장에 남아 있는 예약 말고는 보관 파일을 지운다(취소했는데 남은 것)
      const keep = new Set((msg.ids || []).map(String));
      let dirs = [];
      try { dirs = fs.readdirSync(SCHEDULE_DIR); } catch {}
      // 방금 만들어 아직 확장에 저장되기 전일 수 있는 것(10분 안)은 남긴다
      for (const d of dirs) {
        const st = fs.statSync(path.join(SCHEDULE_DIR, d), { throwIfNoEntry: false });
        if (!keep.has(d) && st && Date.now() - st.mtimeMs > 10 * 60 * 1000) fs.rmSync(path.join(SCHEDULE_DIR, d), { recursive: true, force: true });
      }
      return;
    }
    case 'forget': { // 새 대화 또는 탭 닫힘
      const c = chats.get(msg.tabId);
      c?.runner?.stop();
      chats.delete(msg.tabId);
      return;
    }
    case 'init':
      if (Array.isArray(msg.tools)) extensionTools = msg.tools.map(String);
      extensionVersion = msg.version || null;
      // 판(개발용·배포판)에 따라 서비스별로 켠 연결 방법
      setPolicy(msg.policy || null);
      postStatus();
      checkUpdate(true);
      log('확장 연결', msg.version || '?', extensionTools.length, '개 도구');
      return;
    case 'status':
      return postStatus();
    case 'linkFocus':
      // 이 프로필 창에 초점이 갔다 — 클로드 앱이 이 프로필을 고르게
      if (typeof msg.profile === 'string') linkProfile = msg.profile.slice(0, 40);
      writeLink();
      return;
    case 'setClipboard':
      // 서식 있는 글(HTML)과 글자만 있는 글을 맥 클립보드에 함께 넣는다(붙여넣기 도구용)
      if (IS_WIN) {
        try {
          winSetClipboard(String(msg.html || ''), String(msg.text || ''));
          post({ type: 'reply', reqId: msg.reqId });
        } catch (err) {
          post({ type: 'reply', reqId: msg.reqId, error: `클립보드에 넣지 못했습니다: ${err.message}` });
        }
        return;
      }
      try {
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'knock-clip-'));
        fs.writeFileSync(path.join(dir, 'h'), String(msg.html || ''), { mode: 0o600 });
        fs.writeFileSync(path.join(dir, 't'), String(msg.text || ''), { mode: 0o600 });
        const js = `ObjC.import('AppKit'); const read = (n) => $.NSString.stringWithContentsOfFileEncodingError('${dir}/' + n, $.NSUTF8StringEncoding, null);
          const pb = $.NSPasteboard.generalPasteboard; pb.clearContents;
          ${msg.html ? "pb.setStringForType(read('h'), 'public.html');" : ''} pb.setStringForType(read('t'), 'public.utf8-plain-text'); 'ok'`;
        execFile('osascript', ['-l', 'JavaScript', '-e', js], (err) => {
          fs.rmSync(dir, { recursive: true, force: true });
          post({ type: 'reply', reqId: msg.reqId, ...(err ? { error: `클립보드에 넣지 못했습니다: ${err.message}` } : {}) });
        });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    case 'getClipboard':
      // 원격: 이 PC 에서 복사한 것을 보는 쪽 맥으로 넘기려고 읽는다(2026-11-13 "원격지에서 복사했는데 이 맥에서 붙여넣기가 안 돼")
      if (IS_WIN) {
        try { post({ type: 'reply', reqId: msg.reqId, ...(await winGetClipboard()) }); } catch (err) { post({ type: 'reply', reqId: msg.reqId, error: err.message }); }
        return;
      }
      execFile('osascript', ['-l', 'JavaScript', '-e', `ObjC.import('AppKit'); const pb = $.NSPasteboard.generalPasteboard;
        const s = (t) => { const v = pb.stringForType(t); return v.isNil() ? '' : v.js; };
        JSON.stringify({ text: s('public.utf8-plain-text'), html: s('public.html') })`], { maxBuffer: 20 * 1024 * 1024 }, (err, out) => {
        let r = {};
        try { r = JSON.parse(out); } catch {}
        post({ type: 'reply', reqId: msg.reqId, text: String(r.text || ''), html: String(r.html || ''), ...(err ? { error: err.message } : {}) });
      });
      return;
    // 다른 컴퓨터 잇기: 이 컴퓨터가 받은 파일을 조금씩 읽어 보낸다(확장↔도우미 한 번에 1MB 한도).
    // 확장은 브라우저 다운로드 목록에 있는 파일 경로만 넘긴다.
    case 'readFileChunk':
      try {
        const st = fs.statSync(msg.path);
        if (!st.isFile()) throw new Error('파일이 아닙니다.');
        if (st.size > 30 * 1024 * 1024) throw new Error('30MB 보다 큰 파일은 가져올 수 없습니다.');
        const fd = fs.openSync(msg.path, 'r');
        const buf = Buffer.alloc(Math.max(0, Math.min(600 * 1024, st.size - (msg.offset || 0))));
        fs.readSync(fd, buf, 0, buf.length, msg.offset || 0);
        fs.closeSync(fd);
        post({ type: 'reply', reqId: msg.reqId, size: st.size, b64: buf.toString('base64') });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    // 다른 컴퓨터에서 가져온 파일을 이 컴퓨터 다운로드 폴더에 쓴다(같은 이름이 있으면 (1)·(2)… 붙임)
    case 'saveDownloadChunk':
      try {
        let file = msg.file;
        if (!file) {
          const dir = downloadsDir();
          fs.mkdirSync(dir, { recursive: true });
          const safe = path.basename(String(msg.name || '받은 파일')).replace(/[\\/:*?"<>|]/g, '_') || '받은 파일';
          const ext = path.extname(safe);
          const stem = safe.slice(0, safe.length - ext.length);
          file = path.join(dir, safe);
          for (let i = 1; fs.existsSync(file); i++) file = path.join(dir, `${stem} (${i})${ext}`);
          fs.writeFileSync(file, '');
        }
        if (!path.resolve(file).startsWith(path.resolve(downloadsDir()) + path.sep)) throw new Error('다운로드 폴더 밖에는 쓰지 않습니다.');
        fs.appendFileSync(file, Buffer.from(msg.b64 || '', 'base64'));
        post({ type: 'reply', reqId: msg.reqId, file, name: path.basename(file) });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    // 폴더 안 파일 다루기(2026-11-07 "폴더 내 PNG 지우고 파일명 뒤에 날짜 넣어줘"): 폴더 찾기 · 이름 바꾸기 · 휴지통
    // 다운로드·바탕화면·사진·문서(OneDrive 포함) 안에서만. 지우기는 휴지통으로(되살릴 수 있게).
    case 'folderFiles':
    case 'fileRename':
    case 'fileTrash':
      try {
        const home = require('os').homedir();
        const roots = [downloadsDir(), ...['Desktop', 'Pictures', 'Documents'].map((d) => path.join(home, d)), ...['Desktop', '바탕 화면', 'Pictures', '사진', 'Documents', '문서'].map((d) => path.join(home, 'OneDrive', d))];
        const inRoots = (p) => { const r = path.resolve(p); return roots.some((x) => r.startsWith(path.resolve(x) + path.sep)); };
        if (msg.type === 'folderFiles') {
          // folder: "output" 같은 이름이나 "Downloads/output" 같은 길. 이름이 같은 폴더가 여럿이면 names(안에 있다고 알려 준 파일)가 많이 맞는 것 → 최근 것
          const want = String(msg.folder || '').replace(/[\\/]+$/, '');
          const cands = [];
          const direct = path.isAbsolute(want) ? want : path.join(home, want);
          if (want && fs.existsSync(direct) && fs.statSync(direct).isDirectory() && inRoots(path.join(direct, 'x'))) cands.push(direct);
          if (!cands.length && want) {
            const base = path.basename(want).toLowerCase();
            const walk = (dir, depth) => {
              let list = [];
              try { list = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
              for (const d of list) {
                if (!d.isDirectory() || d.name.startsWith('.')) continue;
                const full = path.join(dir, d.name);
                if (d.name.toLowerCase() === base) cands.push(full);
                if (depth < 3) walk(full, depth + 1);
              }
            };
            for (const r of [...new Set(roots)]) walk(r, 0);
          }
          if (!cands.length) throw new Error(`"${want}" 폴더를 다운로드·바탕화면·사진·문서에서 찾지 못했습니다.`);
          const names = new Set((msg.names || []).map(String));
          const score = (d) => { let n = 0; try { for (const f of fs.readdirSync(d)) if (names.has(f)) n++; } catch {} return n; };
          cands.sort((a, b) => score(b) - score(a) || fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
          const dir = cands[0];
          const files = fs.readdirSync(dir, { withFileTypes: true }).filter((d) => d.isFile() && !d.name.startsWith('.'))
            .map((d) => { const st = fs.statSync(path.join(dir, d.name)); return { path: path.join(dir, d.name), name: d.name, size: st.size, mtime: st.mtimeMs, folder: path.relative(home, dir) }; })
            .sort((a, b) => a.name.localeCompare(b.name, 'ko'));
          post({ type: 'reply', reqId: msg.reqId, dir, files, others: cands.slice(1, 4) });
        } else if (msg.type === 'fileRename') {
          const done = [];
          for (const it of msg.items || []) {
            const from = String(it.path || '');
            const name = String(it.newName || '');
            if (!inRoots(from) || !fs.existsSync(from)) throw new Error(`바꿀 수 없는 파일입니다: ${path.basename(from)}`);
            if (!name || name !== path.basename(name) || /[\\/:*?"<>|]/.test(name)) throw new Error(`새 이름이 올바르지 않습니다: ${name}`);
            const to = path.join(path.dirname(from), name);
            if (to !== from && fs.existsSync(to)) throw new Error(`같은 이름의 파일이 이미 있습니다: ${name}`);
            fs.renameSync(from, to);
            done.push({ from: path.basename(from), to: name, path: to });
          }
          post({ type: 'reply', reqId: msg.reqId, done });
        } else {
          const done = [];
          for (const f of msg.paths || []) {
            if (!inRoots(f) || !fs.existsSync(f) || !fs.statSync(f).isFile()) throw new Error(`지울 수 없는 파일입니다: ${path.basename(String(f))}`);
          }
          for (const f of msg.paths || []) {
            // 휴지통으로: 맥은 knock-desktop(trashItem), 윈도우는 휴지통 보내기(되살리기 가능)
            if (IS_WIN) {
              const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Add-Type -AssemblyName Microsoft.VisualBasic; [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile('${String(f).replace(/'/g, "''")}', 'OnlyErrorDialogs', 'SendToRecycleBin')`], { windowsHide: true });
              if (r.status !== 0) throw new Error(`휴지통으로 옮기지 못했습니다: ${path.basename(f)}`);
            } else {
              const r = await desktop.call({ op: 'trash', path: f });
              if (!r.ok) throw new Error(r.error || `휴지통으로 옮기지 못했습니다: ${path.basename(f)}`);
            }
            done.push(path.basename(f));
          }
          post({ type: 'reply', reqId: msg.reqId, done });
        }
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    // 엑셀 파일 보기 · DB 시트에 줄 더하기(2026-11-09 "여신금융협회 매입내역을 카드DB 시트에 새 것만 추가") — excel.js
    case 'excelRead':
    case 'excelPlan':
    case 'excelWrite':
    case 'excelUndo':
    case 'fileAlias':
      (async () => {
        try {
          const excel = require('./excel');
          const { type, reqId, ...a } = msg; // 확장의 askHost 는 값을 펼쳐 보낸다
          const r = msg.type === 'excelRead' ? await excel.read(a) : msg.type === 'excelPlan' ? await excel.plan(a) : msg.type === 'excelUndo' ? await excel.undo(a) : msg.type === 'fileAlias' ? await excel.fileAlias(a) : await excel.write(a);
          post({ type: 'reply', reqId: msg.reqId, ...r });
        } catch (err) {
          post({ type: 'reply', reqId: msg.reqId, error: err.message });
        }
      })();
      return;
    // 이 컴퓨터에 저장된 파일 목록(다운로드·바탕화면·사진·문서) — AI 가 페이지에 올릴 파일을 고를 때(2026-11-07 개선 요청 "원격지 장치에 저장된 이미지나 파일도")
    case 'listFiles':
      try {
        const home = require('os').homedir();
        const roots = {
          downloads: [downloadsDir()],
          desktop: [path.join(home, 'Desktop'), path.join(home, 'OneDrive', 'Desktop'), path.join(home, 'OneDrive', '바탕 화면')],
          pictures: [path.join(home, 'Pictures'), path.join(home, 'OneDrive', 'Pictures'), path.join(home, 'OneDrive', '사진')],
          documents: [path.join(home, 'Documents'), path.join(home, 'OneDrive', 'Documents'), path.join(home, 'OneDrive', '문서')],
        };
        const want = roots[msg.folder] ? [msg.folder] : Object.keys(roots);
        const q = String(msg.query || '').toLowerCase();
        const out = [];
        const walk = (dir, depth) => {
          let names = [];
          try { names = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
          for (const d of names) {
            if (d.name.startsWith('.') || /^desktop\.ini$|^thumbs\.db$/i.test(d.name)) continue;
            const full = path.join(dir, d.name);
            if (d.isDirectory()) { if (depth < 2) walk(full, depth + 1); continue; }
            if (!d.isFile() || (q && !full.toLowerCase().includes(q))) continue;
            try { const st = fs.statSync(full); out.push({ path: full, name: d.name, size: st.size, mtime: st.mtimeMs, folder: path.relative(home, dir) }); } catch {}
          }
        };
        for (const k of want) for (const dir of [...new Set(roots[k])]) walk(dir, 0);
        out.sort((a, b) => b.mtime - a.mtime);
        post({ type: 'reply', reqId: msg.reqId, files: out.slice(0, Math.min(Number(msg.limit) || 40, 100)) });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    // 다른 컴퓨터(연결한 쪽)에서 보낸 첨부 파일을 이 컴퓨터 임시 칸에 쓴다 — 페이지 파일 칸에 넣으려고(하루 지나면 지움)
    case 'saveUploadChunk':
      try {
        const dir = path.join(HOME, 'uploads');
        fs.mkdirSync(dir, { recursive: true });
        let file = msg.file;
        if (!file) {
          for (const f of fs.readdirSync(dir)) { try { if (Date.now() - fs.statSync(path.join(dir, f)).mtimeMs > 86400000) fs.rmSync(path.join(dir, f), { recursive: true, force: true }); } catch {} }
          const sub = path.join(dir, `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
          fs.mkdirSync(sub);
          file = path.join(sub, path.basename(String(msg.name || '파일')).replace(/[\\/:*?"<>|]/g, '_') || '파일');
          fs.writeFileSync(file, '');
        }
        if (!path.resolve(file).startsWith(path.resolve(dir) + path.sep)) throw new Error('임시 칸 밖에는 쓰지 않습니다.');
        fs.appendFileSync(file, Buffer.from(msg.b64 || '', 'base64'));
        post({ type: 'reply', reqId: msg.reqId, file });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    case 'peerAsk':
      // 이 프로필의 확장이 다른 프로필들에게 묻는다
      post({ type: 'reply', reqId: msg.reqId, results: await peers.ask(msg.op, msg.args || {}) });
      return;
    case 'peerRes': {
      const done = peerWaiting.get(msg.id);
      peerWaiting.delete(msg.id);
      done?.(msg.result ?? null);
      return;
    }
    case 'feedback': {
      // 개선 요청을 한 줄(JSON)씩 모은다. 개발할 때 읽고 고친다.
      const file = path.join(HOME, 'feedback.jsonl');
      fs.appendFileSync(file, `${JSON.stringify(msg.record)}\n`, { mode: 0o600 });
      log('개선 요청 저장', String(msg.record?.comment || '').slice(0, 40));
      return;
    }
    // 원격 그룹 잠금 비밀번호를 맥 지문(Touch ID)으로 열기(2026-11-07): 비밀번호는 맥 키체인에만 두고, 지문이 맞을 때만 꺼낸다
    case 'groupKey':
      try {
        const SERVICE = 'Knock 원격 그룹';
        const id = String(msg.id || '').replace(/[^A-Za-z0-9_-]/g, '');
        const sec = (line) => require('child_process').spawnSync('security', ['-i'], { input: `${line}\n`, encoding: 'utf8' });
        const read = () => {
          const r = require('child_process').spawnSync('security', ['find-generic-password', '-s', SERVICE, '-a', id, '-w'], { encoding: 'utf8' });
          return r.status === 0 ? Buffer.from(r.stdout.trim(), 'base64').toString('utf8') : '';
        };
        let out = {};
        if (process.platform !== 'darwin') out = { available: false };
        else if (msg.action === 'check') out = { available: Boolean((await desktop.call({ op: 'touchidCheck' })).available), has: id ? Boolean(read()) : false };
        else if (!id) throw new Error('그룹이 없습니다.');
        else if (msg.action === 'save') {
          const b64 = Buffer.from(String(msg.password || ''), 'utf8').toString('base64');
          if (sec(`add-generic-password -U -s "${SERVICE}" -a "${id}" -w ${b64}`).status !== 0) throw new Error('키체인에 저장하지 못했습니다.');
          out = { ok: true };
        } else if (msg.action === 'remove') {
          sec(`delete-generic-password -s "${SERVICE}" -a "${id}"`);
          out = { ok: true };
        } else if (msg.action === 'get') {
          if (!read()) throw new Error('지문으로 열기를 켜지 않은 그룹이에요.');
          const t = await desktop.call({ op: 'touchid', reason: String(msg.reason || 'Knock Browser 원격 그룹을 열어요') }, 65000);
          if (!t.ok) throw new Error(t.error || '지문을 확인하지 못했어요.');
          out = { ok: true, password: read() };
        }
        post({ type: 'reply', reqId: msg.reqId, ...out });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    // 계정·프로필 기준안(2026-11-10): 이 PC 에서 쓸 프로필·묻지 않음·프로필 창 열기·새 프로필에 로그인 넘기기
    case 'pcProfiles':
      try {
        const a = msg;
        const out = a.op === 'get' ? { pc: pcProfiles.get(a.account), local: pcProfiles.local() }
          : a.op === 'set' ? { pc: pcProfiles.set(a.account, a.patch || {}) }
            : a.op === 'open' ? pcProfiles.open(a.dir, a.url)
              : a.op === 'newDir' ? { dir: pcProfiles.newDir() }
                : a.op === 'handoffPut' ? pcProfiles.handoffPut(a.data || {})
                  : a.op === 'handoffTake' ? { data: pcProfiles.handoffTake(a) }
                    : a.op === 'unlockPut' ? pcProfiles.unlockPut(a.pid)
                      : a.op === 'unlockTake' ? { ok: pcProfiles.unlockTake(a.pid) }
                        : a.op === 'whereAmI' ? pcProfiles.whereAmI(a.extId, a.marker)
                        : a.op === 'fullPath' ? pcProfiles.fullPath(a.dir)
                        : a.op === 'deviceOf' ? pcProfiles.deviceOf(a.dir, a.extId)
                        : a.op === 'info' ? pcProfiles.browserInfo()
                          : null;
        if (!out) throw new Error('알 수 없는 요청입니다.');
        post({ type: 'reply', reqId: msg.reqId, ...out });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    // 잠긴 프로필 PIN 을 맥 지문(Touch ID)으로(2026-11-10): PIN 은 맥 키체인에만 두고, 지문이 맞을 때만 꺼낸다(원격 그룹 잠금과 같은 방식)
    case 'profileKey':
      try {
        const SERVICE = process.env.KNOCK_PC_HOME ? 'Knock 프로필 PIN 시험용' : 'Knock 프로필 PIN';
        const id = String(msg.id || '').replace(/[^A-Za-z0-9_-]/g, '');
        const sec = (line) => require('child_process').spawnSync('security', ['-i'], { input: `${line}\n`, encoding: 'utf8' });
        const read = () => {
          const r = require('child_process').spawnSync('security', ['find-generic-password', '-s', SERVICE, '-a', id, '-w'], { encoding: 'utf8' });
          return r.status === 0 ? Buffer.from(r.stdout.trim(), 'base64').toString('utf8') : '';
        };
        let out = {};
        if (process.platform !== 'darwin') out = { available: false };
        else if (msg.action === 'check') out = { available: Boolean((await desktop.call({ op: 'touchidCheck' })).available), has: id ? Boolean(read()) : false };
        else if (!id) throw new Error('프로필이 없습니다.');
        else if (msg.action === 'save') {
          const pin = String(msg.pin || '');
          if (!/^\d{6}$/.test(pin)) throw new Error('PIN 모양이 맞지 않습니다.');
          if (sec(`add-generic-password -U -s "${SERVICE}" -a "${id}" -w ${Buffer.from(pin).toString('base64')}`).status !== 0) throw new Error('키체인에 저장하지 못했습니다.');
          out = { ok: true };
        } else if (msg.action === 'remove') {
          sec(`delete-generic-password -s "${SERVICE}" -a "${id}"`);
          out = { ok: true };
        } else if (msg.action === 'get') {
          if (!read()) throw new Error('이 맥에서 지문으로 열기를 아직 쓸 수 없어요. PIN 을 한 번 넣어 주세요.');
          const t = await desktop.call({ op: 'touchid', reason: String(msg.reason || 'Knock Browser 잠긴 프로필을 열어요').slice(0, 120) }, 65000);
          if (!t.ok) throw new Error(t.error || '지문을 확인하지 못했어요.');
          out = { ok: true, pin: read() };
        }
        post({ type: 'reply', reqId: msg.reqId, ...out });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    // MCP 연결(설정 › MCP 연결 — 2026-11-07): 목록·로그인·연결 끊기·작업 방식
    case 'claudeApp': {
      // 설정 › MCP 연결 › 클로드 앱(2026-11-12): 클로드 데스크톱 앱 설정에 Knock Browser MCP(mcp-ext.js)를 넣고 뺀다
      const reply = (r) => post({ type: 'reply', reqId: msg.reqId, ...r });
      try { reply(claudeAppLink(String(msg.action || 'status'))); } catch (err) { reply({ error: err.message }); }
      return;
    }
    case 'mcp': {
      // 설정 › MCP 연결: 서비스마다 Claude·ChatGPT 연결을 따로 한다(연결 열쇠를 각 프로그램이 따로 둔다 — 2026-11-08)
      const reply = (r) => post({ type: 'reply', reqId: msg.reqId, ...r });
      const all = async (fresh) => ({
        available: mcpLinks.available() || codexLinks.available(),
        items: await mcpLinks.list(fresh).catch(() => []),
        gpt: { available: codexLinks.available(), items: await codexLinks.list(fresh).catch(() => []) },
        prefs: mcpLinks.prefs(),
      });
      try {
        const L = msg.ai === 'chatgpt' ? codexLinks : mcpLinks;
        const id = String(msg.id || '');
        if (msg.action === 'prefs') mcpLinks.setPrefs(msg.prefs);
        if (msg.action === 'logout' && L.available()) await L.logout(id);
        if (msg.action === 'login') {
          if (!L.available()) return reply({ ...(await all(false)), message: `${msg.ai === 'chatgpt' ? 'ChatGPT' : 'Claude'} 를 먼저 AI 사용 연동에서 연결해 주세요.` });
          await L.add(id);
          // 서비스 로그인 페이지는 Knock Browser 탭으로 열린다. 허용하면 그 프로그램이 열쇠를 받아 두고 끝난다(5분까지)
          // 허용해도 로그인 프로그램이 스스로 끝나지 않을 때가 있어(2026-11-07 피그마 — "연결 중…"에서 멈춤) 3초마다 연결됐는지 보고, 되면 끈다
          const ok = await new Promise((resolve) => {
            const child = loginInBackground(L.loginCommand(id), { url: (url) => { if (!L.opensItself()) post({ type: 'loginUrl', provider: `mcp-${id}`, url, openInKnock: true }); } });
            let over = false;
            const end = (v) => { if (over) return; over = true; clearInterval(poll); clearTimeout(timer); try { child.kill('SIGTERM'); } catch {} resolve(v); };
            const timer = setTimeout(() => end(false), 5 * 60 * 1000);
            const poll = setInterval(async () => { if ((await L.list(true).catch(() => [])).find((x) => x.id === id)?.connected) end(true); }, 3000);
            child.on('close', (code) => setTimeout(() => end(code === 0), 1500));
          });
          L.forget();
          const r = await all(true);
          const done = (msg.ai === 'chatgpt' ? r.gpt.items : r.items).find((x) => x.id === id)?.connected;
          return reply({ ...r, ...(done ? {} : { message: ok ? '연결을 확인하지 못했어요. 잠시 뒤 다시 확인해 주세요.' : '로그인이 끝나지 않았어요. 다시 [연결]을 눌러 주세요.' }) });
        }
        return reply(await all(msg.action === 'refresh' || msg.action === 'logout'));
      } catch (err) {
        return reply({ error: err.message });
      }
    }
    // 맥 앱 다루기(desktop.js): 접근성 정보로 맥 앱을 읽고 조작한다
    case 'desktop':
      try {
        const { type, reqId, ...req } = msg;
        const result = await desktop.call(req);
        if (result?.image) shrinkShot(result); // 큰 창(레티나 전체 화면 엑셀 등) 사진은 1MB 통로에 맞게 줄인다
        post({ type: 'reply', reqId, result });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    // 윈도우 앱 다루기(desktop-win.js, UI Automation) — 맥 desktop 과 같은 약속(2026-11-09)
    case 'winDesktop':
      try {
        const { type, reqId, ...req } = msg;
        post({ type: 'reply', reqId, result: await require('./desktop-win').call(req) });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    // Knock 원격(remote-input.js): 원격에서 받은 마우스·키보드 동작을 이 맥에 일으킨다
    case 'remoteInput':
      if (!remoteSeen) { remoteSeen = true; log('원격 조작 받기 시작', msg.ev?.t || ''); }
      try { remoteInput.send(msg.ev); } catch (err) { log('원격 조작 실패', err.message); }
      return;
    case 'remoteCheck':
      try {
        post({ type: 'reply', reqId: msg.reqId, ok: await remoteInput.check(!!msg.prompt) });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, ok: false, error: err.message });
      }
      return;
    case 'remoteDisplay':
      try { post({ type: 'reply', reqId: msg.reqId, id: await remoteInput.display(msg.w, msg.h, msg.label) }); } catch (err) { post({ type: 'reply', reqId: msg.reqId, error: err.message }); }
      return;
    case 'remoteDiagLog': {
      // 원격 점검 기록(2026-11-13): host.log 끝부분에서 원격 관련 줄과 최근 줄을 모아 보는 쪽에 보낸다
      let text = '';
      try {
        const st = fs.statSync(LOG_FILE);
        const fd = fs.openSync(LOG_FILE, 'r');
        const size = Math.min(st.size, 512 * 1024);
        const buf = Buffer.alloc(size);
        fs.readSync(fd, buf, 0, size, st.size - size);
        fs.closeSync(fd);
        const lines = buf.toString('utf8').split('\n').slice(size < st.size ? 1 : 0).filter(Boolean); // 중간부터 읽었으면 잘린 첫 줄은 뺀다
        const remoteLines = lines.filter((l) => /원격 조작|원격 비밀번호|도우미 시작|지난 업데이트 결과|확장 연결/.test(l)).slice(-60);
        text = [
          `[점검] ${new Date().toISOString()} · ${os.platform()} ${os.release()} · 도우미 ${process.pid} · 확장 ${msg.ext || '?'}`,
          '', '— 원격·시작 관련 줄 —', ...remoteLines,
          '', '— 마지막 40줄 —', ...lines.slice(-40),
        ].join('\n');
      } catch (err) {
        text = `기록 파일을 읽지 못했습니다: ${err.message}`;
      }
      post({ type: 'reply', reqId: msg.reqId, text });
      return;
    }
    case 'remoteStop':
      remoteSeen = false;
      remoteExits = 0;
      remoteInput.stop();
      return;
    // 사이트 로그인 기억(vault.js). 비밀번호는 기록(log)에 남기지 않는다.
    case 'vaultSave':
    case 'vaultGet':
    case 'vaultList':
    case 'vaultDelete':
      try {
        const out = msg.type === 'vaultSave' ? { site: vault.save(msg.url, msg.username, msg.password) }
          : msg.type === 'vaultGet' ? { login: vault.get(msg.url) }
            : msg.type === 'vaultList' ? { list: vault.list() }
              : (vault.remove(msg.site), {});
        post({ type: 'reply', reqId: msg.reqId, ...out });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    // 저장한 카드·계좌(wallet.js). 번호는 기록(log)에 남기지 않는다.
    case 'walletSave':
    case 'walletGet':
    case 'walletList':
    case 'walletDelete':
      try {
        const out = msg.type === 'walletSave' ? { id: wallet.save(msg.item || {}) }
          : msg.type === 'walletGet' ? { number: wallet.get(String(msg.id)) }
            : msg.type === 'walletList' ? { list: wallet.list() }
              : (wallet.remove(String(msg.id)), {});
        post({ type: 'reply', reqId: msg.reqId, ...out });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    case 'sharedAdd': // 모든 프로필·AI 가 함께 보는 대화 기록에 한 줄 더하기
      try { shared.add(msg.entry); } catch (err) { log('공유 대화 기록 실패', err.message); }
      return;
    case 'recoveredChats': // 브라우저를 다시 켜며 지워진 대화를 되살린 파일(~/.knock/recovered-chats.json)에서 이 프로필 몫을 한 번 넘긴다
      try {
        const file = path.join(os.homedir(), '.knock', 'recovered-chats.json');
        const all = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : {};
        const list = all[msg.profile] || [];
        if (list.length) {
          delete all[msg.profile];
          if (Object.keys(all).length) fs.writeFileSync(file, JSON.stringify(all), { mode: 0o600 });
          else fs.unlinkSync(file);
        }
        post({ type: 'reply', reqId: msg.reqId, list });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    case 'sharedRecent':
      try {
        const list = shared.recent(msg);
        post({ type: 'reply', reqId: msg.reqId, list, text: shared.describe(list, msg.answerLen || 600) });
      } catch (err) {
        post({ type: 'reply', reqId: msg.reqId, error: err.message });
      }
      return;
    case 'chromeProfiles':
    case 'chromeBookmarks':
      try {
        const data = msg.type === 'chromeProfiles' ? { profiles: chromeImport.listProfiles(), why: chromeImport.lastError() } : chromeImport.readProfile(String(msg.dir));
        // 맥 개인정보 보호가 크롬 폴더 읽기를 막으면(EPERM) 확장이 허용 방법·파일 가져오기를 안내한다
        if (data.why) {
          log('크롬 북마크 읽기 막힘', data.why);
          data.blocked = /EPERM|EACCES|not permitted/i.test(data.why);
        }
        const reply = { type: 'reply', reqId: msg.reqId, ...data };
        // 도우미 → 브라우저 메시지는 1MB 까지
        if (Buffer.byteLength(JSON.stringify(reply)) > 1000000) throw new Error('북마크가 너무 많아 한 번에 가져올 수 없습니다.');
        post(reply);
      } catch (err) {
        if (/EPERM|EACCES|not permitted/i.test(err.message)) log('크롬 북마크 읽기 막힘', err.message);
        post({ type: 'reply', reqId: msg.reqId, error: err.message, blocked: /EPERM|EACCES|not permitted/i.test(err.message) });
      }
      return;
    case 'logout':
    case 'setKey':
    case 'removeKey':
    case 'login': {
      // msg.provider: claude | chatgpt | gemini (옛 확장은 안 보냄 → claude)
      const p = PROVIDERS[msg.provider] || PROVIDERS.claude;
      // 이 판에서 꺼 둔 연결 방법은 쓰지 않는다
      const need = msg.type === 'login' || msg.type === 'logout' ? 'account' : 'apiKey';
      if (!allowed(p.id, need) && msg.type !== 'logout' && msg.type !== 'removeKey') {
        post({ type: 'settingsResult', provider: p.id, ok: false, message: `이 판에서는 ${p.name} ${need === 'account' ? '계정 연결' : 'API 키'}을 쓸 수 없습니다.` });
        return;
      }
      try {
        if (msg.type === 'login') return startLogin(p);
        if (msg.type === 'logout') await p.logout();
        if (msg.type === 'setKey') await setKey(p, String(msg.key || '').trim());
        if (msg.type === 'removeKey') await keychain.remove(p.keyService);
        post({ type: 'settingsResult', provider: p.id, ok: true, message: { logout: `${p.name} 계정 연결을 해제했습니다.`, setKey: `${p.name} API 키를 연결했습니다.`, removeKey: `${p.name} API 키를 지웠습니다.` }[msg.type] });
      } catch (err) {
        post({ type: 'settingsResult', provider: p.id, ok: false, message: err.message });
      }
      return postStatus();
    }
    case 'install': {
      const p = PROVIDERS[msg.provider];
      if (!p) return;
      log('설치 시작', p.id);
      install(p)
        .then(() => { log('설치 끝', p.id); post({ type: 'settingsResult', provider: p.id, ok: true, message: `${p.name} 프로그램을 설치했습니다. 이제 로그인해 주세요.` }); })
        .catch((err) => { log('설치 실패', p.id, err.message); post({ type: 'settingsResult', provider: p.id, ok: false, message: err.message }); })
        .finally(() => postStatus());
      return;
    }
    case 'openPrivacy':
      if (IS_WIN) return; // 윈도우에는 맥의 '전체 디스크 접근 권한' 같은 설정이 없다
      // 개인정보 보호 및 보안 → 전체 디스크 접근 권한을 열고, Finder 에 Knock 앱을 보여 준다
      // (사용자가 Knock 을 목록으로 끌어다 놓고 켠다 — 설정은 사용자가 직접 바꾼다)
      execFile('open', ['x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles']);
      setTimeout(() => execFile('open', ['-R', '/Applications/Knock.app']), 800);
      return;
    case 'openChromeBookmarks':
      if (IS_WIN) { const c = winChrome(); if (c) execFile(c, ['chrome://bookmarks/']); return; }
      execFile('open', ['-a', 'Google Chrome', 'chrome://bookmarks/']);
      return;
    case 'externalBrowsers': // 보호 영상이 막혔을 때 넘길 수 있는 브라우저(2026-11-10)
      post({ type: 'reply', reqId: msg.reqId, list: externalBrowsers() });
      return;
    case 'openVideo': { // 넷플릭스 → 넷플릭스 창(로그인 정보 함께)
      let url = '';
      try { const u = new URL(String(msg.url || '')); if (u.protocol === 'https:' && /(^|\.)netflix\.com$/.test(u.hostname)) url = u.href; } catch {}
      if (!url) return;
      log('넷플릭스 창 열기', (msg.cookies || []).length ? '로그인 정보 함께' : '로그인 정보 없음');
      openVideo(url, msg.cookies);
      return;
    }
    case 'openExternal': { // 같은 주소를 이 컴퓨터의 크롬·엣지로 연다
      let url = '';
      try { const u = new URL(String(msg.url || '')); if (u.protocol === 'https:' || u.protocol === 'http:') url = u.href; } catch {}
      const b = EXTERNAL[msg.browser];
      if (!url || !b) return;
      log('다른 브라우저로 열기', msg.browser, new URL(url).hostname);
      if (IS_WIN) { const exe = b.win(); if (exe) execFile(exe, [url]); return; }
      execFile('open', ['-a', b.mac, url]);
      return;
    }
    case 'openChromePasswords': // 크롬 비밀번호 설정(내보내기 단추가 있는 곳)
      if (IS_WIN) { const c = winChrome(); if (c) execFile(c, ['chrome://password-manager/settings']); return; }
      execFile('open', ['-a', 'Google Chrome', 'chrome://password-manager/settings']);
      return;
    case 'updateCheck':
      // AI 창을 열 때마다 온다 — 배포판은 새 판 정보도 다시 읽는다(30초에 한 번까지). 쓰는 중에도 [업데이트]가 바로 뜨게(2026-11-05)
      if (updater.isRelease() && Date.now() - lastRefresh > 30 * 1000) return refreshRelease(true);
      return checkUpdate(true);
    case 'updateInstall':
      // 배포판: GitHub 에 올린 새 판을 받아 바꿔 넣고 다시 켠다
      if (updater.isRelease()) {
        // 두 번 눌러도 한 번만(겹치면 바꿔 넣기가 둘이 돌았다 — 2026-11-05)
        if (installing) return;
        installing = true;
        releaseUpdate().install(log)
          .then(({ old, release, src, ai, aiOnly }) => {
            log(aiOnly ? 'AI 새 판 설치함' : '새 판 설치함', aiOnly ? ai : release, '다시 켜는 중');
            if (IS_WIN) winRelease.relaunch(src, old, aiOnly);
            else updater.relaunch(require('./release-update').APP, old);
          })
          .catch((err) => {
            installing = false;
            log('업데이트 실패', err.message);
            post({ type: 'updateFailed', message: err.message });
          });
        return;
      }
      try {
        // 업데이트 코드 자체가 고쳐졌을 수 있으니 매번 새로 읽는다(도우미를 다시 켜지 않아도 고친 게 적용되게)
        delete require.cache[require.resolve('./update')];
        const fresh = require('./update');
        fresh.install();
        fresh.relaunch();
        log('업데이트 설치함, 다시 켜는 중');
      } catch (err) {
        log('업데이트 실패', err.message);
        post({ type: 'updateFailed', message: err.message });
      }
      return;
    case 'toolResult': {
      const done = waiting.get(msg.callId);
      waiting.delete(msg.callId);
      done?.(msg.result);
      return;
    }
  }
}

// ---------- 업데이트 확인 ----------
let lastUpdate = '';
// 지금 깔린 판(설정 왼쪽 아래에 보인다 — 2026-11-05 "현재 버전을 보려면?")
function versionText(parts = null) {
  try {
    // "ver 판.AI" (2026-11-06 "Knock Browser ver N.N 형식으로") — 맥 배포판은 AI 만 따로 바꾸지 않아 .0
    // AI 번호는 전체 판마다 1부터(aiBase 를 뺀다 — 2026-11-06). aiBase 가 없는 옛 설치는 예전처럼 그대로
    if (IS_WIN && updater.isRelease()) return winRelease.installedVer() || `${winRelease.installedShown()}.${Math.max(0, (winRelease.installedAi() || 0) - winRelease.installedAiBase())}`;
    if (!IS_WIN && updater.isRelease()) { const r = require('./release-update'); return r.installedVer() || `${r.installedRelease()}.0`; }
    // 개발 중인 이 맥: 설치된 앱에 적힌 번호(package.sh 가 넣는다) — 없으면(옛 설치) 마지막으로 올린 번호(2026-11-08·09)
    // 단, 설치된 앱이 지금 소스와 같으면(받을 업데이트 없음) 마지막으로 올린 번호 — 올리기 전에 미리 설치한 내용이
    // 그 뒤 그 번호로 올라가면 앱에는 옛 번호가 적혀 있어 "ver 11.19.0 · 최신"처럼 보였다(2026-11-09)
    if (!IS_WIN) {
      const pub = path.join(__dirname, '..', '..', 'windows', 'version-published.txt');
      const files = parts && !parts.length ? [pub] : ['/Applications/Knock.app/Contents/Resources/knock-version.txt', pub];
      for (const f of files) {
        const v = (() => { try { return fs.readFileSync(f, 'utf8').trim(); } catch { return ''; } })();
        if (/^\d+\.\d+\.\d+$/.test(v)) return v;
      }
    }
  } catch {}
  return '';
}
// 속 번호(본체-AI, 예 "17-34") — 화면 번호(ver 11.8)는 단순 변동 때 그대로라, 원격 목록이 현재·최신을 견줄 때 쓴다
function buildText() {
  try {
    if (IS_WIN && updater.isRelease()) return `${winRelease.installedRelease()}-${winRelease.installedAi() || 0}`;
    if (!IS_WIN && updater.isRelease()) return `${require('./release-update').installedRelease()}`;
  } catch {}
  return '';
}
let installing = false; // 배포판 업데이트 설치 중
function checkUpdate(always) {
  let parts = [];
  try { parts = updater.check(extensionVersion); } catch (err) { log('업데이트 확인 실패', err.message); }
  // 버전 글자도 넣는다 — 업데이트 상태가 같아도 올린 번호가 바뀌면 화면 번호를 고친다(2026-11-08 "내 맥 버전이 낮아")
  const key = `${parts.join(',')}|${versionText(parts)}`;
  if (always || key !== lastUpdate) {
    post({ type: 'update', parts, version: versionText(parts), build: buildText() });
    log('업데이트 알림', parts.join(',') || '(없음)', `확장 ${extensionVersion || '?'}`);
  }
  lastUpdate = key;
}
setInterval(() => checkUpdate(false), 20000);
// 배포판: 켤 때와 1분마다, 그리고 AI 창을 열 때 GitHub 의 새 판 정보를 확인한다(1KB 안쪽 파일 하나 — 2026-11-05
// "맥처럼 창을 닫지 않고 업데이트 알림이 뜨게": 맥 개발판은 20초마다 확인한다)
let lastRefresh = 0;
let lastFeed = '';
let lastFeedError = '';
// always: AI 창이 물어 왔을 때 — 바뀐 게 없어도 지금 상태를 보낸다. 1분마다 확인할 때는 바뀌었을 때만 보내고 남긴다.
function refreshRelease(always = false) {
  lastRefresh = Date.now();
  return releaseUpdate().refresh()
    .then((f) => {
      const fr = (f.full || f).release;
      const line = `${fr}|${f.ai ? `${f.ai.release}/${f.ai.base}` : ''}`;
      if (line !== lastFeed) log('새 판 정보', fr, f.ai ? `AI ${f.ai.release}(기준 ${f.ai.base})` : '', '설치된 판', releaseUpdate().installedRelease(), IS_WIN ? `AI ${winRelease.installedAi()}` : '');
      lastFeed = line;
      lastFeedError = '';
      checkUpdate(always);
      // 윈도우: 새 판이 있으면 뒤에서 받아 풀어 두고, 다 되면 [업데이트]를 띄운다
      // 긴급 업데이트(피드의 urgent — 보안 고침 등): 사용자에게 묻지 않고 바로 설치한다(2026-11-07)
      if (IS_WIN) winRelease.prefetch(log).then(() => { checkUpdate(false); urgentInstall(f); });
    })
    .catch((err) => {
      if (err.message !== lastFeedError) log('새 판 확인 실패', err.message);
      lastFeedError = err.message;
      if (always) checkUpdate(true);
    });
}
// 긴급 업데이트: 받을 새 판이 있고 그 판이 urgent 면, 확장에 알려(탭·대화 저장) 바로 설치한다. 같은 판은 한 번만 시도
let urgentTried = '';
function urgentInstall(f) {
  if (!f || installing) return;
  const fullNew = (f.full || f).release > releaseUpdate().installedRelease();
  const urgent = (fullNew && (f.full || f).urgent) || (!fullNew && f.ai?.urgent && f.ai.release > winRelease.installedAi());
  if (!urgent) return;
  let parts = [];
  try { parts = updater.check(extensionVersion); } catch {}
  if (!parts.length) return; // 아직 받아 두는 중
  const key = `${(f.full || f).release}-${f.ai?.release || 0}`;
  if (urgentTried === key) return;
  urgentTried = key;
  log('긴급 업데이트: 묻지 않고 설치', key);
  post({ type: 'urgentUpdate', notes: (fullNew ? (f.full || f).notes : f.ai?.notes) || '' });
}

// 윈도우: 지난 업데이트 결과(바꿔 넣기가 남긴 것) — 실패했으면 까닭과 할 일을 AI 창에 알린다(2026-11-05 "업데이트가 다 안돼")
function lastUpdateResult() {
  const f = path.join(os.homedir(), '.knock', 'update-result.json');
  try {
    const r = JSON.parse(fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, ''));
    fs.rmSync(f, { force: true });
    log('지난 업데이트 결과', r.ok ? '성공' : '실패', r.want || '');
    // why: 원격 목록에 "실패"로 알릴 까닭(2026-11-09 "다시 시도인지 실패인지 분간")
    if (!r.ok) post({ type: 'updateFailed', message: '지난 업데이트를 끝까지 하지 못했어요. 컴퓨터를 한 번 다시 시작한 뒤 [업데이트]를 다시 눌러 주세요.', why: r.want || '' });
  } catch {}
}
if (updater.isRelease()) {
  if (IS_WIN) setTimeout(lastUpdateResult, 4000);
  if (IS_WIN) setTimeout(() => winRelease.fixShortcuts(log), 8000);
  setTimeout(() => refreshRelease(true), 5000);
  // 윈도우는 똑소리툴즈 서버에 2분마다 묻는다(PC 가 많아도 서버 비용이 거의 안 들게 — 2026-11-06), 맥은 GitHub 에 1분마다
  setInterval(refreshRelease, (IS_WIN ? 2 : 1) * 60 * 1000);
}

// ---------- 다른 프로필과 잇기 ----------
// 다른 프로필의 도우미가 물어오면 이 프로필의 확장에게 넘겨 답한다(읽기 전용 일만).
const peerWaiting = new Map(); // id → resolve
let peerSeq = 1;
peers.serve((op, args) => new Promise((resolve) => {
  const id = peerSeq++;
  const timer = setTimeout(() => { peerWaiting.delete(id); resolve(null); }, 7000);
  peerWaiting.set(id, (result) => { clearTimeout(timer); resolve(result); });
  post({ type: 'peerReq', id, op, args });
}));

cleanOldAttachments();
log('도우미 시작', process.pid);
