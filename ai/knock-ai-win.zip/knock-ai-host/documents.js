// 엑셀·워드·한글 파일에서 글(표는 줄·칸 그대로)을 꺼낸다. AI 에게는 글 문서로 넘긴다.
// 서식·그림은 빠진다. 꺼낸 글이 없으면 null.
const path = require('path');
const XLSX = require('xlsx');
const mammoth = require('mammoth');
const JSZip = require('jszip');
const CFB = require('cfb');
const zlib = require('zlib');

const SHEET_EXT = /\.(xlsx|xlsm|xls|ods)$/i;
const WORD_EXT = /\.docx$/i;
const HWP_EXT = /\.hwp$/i;
const HWPX_EXT = /\.hwpx$/i;

function isDocument(name) {
  return SHEET_EXT.test(name) || WORD_EXT.test(name) || HWP_EXT.test(name) || HWPX_EXT.test(name);
}

// 시트마다 "## 시트 이름" 아래 CSV 로
function sheetText(buf) {
  const book = XLSX.read(buf, { type: 'buffer', cellDates: true });
  return book.SheetNames.map((name) => {
    const csv = XLSX.utils.sheet_to_csv(book.Sheets[name], { blankrows: false }).trim();
    return `## 시트: ${name}\n${csv || '(비어 있음)'}`;
  }).join('\n\n');
}

async function wordText(buf) {
  const { value } = await mammoth.extractRawText({ buffer: buf });
  return value;
}

// HWP 5.0: 압축된 본문(BodyText/Section*)을 풀고 문단 글자 레코드(HWPTAG_PARA_TEXT)만 읽는다.
// 표 안의 글도 문단으로 들어 있어 함께 나온다(칸 구분은 없음).
// 배포용(암호화) 문서는 본문을 못 열어 미리보기 글(PrvText, 앞부분)만 읽는다.
const HWPTAG_PARA_TEXT = 67;
// 8글자(16바이트)를 차지하는 조판 부호. 나머지 32 미만 부호는 1글자.
const HWP_WIDE_CTRL = new Set([1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]);

function paraText(buf) {
  let out = '';
  for (let i = 0; i + 1 < buf.length;) {
    const code = buf.readUInt16LE(i);
    if (code >= 32) { out += String.fromCharCode(code); i += 2; continue; }
    if (code === 9) out += '\t';
    else if (code === 10 || code === 13) out += '\n';
    i += HWP_WIDE_CTRL.has(code) ? 16 : 2;
  }
  return out;
}

function hwpRecordsText(data) {
  const parts = [];
  for (let i = 0; i + 4 <= data.length;) {
    const head = data.readUInt32LE(i);
    i += 4;
    const tag = head & 0x3ff;
    let size = head >>> 20;
    if (size === 0xfff) { size = data.readUInt32LE(i); i += 4; }
    if (tag === HWPTAG_PARA_TEXT) parts.push(paraText(data.subarray(i, i + size)));
    i += size;
  }
  return parts.join('').replace(/\n{3,}/g, '\n\n');
}

function hwpText(buf) {
  const cfb = CFB.read(buf, { type: 'buffer' });
  const stream = (p) => {
    const i = cfb.FullPaths.findIndex((x) => x.toLowerCase().endsWith(p.toLowerCase()));
    return i >= 0 ? Buffer.from(cfb.FileIndex[i].content) : null;
  };
  const header = stream('/FileHeader');
  if (!header) throw new Error('한글(HWP) 파일이 아닙니다.');
  const flags = header.readUInt32LE(36);
  if (flags & 2) throw new Error('암호가 걸린 한글 문서라 읽을 수 없습니다.');
  const preview = () => (stream('/PrvText')?.toString('utf16le') || '').replace(/\0/g, '').trim();
  if (flags & 4) {
    const t = preview();
    return t ? `(배포용 문서라 앞부분 미리보기만 읽었습니다)\n${t}` : '';
  }
  const compressed = Boolean(flags & 1);
  const sections = cfb.FullPaths
    .map((p, i) => [p, i])
    .filter(([p]) => /BodyText\/Section\d+$/i.test(p))
    .sort(([a], [b]) => a.localeCompare(b, undefined, { numeric: true }));
  const texts = [];
  for (const [, i] of sections) {
    const raw = Buffer.from(cfb.FileIndex[i].content);
    try {
      texts.push(hwpRecordsText(compressed ? zlib.inflateRawSync(raw) : raw));
    } catch (err) {
      console.error('[documents] HWP 구역 읽기 실패:', err.message);
    }
  }
  const body = texts.join('\n').trim();
  if (body) return body;
  const t = preview();
  return t ? `(본문을 열지 못해 앞부분 미리보기만 읽었습니다)\n${t}` : '';
}

// HWPX(새 한글 형식): Contents/section*.xml 의 <hp:t> 글자, 문단 <hp:p> 마다 줄바꿈
async function hwpxText(buf) {
  const zip = await JSZip.loadAsync(buf);
  const sections = Object.keys(zip.files)
    .filter((n) => /^Contents\/section\d+\.xml$/i.test(n))
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  const decode = (s) => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
  const parts = [];
  for (const n of sections) {
    const xml = await zip.file(n).async('string');
    for (const p of xml.split(/<\/hp:p>/)) {
      const text = [...p.matchAll(/<hp:t(?:\s[^>]*)?>([\s\S]*?)<\/hp:t>/g)].map((m) => decode(m[1].replace(/<[^>]+>/g, ''))).join('');
      if (text.trim()) parts.push(text);
    }
  }
  return parts.join('\n');
}

async function extractText(name, buf) {
  const base = path.basename(name);
  let text;
  if (SHEET_EXT.test(base)) text = sheetText(buf);
  else if (WORD_EXT.test(base)) text = await wordText(buf);
  else if (HWP_EXT.test(base)) text = hwpText(buf);
  else if (HWPX_EXT.test(base)) text = await hwpxText(buf);
  else return null;
  text = (text || '').trim();
  return text || null;
}

module.exports = { isDocument, extractText };
