// 엑셀·워드·한글 파일에서 글(표는 줄·칸 그대로)을 꺼낸다. AI 에게는 글 문서로 넘긴다.
// 서식·그림은 빠진다. 꺼낸 글이 없으면 null.
const path = require('path');
const XLSX = require('xlsx');
const mammoth = require('mammoth');
const JSZip = require('jszip');
const CFB = require('cfb');
const zlib = require('zlib');

const SHEET_EXT = /\.(xlsx|xlsm|xls|ods)$/i;
const WORD_EXT = /\.docx$/i;
const HWP_EXT = /\.hwp$/i;
const HWPX_EXT = /\.hwpx$/i;
const SLIDE_EXT = /\.pptx$/i;

function isDocument(name) {
  return SHEET_EXT.test(name) || WORD_EXT.test(name) || HWP_EXT.test(name) || HWPX_EXT.test(name) || SLIDE_EXT.test(name);
}

// 시트마다 "## 시트 이름" 아래 CSV 로
function sheetText(buf) {
  const book = XLSX.read(buf, { type: 'buffer', cellDates: true });
  return book.SheetNames.map((name) => {
    const csv = XLSX.utils.sheet_to_csv(book.Sheets[name], { blankrows: false }).trim();
    return `## 시트: ${name}\n${csv || '(비어 있음)'}`;
  }).join('\n\n');
}

async function wordText(buf) {
  const { value } = await mammoth.extractRawText({ buffer: buf });
  return value;
}

// HWP 5.0: 압축된 본문(BodyText/Section*)을 풀고 문단 글자 레코드(HWPTAG_PARA_TEXT)만 읽는다.
// 표 안의 글도 문단으로 들어 있어 함께 나온다(칸 구분은 없음).
// 배포용(암호화) 문서는 본문을 못 열어 미리보기 글(PrvText, 앞부분)만 읽는다.
const HWPTAG_PARA_TEXT = 67;
// 8글자(16바이트)를 차지하는 조판 부호. 나머지 32 미만 부호는 1글자.
const HWP_WIDE_CTRL = new Set([1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]);

function paraText(buf) {
  let out = '';
  for (let i = 0; i + 1 < buf.length;) {
    const code = buf.readUInt16LE(i);
    if (code >= 32) { out += String.fromCharCode(code); i += 2; continue; }
    if (code === 9) out += '\t';
    else if (code === 10 || code === 13) out += '\n';
    i += HWP_WIDE_CTRL.has(code) ? 16 : 2;
  }
  return out;
}

function hwpRecordsText(data) {
  const parts = [];
  for (let i = 0; i + 4 <= data.length;) {
    const head = data.readUInt32LE(i);
    i += 4;
    const tag = head & 0x3ff;
    let size = head >>> 20;
    if (size === 0xfff) { size = data.readUInt32LE(i); i += 4; }
    if (tag === HWPTAG_PARA_TEXT) parts.push(paraText(data.subarray(i, i + size)));
    i += size;
  }
  return parts.join('').replace(/\n{3,}/g, '\n\n');
}

function hwpText(buf) {
  const cfb = CFB.read(buf, { type: 'buffer' });
  const stream = (p) => {
    const i = cfb.FullPaths.findIndex((x) => x.toLowerCase().endsWith(p.toLowerCase()));
    return i >= 0 ? Buffer.from(cfb.FileIndex[i].content) : null;
  };
  const header = stream('/FileHeader');
  if (!header) throw new Error('한글(HWP) 파일이 아닙니다.');
  const flags = header.readUInt32LE(36);
  if (flags & 2) throw new Error('암호가 걸린 한글 문서라 읽을 수 없습니다.');
  const preview = () => (stream('/PrvText')?.toString('utf16le') || '').replace(/\0/g, '').trim();
  if (flags & 4) {
    const t = preview();
    return t ? `(배포용 문서라 앞부분 미리보기만 읽었습니다)\n${t}` : '';
  }
  const compressed = Boolean(flags & 1);
  const sections = cfb.FullPaths
    .map((p, i) => [p, i])
    .filter(([p]) => /BodyText\/Section\d+$/i.test(p))
    .sort(([a], [b]) => a.localeCompare(b, undefined, { numeric: true }));
  const texts = [];
  for (const [, i] of sections) {
    const raw = Buffer.from(cfb.FileIndex[i].content);
    try {
      texts.push(hwpRecordsText(compressed ? zlib.inflateRawSync(raw) : raw));
    } catch (err) {
      console.error('[documents] HWP 구역 읽기 실패:', err.message);
    }
  }
  const body = texts.join('\n').trim();
  if (body) return body;
  const t = preview();
  return t ? `(본문을 열지 못해 앞부분 미리보기만 읽었습니다)\n${t}` : '';
}

// HWPX(새 한글 형식): Contents/section*.xml 의 <hp:t> 글자, 문단 <hp:p> 마다 줄바꿈
async function hwpxText(buf) {
  const zip = await JSZip.loadAsync(buf);
  const sections = Object.keys(zip.files)
    .filter((n) => /^Contents\/section\d+\.xml$/i.test(n))
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  const decode = (s) => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
  const parts = [];
  for (const n of sections) {
    const xml = await zip.file(n).async('string');
    for (const p of xml.split(/<\/hp:p>/)) {
      const text = [...p.matchAll(/<hp:t(?:\s[^>]*)?>([\s\S]*?)<\/hp:t>/g)].map((m) => decode(m[1].replace(/<[^>]+>/g, ''))).join('');
      if (text.trim()) parts.push(text);
    }
  }
  return parts.join('\n');
}

// 파워포인트(2026-11-23 원장님 "MarkItDown 대신 빠진 것만 채워"): 슬라이드마다 "## 슬라이드 N" 아래 글, 표는 칸을 | 로, 발표자 메모도 함께.
const xmlText = (s) => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
  .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n))).replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16))).replace(/&amp;/g, '&');
function slideLines(xml) {
  const lines = [];
  // 표: 줄(a:tr)마다 칸(a:tc)을 | 로 잇는다 — 표 안 글은 아래 문단에서 다시 넣지 않게 지운다
  const body = xml.replace(/<a:tbl>[\s\S]*?<\/a:tbl>/g, (tbl) => {
    const rows = [...tbl.matchAll(/<a:tr[\s>][\s\S]*?<\/a:tr>/g)].map((r) => [...r[0].matchAll(/<a:tc[\s>][\s\S]*?<\/a:tc>/g)]
      .map((c) => [...c[0].matchAll(/<a:t>([\s\S]*?)<\/a:t>/g)].map((t) => xmlText(t[1])).join('').replace(/\|/g, '/').trim()));
    if (rows.length) {
      lines.push(`| ${rows[0].join(' | ')} |`, `|${rows[0].map(() => ' --- ').join('|')}|`, ...rows.slice(1).map((r) => `| ${r.join(' | ')} |`));
    }
    return '';
  });
  for (const p of body.matchAll(/<a:p[\s>][\s\S]*?<\/a:p>/g)) {
    const t = [...p[0].matchAll(/<a:t>([\s\S]*?)<\/a:t>/g)].map((m) => xmlText(m[1])).join('').trim();
    if (t) lines.push(/<a:buChar|<a:buAutoNum/.test(p[0]) ? `- ${t}` : t);
  }
  return lines;
}
async function slidesText(buf) {
  const zip = await JSZip.loadAsync(buf);
  const num = (n) => Number(n.match(/(\d+)\.xml$/)?.[1] || 0);
  // 슬라이드 차례: presentation.xml 의 sldId 순서(파일 번호와 다를 수 있음)
  let order = [];
  try {
    const pres = await zip.file('ppt/presentation.xml')?.async('string');
    const rels = await zip.file('ppt/_rels/presentation.xml.rels')?.async('string');
    if (pres && rels) {
      const target = Object.fromEntries([...rels.matchAll(/Id="([^"]+)"[^>]*Target="([^"]+)"/g)].map((m) => [m[1], `ppt/${m[2].replace(/^\.?\//, '')}`]));
      order = [...pres.matchAll(/<p:sldId [^>]*r:id="([^"]+)"/g)].map((m) => target[m[1]]).filter(Boolean);
    }
  } catch {}
  const slides = Object.keys(zip.files).filter((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n));
  if (order.length) slides.sort((a, b) => (order.indexOf(a) + 1 || 1e9) - (order.indexOf(b) + 1 || 1e9));
  else slides.sort((a, b) => num(a) - num(b));
  const out = [];
  for (const [i, n] of slides.entries()) {
    const lines = slideLines(await zip.file(n).async('string'));
    let note = [];
    try {
      const rels = await zip.file(n.replace('slides/', 'slides/_rels/').replace(/\.xml$/, '.xml.rels'))?.async('string');
      const notePath = rels?.match(/Target="\.\.\/notesSlides\/([^"]+)"/)?.[1];
      const nx = notePath && await zip.file(`ppt/notesSlides/${notePath}`)?.async('string');
      if (nx) note = slideLines(nx).filter((l) => !/^\d+$/.test(l)); // 쪽 번호 칸은 뺀다
    } catch {}
    out.push(`## 슬라이드 ${i + 1}\n${lines.join('\n') || '(글 없음)'}${note.length ? `\n\n> 발표자 메모: ${note.join(' ')}` : ''}`);
  }
  return out.join('\n\n');
}

// PDF 에서 글만 꺼낸다(2026-11-23): ChatGPT·Gemini 처럼 PDF 를 직접 못 읽는 AI, 아주 긴 PDF, .md 로 받기에 쓴다.
// 쪽마다 "## N쪽" 아래, 같은 높이의 글 조각을 한 줄로 잇는다. 스캔한 PDF(그림뿐)는 글이 없다.
const MAX_PDF_PAGES = 2000;
async function pdfText(buf) {
  const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const task = pdfjs.getDocument({ data: new Uint8Array(buf), useSystemFonts: false, isEvalSupported: false, verbosity: 0 });
  const doc = await task.promise;
  const pages = [];
  const total = doc.numPages;
  try {
    for (let n = 1; n <= Math.min(total, MAX_PDF_PAGES); n++) {
      const page = await doc.getPage(n);
      const { items } = await page.getTextContent();
      const lines = [];
      let y = null;
      let line = '';
      for (const it of items) {
        if (typeof it.str !== 'string') continue;
        const iy = Math.round(it.transform?.[5] ?? 0);
        if (y !== null && Math.abs(iy - y) > 2) { if (line.trim()) lines.push(line.trim()); line = ''; }
        y = iy;
        line += it.str;
        if (it.hasEOL) { if (line.trim()) lines.push(line.trim()); line = ''; y = null; }
      }
      if (line.trim()) lines.push(line.trim());
      pages.push(`## ${n}쪽\n${lines.join('\n')}`);
      page.cleanup();
    }
  } finally {
    await task.destroy();
  }
  const text = pages.join('\n\n');
  // 쪽 머리만 있고 글이 없으면(스캔 PDF) 글 없음
  return { text: text.replace(/## \d+쪽\n?/g, '').trim() ? text : '', pages: total };
}

async function extractText(name, buf) {
  const base = path.basename(name);
  let text;
  if (SHEET_EXT.test(base)) text = sheetText(buf);
  else if (WORD_EXT.test(base)) text = await wordText(buf);
  else if (HWP_EXT.test(base)) text = hwpText(buf);
  else if (HWPX_EXT.test(base)) text = await hwpxText(buf);
  else if (SLIDE_EXT.test(base)) text = await slidesText(buf);
  else return null;
  text = (text || '').trim();
  return text || null;
}

// 문서 안에 넣은 사진을 꺼낸다(2026-11-13 원장님 "docx 안 이미지를 가져와서 피그마 편집이 가능하게").
// 워드(word/media)·엑셀(xl/media)·한글 hwpx(BinData)·파워포인트(ppt/media). 문서에 나오는 차례대로.
// EMF·WMF 같은 옛 그림 형식은 AI·피그마가 못 쓰므로 빼고 개수만 알린다.
const IMG_TYPES = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', bmp: 'image/bmp', svg: 'image/svg+xml' };
async function extractImages(name, buf) {
  if (!/\.(docx|xlsx|xlsm|hwpx|pptx)$/i.test(name)) return { images: [], skipped: 0 };
  const zip = await JSZip.loadAsync(buf);
  const media = Object.keys(zip.files).filter((n) => /^(word\/media|xl\/media|ppt\/media|BinData)\//i.test(n) && !zip.files[n].dir);
  // 워드는 본문에 나오는 차례(rId)대로 — 관계 파일에서 그림 순서를 읽는다
  let order = [];
  try {
    const rels = await zip.file('word/_rels/document.xml.rels')?.async('string');
    const doc = await zip.file('word/document.xml')?.async('string');
    if (rels && doc) {
      const target = Object.fromEntries([...rels.matchAll(/Id="([^"]+)"[^>]*Target="([^"]+)"/g)].map((m) => [m[1], `word/${m[2].replace(/^\.?\//, '')}`]));
      order = [...doc.matchAll(/r:embed="([^"]+)"/g)].map((m) => target[m[1]]).filter(Boolean);
    }
  } catch {}
  const rank = (n) => { const i = order.indexOf(n); return i < 0 ? 1e9 : i; };
  media.sort((a, b) => rank(a) - rank(b) || a.localeCompare(b, undefined, { numeric: true }));
  const images = [];
  let skipped = 0;
  for (const n of media) {
    const ext = (n.split('.').pop() || '').toLowerCase();
    if (!IMG_TYPES[ext]) { skipped++; continue; }
    images.push({ ext: ext === 'jpeg' ? 'jpg' : ext, type: IMG_TYPES[ext], data: await zip.file(n).async('nodebuffer') });
  }
  return { images, skipped };
}

module.exports = { isDocument, extractText, extractImages, pdfText };
