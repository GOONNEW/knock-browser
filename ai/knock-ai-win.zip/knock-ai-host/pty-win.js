// 윈도우에서 프로그램을 "가짜 터미널"(ConPTY) 안에서 띄운다(2026-11-12).
// Claude Code 2.1.3xx 부터 `claude mcp login` 이 터미널이 아니면 "stdin isn't a terminal" 로 끝나 버려
// 설정 › MCP 연결(피그마·노션)이 윈도우에서 안 됐다. 맥은 python pty 로 이미 터미널을 준다.
// AI 부분 업데이트는 도우미의 .js 만 바꾸므로 PowerShell 글을 여기 담아 두고 쓸 때 임시 폴더에 .ps1 로 적는다.
// 화면 글은 이 프로세스의 표준 출력으로 그대로 나온다. 이 PowerShell 이 끝나면(도우미가 끄면) 안의 프로그램도 함께 끝난다(작업 개체).
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const PS1 = String.raw`$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
public static class KnockPty {
  [StructLayout(LayoutKind.Sequential)] struct COORD { public short X, Y; }
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] struct STARTUPINFO {
    public int cb; public string lpReserved, lpDesktop, lpTitle; public int dwX, dwY, dwXSize, dwYSize, dwXCountChars, dwYCountChars, dwFillAttribute, dwFlags;
    public short wShowWindow, cbReserved2; public IntPtr lpReserved2, hStdInput, hStdOutput, hStdError; }
  [StructLayout(LayoutKind.Sequential)] struct STARTUPINFOEX { public STARTUPINFO StartupInfo; public IntPtr lpAttributeList; }
  [StructLayout(LayoutKind.Sequential)] struct PROCESS_INFORMATION { public IntPtr hProcess, hThread; public int dwProcessId, dwThreadId; }
  [StructLayout(LayoutKind.Sequential)] struct IO_COUNTERS { public ulong a, b, c, d, e, f; }
  [StructLayout(LayoutKind.Sequential)] struct BASIC_LIMIT { public long t1, t2; public uint LimitFlags; public UIntPtr mn, mx; public uint ac; public UIntPtr aff; public uint pc, sc; }
  [StructLayout(LayoutKind.Sequential)] struct EXT_LIMIT { public BASIC_LIMIT Basic; public IO_COUNTERS Io; public UIntPtr pm, jm, ppu, pju; }
  [DllImport("kernel32.dll", SetLastError = true)] static extern bool CreatePipe(out IntPtr r, out IntPtr w, IntPtr sa, int size);
  [DllImport("kernel32.dll", SetLastError = true)] static extern int CreatePseudoConsole(COORD size, IntPtr hIn, IntPtr hOut, uint flags, out IntPtr hPC);
  [DllImport("kernel32.dll", SetLastError = true)] static extern void ClosePseudoConsole(IntPtr hPC);
  [DllImport("kernel32.dll", SetLastError = true)] static extern bool InitializeProcThreadAttributeList(IntPtr list, int count, int flags, ref IntPtr size);
  [DllImport("kernel32.dll", SetLastError = true)] static extern bool UpdateProcThreadAttribute(IntPtr list, uint flags, IntPtr attr, IntPtr value, IntPtr size, IntPtr prev, IntPtr ret);
  [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern bool CreateProcess(string app, string cmd, IntPtr pa, IntPtr ta, bool inherit, uint flags, IntPtr env, string dir, ref STARTUPINFOEX si, out PROCESS_INFORMATION pi);
  [DllImport("kernel32.dll", SetLastError = true)] static extern uint WaitForSingleObject(IntPtr h, uint ms);
  [DllImport("kernel32.dll", SetLastError = true)] static extern bool GetExitCodeProcess(IntPtr h, out uint code);
  [DllImport("kernel32.dll", SetLastError = true)] static extern bool CloseHandle(IntPtr h);
  [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr CreateJobObject(IntPtr a, string name);
  [DllImport("kernel32.dll", SetLastError = true)] static extern bool SetInformationJobObject(IntPtr job, int cls, ref EXT_LIMIT info, int len);
  [DllImport("kernel32.dll", SetLastError = true)] static extern bool AssignProcessToJobObject(IntPtr job, IntPtr proc);

  public static int Run(string cmdline, string dir) {
    IntPtr inR, inW, outR, outW;
    CreatePipe(out inR, out inW, IntPtr.Zero, 0);
    CreatePipe(out outR, out outW, IntPtr.Zero, 0);
    IntPtr hPC;
    // 넓게 — 로그인 주소가 줄바꿈으로 잘리지 않게
    int hr = CreatePseudoConsole(new COORD { X = 2000, Y = 50 }, inR, outW, 0, out hPC);
    if (hr != 0) throw new Exception("CreatePseudoConsole " + hr);
    IntPtr size = IntPtr.Zero;
    InitializeProcThreadAttributeList(IntPtr.Zero, 1, 0, ref size);
    IntPtr list = Marshal.AllocHGlobal(size);
    InitializeProcThreadAttributeList(list, 1, 0, ref size);
    UpdateProcThreadAttribute(list, 0, (IntPtr)0x00020016, hPC, (IntPtr)IntPtr.Size, IntPtr.Zero, IntPtr.Zero);
    var si = new STARTUPINFOEX();
    si.StartupInfo.cb = Marshal.SizeOf(typeof(STARTUPINFOEX));
    si.lpAttributeList = list;
    // 도우미가 준 표준 입출력(파이프)을 물려받지 않게 — 그래야 가짜 터미널만 본다
    si.StartupInfo.dwFlags = 0x00000100;
    PROCESS_INFORMATION pi;
    if (!CreateProcess(null, cmdline, IntPtr.Zero, IntPtr.Zero, false, 0x00080000, IntPtr.Zero, dir, ref si, out pi))
      throw new Exception("CreateProcess " + Marshal.GetLastWin32Error());
    // 이 PowerShell 이 꺼지면 안의 프로그램도 꺼진다
    IntPtr job = CreateJobObject(IntPtr.Zero, null);
    var lim = new EXT_LIMIT(); lim.Basic.LimitFlags = 0x2000;
    SetInformationJobObject(job, 9, ref lim, Marshal.SizeOf(typeof(EXT_LIMIT)));
    AssignProcessToJobObject(job, pi.hProcess);
    CloseHandle(inR); CloseHandle(outW);
    var output = new FileStream(new SafeFileHandle(outR, true), FileAccess.Read);
    var stdout = Console.OpenStandardOutput();
    var reader = new Thread(() => {
      var buf = new byte[8192];
      try { int n; while ((n = output.Read(buf, 0, buf.Length)) > 0) { stdout.Write(buf, 0, n); stdout.Flush(); } } catch { }
    });
    reader.IsBackground = true;
    reader.Start();
    // 도우미가 보내는 글(붙여넣기 등)을 안으로 넘긴다
    var input = new FileStream(new SafeFileHandle(inW, true), FileAccess.Write);
    var writer = new Thread(() => {
      var stdin = Console.OpenStandardInput(); var buf = new byte[1024];
      try { int n; while ((n = stdin.Read(buf, 0, buf.Length)) > 0) { input.Write(buf, 0, n); input.Flush(); } } catch { }
    });
    writer.IsBackground = true;
    writer.Start();
    WaitForSingleObject(pi.hProcess, 0xFFFFFFFF);
    uint code; GetExitCodeProcess(pi.hProcess, out code);
    Thread.Sleep(300);
    ClosePseudoConsole(hPC);
    reader.Join(1000);
    return (int)code;
  }
}
'@
exit [KnockPty]::Run($env:KNOCK_PTY_CMDLINE, $env:KNOCK_PTY_DIR)
`;

const quote = (a) => (/^[^\s"]+$/.test(a) ? a : `"${String(a).replace(/(\\*)"/g, '$1$1\\"').replace(/(\\+)$/, '$1$1')}"`);

function spawnPty(cmd, args, { cwd, env } = {}) {
  const file = path.join(os.tmpdir(), 'knock-pty-win.ps1');
  fs.writeFileSync(file, `﻿${PS1}`);
  const cmdline = [cmd, ...args].map(quote).join(' ');
  return spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', file], {
    cwd, env: { ...(env || process.env), KNOCK_PTY_CMDLINE: cmdline, KNOCK_PTY_DIR: cwd || os.homedir() },
    stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true,
  });
}

module.exports = { spawnPty };
