// 페이지 조작 도구 정의(똑소리 브라우저 knock-browser/src/shared/tools.js 에서 옮김). mcp.js 가 쓴다.


const TOOLS = [
  {
    name: 'get_page',
    description: '이 대화의 탭의 주소, 조작 가능한 요소 목록(번호 포함), 페이지 글을 읽습니다. 글이 길면 text_offset 으로 이어 읽습니다. tab_id 를 주면 다른 탭(다른 프로필 창 포함)을 읽습니다. 그 탭을 조작할 때는 click 등에도 같은 tab_id 를 줍니다.',
    input_schema: {
      type: 'object',
      properties: {
        text_offset: { type: 'integer', description: '페이지 글을 읽기 시작할 위치(기본 0)' },
        tab_id: { type: 'integer', description: '다른 탭을 읽을 때 그 탭 번호(list_tabs)' },
      },
    },
  },
  {
    name: 'screenshot',
    description: '이 대화의 탭(또는 tab_id 로 고른 다른 탭)의 보이는 화면을 이미지로 봅니다. 달력, 좌석표, 지도처럼 모양이 중요한 화면에 씁니다.',
    input_schema: {
      type: 'object',
      properties: { tab_id: { type: 'integer', description: '다른 탭을 볼 때 그 탭 번호' } },
    },
  },
  {
    name: 'click',
    description: '요소를 클릭합니다. id 는 get_page 결과의 번호(예: "0-12")입니다.',
    input_schema: {
      type: 'object',
      properties: { id: { type: 'string' }, tab_id: { type: 'integer', description: '다른 탭(다른 프로필 포함)에서 할 때 그 탭 번호(list_tabs). 없으면 이 대화의 탭' } },
      required: ['id'],
    },
  },
  {
    name: 'type_text',
    description: '입력칸의 기존 내용을 지우고 글을 입력합니다. submit 이 true 면 입력 후 Enter 를 누릅니다. 민감 정보 칸에는 쓸 수 없습니다. id 없이 부르면 지금 커서 자리에 이어서 씁니다(입력칸으로 잡히지 않는 편집기 — click_at 으로 커서를 먼저 놓으세요).',
    input_schema: {
      type: 'object',
      properties: {
        id: { type: 'string' },
        text: { type: 'string' },
        submit: { type: 'boolean' },
        tab_id: { type: 'integer', description: '다른 탭(다른 프로필 포함)에서 할 때 그 탭 번호(list_tabs). 없으면 이 대화의 탭' },
      },
      required: ['text'],
    },
  },
  // 맥 앱 다루기(접근성 정보). 마우스를 움직이거나 앱을 앞으로 가져오지 않아 사용자가 하던 일을 계속할 수 있다.
  { name: 'mac_apps', description: '켜져 있는 맥 앱 목록(이름·번들ID)을 봅니다.', input_schema: { type: 'object', properties: {} } },
  {
    name: 'mac_open',
    description: '맥 앱을 켭니다(앞으로 가져오지 않음). app 은 앱 이름(예: "메모", "KakaoTalk") 또는 번들ID.',
    input_schema: { type: 'object', properties: { app: { type: 'string' } }, required: ['app'] },
  },
  {
    name: 'mac_read',
    description: '맥 앱의 앞쪽 창을 읽어 단추·입력칸·글을 번호([a3-12])와 함께 보여 줍니다. 웹페이지가 아닌 맥 프로그램(카카오톡·메모·Finder·엑셀 등)을 다룰 때 씁니다. app 을 빼면 맨 앞 앱.',
    input_schema: { type: 'object', properties: { app: { type: 'string' }, limit: { type: 'integer', description: '읽을 칸 수(기본 300)' } } },
  },
  {
    name: 'mac_click',
    description: 'mac_read 의 번호로 단추·메뉴·목록 줄을 누릅니다. 목록 줄(카카오톡 대화방·파일 등)은 누르면 고르기만 되니, 열려면 open 을 true 로 주세요(고른 뒤 그 앱에만 Enter).',
    input_schema: { type: 'object', properties: { ref: { type: 'string' }, open: { type: 'boolean', description: '목록 줄을 골라 엽니다(대화방 열기 등)' } }, required: ['ref'] },
  },
  {
    name: 'mac_type',
    description: 'mac_read 의 번호로 입력칸의 글을 바꿉니다. submit 이 true 면 넣은 뒤 그 앱에 Enter 를 보냅니다.',
    input_schema: { type: 'object', properties: { ref: { type: 'string' }, text: { type: 'string' }, submit: { type: 'boolean' } }, required: ['ref', 'text'] },
  },
  {
    name: 'mac_menu',
    description: '맥 앱의 메뉴 막대를 누릅니다. path 는 메뉴 이름 순서(예: ["파일", "새로운 메모"]).',
    input_schema: { type: 'object', properties: { app: { type: 'string' }, path: { type: 'array', items: { type: 'string' } } }, required: ['path'] },
  },
  {
    name: 'mac_note',
    description: '맥 메모 앱(Notes)을 화면에 띄우지 않고 다룹니다. 메모 일은 mac_type·mac_menu 대신 이것을 쓰세요(화면 입력은 서식이 꼬입니다). '
      + 'action: find(query 로 제목 찾기) · read(id 로 내용 읽기, html 도 줌) · write(id 가 있으면 그 메모 내용을 html 로 바꿈, 없으면 folder 에 새 메모) · folders(폴더 목록). '
      + 'html 은 첫 줄이 메모 제목: <h1>제목</h1> 다음 <h2>소제목</h2>, <div>본문 한 줄</div>, <b>굵게</b>, <ul><li>항목</li></ul>, 빈 줄은 <div><br></div>.',
    input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['find', 'read', 'write', 'folders'] }, query: { type: 'string' }, id: { type: 'string' }, folder: { type: 'string' }, html: { type: 'string' } }, required: ['action'] },
  },
  {
    name: 'mac_key',
    description: '맥 앱 하나에만 키를 보냅니다(다른 앱·사용자 입력에 섞이지 않음). key 예: Enter, Tab, Escape, ArrowDown, a. mods 예: ["cmd"].',
    input_schema: { type: 'object', properties: { app: { type: 'string' }, key: { type: 'string' }, mods: { type: 'array', items: { type: 'string' } } }, required: ['key'] },
  },
  // 그림으로만 보이는 창(아이폰 미러링·원격 화면·게임 등): mac_read 로 칸이 안 읽힐 때만 쓴다
  {
    name: 'mac_look',
    description: '맥 앱 창을 사진으로 봅니다. 아이폰 미러링(iPhone Mirroring)처럼 mac_read 로 칸·글이 읽히지 않는 창에만 씁니다. 그 앱을 잠깐 앞으로 가져옵니다. '
      + '사진의 픽셀 자리(x, y)를 mac_tap 에 주면 그 자리를 누릅니다.',
    input_schema: { type: 'object', properties: { app: { type: 'string', description: '앱 이름이나 번들ID (예: "iPhone 미러링", com.apple.ScreenContinuity)' } }, required: ['app'] },
  },
  {
    name: 'mac_tap',
    description: 'mac_look 사진의 자리(x, y 픽셀)를 진짜 마우스로 누릅니다(누른 뒤 마우스 자리는 되돌림). hold 초를 주면 길게 누름. '
      + 'scroll 을 주면 누르지 않고 그 자리에서 넘깁니다(+ 아래로, - 위로, 픽셀 — 예: 400). 누른 뒤에는 mac_look 으로 결과를 확인하세요.',
    input_schema: { type: 'object', properties: { app: { type: 'string' }, x: { type: 'number' }, y: { type: 'number' }, hold: { type: 'number' }, scroll: { type: 'number' } }, required: ['app', 'x', 'y'] },
  },
  {
    name: 'mac_screen_type',
    description: 'mac_look 으로 보는 창에 키를 누르고(먼저) 글을 넣습니다. 먼저 mac_tap 으로 입력칸을 눌러 두세요. '
      + '칸의 글을 모두 바꾸려면 key "a" + mods ["cmd"] 와 text 를 함께 주세요(전체 선택 → 넣기). key 예: Enter, Backspace, Tab, a(+cmd), Space(+ctrl = 아이폰 자판 언어 바꾸기). '
      + '글은 기본으로 맥 클립보드에 담아 ⌘V 로 붙여넣습니다. 붙여넣기가 안 들어가면 typing: true 로 자판을 한 글자씩 칩니다 — 한글은 아이폰 자판이 한국어일 때, 영문 글자는 영어일 때만 맞게 들어가니 '
      + '한글과 영문이 섞이면 나눠서 치고 사이에 자판 언어를 바꾸세요(숫자·기호는 어느 쪽이든 됨). 칠 때마다 mac_look 으로 확인하세요.',
    input_schema: { type: 'object', properties: { app: { type: 'string' }, text: { type: 'string' }, key: { type: 'string' }, mods: { type: 'array', items: { type: 'string' } }, typing: { type: 'boolean', description: '붙여넣기 대신 자판으로 치기' } }, required: ['app'] },
  },
  {
    name: 'saved_card',
    description: '사용자가 설정(⚙︎ › AI 동작 보안 › 기억해 둔 로그인 · 저장한 카드·계좌)에 직접 저장해 둔 카드·계좌를 씁니다. id 없이 부르면 이름표 목록(예: "광주은행 카드 …1234")만 줍니다 — 번호는 보이지 않습니다. '
      + 'id 를 주면 그 번호를 가림표([[비공개N]])로 줍니다. type_text 의 text 에 가림표를 그대로 넣으면 넣기 전에 사용자에게 묻고 그 칸에만 실제 번호가 들어갑니다. '
      + '카드 비밀번호·CVC 는 저장돼 있지 않으니 ask_secrets 로 받으세요. 저장한 것이 없으면 사용자에게 설정에서 저장하거나 ask_secrets 로 넣어 달라고 하세요.',
    input_schema: {
      type: 'object',
      properties: { id: { type: 'string', description: '목록에서 고른 저장 번호(없으면 목록)' } },
    },
  },
  {
    name: 'ask_secrets',
    description: '민감정보(카드번호·카드 비밀번호·CVC·비밀번호·인증번호·주민번호 뒷자리 등)를 사용자에게 받을 때 씁니다. AI 창에 이름마다 가려진 칸을 띄우고, 사용자가 넣은 값 대신 가림표([[비공개N]])를 돌려줍니다(실제 값은 AI 에게 보이지 않음). '
      + '"무엇을 넣어야 하나요?"처럼 필요한 정보를 알려 줄 때도, 민감한 항목은 채팅으로 적어 달라고 하지 말고 이 도구로 칸을 띄우세요(민감하지 않은 항목만 채팅으로 물음). '
      + '받은 가림표는 type_text 의 text 에 그대로 넣으면 그 칸에만 실제 값이 들어갑니다(넣기 전에 사용자에게 물음). 로그인 비밀번호 한 칸은 request_password 가 더 알맞습니다.',
    input_schema: {
      type: 'object',
      properties: {
        reason: { type: 'string', description: '왜 필요한지 한 줄(예: "광주은행 카드 이용내역 조회")' },
        fields: { type: 'array', items: { type: 'string' }, description: '칸 이름들(예: ["카드번호", "카드 비밀번호 앞 2자리", "CVC(뒷면 3자리)"]), 6개까지' },
      },
      required: ['fields'],
    },
  },
  {
    name: 'request_password',
    description: '비밀번호·인증번호 칸을 채울 때 씁니다. AI 창에 가려진 입력 칸을 띄워 사용자가 직접 넣게 하고, 그 값을 페이지 칸에 넣습니다. 값은 AI 에게 보이지 않습니다. 사용자에게 채팅으로 비밀번호를 적어 달라고 하지 말고 이 도구를 쓰세요. 사용자가 그 사이트 로그인을 기억해 두었으면 묻지 않고 바로 채웁니다(아이디 칸이 비어 있으면 아이디도). 로그인이 풀려 다시 로그인할 때도 이 도구를 씁니다. id 는 get_page 의 칸 번호(없으면 지금 커서가 있는 칸), submit 이 true 면 넣은 뒤 Enter.',
    input_schema: {
      type: 'object',
      properties: {
        id: { type: 'string' },
        label: { type: 'string', description: '사용자에게 보여 줄 칸 이름(예: "네이버 비밀번호")' },
        submit: { type: 'boolean' },
      },
    },
  },
  {
    name: 'drag',
    description: '화면 사진(screenshot)에서 끌어다 놓습니다: (from_x, from_y) 에서 눌러 (to_x, to_y) 에 놓습니다(픽셀 좌표). 사진 순서 바꾸기, 사진을 다른 사진 옆에 놓아 한 줄로 묶기(네이버 블로그: 다른 사진의 오른쪽 가장자리에 놓기), 파일·카드 옮기기처럼 끌어야만 되는 일에 씁니다. 놓은 뒤 screenshot 으로 결과를 확인하세요.',
    input_schema: {
      type: 'object',
      properties: { from_x: { type: 'number' }, from_y: { type: 'number' }, to_x: { type: 'number' }, to_y: { type: 'number' }, tab_id: { type: 'integer', description: '다른 탭(원격 PC 탭 포함)에서 할 때 그 탭 번호' } },
      required: ['from_x', 'from_y', 'to_x', 'to_y'],
    },
  },
  {
    name: 'click_at',
    description: '화면 사진(screenshot)의 좌표를 클릭합니다. get_page 에 요소로 잡히지 않는 곳(네이버 블로그 글쓰기의 제목·본문칸, 구글 문서처럼 그림으로 그리는 편집기)에 커서를 놓을 때 씁니다. x·y 는 가장 최근 screenshot 사진의 픽셀 좌표입니다.',
    input_schema: {
      type: 'object',
      properties: { x: { type: 'number' }, y: { type: 'number' }, tab_id: { type: 'integer', description: '다른 탭(다른 프로필 포함)에서 할 때 그 탭 번호' } },
      required: ['x', 'y'],
    },
  },
  {
    name: 'paste_html',
    description: '서식 있는 글(제목·굵게·목록·표)을 지금 커서 자리에 붙여넣습니다(⌘V 와 같음). 긴 원고를 블로그·편집기 본문에 옮길 때 한 글자씩 치지 말고 이것을 씁니다. url 을 주면 그 주소의 글을 받아 붙입니다 — 구글 문서는 https://docs.google.com/document/d/<문서ID>/export?format=html (로그인이 필요하면 그 계정이 로그인된 다른 프로필로 받음). 직접 만든 HTML 은 html 에 줍니다. 먼저 click_at 으로 본문칸에 커서를 놓으세요. 사용자의 클립보드 내용이 이 글로 바뀝니다.',
    input_schema: {
      type: 'object',
      properties: {
        url: { type: 'string' },
        html: { type: 'string' },
        tab_id: { type: 'integer', description: '다른 탭(다른 프로필 포함)에서 할 때 그 탭 번호' },
      },
    },
  },
  {
    name: 'remember_site_tip',
    description: '이 사이트에서 시행착오 끝에 알아낸 방법을 짧게 저장합니다. 다음에 이 사이트를 쓸 때 대화 머리말에 "사이트 요령"으로 먼저 알려 줍니다. 예: "인용구 선택 목록: 인용구 2 = 버티컬 라인, 인용구 4 = 라인&따옴표". 한 번에 한 가지, 다음에 바로 따라 할 수 있게 구체적으로(단추 이름·순서). 사용자 개인정보·비밀번호는 적지 않습니다. 이미 요령에 있는 내용은 다시 저장하지 않습니다.',
    input_schema: {
      type: 'object',
      properties: {
        tip: { type: 'string' },
        replace_id: { type: 'string', description: '틀린 요령을 이것으로 고칠 때 그 요령 번호(예: b-blog.naver.com-3, l-1793...)' },
        tab_id: { type: 'integer', description: '다른 탭의 사이트 요령일 때 그 탭 번호' },
      },
      required: ['tip'],
    },
  },
  {
    name: 'forget_site_tip',
    description: '사이트 요령 중 틀린 것으로 확인된 요령을 지웁니다(요령 목록의 [번호]). 고쳐 쓸 내용이 있으면 remember_site_tip 의 replace_id 를 씁니다.',
    input_schema: {
      type: 'object',
      properties: { id: { type: 'string' }, reason: { type: 'string', description: '왜 틀렸는지 한 줄' } },
      required: ['id'],
    },
  },
  {
    name: 'select_option',
    description: '선택 상자(select)에서 항목을 고릅니다. option 은 선택지의 글자 또는 값입니다. 카드 유효기간처럼 가려 둔 값([[비공개N]])도 option 에 그대로 넣으면 사용자에게 묻고 진짜 값으로 고릅니다.',
    input_schema: {
      type: 'object',
      properties: { id: { type: 'string' }, option: { type: 'string' }, tab_id: { type: 'integer', description: '다른 탭(다른 프로필 포함)에서 할 때 그 탭 번호(list_tabs). 없으면 이 대화의 탭' } },
      required: ['id', 'option'],
    },
  },
  {
    name: 'scroll',
    description: '페이지를 스크롤합니다. id 를 주면 그 요소가 보이도록 스크롤합니다.',
    input_schema: {
      type: 'object',
      properties: {
        direction: { type: 'string', enum: ['up', 'down', 'top', 'bottom'] },
        id: { type: 'string' },
        tab_id: { type: 'integer', description: '다른 탭(다른 프로필 포함)에서 할 때 그 탭 번호(list_tabs). 없으면 이 대화의 탭' },
      },
      required: ['direction'],
    },
  },
  {
    name: 'press_key',
    description: '현재 포커스된 곳에 키를 누릅니다. key 는 Enter·Tab·Escape·Backspace·Delete·화살표(ArrowUp 등)·PageUp·PageDown·Home·End·Space 또는 글자 한 개(a~z, 0~9). modifiers 로 단축키를 씁니다: ⌘A(전체 선택)=key "a" + ["cmd"], ⌘Z(되돌리기), Shift+화살표(글 선택), ⌘+Shift+ArrowDown(끝까지 선택), Alt+Backspace(단어 지우기). 같은 키를 여러 번 누를 때는 한 번씩 부르지 말고 repeat 를 쓰세요(예: Backspace 30번 = repeat 30). 숫자·글을 넣을 때는 press_key 로 한 글자씩 누르지 말고 type_text 로 한 번에 넣으세요(한 글자씩 넣으면 사이트가 첫 글자에서 확인 창을 띄워 나머지가 막힐 수 있습니다).',
    input_schema: {
      type: 'object',
      properties: {
        key: { type: 'string' },
        modifiers: { type: 'array', items: { type: 'string' }, description: 'cmd · shift · alt · ctrl 중 함께 누를 것' },
        repeat: { type: 'integer', description: '같은 키를 누를 횟수(1~200, 기본 1)' },
        tab_id: { type: 'integer', description: '다른 탭(다른 프로필 포함)에서 할 때 그 탭 번호(list_tabs). 없으면 이 대화의 탭' } },
      required: ['key'],
    },
  },
  {
    name: 'navigate',
    description: '현재 탭에서 주소로 이동합니다. 주소가 아닌 글을 주면 네이버에서 검색합니다. 이동하면 사용자가 보던 화면과 입력해 둔 내용이 사라지니, 다른 사이트 정보를 가져오기만 할 때는 쓰지 않습니다(read_url, 안 되면 open_tab).',
    input_schema: {
      type: 'object',
      properties: { url: { type: 'string' }, tab_id: { type: 'integer', description: '다른 탭(다른 프로필 포함)에서 할 때 그 탭 번호(list_tabs). 없으면 이 대화의 탭' } },
      required: ['url'],
    },
  },
  {
    name: 'go_back',
    description: '현재 탭에서 뒤로 갑니다.',
    input_schema: { type: 'object', properties: { tab_id: { type: 'integer', description: '다른 탭(다른 프로필 포함)에서 할 때 그 탭 번호(list_tabs). 없으면 이 대화의 탭' } } },
  },
  {
    name: 'list_tabs',
    description: '열려 있는 탭 목록과 번호를 봅니다. ▶ 가 이 대화의 탭입니다. 다른 프로필 창의 탭도 "(프로필: 이름)"으로 함께 보입니다. 다른 탭(다른 프로필 포함)도 각 도구에 tab_id 를 주면 읽고 조작할 수 있습니다. 이은 다른 컴퓨터가 있으면 줄 끝에 보이고, computer 를 주면 그 컴퓨터에 연결해 탭을 "(컴퓨터: 이름)"으로 보여 줍니다(처음 연결 때 그 컴퓨터에서 허락이 필요할 수 있음).',
    input_schema: { type: 'object', properties: { computer: { type: 'string', description: '이은 다른 컴퓨터의 이름(사용자가 "PC 에서"처럼 말할 때). 없으면 이 컴퓨터' } } },
  },
  {
    name: 'list_downloads',
    description: '이 브라우저로 받은 파일 목록을 최근 것부터 봅니다(파일 이름·받는 중/완료/실패·크기·시작 시각). 내려받기 단추를 누른 뒤 파일이 받아졌는지 여기서 확인합니다. 받는 중이면 wait 후 다시 봅니다. 확인하지 않고 내려받기를 다시 누르면 같은 파일이 두 번 받아지니, 다시 누르기 전에 꼭 먼저 봅니다. 받은 뒤에도 사이트의 내려받기 창이 그대로 떠 있는 경우가 많으니, 그 창이 남아 있다는 것만으로 실패했다고 보지 않습니다.',
    input_schema: { type: 'object', properties: { limit: { type: 'integer', description: '몇 개까지 볼지(기본 10, 최대 30)' }, computer: { type: 'string', description: '이은 다른 컴퓨터의 이름(사용자가 "PC 에서"처럼 말할 때). 없으면 이 컴퓨터' } } },
  },
  {
    name: 'bring_file',
    description: '이은 다른 컴퓨터에서 받은 파일을 이 컴퓨터의 다운로드 폴더로 가져옵니다(30MB 까지). id 는 list_downloads(computer) 결과의 [파일 번호]입니다. 사용자가 그 컴퓨터에서 받은 파일(홈택스 엑셀 등)을 여기서 쓰고 싶어 할 때 씁니다.',
    input_schema: { type: 'object', properties: { computer: { type: 'string' }, id: { type: 'integer' } }, required: ['computer', 'id'] },
  },
  {
    name: 'read_url',
    description: '주소의 페이지를 화면에 띄우지 않고 읽습니다(제목·본문 글·링크). 이 프로필에서 로그인이 필요해 막히면(구글 문서 등) 그 계정이 로그인된 다른 프로필로 자동으로 읽습니다. 구글 문서 전체 글은 https://docs.google.com/document/d/<문서ID>/export?format=txt 로 읽을 수 있습니다. 검색 결과의 블로그·뉴스 글 여러 개를 살펴볼 때처럼, 사용자 화면을 바꾸지 않고 다른 페이지를 읽을 때 씁니다. 글이 길면 text_offset 으로 이어 읽습니다. 글이 거의 없으면(자바스크립트로 그리는 페이지) 그때만 다른 방법을 씁니다.',
    input_schema: {
      type: 'object',
      properties: {
        url: { type: 'string' },
        text_offset: { type: 'integer', description: '본문을 읽기 시작할 위치(기본 0)' },
      },
      required: ['url'],
    },
  },
  {
    name: 'open_tab',
    description: '새 탭을 뒤에 열고 그 번호를 알려 줍니다. 탭이 늘면 사용자가 헷갈리므로 꼭 필요할 때만 씁니다: 읽기만 하려면 read_url, 이동은 이 대화의 탭에서 navigate. 다만 지금 탭에서 하던 일(입력 중인 화면 등)에 다른 사이트 정보가 필요한데 read_url 로 안 읽히면(구글 캘린더 등), 지금 탭을 옮기지 말고 이것으로 작업용 탭을 열어 tab_id 로 읽고 누릅니다. 작업에 어쩔 수 없이 연 탭은 일이 끝나면 저절로 닫힙니다. 사용자가 "탭을 열어 줘"처럼 남겨 두길 원하면 keep=true.',
    input_schema: {
      type: 'object',
      properties: {
        url: { type: 'string' },
        keep: { type: 'boolean', description: '사용자가 열어 달라고 한 탭이면 true(끝나도 닫지 않음)' },
        computer: { type: 'string', description: '이은 다른 컴퓨터의 이름(사용자가 "PC 에서"처럼 말할 때). 없으면 이 컴퓨터' },
      },
      required: ['url'],
    },
  },
  {
    name: 'upload_file',
    description: '페이지의 "파일 올리기 칸"에 파일을 넣습니다(사진 첨부 등). id 는 get_page 결과에서 "파일 올리기 칸"으로 표시된 번호이거나, 누르면 파일 선택 창이 뜨는 단추([사진]·[파일 첨부] 등 — 네이버 블로그 편집기처럼 파일 칸이 처음엔 없는 곳)의 번호입니다. 단추면 선택 창을 띄우지 않고 그 자리에 넣습니다. '
      + '사용자가 AI 창에 첨부한 파일은 files 에 이름을, 그 탭이 있는 컴퓨터(원격 연결한 PC 포함)에 저장된 파일은 list_files 로 찾은 번호(F1 등)를 device_files 에 줍니다. '
      + '원격 PC 탭에도 AI 창에 첨부한 파일을 그대로 넣을 수 있습니다(그 PC 로 보내서 넣음). "사진 추가" 같은 단추를 click 으로 누르면 파일 선택 창이 떠서 조작할 수 없으니, 그 단추 번호를 이 도구의 id 로 주세요.',
    input_schema: {
      type: 'object',
      properties: {
        id: { type: 'string' },
        files: { type: 'array', items: { type: 'string' }, description: 'AI 창에 첨부한 파일 이름' },
        device_files: { type: 'array', items: { type: 'string' }, description: 'list_files 의 번호(F1 등) — 그 컴퓨터에 저장된 파일' },
        tab_id: { type: 'integer', description: '다른 탭(원격 PC 탭 포함)에 올릴 때 그 탭 번호' },
        key: { type: 'string', description: '단추가 없고 단축키로 파일 선택 창을 여는 곳에서 그 키(예: 피그마 "이미지 넣기" = key "k" + modifiers ["shift","cmd"], 윈도우는 ["shift","ctrl"]). 주면 id 없이 그 단축키로 열어 넣습니다' },
        modifiers: { type: 'array', items: { type: 'string' }, description: 'key 와 함께 누를 것(cmd · shift · alt · ctrl)' },
      },
    },
  },
  {
    name: 'approve_remote',
    description: 'Knock 이 쓰는 확인 도구입니다(연결된 서비스의 바꾸는 작업 전에 사용자에게 묻기). 직접 부르지 마세요.',
    input_schema: {
      type: 'object',
      properties: { tool_name: { type: 'string' }, input: { type: 'object' }, tool_use_id: { type: 'string' } },
      required: ['tool_name'],
    },
  },
  {
    name: 'download_file',
    description: '인터넷 주소의 그림·파일을 이 컴퓨터 다운로드 폴더(Knock)에 받고 파일 번호(F1 등)를 알려 줍니다. 검색으로 찾은 그림을 피그마·문서·블로그에 넣을 때: 이것으로 받은 뒤 upload_file 의 device_files 에 번호를 줍니다. url 은 그림 원본 주소(이미지 파일 주소 — 검색 결과 페이지 주소가 아님). 화질이 좋은 큰 원본을 고르세요. 실행 파일은 받지 않습니다(50MB 까지).',
    input_schema: {
      type: 'object',
      properties: {
        url: { type: 'string', description: '그림·파일의 원본 주소(http·https)' },
        name: { type: 'string', description: '저장할 이름(확장자 포함, 예: 마션-포스터.jpg). 없으면 주소의 이름' },
      },
      required: ['url'],
    },
  },
  {
    name: 'folder_files',
    description: '폴더 안의 파일 목록을 봅니다(이름·크기·날짜, 번호 F1 등). 사용자가 AI 창에 폴더를 첨부했거나("첨부한 폴더: output") 폴더 이름을 말하면 씁니다. '
      + 'folder 는 폴더 이름(예: "output") 또는 길(예: "Downloads/output"), names 에는 첨부 때 알려 준 그 폴더 안 파일 이름 몇 개를 주면 같은 이름 폴더 중 맞는 것을 고릅니다. '
      + '다운로드·바탕화면·사진·문서 안의 폴더만 됩니다. 결과 번호로 file_rename·file_trash·upload_file(device_files)을 씁니다. tab_id 에 원격 PC 탭 번호를 주면 그 PC 의 폴더를 봅니다.',
    input_schema: { type: 'object', properties: { folder: { type: 'string' }, names: { type: 'array', items: { type: 'string' } }, tab_id: { type: 'integer' } }, required: ['folder'] },
  },
  {
    name: 'file_rename',
    description: 'folder_files·list_files 번호의 파일 이름을 바꿉니다. items 는 [{ id: "F3", new_name: "사진_20261107.jpg" }] — 확장자는 그대로 두세요. 바꾸기 전에 사용자에게 목록을 보여 주고 묻습니다. 같은 이름이 이미 있으면 바꾸지 않습니다.',
    input_schema: { type: 'object', properties: { items: { type: 'array', items: { type: 'object', properties: { id: { type: 'string' }, new_name: { type: 'string' } }, required: ['id', 'new_name'] } }, tab_id: { type: 'integer' } }, required: ['items'] },
  },
  {
    name: 'file_trash',
    description: 'folder_files·list_files 번호의 파일을 휴지통으로 옮깁니다(지우기 — 휴지통에서 되살릴 수 있음). 옮기기 전에 사용자에게 목록을 보여 주고 묻습니다.',
    input_schema: { type: 'object', properties: { ids: { type: 'array', items: { type: 'string' } }, tab_id: { type: 'integer' } }, required: ['ids'] },
  },
  {
    name: 'list_files',
    description: '탭이 있는 컴퓨터에 저장된 파일을 최근 것부터 찾습니다(다운로드·바탕화면·사진·문서 폴더, 하위 폴더 2단계까지). tab_id 에 원격 PC 탭 번호를 주면 그 PC 의 파일을 봅니다. '
      + '결과의 번호(F1 등)를 upload_file 의 device_files 에 주면 그 파일을 페이지에 올립니다. 파일 내용은 읽지 않고 이름·크기·날짜만 봅니다.',
    input_schema: {
      type: 'object',
      properties: {
        folder: { type: 'string', enum: ['downloads', 'desktop', 'pictures', 'documents'], description: '없으면 네 곳 모두' },
        query: { type: 'string', description: '파일 이름·폴더 이름에 든 글자(예: "이든치과", ".jpg")' },
        tab_id: { type: 'integer', description: '원격 PC 탭 번호(그 PC 의 파일을 볼 때). 없으면 이 컴퓨터' },
      },
    },
  },
  {
    name: 'answer_dialog',
    description: '페이지에 뜬 알림창(alert·confirm·prompt)에 답합니다. accept=true 는 "확인", false 는 "취소"입니다. 알림창이 떠 있으면 다른 조작은 막힙니다.',
    input_schema: {
      type: 'object',
      properties: {
        accept: { type: 'boolean' },
        text: { type: 'string', description: 'prompt 창에 넣을 글(필요할 때만)' },
      },
      required: ['accept'],
    },
  },
  {
    name: 'import_chrome_bookmarks',
    description: '이 컴퓨터의 크롬 북마크를 Knock 북마크로 가져옵니다(폴더 그대로, 이미 있는 주소는 건너뜀). 사용자가 크롬 북마크를 가져와 달라고 할 때 씁니다. 크롬 프로필이 여러 개면 목록이 돌아오니, 사용자에게 고르게 한 뒤 profile 에 그 이름을 넣어 다시 부릅니다.',
    input_schema: {
      type: 'object',
      properties: { profile: { type: 'string', description: '크롬 프로필 이름(여러 개일 때만)' } },
    },
  },
  {
    name: 'wait',
    description: '페이지가 바뀌기를 잠시 기다립니다(seconds, 최대 10초). until("08:30:00" 같은 이 컴퓨터 시각)을 주면 그 시각까지 기다립니다(최대 4분) — 정각에 눌러야 하는 예약 작업에서, 페이지와 단추를 미리 준비해 둔 뒤 씁니다.',
    input_schema: {
      type: 'object',
      properties: {
        seconds: { type: 'number' },
        until: { type: 'string', description: '기다릴 시각 HH:MM:SS(오늘)' },
      },
    },
  },
  {
    name: 'schedule_task',
    description: '정한 시각에 AI 가 할 일을 예약합니다(한 번 또는 반복). 사용자가 "8시 30분에 등록해 줘", "매일 아침 확인해 줘"처럼 시간을 정해 맡기면 씁니다. 그 시각에 이 대화의 탭(닫혔으면 같은 주소의 새 탭)에서 prompt 를 사용자 말처럼 받아 일합니다. 사용자가 확인 카드로 허락해야 만들어집니다. Knock 이 켜져 있고 컴퓨터가 깨어 있어야 실행됩니다.\n정각에 눌러야 하는 일(신청·예매 오픈 등)은 2~3분 일찍 예약하고, prompt 에 "페이지를 새로 열어 단추를 찾아 둔 뒤 wait 의 until 로 정각까지 기다렸다가 바로 누른다"고 적습니다.\n첨부 파일이 필요하면 files 에 이 대화에서 첨부한 파일 이름을 넣습니다 — 예약을 취소할 때까지 보관했다가 실행할 때마다 다시 첨부합니다.',
    input_schema: {
      type: 'object',
      properties: {
        title: { type: 'string', description: '짧은 이름(예: 수강 신청)' },
        prompt: { type: 'string', description: '그 시각에 할 일. 나중에 이것만 보고 할 수 있게 구체적으로(어느 사이트·무엇을·어떻게 확인)' },
        at: { type: 'string', description: '처음(또는 한 번) 실행할 이 컴퓨터 시각 YYYY-MM-DDTHH:MM(:SS)' },
        repeat: { type: 'string', enum: ['none', 'daily', 'weekdays', 'weekly', 'every'], description: '반복: 없음·매일·평일·매주(at 의 요일)·몇 분마다' },
        every_minutes: { type: 'integer', description: 'repeat=every 일 때 간격(5분 이상)' },
        files: { type: 'array', items: { type: 'string' }, description: '보관해 두고 실행할 때마다 첨부할 파일 이름' },
      },
      required: ['title', 'prompt', 'at'],
    },
  },
  {
    name: 'recall_conversations',
    description: '다른 대화에서 나눈 내용을 찾아봅니다: 이 맥의 모든 Knock 프로필, 다른 탭의 Knock AI 대화, 옆창 Gemini 대화. 사용자가 "아까 Gemini 에게 물은 거", "다른 창(프로필)에서 한 얘기", "지난번에 정리한 것"처럼 말하면 씁니다. query 는 찾을 낱말(없으면 최근 것).',
    input_schema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '찾을 낱말(띄어 쓰면 모두 들어간 것)' },
        limit: { type: 'integer', description: '몇 개(기본 5, 최대 20)' },
      },
    },
  },
  {
    name: 'list_scheduled_tasks',
    description: '예약해 둔 작업 목록(번호·시각·할 일·보관 파일)을 봅니다.',
    input_schema: { type: 'object', properties: {} },
  },
  {
    name: 'cancel_scheduled_task',
    description: '예약 작업을 취소합니다(보관한 첨부 파일도 지웁니다). id 는 list_scheduled_tasks 의 번호입니다.',
    input_schema: {
      type: 'object',
      properties: { id: { type: 'string' } },
      required: ['id'],
    },
  },
  // 똑소리HR·TR 연결(2026-11-03, extension/toksori.js). 화면을 읽고 누르는 대신 그 서비스의 에이전트 창구를 부른다.
  {
    name: 'toksori_kit',
    description: '똑소리HR(hr.knocktools.com)에서 이 사용자가 쓸 수 있는 기능(도구 목록·입력 형식)과 쓰는 법, 화면 사용법을 받습니다. 직원·연차·급여·계약·근태처럼 똑소리HR 기록을 다루는 일이면 화면을 읽기 전에 먼저 부르세요(한 대화에 한 번이면 됩니다). 사용자가 똑소리HR 에 로그인해 있어야 합니다.',
    input_schema: {
      type: 'object',
      properties: {
        service: { type: 'string', enum: ['hr'], description: '서비스(지금은 hr 만)' },
        device: { type: 'string', enum: ['remote', 'here'], description: '원격 창 대화일 때만: remote = 원격 연결된 PC 의 똑소리, here = 지금 사용자가 쓰는 이 장치의 똑소리. 사용자가 장치를 말했으면(예: \"이 맥에서\", \"노트북 것\") 그쪽으로 넣고, 말하지 않았으면 비워 두세요(그러면 사용자에게 물어보라는 답이 옵니다).' },
      },
    },
  },
  {
    name: 'toksori_call',
    description: '똑소리HR 기능 하나를 실행합니다. tool 은 toksori_kit 이 준 도구 이름, input 은 그 도구의 입력입니다. 사용자의 로그인·권한대로 서버가 거른 결과가 옵니다(화면을 읽는 것보다 빠르고 정확합니다).',
    input_schema: {
      type: 'object',
      properties: {
        service: { type: 'string', enum: ['hr'] },
        tool: { type: 'string', description: 'toksori_kit 의 도구 이름' },
        input: { type: 'object', description: '그 도구의 입력' },
        device: { type: 'string', enum: ['remote', 'here'], description: '원격 창 대화일 때만: remote = 원격 연결된 PC 의 똑소리, here = 지금 사용자가 쓰는 이 장치의 똑소리. 사용자가 장치를 말했으면(예: \"이 맥에서\", \"노트북 것\") 그쪽으로 넣고, 말하지 않았으면 비워 두세요(그러면 사용자에게 물어보라는 답이 옵니다).' },
      },
      required: ['tool'],
    },
  },
];

const TOOL_BY_NAME = new Map(TOOLS.map((t) => [t.name, t]));

// 스트리밍 중 잘린 입력이 그대로 실행되지 않도록 스키마를 직접 확인한다.
function validateInput(name, input) {
  const tool = TOOL_BY_NAME.get(name);
  if (!tool) return `알 수 없는 도구: ${name}`;
  if (!input || typeof input !== 'object' || Array.isArray(input)) return '입력이 객체가 아닙니다.';
  const { properties = {}, required = [] } = tool.input_schema;
  for (const key of required) {
    if (!(key in input)) return `필수 값 ${key} 가 없습니다.`;
  }
  for (const [key, value] of Object.entries(input)) {
    const spec = properties[key];
    if (!spec) return `알 수 없는 값 ${key}`;
    const ok = spec.type === 'integer' ? Number.isInteger(value)
      : spec.type === 'number' ? typeof value === 'number'
        : spec.type === 'array' ? Array.isArray(value) && value.every((v) => typeof v === spec.items.type)
          : typeof value === spec.type;
    if (!ok) return `${key} 의 형식이 틀렸습니다(${spec.type} 이어야 함).`;
    if (spec.enum && !spec.enum.includes(value)) return `${key} 는 ${spec.enum.join(', ')} 중 하나여야 합니다.`;
  }
  return null;
}

module.exports = { TOOLS, validateInput };
