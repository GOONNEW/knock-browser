// 받아쓰기 일꾼(transcribe.js 가 띄움). 음성 인식 부품(onnxruntime)은 끝날 때 맥에서 비정상 종료 오류를 내므로
// 따로 떨어진 프로그램으로 돌리고, 끝낼 때는 SIGKILL 로 바로 끈다(오류 보고 창이 뜨지 않게).
// 입력: 한 줄 JSON { id, pcm(base64 16kHz 16비트), language } → 출력: { id, note } · { id, segments } · { id, error }
const os = require('os');
const path = require('path');

// 그림 처리 부품(sharp)은 받아쓰기에 쓰지 않는다 — 빈 것으로 바꿔 끼워 설치판에서 뺄 수 있게(윈도우·맥 모두)
require('module').registerHooks({
  resolve(spec, ctx, next) {
    if (spec === 'sharp') return { url: `data:text/javascript,${encodeURIComponent('export default function sharp() { throw new Error("no image"); }')}`, shortCircuit: true };
    return next(spec, ctx);
  },
});

const MODEL = 'onnx-community/whisper-large-v3-turbo';
let asr = null;
const out = (o) => process.stdout.write(`${JSON.stringify(o)}\n`);

async function load(id) {
  if (asr) return asr;
  const { pipeline, env } = await import('@huggingface/transformers');
  env.cacheDir = path.join(os.homedir(), '.knock', 'models');
  env.allowLocalModels = false;
  const seen = new Map();
  let last = 0;
  asr = await pipeline('automatic-speech-recognition', MODEL, {
    dtype: 'q4',
    progress_callback: (e) => {
      if (e.status !== 'progress' || !e.total) return;
      seen.set(e.file, [e.loaded, e.total]);
      if (Date.now() - last < 10000) return;
      last = Date.now();
      let got = 0;
      let all = 0;
      for (const [a, b] of seen.values()) { got += a; all += b; }
      if (all < 50 * 1048576) return; // 이미 받아 둔 것을 읽을 때는 알리지 않는다
      out({ id, note: `음성 인식 부품 받는 중(처음 한 번, 약 760MB) ${Math.round(got / 1048576)}/${Math.round(all / 1048576)}MB` });
    },
  });
  return asr;
}

// 음악·조용한 구간에서 Whisper 가 지어내는 흔한 말(실제로 말하지 않았는데 나옴) — 짧은 조각이면 버린다
const GHOST = /다음 영상에서 만나요|시청해\s*주셔서\s*감사|구독(과|이랑|하고)?\s*좋아요|좋아요(와|랑)?\s*구독|MBC\s*뉴스|자막\s*(제공|by)|thanks? for watching/i;

async function job({ id, pcm: b64, language }) {
  const buf = Buffer.from(b64 || '', 'base64');
  const pcm = new Int16Array(buf.buffer, buf.byteOffset, Math.floor(buf.length / 2));
  if (pcm.length < 8000) return out({ id, segments: [] });
  const audio = Float32Array.from(pcm, (v) => v / 32768);
  // 소리가 거의 없으면(무음 영상) 받아쓰지 않는다 — Whisper 는 무음에서 없는 말을 지어내기도 한다
  let sum = 0;
  for (let i = 0; i < audio.length; i += 4) sum += audio[i] * audio[i];
  if (Math.sqrt(sum / (audio.length / 4)) < 0.003) return out({ id, segments: [] });
  const p = await load(id);
  out({ id, note: '말소리 받아쓰는 중' });
  const r = await p(audio, { language: language || 'korean', task: 'transcribe', chunk_length_s: 30, stride_length_s: 5, return_timestamps: true });
  const segments = (r.chunks || [{ timestamp: [0, audio.length / 16000], text: r.text }])
    .map((c) => ({ start: Number(c.timestamp?.[0]) || 0, end: Number(c.timestamp?.[1]) || 0, text: String(c.text || '').trim() }))
    .filter((c) => c.text && !(c.text.length < 40 && GHOST.test(c.text)));
  // 노래·음악에서 같은 말을 되풀이하는 것을 한 번으로(조각 안 반복 → 줄이고, 같은 조각이 잇달아 나오면 버림)
  const clean = [];
  for (const c of segments) {
    c.text = c.text.replace(/(.{2,60}?)(?:[\s,.!?…]*\1){2,}/g, '$1');
    const prev = clean[clean.length - 1];
    if (prev && prev.text === c.text) { prev.end = c.end; continue; }
    clean.push(c);
  }
  out({ id, segments: clean });
}

let buf = '';
let chain = Promise.resolve();
process.stdin.setEncoding('utf8');
process.stdin.on('data', (d) => {
  buf += d;
  let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i);
    buf = buf.slice(i + 1);
    let msg;
    try { msg = JSON.parse(line); } catch { continue; }
    chain = chain.then(() => job(msg)).catch((err) => out({ id: msg.id, error: err.message || String(err) }));
  }
});
process.stdin.on('end', () => process.kill(process.pid, 'SIGKILL'));
