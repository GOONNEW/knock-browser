// Grok(xAI) — 명령줄 프로그램 없이 xAI API(OpenAI 와 같은 모양)로 직접 묻는다(2026-11-23 원장님 "그록 MCP, API 붙일 수 있게").
// 도구: Knock 페이지 도구 MCP 서버(mcp.js)와 똑소리 TR·HR MCP 에 MCP 클라이언트로 붙어 도구 목록을 그대로 넘긴다.
// TR·HR 도구는 Claude 와 같은 Knock 확인 카드(approve_remote)를 거친다 — 읽기는 통과, 바꾸기는 묻는다.
// 대화는 ~/.knock/grok-sessions/<번호>.json 에 남겨 이어 말할 수 있게 한다(이 사용자만 읽음).
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

// 시험할 때만 KNOCK_XAI_API 로 가짜 서버를 쓴다
const API = process.env.KNOCK_XAI_API || 'https://api.x.ai/v1';
const SESSIONS = path.join(os.homedir(), '.knock', 'grok-sessions');
const MAX_STEPS = 200; // 한 번 말에 도구를 부르는 횟수 한도(안전장치)
const KEEP_MESSAGES = 400; // 이어 말하기로 남겨 둘 메시지 수

const TOKSORI = { knocktr: '똑소리 TR', knockhr: '똑소리 HR' };

function sessionFile(id) {
  return path.join(SESSIONS, `${String(id).replace(/[^\w-]/g, '')}.json`);
}
function loadSession(id) {
  if (!id) return null;
  try { return JSON.parse(fs.readFileSync(sessionFile(id), 'utf8')); } catch { return null; }
}
function saveSession(id, messages) {
  fs.mkdirSync(SESSIONS, { recursive: true, mode: 0o700 });
  // 지난 차례의 사진은 글로 바꿔 둔다(파일이 커지지 않게, 다시 보낼 때 토큰도 아낌)
  const slim = messages.slice(-KEEP_MESSAGES).map((m) => (Array.isArray(m.content)
    ? { ...m, content: m.content.map((c) => (c.type === 'image_url' ? { type: 'text', text: '[사진 — 지난 차례라 빠짐]' } : c)) }
    : m));
  while (slim.length && slim[0].role === 'tool') slim.shift(); // 도구 결과로 시작하면 API 가 받지 않는다
  // 멈춘 때: 도구 결과가 다 오지 않은 도구 부름은 지운다(다음 차례에 API 가 받지 않는다)
  for (let i = slim.length - 1; i >= 0; i--) {
    const m = slim[i];
    if (m.role !== 'assistant' || !m.tool_calls?.length) continue;
    const got = new Set(slim.slice(i + 1).filter((x) => x.role === 'tool').map((x) => x.tool_call_id));
    if (!m.tool_calls.every((c) => got.has(c.id))) slim.splice(i);
    break;
  }
  const tmp = `${sessionFile(id)}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify({ messages: slim }), { mode: 0o600 });
  fs.renameSync(tmp, sessionFile(id));
}

// Knock 내용 블록(Anthropic 모양) → OpenAI 모양 사용자 말
function userContent(content, blocksToText) {
  const parts = [];
  const text = blocksToText(content);
  if (text) parts.push({ type: 'text', text });
  for (const b of content) {
    if (b.type === 'image' && b.source?.type === 'base64') parts.push({ type: 'image_url', image_url: { url: `data:${b.source.media_type};base64,${b.source.data}`, detail: 'high' } });
  }
  return parts.length ? parts : [{ type: 'text', text: '(빈 말)' }];
}

// MCP 결과 → 도구 답 글 + 따로 보낼 사진들
function toolOutput(result) {
  const texts = [];
  const images = [];
  for (const c of result?.content || []) {
    if (c.type === 'text') texts.push(c.text);
    else if (c.type === 'image') images.push({ type: 'image_url', image_url: { url: `data:${c.mimeType};base64,${c.data}`, detail: 'high' } });
  }
  let text = texts.join('\n') || (images.length ? '(사진으로 답함 — 다음 메시지)' : '(빈 결과)');
  if (result?.isError) text = `오류: ${text}`;
  return { text, images };
}

// 서버 보낸 이벤트(SSE) 줄 읽기
async function* sse(body) {
  const dec = new TextDecoder();
  let buf = '';
  for await (const chunk of body) {
    buf += dec.decode(chunk, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line.startsWith('data:')) continue;
      const data = line.slice(5).trim();
      if (data === '[DONE]') return;
      try { yield JSON.parse(data); } catch {}
    }
  }
}

function apiError(status, body) {
  let msg = '';
  try { const j = JSON.parse(body); msg = j.error?.message || j.error || j.message || ''; } catch { msg = body.slice(0, 300); }
  if (status === 401 || status === 403) return `Grok API 키가 맞지 않거나 막혔습니다. ⚙︎ 설정에서 키를 다시 넣어 주세요. (${msg})`;
  if (status === 429) return `Grok 사용량 한도에 걸렸습니다. 잠시 뒤 다시 해 주세요. (${msg})`;
  if (status === 402 || /credit|balance|billing/i.test(msg)) return `xAI 계정에 남은 금액(크레딧)이 없습니다. console.x.ai 에서 확인해 주세요. (${msg})`;
  return `Grok 응답 오류 ${status}: ${msg}`;
}

function createGrok({ blocksToText, verifyHttp }) {
  const grok = {
    id: 'grok',
    name: 'Grok',
    keyService: 'Knock AI - xAI API key',
    keyHint: 'xai-로 시작하는 키',
    install: '',
    models: () => [
      { id: 'grok-4.7', name: 'Grok 4.7 · 가장 똑똑함' },
      { id: 'grok-4.6', name: 'Grok 4.6 · 빠르고 균형' },
      { id: 'grok-4.3', name: 'Grok 4.3 · 가장 빠름' },
    ],
    // 계정 로그인은 없다 — API 키로만 쓴다(설치할 프로그램도 없음)
    async account() { return { installed: true, loggedIn: false }; },
    loginCommand() { return null; },
    async logout() {},
    async verifyKey(key) {
      if (!/^xai-[\w-]{20,}$/.test(key)) throw new Error('xAI API 키 모양이 아닙니다. "xai-" 로 시작하는 키를 붙여 넣어 주세요.');
      await verifyHttp(`${API}/models`, { authorization: `Bearer ${key}` }, '이 키로는 연결되지 않습니다. 키를 다시 확인해 주세요.');
    },
    run({ content, sessionId, model, mcp, system, cwd, key, tr = null, hr = null }, on) {
      const ctrl = new AbortController();
      let stopped = false;
      let ended = false;
      const pending = []; // 일하는 중에 덧붙인 말
      const clients = [];
      const id = sessionId && loadSession(sessionId) ? sessionId : crypto.randomUUID();
      const messages = loadSession(id)?.messages || [];
      const finish = (() => {
        let done = false;
        return (error) => {
          if (done) return;
          done = true;
          for (const c of clients) c.close().catch(() => {});
          on.done(stopped ? null : error, stopped);
        };
      })();

      (async () => {
        const { Client } = require('@modelcontextprotocol/sdk/client/index.js');
        const { StdioClientTransport } = require('@modelcontextprotocol/sdk/client/stdio.js');
        const { StreamableHTTPClientTransport } = require('@modelcontextprotocol/sdk/client/streamableHttp.js');
        // 도구 이름 → { client, name, server }
        const route = new Map();
        const tools = [];
        const connect = async (server, transport) => {
          const client = new Client({ name: 'knock-grok', version: '1.0.0' });
          await client.connect(transport);
          clients.push(client);
          const { tools: list } = await client.listTools();
          for (const t of list) {
            if (server === 'knock-browser' && t.name === 'approve_remote') continue; // Knock 이 쓰는 확인 카드 — AI 가 부를 것이 아님
            const fn = server === 'knock-browser' ? t.name : `${server}__${t.name}`.slice(0, 64);
            route.set(fn, { client, name: t.name, server });
            tools.push({ type: 'function', function: { name: fn, description: String(t.description || '').slice(0, 4000), parameters: t.inputSchema || { type: 'object', properties: {} } } });
          }
        };
        await connect('knock-browser', new StdioClientTransport({ command: mcp.command, args: mcp.args, env: { ...process.env, ...mcp.env }, cwd, stderr: 'ignore' }));
        for (const [server, s] of [['knocktr', tr], ['knockhr', hr]]) {
          if (!s) continue;
          try {
            await connect(server, new StreamableHTTPClientTransport(new URL(s.url), { requestInit: { headers: { Authorization: `Bearer ${s.token}` } } }));
          } catch (err) {
            on.note?.(`${TOKSORI[server]} 연결을 열지 못해 이번에는 빼고 합니다: ${err.message}`);
          }
        }
        const toksori = [...route.values()].some((r) => r.server !== 'knock-browser');
        const sys = `${system}\n\n도구는 Knock 브라우저 도구${toksori ? '와 똑소리 TR·HR 도구(knocktr__·knockhr__ 로 시작)' : ''}만 씁니다. 파일·명령어 도구는 없습니다.`;
        on.session(id);
        messages.push({ role: 'user', content: userContent(content, blocksToText) });
        on.delivered();

        let wrote = false;
        for (let step = 0; step < MAX_STEPS && !stopped; step++) {
          while (pending.length) {
            messages.push({ role: 'user', content: userContent(pending.shift(), blocksToText) });
            on.delivered();
          }
          const res = await fetch(`${API}/chat/completions`, {
            method: 'POST',
            signal: ctrl.signal,
            headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json' },
            body: JSON.stringify({
              model: model || 'grok-4.7',
              messages: [{ role: 'system', content: sys }, ...messages],
              tools,
              tool_choice: 'auto',
              stream: true,
              stream_options: { include_usage: true },
            }),
          });
          if (!res.ok) throw new Error(apiError(res.status, await res.text().catch(() => '')));
          let text = '';
          const calls = [];
          let usage = null;
          let fresh = wrote;
          for await (const ev of sse(res.body)) {
            if (ev.usage) usage = ev.usage;
            const d = ev.choices?.[0]?.delta;
            if (!d) continue;
            if (d.content) {
              text += d.content;
              on.text(d.content, fresh);
              fresh = false;
              wrote = true;
            }
            for (const tc of d.tool_calls || []) {
              const c = (calls[tc.index ?? calls.length] ||= { id: '', type: 'function', function: { name: '', arguments: '' } });
              if (tc.id) c.id = tc.id;
              if (tc.function?.name) c.function.name += tc.function.name;
              if (tc.function?.arguments) c.function.arguments += tc.function.arguments;
            }
          }
          if (usage) {
            const cached = Number(usage.prompt_tokens_details?.cached_tokens) || 0;
            const units = Math.round(Math.max(0, (usage.prompt_tokens || 0) - cached) + cached * 0.1 + (usage.completion_tokens || 0) * 5);
            if (units > 0) on.usage?.(units);
          }
          const real = calls.filter(Boolean);
          messages.push({ role: 'assistant', content: text || null, ...(real.length ? { tool_calls: real } : {}) });
          if (!real.length) {
            if (pending.length) continue; // 답 끝에 덧붙인 말이 있으면 이어서
            break;
          }
          const images = [];
          for (const c of real) {
            if (stopped) break;
            const r = route.get(c.function.name);
            let input = {};
            try { input = c.function.arguments ? JSON.parse(c.function.arguments) : {}; } catch {}
            let out;
            if (!r) {
              out = { text: `없는 도구입니다: ${c.function.name}`, images: [] };
            } else {
              let allow = true;
              if (r.server !== 'knock-browser') {
                on.note?.(`${TOKSORI[r.server]}: ${r.name}`);
                allow = false;
                const a = await on.approve?.(`mcp__${r.server}__${r.name}`, input).catch(() => null);
                try { allow = JSON.parse(a?.content || '{}').behavior === 'allow'; } catch {}
              }
              if (!allow) out = { text: '사용자가 허용하지 않았습니다. 이 일은 하지 말고 그렇게 알리세요.', images: [] };
              else {
                try {
                  out = toolOutput(await r.client.callTool({ name: r.name, arguments: input }, undefined, { timeout: 8 * 60 * 1000 }));
                } catch (err) {
                  out = { text: `오류: ${err.message}`, images: [] };
                }
              }
            }
            messages.push({ role: 'tool', tool_call_id: c.id, content: out.text });
            images.push(...out.images);
          }
          // 도구 답의 사진(화면 사진 등)은 도구 답에 못 넣어 사용자 말로 붙인다
          if (images.length) messages.push({ role: 'user', content: [{ type: 'text', text: '[바로 앞 도구 결과의 사진입니다]' }, ...images] });
        }
        ended = true;
        saveSession(id, messages);
        finish(null);
      })().catch((err) => {
        ended = true;
        try { if (messages.length) saveSession(id, messages); } catch {}
        finish(stopped || err.name === 'AbortError' ? null : err.message);
      });

      return {
        stop: () => { stopped = true; ctrl.abort(); },
        inject: (c) => { if (stopped || ended) return false; pending.push(c); return true; },
      };
    },
  };
  return grok;
}

module.exports = { createGrok };
