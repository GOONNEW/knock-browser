// 업데이트 확인·설치(개발 중인 이 컴퓨터용).
// 새로 만든 것(AI 확장 소스, 다시 만든 Knock.app, 도우미 코드)이 설치된 /Applications/Knock.app 과 다르면 "업데이트 있음".
// 설치: package.sh 로 묶어 /Applications 에 덮어쓰고, Knock 을 껐다 켠다(탭·대화는 확장이 되살린다).
// 배포판의 자동 업데이트(서버에서 받기)는 배포 방식이 정해지면 따로 붙인다.
//
// 명령줄: node update.js stamp <파일>  — 지금 소스 상태를 기록(package.sh 가 앱 안에 넣는다)
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');

const AI_DIR = path.join(__dirname, '..');
const ROOT = path.join(AI_DIR, '..'); // knock-chromium
const EXT_DIR = path.join(AI_DIR, 'extension');
const HOST_DIR = __dirname;
const BUILT_APP = path.join(ROOT, 'chromium/src/out/Release/Knock.app');
const INSTALLED_APP = '/Applications/Knock.app';
const STAMP_FILE = 'Contents/Resources/knock-build.json';
const BUILD_SETTLE_MS = 60000; // 만드는 중인 앱을 설치하지 않도록, 바뀐 뒤 1분은 기다린다

function hashDir(dir, skip = new Set()) {
  const h = crypto.createHash('sha256');
  const walk = (d) => {
    for (const name of fs.readdirSync(d).sort()) {
      if (skip.has(name) || name.startsWith('.')) continue;
      const p = path.join(d, name);
      const st = fs.statSync(p);
      if (st.isDirectory()) walk(p);
      else h.update(path.relative(dir, p)).update(fs.readFileSync(p));
    }
  };
  walk(dir);
  return h.digest('hex').slice(0, 16);
}

// 다시 만들 때마다 바뀌는 앱 실행 파일들의 수정 시각
function appTime() {
  const files = [
    path.join(BUILT_APP, 'Contents/MacOS/Knock'),
    path.join(BUILT_APP, 'Contents/Frameworks/Knock Framework.framework/Versions/Current/Knock Framework'),
  ];
  return Math.max(...files.map((f) => {
    try { return Math.floor(fs.statSync(f).mtimeMs); } catch { return 0; }
  }));
}

const hostHash = () => hashDir(HOST_DIR, new Set(['node_modules', 'run.sh']));
const HOST_AT_START = hostHash();

function sourceStamp() {
  return { ext: hashDir(EXT_DIR), app: appTime() };
}

function installedStamp() {
  try {
    return JSON.parse(fs.readFileSync(path.join(INSTALLED_APP, STAMP_FILE), 'utf8'));
  } catch {
    return null;
  }
}

function installedVersion() {
  try {
    return JSON.parse(fs.readFileSync(path.join(INSTALLED_APP, 'Contents/Resources/knock-ai/manifest.json'), 'utf8')).version;
  } catch {
    return null;
  }
}

// 바뀐 부분 목록. 없으면 빈 배열.
// runningVersion: 지금 Knock 에서 돌고 있는 AI 확장 버전(모르면 null) — 설치는 됐는데 아직 다시 켜지 않은 경우도 알린다.
function check(runningVersion) {
  const parts = [];
  // 설치판(앱 안에 넣은 도우미)에는 개발 소스가 없다 — 배포판은 GitHub 에 올린 새 판으로 확인한다(release-update.js)
  if (!fs.existsSync(EXT_DIR)) return require('./release-update').parts();
  const installed = installedStamp();
  if (installed) {
    const src = sourceStamp();
    const notRestarted = installedVersion() && runningVersion !== installedVersion();
    if (src.ext !== installed.ext || notRestarted) parts.push('AI 창');
    if (src.app > installed.app && Date.now() - src.app > BUILD_SETTLE_MS) parts.push('Knock 브라우저');
  }
  try {
    if (hostHash() !== HOST_AT_START) parts.push('AI 도우미');
  } catch {}
  return parts;
}

// 새로 묶어 /Applications 에 덮어쓴다. 도우미만 바뀐 경우는 다시 켜기만 하면 된다.
function install() {
  const installed = installedStamp();
  const src = sourceStamp();
  if (installed && src.ext === installed.ext && src.app <= installed.app) return;
  const pack = spawnSync(path.join(ROOT, 'package.sh'), { encoding: 'utf8' });
  if (pack.status !== 0) throw new Error(`묶기 실패: ${(pack.stderr || pack.stdout).trim().split('\n').slice(-2).join(' ')}`);
  // 예전 AI 파일(이름이 바뀐 옛 백그라운드 등)이 남지 않게 AI 폴더는 비우고 덮는다
  fs.rmSync(path.join(INSTALLED_APP, 'Contents/Resources/knock-ai'), { recursive: true, force: true });
  const copy = spawnSync('ditto', [path.join(ROOT, 'dist/Knock.app'), INSTALLED_APP], { encoding: 'utf8' });
  if (copy.status !== 0) throw new Error(`설치 실패: ${copy.stderr.trim()}`);
}

// Knock 을 끄고 새로 켠다. 이 도우미도 Knock 과 함께 꺼지므로 따로 떨어진 셸이 한다.
// Knock 이 다 꺼지기까지 오래 걸릴 수 있어(탭이 많을 때) 2분까지 기다리고,
// 켠 뒤에는 정말 켜졌는지 보고 안 켜졌으면 몇 번 더 켠다. 모든 단계를 host.log 에 남긴다.
// app: 다시 켤 Knock.app, cleanup: 다시 켠 뒤 지울 옛 앱(배포판 업데이트)
function relaunch(app = INSTALLED_APP, cleanup = null) {
  const logFile = path.join(require('os').homedir(), '.knock', 'host.log');
  // 켜져 있는 설치판 Knock 의 프로세스 번호. pgrep -f 는 Knock 이 띄운 이 도우미 안에서는
  // 다른 프로그램의 실행 줄을 읽지 못해(맥 보호) 늘 "없음"이 나왔다 — 맥의 앱 목록으로 찾는다.
  const pids = `osascript -l JavaScript -e 'ObjC.import("AppKit"); const a = $.NSWorkspace.sharedWorkspace.runningApplications; const out = []; for (let i = 0; i < a.count; i++) { const x = a.objectAtIndex(i); const u = x.bundleURL; if (u && !u.isNil() && u.path.js === "${app}") out.push(x.processIdentifier); } out.join(" ")'`;
  const script = `
    exec >>"${logFile}" 2>&1
    echo "[relaunch] 시작 $$"
    sleep 1
    old=$(${pids})
    if [ -z "$old" ]; then echo "[relaunch] 켜진 Knock 을 찾지 못함 — 켜기만 함"; fi
    # 설치된 Knock 에게만 "종료"를 부탁한다(크롬 계열은 TERM 신호로는 꺼지지 않는다).
    # 앱 이름으로 부탁하면 같은 이름의 다른 Knock(시험용 창)만 꺼질 수 있어서, 프로세스 번호로 정확히 고른다.
    for pid in $old; do
      osascript -l JavaScript -e "ObjC.import('AppKit'); \$.NSRunningApplication.runningApplicationWithProcessIdentifier($pid).terminate" >/dev/null
      echo "[relaunch] 종료 부탁: $pid"
    done
    alive() { for pid in $old; do kill -0 $pid 2>/dev/null && return 0; done; return 1; }
    for i in $(seq 1 240); do alive || break; sleep 0.5; done
    if alive; then echo "[relaunch] 2분이 지나도 안 꺼짐 — 다시 켜지 않음"; exit 1; fi
    echo "[relaunch] 꺼짐 확인, 다시 켜기"
    for try in 1 2 3; do
      open "${app}"
      sleep 4
      if [ -n "$(${pids})" ]; then echo "[relaunch] 켜짐($try 번째)"; ${cleanup ? `rm -rf "${cleanup}"; echo "[relaunch] 옛 판 지움";` : ''} exit 0; fi
      echo "[relaunch] 아직 안 켜짐, 다시 시도"
    done
    echo "[relaunch] 다시 켜지 못함"
  `;
  spawn('/bin/sh', ['-c', script], { detached: true, stdio: 'ignore' }).unref();
}

if (require.main === module && process.argv[2] === 'stamp') {
  fs.writeFileSync(process.argv[3], JSON.stringify(sourceStamp()));
}

// 배포판인지(앱 안에 넣은 도우미로 돌고, 개발 소스가 없음)
const isRelease = () => !fs.existsSync(EXT_DIR);

module.exports = { check, install, relaunch, isRelease };
