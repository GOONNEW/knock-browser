// 크롬 북마크 읽기(똑소리 브라우저 chromeImport.js 에서 옮김). 크롬이 저장해 둔 Bookmarks 파일(JSON)을 읽기만 한다.
const fs = require('fs');
const os = require('os');
const path = require('path');

function chromeDir() {
  if (process.platform === 'darwin') return path.join(os.homedir(), 'Library/Application Support/Google/Chrome');
  if (process.platform === 'win32') return path.join(process.env.LOCALAPPDATA || '', 'Google/Chrome/User Data');
  return path.join(os.homedir(), '.config/google-chrome');
}

function countUrls(node) {
  if (!node) return 0;
  if (node.type === 'url') return 1;
  return (node.children || []).reduce((n, c) => n + countUrls(c), 0);
}

function readBookmarks(profileDir) {
  if (/[\\/]|\.\./.test(profileDir)) throw new Error('프로필 이름이 이상합니다.');
  return JSON.parse(fs.readFileSync(path.join(chromeDir(), profileDir, 'Bookmarks'), 'utf8')).roots;
}

let lastError = null; // 크롬 폴더를 읽지 못한 이유(맥 개인정보 보호 등)

// 북마크가 있는 크롬 프로필 목록: [{ dir, name, email, count }] (많은 순) — 크롬은 프로필마다 구글 계정이 하나(email, 없으면 '')
function listProfiles() {
  let info = {};
  try {
    info = JSON.parse(fs.readFileSync(path.join(chromeDir(), 'Local State'), 'utf8')).profile.info_cache;
  } catch (err) {
    lastError = err.message;
    info = { Default: { name: '기본' } };
  }
  const out = [];
  for (const [dir, p] of Object.entries(info)) {
    try {
      const roots = readBookmarks(dir);
      const count = countUrls(roots.bookmark_bar) + countUrls(roots.other) + countUrls(roots.synced);
      if (count > 0) out.push({ dir, name: p.name || dir, email: p.user_name || '', count });
    } catch (err) {
      // 북마크 파일이 없는 프로필은 건너뛴다(읽기를 막힌 경우는 이유를 남긴다)
      if (err.code !== 'ENOENT') lastError = err.message;
    }
  }
  return out.sort((a, b) => b.count - a.count);
}

// 크롬 형식 → { title, url } / { title, children }. 열 수 없는 주소(javascript:, chrome:// 등)는 뺀다.
function convert(nodes, skipped) {
  const out = [];
  for (const n of nodes || []) {
    if (n.type === 'folder') {
      out.push({ title: n.name, children: convert(n.children, skipped) });
    } else if (n.type === 'url') {
      if (/^https?:/i.test(n.url)) out.push({ title: n.name || n.url, url: n.url });
      else skipped.push(n.name || n.url);
    }
  }
  return out;
}

// 북마크바와 기타 북마크(모바일 북마크는 기타에 더한다)
function readProfile(dir) {
  const roots = readBookmarks(dir);
  const skipped = [];
  const bar = convert(roots.bookmark_bar?.children, skipped);
  const other = convert(roots.other?.children, skipped);
  const synced = convert(roots.synced?.children, skipped);
  if (synced.length) other.push({ title: '모바일 북마크', children: synced });
  return { bar, other, skipped: skipped.length };
}

module.exports = { listProfiles, readProfile, lastError: () => lastError };
