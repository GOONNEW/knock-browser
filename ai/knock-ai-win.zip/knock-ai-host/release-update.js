// 배포판(설치 파일로 깐 Knock)의 업데이트.
// 새 판은 GitHub(GOONNEW/knock-browser)의 "최신 릴리스"에 올린다: Knock.dmg(서명·공증된 설치 파일) + latest.json.
//   latest.json = { release: 판 번호, version, url: Knock.dmg 주소, sha256, size, date, notes }
// 확인: 켤 때와 몇 시간마다 latest.json 을 읽어, 설치된 판 번호(앱 안 knock-release.json)보다 크면 "업데이트 있음".
// 설치: 내려받기 → 내용 확인(sha256) → 열어서 우리 애플 개발자 서명(팀 L5R53MS9QZ)·애플 공증인지 확인 →
//       지금 앱은 옆으로 비켜 두고 새 앱을 같은 자리에 넣는다(다시 켠 뒤 옛 앱은 지운다).
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { Readable } = require('stream');
const { pipeline } = require('stream/promises');

const FEED = process.env.KNOCK_UPDATE_FEED || 'https://github.com/GOONNEW/knock-browser/releases/latest/download/latest.json';
const TEAM_ID = 'L5R53MS9QZ';
// 이 도우미는 Knock.app/Contents/Resources/knock-ai-host 안에서 돈다
const APP = path.resolve(__dirname, '../../..');

function installedRelease() {
  try {
    return Number(JSON.parse(fs.readFileSync(path.join(APP, 'Contents/Resources/knock-release.json'), 'utf8')).release) || 0;
  } catch {
    return 0;
  }
}

let latest = null; // 마지막으로 읽은 latest.json

async function refresh() {
  const res = await fetch(FEED, { redirect: 'follow', headers: { 'cache-control': 'no-cache' } });
  if (!res.ok) throw new Error(`새 판 정보를 받지 못했습니다(${res.status}).`);
  const feed = await res.json();
  if (!Number.isInteger(feed.release) || !/^https:\/\/(github\.com|objects\.githubusercontent\.com)\//.test(feed.url || '') || !/^[0-9a-f]{64}$/.test(feed.sha256 || '')) {
    throw new Error('새 판 정보가 이상합니다.');
  }
  latest = feed;
  return feed;
}

function parts() {
  return latest && latest.release > installedRelease() ? ['Knock 새 판'] : [];
}

function run(cmd, args) {
  const r = spawnSync(cmd, args, { encoding: 'utf8' });
  return { ok: r.status === 0, out: `${r.stdout || ''}${r.stderr || ''}` };
}

// 우리 서명(팀 번호)과 애플 공증이 맞는 Knock 인지
function verifyApp(app) {
  if (!run('codesign', ['--verify', '--deep', '--strict', app]).ok) throw new Error('새 판의 서명이 맞지 않아 설치하지 않았습니다.');
  const info = run('codesign', ['-dv', '--verbose=2', app]).out;
  if (!info.includes(`TeamIdentifier=${TEAM_ID}`)) throw new Error('새 판이 Knock 개발사의 서명이 아니라 설치하지 않았습니다.');
  if (!run('spctl', ['--assess', '--type', 'execute', app]).ok) throw new Error('새 판이 애플 확인(공증)을 받지 않아 설치하지 않았습니다.');
}

// 새 판을 받아 바꿔 넣는다. 돌려주는 old: 다시 켠 뒤 지울 옛 앱 경로
async function install(log = () => {}) {
  const feed = await refresh();
  if (!(feed.release > installedRelease())) throw new Error('이미 최신 판입니다.');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'knock-update-'));
  const dmg = path.join(dir, 'Knock.dmg');
  const mnt = path.join(dir, 'mnt');
  try {
    log('새 판 내려받는 중', feed.release);
    const res = await fetch(feed.url, { redirect: 'follow' });
    if (!res.ok || !res.body) throw new Error(`새 판을 내려받지 못했습니다(${res.status}).`);
    await pipeline(Readable.fromWeb(res.body), fs.createWriteStream(dmg));
    const sum = crypto.createHash('sha256').update(fs.readFileSync(dmg)).digest('hex');
    if (sum !== feed.sha256) throw new Error('내려받은 파일이 올린 것과 달라 설치하지 않았습니다.');
    fs.mkdirSync(mnt);
    if (!run('hdiutil', ['attach', '-nobrowse', '-readonly', '-noautoopen', '-mountpoint', mnt, dmg]).ok) throw new Error('설치 파일을 열지 못했습니다.');
    try {
      const src = path.join(mnt, 'Knock.app');
      verifyApp(src);
      const old = path.join(path.dirname(APP), `.Knock-old-${Date.now()}.app`);
      try {
        fs.renameSync(APP, old);
      } catch (err) {
        throw new Error(`Knock 을 바꿀 권한이 없습니다(${err.code}). 응용 프로그램 폴더에 쓸 수 있는 계정인지 확인하세요.`);
      }
      const copy = run('ditto', [src, APP]);
      if (!copy.ok) {
        fs.rmSync(APP, { recursive: true, force: true });
        fs.renameSync(old, APP); // 되돌린다
        throw new Error(`새 판을 넣지 못했습니다: ${copy.out.trim().split('\n').pop()}`);
      }
      log('새 판 넣음', feed.release);
      return { old, release: feed.release };
    } finally {
      run('hdiutil', ['detach', mnt, '-force']);
    }
  } finally {
    fs.rmSync(dmg, { force: true });
  }
}

// 화면에 보이는 버전 세 자리(2026-11-07) — 없으면 ''
function installedVer() {
  try {
    const v = String(JSON.parse(fs.readFileSync(path.join(APP, 'Contents/Resources/knock-release.json'), 'utf8')).ver || '');
    return /^\d+\.\d+\.\d+$/.test(v) ? v : '';
  } catch {
    return '';
  }
}

module.exports = { FEED, APP, refresh, parts, install, installedRelease, installedVer };
