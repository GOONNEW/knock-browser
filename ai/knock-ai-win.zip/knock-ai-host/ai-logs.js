// AI 원본 기록(2026-11-18 원장님 "원본기록파일 삭제는 환경설정에 삭제 기능을 넣어줘. 사용자가 삭제하거나, 일정기간 자동 삭제"):
// Claude·ChatGPT(Codex)·Gemini 프로그램이 이 PC 에 따로 쌓는 대화 원본(AI 가 읽은 페이지·도구 결과까지 그대로 든 파일).
// 지난 대화 목록(브라우저·똑소리 서버)과는 따로라 지워도 목록은 남는다 — 오래된 대화를 이어 갈 때 AI 가 그때 읽은 페이지를
// 그대로 기억하지 못할 뿐(보이는 질문·답은 넘겨받는다).
// 설정: ~/.knock/ai-logs.json { days } — 기본 14일(지난 대화 보관과 같게), 0 = 자동으로 지우지 않음.
const fs = require('fs');
const os = require('os');
const path = require('path');

const HOME = path.join(os.homedir(), '.knock');
const PREFS = path.join(HOME, 'ai-logs.json');
const DIRS = [
  path.join(HOME, 'claude-config', 'projects'),
  path.join(HOME, 'codex-home', 'sessions'),
  path.join(HOME, 'gemini-home', '.gemini', 'tmp'),
];
const CHOICES = [3, 7, 14, 30, 0];
const BUSY_MS = 10 * 60 * 1000; // 지금 쓰는 대화(10분 안에 바뀐 파일)는 지우지 않는다

function days() {
  try { const d = JSON.parse(fs.readFileSync(PREFS, 'utf8')).days; return CHOICES.includes(d) ? d : 14; } catch { return 14; }
}

function walk(dir, fn) {
  let list = [];
  try { list = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of list) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      walk(p, fn);
      try { if (!fs.readdirSync(p).length) fs.rmdirSync(p); } catch {}
    } else if (e.isFile()) fn(p);
  }
}

function info() {
  let bytes = 0;
  let files = 0;
  for (const d of DIRS) walk(d, (p) => { try { bytes += fs.statSync(p).size; files += 1; } catch {} });
  return { bytes, files, days: days() };
}

/** olderThanMs 보다 오래된 파일을 지운다(지금 쓰는 것은 빼고) → 지운 수 */
function prune(olderThanMs) {
  const cut = Date.now() - Math.max(olderThanMs, BUSY_MS);
  let removed = 0;
  for (const d of DIRS) walk(d, (p) => {
    try { if (fs.statSync(p).mtimeMs < cut) { fs.unlinkSync(p); removed += 1; } } catch {}
  });
  return removed;
}

// Claude 프로그램도 같은 기간에 스스로 지우게(설정 파일의 cleanupPeriodDays). 0(지우지 않음)이면 10년
function claudeSetting(d) {
  const f = path.join(HOME, 'claude-config', 'settings.json');
  let s = {};
  try { s = JSON.parse(fs.readFileSync(f, 'utf8')) || {}; } catch {}
  const want = d || 3650;
  if (s.cleanupPeriodDays === want) return;
  s.cleanupPeriodDays = want;
  try { fs.mkdirSync(path.dirname(f), { recursive: true, mode: 0o700 }); fs.writeFileSync(f, JSON.stringify(s, null, 2), { mode: 0o600 }); } catch {}
}

function auto() {
  const d = days();
  claudeSetting(d);
  return d ? prune(d * 86400000) : 0;
}

function setDays(d) {
  if (!CHOICES.includes(d)) throw new Error('기간을 다시 골라 주세요.');
  fs.mkdirSync(HOME, { recursive: true, mode: 0o700 });
  fs.writeFileSync(PREFS, JSON.stringify({ days: d }), { mode: 0o600 });
  auto();
}

function clearAll() {
  return prune(0);
}

// 도우미가 켜질 때와 6시간마다
function start(log = () => {}) {
  const run = () => { try { const n = auto(); if (n) log(`AI 원본 기록 ${n}개 지움(${days()}일 지난 것)`); } catch {} };
  setTimeout(run, 30 * 1000).unref?.();
  setInterval(run, 6 * 3600 * 1000).unref?.();
}

module.exports = { info, setDays, clearAll, start, CHOICES, DIRS };
