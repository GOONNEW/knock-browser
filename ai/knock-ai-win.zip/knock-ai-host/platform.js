// 맥·윈도우 차이를 한곳에 모은다. 맥은 예전 그대로(키체인·osascript), 윈도우는 아래처럼 바꿔 쓴다.
//   비밀 보관   맥: 키체인(security) · 윈도우: 이 사용자 계정으로만 풀리는 DPAPI 암호 파일(~/.knock/secrets)
//   클립보드    맥: NSPasteboard · 윈도우: .NET 클립보드(HTML 형식 + 글자)
// 비밀 값은 명령줄 인자에 드러나지 않게 입력(stdin)·환경 변수로만 넘긴다.
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn, spawnSync } = require('child_process');

const IS_WIN = process.platform === 'win32';
const SECRET_DIR = path.join(os.homedir(), '.knock', 'secrets');

function powershell(script, { input, env } = {}) {
  return spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-STA', '-Command', script], {
    input, env: { ...process.env, ...env }, encoding: 'utf8', timeout: 15000, windowsHide: true,
  });
}

function powershellAsync(script, { env } = {}) {
  return new Promise((resolve) => {
    const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-STA', '-Command', script], { env: { ...process.env, ...env }, windowsHide: true });
    let stderr = '';
    p.stderr.on('data', (d) => { stderr += d; });
    p.stdout.resume();
    const timer = setTimeout(() => p.kill(), 15000);
    p.on('error', (err) => { clearTimeout(timer); resolve({ status: -1, stderr: err.message }); });
    p.on('close', (status) => { clearTimeout(timer); resolve({ status, stderr }); });
  });
}

function secretFile(service, account) {
  const name = crypto.createHash('sha256').update(`${service}\n${account}`).digest('hex').slice(0, 32);
  return path.join(SECRET_DIR, `${name}.dpapi`);
}

// 윈도우 비밀 보관(맥은 security 명령을 그대로 쓴다 — providers.js·vault.js)
const winSecret = {
  get(service, account) {
    const file = secretFile(service, account);
    if (!fs.existsSync(file)) return null;
    const r = powershell(
      "Add-Type -AssemblyName System.Security; $e=[IO.File]::ReadAllBytes($env:KNOCK_SECRET_FILE); "
      + "[Console]::Out.Write([Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Unprotect($e,$null,'CurrentUser')))",
      { env: { KNOCK_SECRET_FILE: file } },
    );
    if (r.status !== 0) throw new Error('윈도우 보관함에서 꺼내지 못했습니다.');
    return Buffer.from(r.stdout.trim(), 'base64').toString('utf8') || null;
  },
  set(service, account, value) {
    fs.mkdirSync(SECRET_DIR, { recursive: true, mode: 0o700 });
    const r = powershell(
      "Add-Type -AssemblyName System.Security; $b=[Convert]::FromBase64String([Console]::In.ReadToEnd().Trim()); "
      + "[IO.File]::WriteAllBytes($env:KNOCK_SECRET_FILE,[Security.Cryptography.ProtectedData]::Protect($b,$null,'CurrentUser'))",
      { input: Buffer.from(String(value), 'utf8').toString('base64'), env: { KNOCK_SECRET_FILE: secretFile(service, account) } },
    );
    if (r.status !== 0) throw new Error('윈도우 보관함에 저장하지 못했습니다.');
  },
  remove(service, account) {
    fs.rmSync(secretFile(service, account), { force: true });
  },
};

// 윈도우 클립보드에 서식 있는 글(HTML)과 글자만 있는 글을 함께 넣는다.
// HTML 형식은 앞머리에 바이트 위치를 적어야 한다(CF_HTML).
function winSetClipboard(html, text) {
  const body = `<html><body><!--StartFragment-->${html}<!--EndFragment--></body></html>`;
  const head = 'Version:0.9\r\nStartHTML:0000000000\r\nEndHTML:0000000000\r\nStartFragment:0000000000\r\nEndFragment:0000000000\r\n';
  const len = (s) => Buffer.byteLength(s, 'utf8');
  const pad = (n) => String(n).padStart(10, '0');
  const start = len(head);
  const fragStart = start + len(body.slice(0, body.indexOf('<!--StartFragment-->') + '<!--StartFragment-->'.length));
  const fragEnd = start + len(body.slice(0, body.indexOf('<!--EndFragment-->')));
  const cf = head.replace('StartHTML:0000000000', `StartHTML:${pad(start)}`)
    .replace('EndHTML:0000000000', `EndHTML:${pad(start + len(body))}`)
    .replace('StartFragment:0000000000', `StartFragment:${pad(fragStart)}`)
    .replace('EndFragment:0000000000', `EndFragment:${pad(fragEnd)}`) + body;
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'knock-clip-'));
  try {
    fs.writeFileSync(path.join(dir, 'h'), html ? cf : ''); // 서식 없이 글만 복사한 때는 빈 서식을 넣지 않는다(엑셀이 빈 서식을 붙였다)
    fs.writeFileSync(path.join(dir, 't'), String(text || ''));
    const r = powershell(
      "Add-Type -AssemblyName System.Windows.Forms; $u=New-Object Text.UTF8Encoding $false; $d=New-Object Windows.Forms.DataObject; "
      + "$h=[IO.File]::ReadAllBytes((Join-Path $env:KNOCK_CLIP 'h')); if($h.Length){$d.SetData('HTML Format',(New-Object IO.MemoryStream(,$h)))}; "
      + "$t=[IO.File]::ReadAllText((Join-Path $env:KNOCK_CLIP 't'),$u); if($t){$d.SetText($t)}; [Windows.Forms.Clipboard]::SetDataObject($d,$true)",
      { env: { KNOCK_CLIP: dir } },
    );
    if (r.status !== 0) throw new Error((r.stderr || '').trim().split('\n').pop() || `종료 코드 ${r.status}`);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

// 윈도우에 설치된 구글 크롬
function winChrome() {
  const roots = [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], process.env.LOCALAPPDATA].filter(Boolean);
  return roots.map((r) => path.join(r, 'Google', 'Chrome', 'Application', 'chrome.exe')).find((p) => fs.existsSync(p)) || null;
}

// 윈도우에 설치된 마이크로소프트 엣지(보호 영상 넘기기, 2026-11-10)
function winEdge() {
  const roots = [process.env['ProgramFiles(x86)'], process.env.ProgramFiles, process.env.LOCALAPPDATA].filter(Boolean);
  return roots.map((r) => path.join(r, 'Microsoft', 'Edge', 'Application', 'msedge.exe')).find((p) => fs.existsSync(p)) || null;
}

// 이 사용자의 다운로드 폴더(윈도우는 위치를 옮겨 둘 수 있어 실제 위치를 묻는다 — 패러렐즈는 맥 폴더로 돌려 둠)
let downloads = null;
function downloadsDir() {
  if (downloads) return downloads;
  if (IS_WIN) {
    const r = powershell("[Console]::Out.Write((New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path)");
    if (r.status === 0 && r.stdout.trim()) downloads = r.stdout.trim();
  }
  downloads ||= path.join(os.homedir(), 'Downloads');
  return downloads;
}

// 윈도우 클립보드의 글자와 서식 있는 글(HTML)을 읽는다(원격: 그 PC 에서 복사한 것을 보는 쪽 맥으로, 2026-11-13).
// HTML 형식은 앞머리(CF_HTML)의 바이트 위치로 본문만 잘라 낸다.
const CLIP_DEF = ['[DllImport("user32.dll")] public static extern bool OpenClipboard(IntPtr h);',
  '[DllImport("user32.dll")] public static extern bool CloseClipboard();',
  '[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint RegisterClipboardFormat(string n);',
  '[DllImport("user32.dll")] public static extern IntPtr GetClipboardData(uint f);',
  '[DllImport("kernel32.dll")] public static extern IntPtr GlobalLock(IntPtr h);',
  '[DllImport("kernel32.dll")] public static extern bool GlobalUnlock(IntPtr h);',
  '[DllImport("kernel32.dll")] public static extern UIntPtr GlobalSize(IntPtr h);'].join(' ');
// 원격 조작 중에 부르므로 도우미를 멈추지 않게(마우스가 굳지 않게) 따로 돌린다
async function winGetClipboard() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'knock-clip-'));
  try {
    const r = await powershellAsync(
      "Add-Type -AssemblyName System.Windows.Forms; $u=New-Object Text.UTF8Encoding $false; $d=[Windows.Forms.Clipboard]::GetDataObject(); "
      + "$t=''; if($d -and $d.GetDataPresent([Windows.Forms.DataFormats]::UnicodeText)){$t=[string]$d.GetData([Windows.Forms.DataFormats]::UnicodeText)}; "
      + "[IO.File]::WriteAllText((Join-Path $env:KNOCK_CLIP 't'),$t,$u); "
      // HTML 형식은 .NET 이 한글을 깨뜨려 읽어(옛 코드 페이지) 바이트 그대로 꺼낸다
      + "Add-Type -Name KnockClip -Namespace W -MemberDefinition $env:KNOCK_CLIPDEF; "
      + "if([W.KnockClip]::OpenClipboard([IntPtr]::Zero)){ try { $g=[W.KnockClip]::GetClipboardData([W.KnockClip]::RegisterClipboardFormat('HTML Format')); "
      + "if($g -ne [IntPtr]::Zero){ $p=[W.KnockClip]::GlobalLock($g); $n=[int][W.KnockClip]::GlobalSize($g).ToUInt64(); $b=New-Object byte[] $n; [Runtime.InteropServices.Marshal]::Copy($p,$b,0,$n); [W.KnockClip]::GlobalUnlock($g) | Out-Null; "
      + "[IO.File]::WriteAllBytes((Join-Path $env:KNOCK_CLIP 'h'),$b) } } finally { [W.KnockClip]::CloseClipboard() | Out-Null } }",
      { env: { KNOCK_CLIP: dir, KNOCK_CLIPDEF: CLIP_DEF } },
    );
    if (r.status !== 0) throw new Error((r.stderr || '').trim().split('\n').pop() || `종료 코드 ${r.status}`);
    const text = fs.existsSync(path.join(dir, 't')) ? fs.readFileSync(path.join(dir, 't'), 'utf8') : '';
    let html = '';
    if (fs.existsSync(path.join(dir, 'h'))) {
      const buf = fs.readFileSync(path.join(dir, 'h'));
      const head = buf.subarray(0, 400).toString('latin1');
      const at = (k) => Number((head.match(new RegExp(`${k}:(\\d+)`)) || [])[1]);
      const start = at('StartHTML'); const end = at('EndHTML');
      html = (start >= 0 && end > start ? buf.subarray(start, end) : buf).toString('utf8').replace(/\0+$/, '');
    }
    return { text, html };
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

module.exports = { IS_WIN, winSecret, winSetClipboard, winGetClipboard, winChrome, winEdge, downloadsDir };
