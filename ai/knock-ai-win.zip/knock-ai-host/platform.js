// 맥·윈도우 차이를 한곳에 모은다. 맥은 예전 그대로(키체인·osascript), 윈도우는 아래처럼 바꿔 쓴다.
//   비밀 보관   맥: 키체인(security) · 윈도우: 이 사용자 계정으로만 풀리는 DPAPI 암호 파일(~/.knock/secrets)
//   클립보드    맥: NSPasteboard · 윈도우: .NET 클립보드(HTML 형식 + 글자)
// 비밀 값은 명령줄 인자에 드러나지 않게 입력(stdin)·환경 변수로만 넘긴다.
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const IS_WIN = process.platform === 'win32';
const SECRET_DIR = path.join(os.homedir(), '.knock', 'secrets');

function powershell(script, { input, env } = {}) {
  return spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-STA', '-Command', script], {
    input, env: { ...process.env, ...env }, encoding: 'utf8', timeout: 15000, windowsHide: true,
  });
}

function secretFile(service, account) {
  const name = crypto.createHash('sha256').update(`${service}\n${account}`).digest('hex').slice(0, 32);
  return path.join(SECRET_DIR, `${name}.dpapi`);
}

// 윈도우 비밀 보관(맥은 security 명령을 그대로 쓴다 — providers.js·vault.js)
const winSecret = {
  get(service, account) {
    const file = secretFile(service, account);
    if (!fs.existsSync(file)) return null;
    const r = powershell(
      "Add-Type -AssemblyName System.Security; $e=[IO.File]::ReadAllBytes($env:KNOCK_SECRET_FILE); "
      + "[Console]::Out.Write([Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Unprotect($e,$null,'CurrentUser')))",
      { env: { KNOCK_SECRET_FILE: file } },
    );
    if (r.status !== 0) throw new Error('윈도우 보관함에서 꺼내지 못했습니다.');
    return Buffer.from(r.stdout.trim(), 'base64').toString('utf8') || null;
  },
  set(service, account, value) {
    fs.mkdirSync(SECRET_DIR, { recursive: true, mode: 0o700 });
    const r = powershell(
      "Add-Type -AssemblyName System.Security; $b=[Convert]::FromBase64String([Console]::In.ReadToEnd().Trim()); "
      + "[IO.File]::WriteAllBytes($env:KNOCK_SECRET_FILE,[Security.Cryptography.ProtectedData]::Protect($b,$null,'CurrentUser'))",
      { input: Buffer.from(String(value), 'utf8').toString('base64'), env: { KNOCK_SECRET_FILE: secretFile(service, account) } },
    );
    if (r.status !== 0) throw new Error('윈도우 보관함에 저장하지 못했습니다.');
  },
  remove(service, account) {
    fs.rmSync(secretFile(service, account), { force: true });
  },
};

// 윈도우 클립보드에 서식 있는 글(HTML)과 글자만 있는 글을 함께 넣는다.
// HTML 형식은 앞머리에 바이트 위치를 적어야 한다(CF_HTML).
function winSetClipboard(html, text) {
  const body = `<html><body><!--StartFragment-->${html}<!--EndFragment--></body></html>`;
  const head = 'Version:0.9\r\nStartHTML:0000000000\r\nEndHTML:0000000000\r\nStartFragment:0000000000\r\nEndFragment:0000000000\r\n';
  const len = (s) => Buffer.byteLength(s, 'utf8');
  const pad = (n) => String(n).padStart(10, '0');
  const start = len(head);
  const fragStart = start + len(body.slice(0, body.indexOf('<!--StartFragment-->') + '<!--StartFragment-->'.length));
  const fragEnd = start + len(body.slice(0, body.indexOf('<!--EndFragment-->')));
  const cf = head.replace('StartHTML:0000000000', `StartHTML:${pad(start)}`)
    .replace('EndHTML:0000000000', `EndHTML:${pad(start + len(body))}`)
    .replace('StartFragment:0000000000', `StartFragment:${pad(fragStart)}`)
    .replace('EndFragment:0000000000', `EndFragment:${pad(fragEnd)}`) + body;
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'knock-clip-'));
  try {
    fs.writeFileSync(path.join(dir, 'h'), cf);
    fs.writeFileSync(path.join(dir, 't'), String(text || ''));
    const r = powershell(
      "Add-Type -AssemblyName System.Windows.Forms; $u=New-Object Text.UTF8Encoding $false; $d=New-Object Windows.Forms.DataObject; "
      + "$h=[IO.File]::ReadAllBytes((Join-Path $env:KNOCK_CLIP 'h')); $d.SetData('HTML Format',(New-Object IO.MemoryStream(,$h))); "
      + "$t=[IO.File]::ReadAllText((Join-Path $env:KNOCK_CLIP 't'),$u); if($t){$d.SetText($t)}; [Windows.Forms.Clipboard]::SetDataObject($d,$true)",
      { env: { KNOCK_CLIP: dir } },
    );
    if (r.status !== 0) throw new Error((r.stderr || '').trim().split('\n').pop() || `종료 코드 ${r.status}`);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

// 윈도우에 설치된 구글 크롬
function winChrome() {
  const roots = [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], process.env.LOCALAPPDATA].filter(Boolean);
  return roots.map((r) => path.join(r, 'Google', 'Chrome', 'Application', 'chrome.exe')).find((p) => fs.existsSync(p)) || null;
}

// 이 사용자의 다운로드 폴더(윈도우는 위치를 옮겨 둘 수 있어 실제 위치를 묻는다 — 패러렐즈는 맥 폴더로 돌려 둠)
let downloads = null;
function downloadsDir() {
  if (downloads) return downloads;
  if (IS_WIN) {
    const r = powershell("[Console]::Out.Write((New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path)");
    if (r.status === 0 && r.stdout.trim()) downloads = r.stdout.trim();
  }
  downloads ||= path.join(os.homedir(), 'Downloads');
  return downloads;
}

module.exports = { IS_WIN, winSecret, winSetClipboard, winChrome, downloadsDir };
