// Knock 맥 앱 다루기: 접근성 정보로 맥 앱을 읽고 조작하는 작은 프로그램(bin/knock-desktop)을 다룬다.
// 한 프로그램을 켜 두고 요청을 차례로 보낸다(번호 ref 는 그 프로그램 안에 기억된다).
// 설치판은 묶을 때 미리 만든 것을, 개발판은 없으면 swiftc 로 만들어 쓴다.
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { spawn, spawnSync } = require('child_process');

const BIN = path.join(__dirname, 'bin', 'knock-desktop');
const SRC = path.join(__dirname, 'input', 'knock-desktop.swift');

let proc = null;
let waiting = [];
let chain = Promise.resolve(); // 요청은 하나씩

function ensureBin() {
  if (process.platform === 'win32') throw new Error('맥 앱 다루기는 아직 윈도우에서 쓸 수 없습니다.');
  if (fs.existsSync(BIN) && (!fs.existsSync(SRC) || fs.statSync(BIN).mtimeMs >= fs.statSync(SRC).mtimeMs)) return;
  if (!fs.existsSync(SRC)) throw new Error('맥 앱 다루기 도구가 없습니다.');
  fs.mkdirSync(path.dirname(BIN), { recursive: true });
  const r = spawnSync('swiftc', ['-O', '-o', BIN, SRC], { encoding: 'utf8' });
  if (r.status !== 0) throw new Error(`맥 앱 다루기 도구를 만들지 못했습니다: ${(r.stderr || '').trim().split('\n').pop()}`);
  // Knock 이 띄운 프로그램이 만든 파일에는 맥이 '받은 파일' 표시를 붙여 열기를 막는다 — 직접 만든 것이니 뗀다
  spawnSync('xattr', ['-d', 'com.apple.quarantine', BIN]);
}

function start() {
  if (proc) return proc;
  ensureBin();
  proc = spawn(BIN, [], { stdio: ['pipe', 'pipe', 'ignore'] });
  readline.createInterface({ input: proc.stdout }).on('line', (line) => {
    let r;
    try { r = JSON.parse(line); } catch { r = { ok: false, error: '답을 읽지 못했습니다.' }; }
    waiting.shift()?.(r);
  });
  proc.on('exit', () => {
    proc = null;
    for (const w of waiting.splice(0)) w({ ok: false, error: '맥 앱 다루기 도구가 멈췄습니다.' });
  });
  return proc;
}

// 손쉬운 사용 권한은 프로그램이 켜질 때 정해지므로, 권한이 없다고 답하면 다음 요청 때 새로 켠다
function call(req, timeoutMs = 20000) {
  if (/^note/.test(req.op || '')) return note(req);
  const run = () => new Promise((resolve) => {
    const p = start();
    const timer = setTimeout(() => {
      resolve({ ok: false, error: '앱이 답하지 않습니다(바쁘거나 멈춤).' });
      stop();
    }, timeoutMs);
    waiting.push((r) => {
      clearTimeout(timer);
      if (r.error && /손쉬운 사용/.test(r.error)) stop();
      resolve(r);
    });
    p.stdin.write(`${JSON.stringify(req)}\n`);
  });
  const next = chain.then(run, run);
  chain = next.catch(() => {});
  return next;
}

// 메모 앱: 화면을 누르고 치면 서식이 꼬인다(첫 줄 제목 서식이 전체에 번짐 · 메뉴가 본문에 안 먹음).
// 메모 앱이 직접 받는 명령(Apple 이벤트)으로 찾고·읽고·HTML 로 쓴다 — 화면에 띄우지 않고, 사용자 입력과 섞이지 않는다.
const NOTE_JXA = `
function run(argv) {
  const m = JSON.parse(argv[0]);
  const Notes = Application('Notes');
  const info = (n) => ({ id: n.id(), name: n.name(), folder: (() => { try { return n.container().name(); } catch (e) { return ''; } })(), modified: n.modificationDate().toISOString() });
  if (m.op === 'noteFind') {
    const q = String(m.query || '');
    const list = q ? Notes.notes.whose({ name: { _contains: q } })() : Notes.notes();
    return JSON.stringify({ ok: true, notes: list.slice(0, 20).map(info) });
  }
  if (m.op === 'noteRead') {
    const n = Notes.notes.byId(m.id);
    return JSON.stringify({ ok: true, ...info(n), text: n.plaintext(), html: n.body() });
  }
  if (m.op === 'noteWrite') {
    if (m.id) {
      const n = Notes.notes.byId(m.id);
      n.body = m.html;
      return JSON.stringify({ ok: true, ...info(n) });
    }
    const folder = m.folder ? Notes.folders.whose({ name: m.folder })()[0] : null;
    if (m.folder && !folder) return JSON.stringify({ ok: false, error: '그 이름의 메모 폴더가 없습니다: ' + m.folder });
    const n = Notes.Note({ body: m.html });
    (folder ? folder.notes : Notes.defaultAccount().defaultFolder().notes).push(n);
    return JSON.stringify({ ok: true, ...info(n) });
  }
  if (m.op === 'noteFolders') {
    return JSON.stringify({ ok: true, folders: Notes.folders().map((f) => f.name()) });
  }
  return JSON.stringify({ ok: false, error: '모르는 메모 명령' });
}`;
function note(req) {
  return new Promise((resolve) => {
    const p = spawn('osascript', ['-l', 'JavaScript', '-e', NOTE_JXA, JSON.stringify(req)], { stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '';
    let err = '';
    p.stdout.on('data', (d) => { out += d; });
    p.stderr.on('data', (d) => { err += d; });
    const timer = setTimeout(() => { p.kill(); resolve({ ok: false, error: '메모 앱이 답하지 않습니다.' }); }, 30000);
    p.on('close', () => {
      clearTimeout(timer);
      try { return resolve(JSON.parse(out)); } catch {}
      // 처음 한 번은 맥이 "Knock 이 메모를 제어하려고 합니다"를 묻는다
      if (/-1743|not authori[sz]ed|허용되지/i.test(err)) return resolve({ ok: false, error: '메모 앱을 다룰 권한이 없습니다. 맥 설정 → 개인정보 보호 및 보안 → 자동화에서 Knock 의 "메모"를 켜 주세요.' });
      resolve({ ok: false, error: `메모 앱 명령이 실패했습니다: ${err.trim().split('\n').pop() || '알 수 없음'}` });
    });
  });
}

function stop() {
  proc?.kill();
  proc = null;
}

module.exports = { call, stop };
