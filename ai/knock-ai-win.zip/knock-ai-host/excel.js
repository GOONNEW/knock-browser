// 엑셀 DB 파일에 줄 더하기(2026-11-09 원장님 "여신금융협회 매입내역 받아서 카드DB 시트에 새 것만 추가").
// 원본 표(내려받은 .xls — 옛 BIFF·HTML 표, .xlsx, .csv)를 읽어 대상 xlsx 시트의 열 머리·형식에 맞춰 바꾸고,
// 이미 있는 줄은 빼고 맨 아래에 붙인다.
// 대상 파일은 SheetJS 로 다시 쓰지 않는다(서식·피벗·수식·다른 시트가 깨짐). xlsx 안의 XML 에서
// 그 시트의 <sheetData> 끝에 줄만 넣고, 엑셀 표(테이블) 범위·필터·피벗 원본 범위·이름 범위만 늘린다.
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const XLSX = require('xlsx');
const JSZip = require('jszip');
const { downloadsDir } = require('./platform');

const IS_WIN = process.platform === 'win32';
const BACKUP_MARK = 'Knock 백업';

// ── 파일 찾기: 다운로드·바탕화면·문서·사진·OneDrive·구글 드라이브(맥 CloudStorage) 안에서만 ──
function roots() {
  const home = os.homedir();
  const list = [downloadsDir(), ...['Desktop', 'Documents', 'Pictures', 'OneDrive'].map((d) => path.join(home, d))];
  const cloud = path.join(home, 'Library', 'CloudStorage');
  if (!IS_WIN && fs.existsSync(cloud)) list.push(cloud);
  if (IS_WIN) { // 윈도우 구글 드라이브(G: 등) · 맥 공유 폴더(Parallels \\Mac\Home)
    for (const d of 'DEFGHIJ') { const p = `${d}:\\내 드라이브`; if (fs.existsSync(p)) list.push(p); }
  }
  if (process.env.KNOCK_EXCEL_TEST_ROOT) list.push(process.env.KNOCK_EXCEL_TEST_ROOT); // 시험용 폴더(시험할 때만)
  return [...new Set(list.map((p) => path.resolve(p)))].filter((p) => fs.existsSync(p));
}
const inRoots = (p) => { const r = path.resolve(p); return roots().some((x) => r.startsWith(x + path.sep)); };
const isTemp = (n) => n.startsWith('~$') || n.startsWith('.');

// spec: 전체 경로 · 홈 기준 길 · 파일 이름. 이름이면 찾아서 최근 것을 고르고 같은 이름 다른 곳도 알린다.
function resolveFile(spec, exts) {
  const want = String(spec || '').trim();
  if (!want) throw new Error('파일을 알려 주세요(파일 이름이나 F 번호).');
  const tryPath = [want, path.join(os.homedir(), want)].find((p) => path.isAbsolute(p) && fs.existsSync(p) && fs.statSync(p).isFile());
  if (tryPath) {
    if (!inRoots(tryPath)) throw new Error('다운로드·바탕화면·문서·사진·OneDrive·구글 드라이브 안의 파일만 다룹니다.');
    return { file: tryPath, others: [] };
  }
  const base = path.basename(want).normalize('NFC').toLowerCase();
  const hasExt = /\.[a-z0-9]{2,5}$/i.test(base);
  const ok = (n) => {
    const l = n.normalize('NFC').toLowerCase();
    if (isTemp(n) || (l.includes(BACKUP_MARK.toLowerCase()) && !base.includes(BACKUP_MARK.toLowerCase()))) return false;
    if (hasExt) return l === base;
    return exts.test(l) && (l.slice(0, l.lastIndexOf('.')) === base || l.startsWith(base));
  };
  const found = new Set();
  const walk = (dir, depth, maxDepth, deadline) => {
    if (Date.now() > deadline || found.size > 50) return;
    let list = [];
    try { list = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const d of list) {
      if (d.name.startsWith('.') || d.name === 'node_modules') continue;
      const full = path.join(dir, d.name);
      if (d.isDirectory()) { if (depth < maxDepth) walk(full, depth + 1, maxDepth, deadline); } else if (ok(d.name)) found.add(full);
    }
  };
  // 1) 다운로드 폴더(사이트에서 받은 파일) 먼저 얕게
  const all = roots();
  for (const r of all.filter((x) => x === path.resolve(downloadsDir()) || x === process.env.KNOCK_EXCEL_TEST_ROOT)) walk(r, 0, 3, Date.now() + 3000);
  // 2) 맥: Spotlight(구글 드라이브까지 빠름)
  if (!IS_WIN) {
    const q = hasExt ? base.slice(0, base.lastIndexOf('.')) : base;
    const r = spawnSync('mdfind', ['-name', q], { encoding: 'utf8', timeout: 8000 });
    for (const line of (r.stdout || '').split('\n')) if (line && ok(path.basename(line)) && inRoots(line)) found.add(line);
  }
  // 3) 그래도 없으면 직접 훑기
  if (!found.size) { const deadline = Date.now() + 15000; for (const r of all) walk(r, 0, 7, deadline); }
  if (!found.size) throw new Error(`"${want}" 파일을 다운로드·바탕화면·문서·사진·OneDrive·구글 드라이브에서 찾지 못했습니다.`);
  const st = (p) => { try { return fs.statSync(p).mtimeMs; } catch { return 0; } };
  const list = [...found].filter((p) => st(p));
  if (!list.length) throw new Error(`"${want}" 파일을 찾지 못했습니다.`);
  list.sort((a, b) => st(b) - st(a));
  return { file: list[0], others: list.slice(1, 5) };
}

// 엑셀이 열고 있으면 같은 폴더에 "~$이름" 잠금 파일이 있다(긴 이름은 앞 1~2글자가 빠지기도 함)
function lockedBy(file) {
  const dir = path.dirname(file);
  const name = path.basename(file);
  let list = [];
  try { list = fs.readdirSync(dir); } catch { return null; }
  return list.find((n) => n.startsWith('~$') && n.length > 4 && name.endsWith(n.slice(2)) && n.slice(2).length >= name.length - 2) || null;
}

// ── 원본 표 읽기 ──
function decodeText(buf) {
  const head = buf.subarray(0, 4096).toString('latin1');
  const meta = /charset\s*=\s*["']?\s*(euc-kr|ks_c_5601-1987|cp949|utf-8)/i.exec(head);
  const utf8 = buf.toString('utf8');
  if (meta && !/utf-8/i.test(meta[1])) return new TextDecoder('euc-kr').decode(buf);
  if (!meta && utf8.includes('\uFFFD')) return new TextDecoder('euc-kr').decode(buf); // UTF-8 이 아니면 한국 사이트는 대개 EUC-KR
  return utf8.replace(/^\uFEFF/, '');
}

function readSourceBook(file) {
  const buf = fs.readFileSync(file);
  const sig = buf.subarray(0, 8).toString('hex');
  const isZip = sig.startsWith('504b0304');
  const isBiff = sig === 'd0cf11e0a1b11ae1';
  let book;
  if (isZip || isBiff) book = XLSX.read(buf, { type: 'buffer', raw: true, cellDates: false });
  else book = XLSX.read(decodeText(buf), { type: 'string', raw: true, cellDates: false }); // HTML 표·CSV 를 .xls 로 주는 사이트
  const kind = isZip ? 'xlsx' : isBiff ? '옛 엑셀 xls' : /<table/i.test(buf.subarray(0, 65536).toString('latin1')) ? 'HTML 표 xls' : 'csv·글';
  return { book, kind };
}

function sourceRows(file, sheet) {
  const { book, kind } = readSourceBook(file);
  const name = sheet && book.SheetNames.includes(sheet) ? sheet : book.SheetNames[0];
  const rows = XLSX.utils.sheet_to_json(book.Sheets[name], { header: 1, raw: true, defval: '', blankrows: false });
  return { kind, sheets: book.SheetNames, sheet: name, rows };
}

// ── xlsx 안쪽 읽기 ──
const xmlDecode = (s) => s.replace(/&(lt|gt|amp|quot|apos|#\d+|#x[0-9a-f]+);/gi, (m, e) => {
  const l = e.toLowerCase();
  if (l === 'lt') return '<'; if (l === 'gt') return '>'; if (l === 'amp') return '&'; if (l === 'quot') return '"'; if (l === 'apos') return "'";
  return String.fromCodePoint(l[1] === 'x' ? parseInt(l.slice(2), 16) : parseInt(l.slice(1), 10));
});
const xmlEncode = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
  // XML 에 못 넣는 제어 문자는 뺀다
  // eslint-disable-next-line no-control-regex
  .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
const attr = (tag, name) => { const m = new RegExp(`\\s${name}="([^"]*)"`).exec(tag); return m ? xmlDecode(m[1]) : null; };
const colNum = (letters) => { let n = 0; for (const ch of letters) n = n * 26 + (ch.charCodeAt(0) - 64); return n; };
const colName = (n) => { let s = ''; for (; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + ((n - 1) % 26)) + s; return s; };
const splitRef = (ref) => { const m = /^\$?([A-Z]+)\$?(\d+)$/.exec(ref); return m ? { c: colNum(m[1]), r: Number(m[2]) } : null; };
const resolveTarget = (baseDir, target) => (target.startsWith('/') ? target.slice(1) : path.posix.normalize(path.posix.join(baseDir, target)));

async function openBook(file) {
  const zip = await JSZip.loadAsync(fs.readFileSync(file));
  const text = async (p) => (zip.file(p) ? zip.file(p).async('string') : null);
  const wb = await text('xl/workbook.xml');
  if (!wb) throw new Error('엑셀(xlsx) 파일이 아닙니다.');
  const rels = await text('xl/_rels/workbook.xml.rels') || '';
  const relMap = {};
  for (const m of rels.matchAll(/<Relationship\b[^>]*>/g)) relMap[attr(m[0], 'Id')] = { target: attr(m[0], 'Target'), type: attr(m[0], 'Type') || '' };
  const sheets = [...wb.matchAll(/<sheet\b[^>]*>/g)].map((m) => ({ name: attr(m[0], 'name'), part: resolveTarget('xl', relMap[attr(m[0], 'r:id')]?.target || '') }));
  const ssPart = Object.values(relMap).find((r) => r.type.endsWith('/sharedStrings'));
  const stPart = Object.values(relMap).find((r) => r.type.endsWith('/styles'));
  return { zip, text, wb, sheets, ssPath: ssPart ? resolveTarget('xl', ssPart.target) : null, stPath: stPart ? resolveTarget('xl', stPart.target) : null, date1904: /<workbookPr\b[^>]*date1904="(1|true)"/.test(wb) };
}

function parseShared(xml) {
  const out = [];
  if (!xml) return out;
  for (const m of xml.matchAll(/<si>([\s\S]*?)<\/si>|<si\/>/g)) {
    const body = (m[1] || '').replace(/<rPh\b[\s\S]*?<\/rPh>/g, ''); // 한글 읽기(후리가나) 부분은 뺀다
    out.push([...body.matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>|<t\b[^>]*\/>/g)].map((t) => xmlDecode(t[1] || '')).join(''));
  }
  return out;
}

// 날짜 서식인지(셀 서식 번호 → 표시 형식)
const BUILTIN_DATE = new Set([14, 15, 16, 17, 18, 19, 20, 21, 22, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 45, 46, 47, 50, 51, 52, 53, 54, 55, 56, 57, 58]);
function styleInfo(xml) {
  const fmts = {};
  for (const m of (xml || '').matchAll(/<numFmt\b[^>]*>/g)) fmts[Number(attr(m[0], 'numFmtId'))] = attr(m[0], 'formatCode') || '';
  const cellXfs = /<cellXfs\b[^>]*>([\s\S]*?)<\/cellXfs>/.exec(xml || '');
  const xfs = cellXfs ? [...cellXfs[1].matchAll(/<xf\b[^>]*\/?>/g)].map((m) => Number(attr(m[0], 'numFmtId') || 0)) : [];
  const isDateFmt = (id) => {
    if (BUILTIN_DATE.has(id)) return true;
    const code = fmts[id];
    if (!code) return false;
    const plain = code.replace(/"[^"]*"|\[[^\]]*\]|\\./g, '');
    return /[ymdh]/i.test(plain) && !/^[#0,.\s_\-*;@()]+$/.test(plain);
  };
  return {
    isDate: (s) => isDateFmt(xfs[Number(s) || 0] ?? 0),
    isText: (s) => (xfs[Number(s) || 0] ?? 0) === 49,
  };
}

// 시트 XML 의 줄 위치들. 큰 시트(5천만 글자)도 한 번 훑기만 한다.
function rowIndex(xml) {
  const start = xml.indexOf('<sheetData');
  const open = xml.indexOf('>', start);
  const selfClose = xml[open - 1] === '/';
  const end = selfClose ? open + 1 : xml.indexOf('</sheetData>', open);
  const rows = [];
  if (!selfClose) {
    const re = /<row\b[^>]*?(\/?)>/g;
    re.lastIndex = open + 1;
    let auto = 0;
    for (let m = re.exec(xml); m && m.index < end; m = re.exec(xml)) {
      const r = Number(attr(m[0], 'r')) || auto + 1;
      auto = r;
      const bodyStart = m.index + m[0].length;
      const close = m[1] === '/' ? bodyStart : xml.indexOf('</row>', bodyStart);
      rows.push({ r, at: m.index, tag: m[0], bodyStart, bodyEnd: close, after: m[1] === '/' ? bodyStart : close + 6 });
      re.lastIndex = m[1] === '/' ? bodyStart : close + 6;
    }
  }
  return { start, open, end, selfClose, rows };
}

function parseCells(body, rowNo) {
  const cells = {};
  let auto = 0;
  for (const m of body.matchAll(/<c\b([^>]*?)(\/>|>([\s\S]*?)<\/c>)/g)) {
    const tag = `<c${m[1]}>`;
    const ref = attr(tag, 'r');
    const c = ref ? splitRef(ref)?.c : auto + 1;
    auto = c;
    const inner = m[3] || '';
    const f = /<f\b([^>]*?)(\/>|>([\s\S]*?)<\/f>)/.exec(inner);
    const v = /<v>([\s\S]*?)<\/v>/.exec(inner);
    const is = /<is>([\s\S]*?)<\/is>/.exec(inner);
    cells[c] = {
      s: attr(tag, 's'), t: attr(tag, 't'), v: v ? xmlDecode(v[1]) : null,
      is: is ? [...is[1].matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map((x) => xmlDecode(x[1])).join('') : null,
      f: f ? { attrs: f[1], text: f[3] != null ? xmlDecode(f[3]) : '' } : null, row: rowNo,
    };
  }
  return cells;
}

function cellValue(cell, shared) {
  if (!cell) return '';
  if (cell.t === 's') return shared[Number(cell.v)] ?? '';
  if (cell.t === 'inlineStr') return cell.is ?? '';
  if (cell.t === 'str' || cell.t === 'e') return cell.v ?? '';
  if (cell.t === 'b') return cell.v === '1';
  if (cell.v == null || cell.v === '') return '';
  return Number(cell.v);
}

// 대상 시트 읽기: 머리줄·표·열 종류·마지막 줄(본보기)
async function loadTarget(file, sheetName) {
  const book = await openBook(file);
  const sheet = book.sheets.find((s) => s.name === sheetName) || book.sheets.find((s) => s.name.replace(/\s/g, '') === String(sheetName || '').replace(/\s/g, ''));
  if (!sheet) throw new Error(`"${sheetName}" 시트가 없습니다. 있는 시트: ${book.sheets.map((s) => s.name).join(', ')}`);
  const xml = await book.text(sheet.part);
  const shared = parseShared(book.ssPath ? await book.text(book.ssPath) : null);
  const styles = styleInfo(book.stPath ? await book.text(book.stPath) : null);
  // 이 시트에 걸린 엑셀 표(테이블)
  const sheetDir = path.posix.dirname(sheet.part);
  const relPath = `${sheetDir}/_rels/${path.posix.basename(sheet.part)}.rels`;
  const srels = await book.text(relPath) || '';
  const tables = [];
  for (const m of srels.matchAll(/<Relationship\b[^>]*>/g)) {
    if (!(attr(m[0], 'Type') || '').endsWith('/table')) continue;
    const p = resolveTarget(sheetDir, attr(m[0], 'Target'));
    const tx = await book.text(p);
    if (!tx) continue;
    const tag = /<table\b[^>]*>/.exec(tx)[0];
    const [a, b] = attr(tag, 'ref').split(':').map(splitRef);
    const cols = [...tx.matchAll(/<tableColumn\b([^>]*?)(\/>|>([\s\S]*?)<\/tableColumn>)/g)].map((c) => ({
      name: attr(`<x${c[1]}>`, 'name'), calc: /<calculatedColumnFormula\b[^>]*>([\s\S]*?)<\/calculatedColumnFormula>/.exec(c[3] || '')?.[1],
    }));
    tables.push({ path: p, xml: tx, name: attr(tag, 'displayName') || attr(tag, 'name'), ref: attr(tag, 'ref'), c1: a.c, r1: a.r, c2: b.c, r2: b.r,
      header: Number(attr(tag, 'headerRowCount') ?? 1), totals: Number(attr(tag, 'totalsRowCount') || 0), cols });
  }
  const idx = rowIndex(xml);
  const table = tables[0] || null;
  const rowsWithData = idx.rows.filter((r) => /<v>|<is>|<f[\s>]/.test(xml.slice(r.bodyStart, r.bodyEnd)));
  const headerNo = table ? table.r1 : rowsWithData[0]?.r;
  if (!headerNo) throw new Error(`"${sheet.name}" 시트가 비어 있습니다. 첫 줄에 열 이름을 넣어 두세요.`);
  const rowAt = new Map(idx.rows.map((r) => [r.r, r]));
  const cellsOf = (r) => { const x = rowAt.get(r); return x ? parseCells(xml.slice(x.bodyStart, x.bodyEnd), r) : {}; };
  const headCells = cellsOf(headerNo);
  let c1 = table ? table.c1 : Math.min(...Object.keys(headCells).map(Number));
  let c2 = table ? table.c2 : Math.max(...Object.keys(headCells).filter((c) => cellValue(headCells[c], shared) !== '').map(Number));
  if (!Number.isFinite(c1)) c1 = 1;
  // 표가 없으면 머리줄 아래로 빈 줄 없이 이어진 곳까지가 자료(그 아래 메모 등은 자료로 보지 않는다 — 쓸 때 막힘)
  let lastNo = headerNo;
  if (table) lastNo = table.r2 - table.totals;
  else {
    const filledRows = new Set(rowsWithData.map((r) => r.r));
    while (filledRows.has(lastNo + 1)) lastNo++;
  }
  const columns = [];
  for (let c = c1; c <= c2; c++) {
    const name = table ? table.cols[c - c1]?.name : String(cellValue(headCells[c], shared) ?? '');
    columns.push({ c, letter: colName(c), name: String(name ?? '').trim(), calc: table ? table.cols[c - c1]?.calc : null });
  }
  // 열 종류: 마지막 200줄을 보고 정한다(날짜·숫자·글자). 수식 열은 표의 계산 열이거나 마지막 줄에 수식이 있으면.
  const sample = idx.rows.filter((r) => r.r > headerNo && r.r <= lastNo).slice(-200).map((r) => parseCells(xml.slice(r.bodyStart, r.bodyEnd), r.r));
  const template = lastNo > headerNo ? cellsOf(lastNo) : {};
  for (const col of columns) {
    const cnt = { date: 0, number: 0, text: 0 };
    for (const cells of sample) {
      const cell = cells[col.c];
      if (!cell || (cell.v == null && cell.is == null)) continue;
      if (cell.t === 's' || cell.t === 'inlineStr' || cell.t === 'str') cnt.text++;
      else if (cell.t == null || cell.t === 'n') (styles.isDate(cell.s) ? cnt.date++ : cnt.number++);
    }
    const tpl = template[col.c];
    col.style = tpl?.s ?? null;
    col.formula = tpl?.f ? tpl.f : null;
    col.kind = col.calc || col.formula ? 'formula'
      : cnt.date >= Math.max(cnt.number, cnt.text) && cnt.date ? 'date'
        : cnt.text >= cnt.number && cnt.text ? 'text'
          : cnt.number ? 'number'
            : styles.isDate(col.style) ? 'date' : styles.isText(col.style) ? 'text' : 'auto';
  }
  return { book, sheet, xml, shared, styles, table, tables, idx, rowAt, headerNo, lastNo, columns, template, cellsOf, templateRowTag: rowAt.get(lastNo)?.tag || null };
}

// ── 값 바꾸기 ──
const DAY = 86400000;
function serialOf(y, mo, d, h = 0, mi = 0, s = 0, date1904 = false) {
  const t = Date.UTC(y, mo - 1, d, h, mi, s);
  const base = date1904 ? Date.UTC(1904, 0, 1) : Date.UTC(1899, 11, 30);
  const v = (t - base) / DAY;
  return Math.round(v * 86400) / 86400;
}
function toDate(v, date1904) {
  if (v === '' || v == null) return null;
  if (typeof v === 'number') {
    if (/^(19|20)\d{6}$/.test(String(v))) return toDate(String(v), date1904);
    return v > 0 && v < 2958466 ? v : null; // 엑셀 날짜 숫자
  }
  const s = String(v).trim();
  let m = /^((?:19|20)\d{2})[-./년\s]*(\d{1,2})[-./월\s]*(\d{1,2})일?(?:[\sT]+(\d{1,2})[:시](\d{1,2})(?:[:분](\d{1,2}))?초?)?$/.exec(s);
  if (!m) m = /^((?:19|20)\d{2})(\d{2})(\d{2})(?:(\d{2})(\d{2})(\d{2})?)?$/.exec(s.replace(/\s/g, ''));
  if (!m) return null;
  const [y, mo, d, h, mi, se] = m.slice(1).map((x) => Number(x || 0));
  if (mo < 1 || mo > 12 || d < 1 || d > 31 || h > 23 || mi > 59 || se > 59) return null;
  return serialOf(y, mo, d, h, mi, se, date1904);
}
function toNumber(v) {
  if (typeof v === 'number') return v;
  let s = String(v ?? '').trim();
  if (!s || s === '-') return null;
  let neg = false;
  if (/^\(.*\)$/.test(s)) { neg = true; s = s.slice(1, -1); }
  s = s.replace(/[,\s원₩%]/g, '');
  if (!/^[-+]?\d*\.?\d+(e[-+]?\d+)?$/i.test(s)) return null;
  const n = Number(s);
  return neg ? -n : n;
}
const numText = (n) => (Number.isInteger(n) ? n.toFixed(0) : String(n));
const keyText = (s) => { const t = String(s ?? '').trim().replace(/\s+/g, ' '); return /^\d+$/.test(t) ? t.replace(/^0+(?=\d)/, '') : t; };
function keyOf(kind, v) {
  if (v === '' || v == null) return '';
  if (kind === 'date' && typeof v === 'number') return `d${Math.round(v * 86400)}`;
  if (typeof v === 'number') return keyText(numText(v));
  return keyText(v);
}
const norm = (s) => String(s ?? '').replace(/\s+/g, '').toLowerCase();
const normLoose = (s) => norm(s).replace(/\([^)]*\)|\[[^\]]*\]/g, '').replace(/[.·_\-:]/g, '');

// 원본 열 → 대상 열 맞추기: 사용자가 준 map 먼저, 다음 같은 이름, 다음 괄호 뗀 이름
function matchColumns(targetCols, header, map = {}) {
  const used = new Set();
  const pick = (fn) => header.findIndex((h, i) => !used.has(i) && fn(h));
  const out = {};
  const mapN = Object.fromEntries(Object.entries(map || {}).map(([k, v]) => [norm(k), v]));
  for (const col of targetCols) {
    if (col.kind === 'formula') continue;
    const given = mapN[norm(col.name)];
    let i = -1;
    if (given === '' || given === null) continue; // 일부러 비움
    if (given != null) i = pick((h) => norm(h) === norm(given));
    if (i < 0 && given == null) i = pick((h) => norm(h) === norm(col.name));
    if (i < 0 && given == null && normLoose(col.name)) i = pick((h) => normLoose(h) === normLoose(col.name));
    if (i >= 0) { out[col.c] = i; used.add(i); }
  }
  return { cols: out, unused: header.map((h, i) => (used.has(i) || !String(h).trim() ? null : String(h).trim())).filter(Boolean) };
}

// 원본에서 머리줄 찾기: 앞 30줄 중 대상 열 이름과 가장 많이 맞는 줄
function findHeader(rows, targetCols, map) {
  let best = { i: -1, n: 0 };
  for (let i = 0; i < Math.min(rows.length, 30); i++) {
    const n = Object.keys(matchColumns(targetCols, rows[i].map((x) => String(x ?? '')), map).cols).length;
    if (n > best.n) best = { i, n };
  }
  return best;
}

function convert(kind, v, date1904) {
  if (v === '' || v == null) return { type: 'empty' };
  if (kind === 'date') { const d = toDate(v, date1904); return d != null ? { type: 'n', v: d } : { type: 's', v: String(v).trim(), warn: true }; }
  if (kind === 'number') { const n = toNumber(v); return n != null ? { type: 'n', v: n } : { type: 's', v: String(v).trim(), warn: String(v).trim() !== '-' }; }
  if (kind === 'text') return { type: 's', v: typeof v === 'number' ? numText(v) : String(v).trim() };
  // auto: 숫자처럼 보이면(앞자리 0 없음) 숫자, 아니면 글자
  if (typeof v === 'number') return { type: 'n', v };
  const s = String(v).trim();
  return /^-?[1-9]\d{0,14}(\.\d+)?$|^0(\.\d+)?$/.test(s.replace(/,/g, '')) ? { type: 'n', v: Number(s.replace(/,/g, '')) } : { type: 's', v: s };
}

// 수식 칸: 표의 계산 열이면 그 수식, 아니면 본보기 줄의 수식을 줄 번호만 옮겨 쓴다(공유 수식은 처음 칸에서)
function shiftFormula(text, delta) {
  return text.replace(/("[^"]*")|('[^']*'!|\b[A-Za-z_][\w.]*!)?(\$?)([A-Z]{1,3})(\$?)(\d+)\b/g, (m, str, sheet, d1, col, d2, row) => {
    if (str) return str;
    return `${sheet || ''}${d1}${col}${d2}${d2 ? row : Number(row) + delta}`;
  });
}

const fmtNum = (n) => Math.round(n).toLocaleString('ko-KR');
function serialText(v, date1904) {
  const base = date1904 ? Date.UTC(1904, 0, 1) : Date.UTC(1899, 11, 30);
  const d = new Date(base + Math.round(v * 86400) * 1000);
  return d.toISOString().slice(0, 10);
}

// ── 계획 세우기(읽기만) ──
const plans = new Map();
let planSeq = 0;

async function plan({ source, target, sheet, sourceSheet, keys, map, header_row: headerRow }) {
  const src = resolveFile(source, /\.(xls|xlsx|xlsm|csv|txt|htm|html)$/i);
  const dst = resolveFile(target, /\.(xlsx|xlsm)$/i);
  if (!/\.(xlsx|xlsm)$/i.test(dst.file)) throw new Error('붙일 파일은 .xlsx(또는 .xlsm)여야 합니다. 옛 .xls 는 엑셀에서 "다른 이름으로 저장 → xlsx"로 바꿔 주세요.');
  if (path.resolve(src.file) === path.resolve(dst.file)) throw new Error('원본과 붙일 파일이 같습니다.');
  const before = fs.statSync(dst.file);
  const t = await loadTarget(dst.file, sheet);
  if (t.table?.totals) throw new Error(`"${t.sheet.name}" 표에 합계 줄이 있어 아래에 붙일 수 없습니다. 엑셀에서 표 디자인 › "요약 행"을 끄고 다시 해 주세요.`);
  const date1904 = t.book.date1904;
  const s = sourceRows(src.file, sourceSheet);
  const hdr = Number.isInteger(headerRow) && headerRow > 0 ? { i: headerRow - 1, n: 0 } : findHeader(s.rows, t.columns, map);
  if (hdr.i < 0) throw new Error(`원본 "${path.basename(src.file)}"에서 "${t.sheet.name}" 시트와 같은 열 이름을 찾지 못했습니다. 대상 열: ${t.columns.map((c) => c.name).join(', ')}`);
  const header = s.rows[hdr.i].map((x) => String(x ?? '').trim());
  const { cols, unused } = matchColumns(t.columns, header, map);
  if (Object.keys(cols).length < Math.min(2, t.columns.filter((c) => c.kind !== 'formula').length)) throw new Error('맞는 열이 너무 적습니다. map 으로 짝을 알려 주세요.');
  // 겹침 확인에 쓸 열
  const keyCols = (keys?.length ? keys : null)
    ? keys.map((k) => { const c = t.columns.find((x) => norm(x.name) === norm(k)); if (!c) throw new Error(`키 열 "${k}"이(가) "${t.sheet.name}" 시트에 없습니다.`); return c; })
    : t.columns.filter((c) => cols[c.c] != null);
  // 이미 있는 줄의 키(같은 키가 여러 번이면 그 수만큼)
  const have = new Map();
  for (const r of t.idx.rows) {
    if (r.r <= t.headerNo || r.r > t.lastNo) continue;
    const cells = parseCells(t.xml.slice(r.bodyStart, r.bodyEnd), r.r);
    const k = keyCols.map((c) => keyOf(c.kind, cellValue(cells[c.c], t.shared))).join('\u0001');
    if (k.replace(/\u0001/g, '')) have.set(k, (have.get(k) || 0) + 1);
  }
  // 원본 줄 바꾸기
  const firstCol = header.findIndex((h) => h);
  const out = [];
  let dup = 0; let skipped = 0; const warns = new Set();
  for (const row of s.rows.slice(hdr.i + 1)) {
    if (!row.some((v) => String(v ?? '').trim())) continue;
    if (/^(합계|소계|총계|총합계|계|total)$/i.test(String(row[firstCol] ?? '').replace(/\s/g, ''))) { skipped++; continue; }
    const vals = {};
    let any = false;
    for (const col of t.columns) {
      if (cols[col.c] == null) continue;
      const cv = convert(col.kind, row[cols[col.c]], date1904);
      if (cv.warn) warns.add(col.name);
      if (cv.type !== 'empty') any = true;
      vals[col.c] = cv;
    }
    if (!any) { skipped++; continue; }
    const k = keyCols.map((c) => { const cv = vals[c.c]; return cv && cv.type !== 'empty' ? keyOf(c.kind, cv.v) : ''; }).join('\u0001');
    if (!k.replace(/\u0001/g, '')) { skipped++; continue; } // 키가 비면(합계 줄 등) 넣지 않음
    if (have.get(k)) { have.set(k, have.get(k) - 1); dup++; continue; }
    out.push(vals);
  }
  // 요약: 금액 합계 · 날짜 범위
  const sums = t.columns.filter((c) => c.kind === 'number' && /금액|합계|총액|매출/.test(c.name) && cols[c.c] != null)
    .map((c) => ({ name: c.name, sum: out.reduce((a, v) => a + (v[c.c]?.type === 'n' ? v[c.c].v : 0), 0) })).filter((x) => x.sum).slice(0, 3);
  const dateCol = t.columns.find((c) => c.kind === 'date' && cols[c.c] != null);
  const ds = dateCol ? out.map((v) => v[dateCol.c]).filter((x) => x?.type === 'n').map((x) => x.v) : [];
  const id = `X${++planSeq}`;
  const p = {
    id, file: dst.file, size: before.size, mtime: before.mtimeMs, sheet: t.sheet.name, table: t.table?.name || null, rows: out, from: t.lastNo + 1,
    source: src.file,
  };
  plans.set(id, p);
  if (plans.size > 20) plans.delete(plans.keys().next().value);
  return {
    id,
    target: dst.file, targetOthers: dst.others, source: src.file, sourceOthers: src.others, sourceKind: s.kind,
    sheet: t.sheet.name, table: t.table?.name || null, existing: t.lastNo - t.headerNo,
    sourceRows: out.length + dup, add: out.length, dup, skipped,
    keys: keyCols.map((c) => c.name),
    mapping: t.columns.map((c) => ({ target: c.name, kind: c.kind, from: c.kind === 'formula' ? '(수식 — 엑셀이 계산)' : cols[c.c] != null ? header[cols[c.c]] : '(빈칸)' })),
    unused, warns: [...warns],
    sums: sums.map((x) => ({ name: x.name, sum: x.sum, text: `${fmtNum(x.sum)}` })),
    dates: ds.length ? { col: dateCol.name, from: serialText(Math.min(...ds), date1904), to: serialText(Math.max(...ds), date1904) } : null,
    locked: lockedBy(dst.file),
    rowsFrom: t.lastNo + 1, rowsTo: t.lastNo + out.length,
  };
}

// ── 쓰기 ──
function backupName(file) {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  const stamp = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  const ext = path.extname(file);
  return path.join(path.dirname(file), `${path.basename(file, ext)} (${BACKUP_MARK} ${stamp})${ext}`);
}

function extendRef(ref, oldEnd, newEnd) {
  // "A1:Q74544" · "$A$1:$Q$74544" · "카드DB!$A$1:$Q$74544" 에서 끝 줄이 oldEnd 인 범위만 늘린다
  return ref.replace(/(\$?[A-Z]{1,3}\$?\d+):(\$?[A-Z]{1,3})(\$?)(\d+)/g, (m, a, col, d, row) => (Number(row) === oldEnd ? `${a}:${col}${d}${newEnd}` : m));
}

// ── 되돌리기 기록: 넣은 줄의 자리와 값 지문(나중에 그 줄이 그대로인지 확인) ──
const UNDO_FILE = path.join(os.homedir(), '.knock', 'excel-undo.json');
function undoList() { try { return JSON.parse(fs.readFileSync(UNDO_FILE, 'utf8')); } catch { return []; } }
function saveUndo(list) {
  fs.mkdirSync(path.dirname(UNDO_FILE), { recursive: true });
  fs.writeFileSync(UNDO_FILE, JSON.stringify(list.slice(-30)), { mode: 0o600 });
}
// 수식 열은 엑셀이 다시 계산하면 값이 바뀌니 빼고, 넣은 값 열만으로 지문을 만든다
function rowsPrint(t, from, to) {
  const h = require('crypto').createHash('sha256');
  const cols = t.columns.filter((c) => c.kind !== 'formula');
  for (let r = from; r <= to; r++) {
    const cells = t.cellsOf(r);
    h.update(cols.map((c) => String(cellValue(cells[c.c], t.shared) ?? '')).join('\u0001'));
    h.update('\u0002');
  }
  return h.digest('hex');
}
const samePath = (a, b) => path.resolve(a).normalize('NFC').toLowerCase() === path.resolve(b).normalize('NFC').toLowerCase();

async function write({ id, backup: keepBackup = true }) {
  const p = plans.get(id);
  if (!p) throw new Error('계획이 없습니다(오래됐거나 도우미가 다시 켜짐). excel_append 를 다시 부르세요.');
  const lock = lockedBy(p.file);
  if (lock) return { locked: lock };
  const st = fs.statSync(p.file);
  if (st.size !== p.size || Math.abs(st.mtimeMs - p.mtime) > 1) throw new Error('확인하는 사이 파일이 바뀌었습니다. 다시 해 주세요.');
  if (!p.rows.length) return { added: 0 };
  const t = await loadTarget(p.file, p.sheet);
  if (t.lastNo + 1 !== p.from) throw new Error('확인하는 사이 시트 줄 수가 바뀌었습니다. 다시 해 주세요.');
  const { book, xml } = t;
  const oldEnd = t.table ? t.table.r2 : t.lastNo;
  const newLast = t.lastNo + p.rows.length;
  const newEnd = oldEnd + p.rows.length;
  // 표 아래(또는 마지막 줄 아래)에 내용이 있으면 덮지 않는다. 내용 없는 서식만 있는 줄은 지우고 그 자리에 넣는다.
  const below = t.idx.rows.filter((r) => r.r > t.lastNo);
  const filled = below.find((r) => /<v>|<is>|<f[\s>]/.test(xml.slice(r.bodyStart, r.bodyEnd)));
  if (filled) throw new Error(`"${p.sheet}" 시트 ${filled.r}번째 줄(표 아래)에 다른 내용이 있어 붙이지 않았습니다. 그 내용을 옮긴 뒤 다시 해 주세요.`);
  // 글자: 공유 글자 목록(sharedStrings)에 더한다(이미 있는 글자는 그 번호)
  let ssXml = book.ssPath ? await book.text(book.ssPath) : null;
  const ssIndex = new Map();
  let ssCount = 0;
  const ssAdd = [];
  if (ssXml) {
    t.shared.forEach((s, i) => { if (!ssIndex.has(s)) ssIndex.set(s, i); });
    ssCount = t.shared.length;
  }
  let refs = 0;
  const strCell = (ref, s, text) => {
    if (!ssXml) return `<c r="${ref}"${s} t="inlineStr"><is><t xml:space="preserve">${xmlEncode(text)}</t></is></c>`;
    let i = ssIndex.get(text);
    if (i == null) { i = ssCount++; ssIndex.set(text, i); ssAdd.push(text); }
    refs++;
    return `<c r="${ref}"${s} t="s"><v>${i}</v></c>`;
  };
  // 본보기 줄 모양(높이 등)은 따르고 숨김·접기는 따르지 않는다
  const tplTag = (t.templateRowTag || '<row>').replace(/\s(r|hidden|collapsed|outlineLevel)="[^"]*"/g, '').replace(/\/>$/, '>');
  let formulas = false;
  const parts = [];
  p.rows.forEach((vals, i) => {
    const r = t.lastNo + 1 + i;
    const cells = [];
    for (const col of t.columns) {
      const ref = `${col.letter}${r}`;
      const s = col.style != null ? ` s="${col.style}"` : '';
      if (col.kind === 'formula') {
        let f = col.calc ? xmlDecode(col.calc) : null;
        if (!f && col.formula) {
          if (/t="shared"/.test(col.formula.attrs) && !col.formula.text) {
            const si = /si="(\d+)"/.exec(col.formula.attrs)?.[1];
            const master = new RegExp(`<c\\b[^>]*\\br="([A-Z]+)(\\d+)"[^>]*>(?:(?!</c>)[\\s\\S])*?<f\\b[^>]*t="shared"[^>]*si="${si}"[^>]*>([^<]+)</f>`).exec(xml);
            f = master ? shiftFormula(xmlDecode(master[3]), r - Number(master[2])) : null;
          } else if (col.formula.text) f = shiftFormula(col.formula.text, r - t.lastNo);
        }
        if (f) { cells.push(`<c r="${ref}"${s}><f>${xmlEncode(f)}</f></c>`); formulas = true; } else cells.push(`<c r="${ref}"${s}/>`);
        continue;
      }
      const cv = vals[col.c];
      if (!cv || cv.type === 'empty') cells.push(`<c r="${ref}"${s}/>`);
      else if (cv.type === 'n') cells.push(`<c r="${ref}"${s}><v>${cv.v}</v></c>`);
      else cells.push(strCell(ref, s, cv.v));
    }
    parts.push(`${tplTag.replace(/^<row\b/, `<row r="${r}"`)}${cells.join('')}</row>`);
  });
  // 시트 XML: 표 아래의 빈 줄을 걷어 내고 새 줄을 넣는다
  let sheetXml;
  if (t.idx.selfClose) sheetXml = `${xml.slice(0, t.idx.start)}<sheetData>${parts.join('')}</sheetData>${xml.slice(t.idx.open + 1)}`;
  else {
    const cut = below.length ? below[0].at : t.idx.end;
    sheetXml = xml.slice(0, cut) + parts.join('') + xml.slice(t.idx.end);
  }
  // 시트 크기 · 조건부 서식 · 데이터 유효성 범위
  sheetXml = sheetXml.replace(/<dimension ref="([^"]*)"\s*\/>/, (m, ref) => `<dimension ref="${extendRef(ref, oldEnd, newEnd).replace(/:(\$?[A-Z]+)(\d+)$/, (x, c, n) => `:${c}${Math.max(Number(n), newEnd)}`)}"/>`);
  sheetXml = sheetXml.replace(/(<(?:conditionalFormatting|dataValidation)\b[^>]*\ssqref=")([^"]*)"/g, (m, a, ref) => `${a}${extendRef(ref, oldEnd, newEnd)}"`);
  book.zip.file(t.sheet.part, sheetXml);
  // 엑셀 표 범위 · 자동 필터
  if (t.table) {
    const newRef = t.table.ref.replace(/(\d+)$/, String(newEnd));
    const tx = t.table.xml.replace(/(<table\b[^>]*\sref=")[^"]*"/, `$1${newRef}"`).replace(/(<autoFilter\b[^>]*\sref=")[^"]*"/, `$1${newRef}"`);
    book.zip.file(t.table.path, tx);
  }
  // 공유 글자 목록(되돌릴 때 넣기 전 모양으로 돌리려고 전·후 수를 적어 둔다)
  const ssTag0 = ssXml ? /<sst\b[^>]*>/.exec(ssXml)?.[0] || '' : '';
  const ssBefore = ssXml ? { count: attr(ssTag0, 'count'), unique: attr(ssTag0, 'uniqueCount'), added: ssAdd.length } : null;
  if (ssXml && ssAdd.length + refs) {
    const add = ssAdd.map((s) => `<si><t${/^\s|\s$/.test(s) ? ' xml:space="preserve"' : ''}>${xmlEncode(s)}</t></si>`).join('');
    ssXml = ssXml.replace(/<sst\b[^>]*>/, (tag) => {
      const cnt = Number(attr(tag, 'count') || 0) + refs;
      const uniq = ssCount;
      let x = /\scount="/.test(tag) ? tag.replace(/\scount="[^"]*"/, ` count="${cnt}"`) : tag.replace(/>$/, ` count="${cnt}">`);
      x = /\suniqueCount="/.test(x) ? x.replace(/\suniqueCount="[^"]*"/, ` uniqueCount="${uniq}"`) : x.replace(/>$/, ` uniqueCount="${uniq}">`);
      return x;
    });
    ssXml = ssXml.replace(/<\/sst>\s*$/, `${add}</sst>`);
    book.zip.file(book.ssPath, ssXml);
  }
  // 이 시트를 원본으로 쓰는 피벗(범위로 잡은 것)과 이름 범위도 늘린다. 피벗 숫자는 엑셀에서 [새로 고침]해야 바뀐다.
  let pivots = 0;
  for (const name of Object.keys(book.zip.files)) {
    if (!/^xl\/pivotCache\/pivotCacheDefinition\d+\.xml$/.test(name)) continue;
    const px = await book.text(name);
    const ws = /<worksheetSource\b[^>]*\/?>/.exec(px);
    if (!ws) continue;
    if (attr(ws[0], 'name') && attr(ws[0], 'name') === t.table?.name) { pivots++; continue; }
    if (attr(ws[0], 'sheet') !== t.sheet.name || !attr(ws[0], 'ref')) continue;
    const nr = extendRef(attr(ws[0], 'ref'), oldEnd, newEnd);
    if (nr !== attr(ws[0], 'ref')) { book.zip.file(name, px.replace(ws[0], ws[0].replace(/\sref="[^"]*"/, ` ref="${nr}"`))); pivots++; }
  }
  let wb = book.wb;
  const esc = t.sheet.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  wb = wb.replace(new RegExp(`(<definedName\\b[^>]*>)((?:'${esc}'|${esc})![^<]*)(</definedName>)`, 'g'), (m, a, ref, b) => `${a}${extendRef(ref, oldEnd, newEnd)}${b}`);
  // 수식을 넣었으면 열 때 다시 계산하게
  if (formulas && !/fullCalcOnLoad="1"/.test(wb)) wb = /<calcPr\b/.test(wb) ? wb.replace(/<calcPr\b/, '<calcPr fullCalcOnLoad="1"') : wb.replace(/<\/workbook>/, '<calcPr fullCalcOnLoad="1"/></workbook>');
  if (wb !== book.wb) book.zip.file('xl/workbook.xml', wb);
  // 사본을 남기고, 옆에 임시로 쓴 뒤 바꿔 끼운다(쓰다 끊겨도 원래 파일은 그대로)
  if (lockedBy(p.file)) return { locked: lockedBy(p.file) };
  const backup = keepBackup ? backupName(p.file) : null;
  if (backup) fs.copyFileSync(p.file, backup);
  const tmp = path.join(path.dirname(p.file), `.knock-tmp-${process.pid}-${Date.now()}${path.extname(p.file)}`);
  try {
    const out = await book.zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 6 } });
    fs.writeFileSync(tmp, out);
    // 다시 열어 확인: 시트 줄 수가 맞는지
    const check = await loadTarget(tmp, p.sheet);
    if (check.lastNo !== newLast) throw new Error(`쓴 파일을 확인했더니 줄 수가 맞지 않습니다(${check.lastNo} ≠ ${newLast}).`);
    if (lockedBy(p.file)) { fs.unlinkSync(tmp); return { locked: lockedBy(p.file), backup }; }
    const ssTag1 = ssXml ? /<sst\b[^>]*>/.exec(ssXml)?.[0] || '' : '';
    var undoEntry = { file: p.file, sheet: p.sheet, from: t.lastNo + 1, to: newLast, oldEnd, newEnd, hash: rowsPrint(check, t.lastNo + 1, newLast), at: Date.now(),
      ss: ssBefore && { ...ssBefore, countAfter: attr(ssTag1, 'count'), uniqueAfter: attr(ssTag1, 'uniqueCount') } };
    fs.renameSync(tmp, p.file);
  } catch (err) {
    try { fs.unlinkSync(tmp); } catch {}
    throw err;
  }
  plans.delete(id);
  try { saveUndo([...undoList().filter((e) => !(samePath(e.file, p.file) && e.sheet === p.sheet && e.from === undoEntry.from)), undoEntry]); } catch {}
  return { added: p.rows.length, from: t.lastNo + 1, to: newLast, backup, pivots, formulas };
}

// ── 되돌리기: 마지막으로 넣은 줄만 지운다(그 뒤로 그 줄이 그대로이고 아래에 더 붙은 줄이 없을 때만) ──
// check=true 면 지우지 않고 무엇을 지울지만 알려 준다.
async function undo({ file, check = false }) {
  let list = undoList();
  let want = null;
  if (String(file || '').trim()) {
    const f = resolveFile(file, /\.(xlsx|xlsm)$/i);
    want = f.file;
  }
  const entry = [...list].reverse().find((e) => !want || samePath(e.file, want));
  if (!entry) throw new Error(want ? `"${path.basename(want)}"에 AI 가 넣은 줄 기록이 없습니다(되돌릴 것이 없음).` : 'AI 가 엑셀에 넣은 줄 기록이 없습니다(되돌릴 것이 없음).');
  if (!fs.existsSync(entry.file)) throw new Error(`"${path.basename(entry.file)}" 파일이 없습니다(옮겼거나 이름이 바뀜).`);
  const info = { file: entry.file, sheet: entry.sheet, from: entry.from, to: entry.to, count: entry.to - entry.from + 1, at: entry.at };
  const lock = lockedBy(entry.file);
  if (lock) return { ...info, locked: lock };
  const t = await loadTarget(entry.file, entry.sheet);
  const end = t.table ? t.table.r2 : t.lastNo;
  if (t.lastNo !== entry.to || end !== entry.newEnd) {
    throw new Error(`"${entry.sheet}" 시트의 마지막 줄이 넣을 때(${entry.to}번째)와 다릅니다(지금 ${t.lastNo}번째). 그 뒤로 줄을 더하거나 지운 것 같아 지우지 않았습니다. 사본이 있으면 사본으로 되돌려 주세요.`);
  }
  if (rowsPrint(t, entry.from, entry.to) !== entry.hash) {
    throw new Error(`넣은 줄(${entry.from}~${entry.to}번째)의 내용이 넣을 때와 달라 지우지 않았습니다(그 뒤로 고친 것 같음). 사본이 있으면 사본으로 되돌려 주세요.`);
  }
  if (check) return { ...info, ok: true };
  const first = t.rowAt.get(entry.from);
  const last = t.rowAt.get(entry.to);
  if (!first || !last) throw new Error('지울 줄을 시트에서 찾지 못했습니다.');
  const { book, xml } = t;
  const below = t.idx.rows.filter((r) => r.r > entry.to);
  if (below.find((r) => /<v>|<is>|<f[\s>]/.test(xml.slice(r.bodyStart, r.bodyEnd)))) throw new Error('넣은 줄 아래에 다른 내용이 있어 지우지 않았습니다.');
  const shrink = (ref) => extendRef(ref, entry.newEnd, entry.oldEnd);
  let sheetXml = xml.slice(0, first.at) + xml.slice(below.length ? below[below.length - 1].after : last.after);
  sheetXml = sheetXml.replace(/<dimension ref="([^"]*)"\s*\/>/, (m, ref) => `<dimension ref="${shrink(ref)}"/>`);
  sheetXml = sheetXml.replace(/(<(?:conditionalFormatting|dataValidation)\b[^>]*\ssqref=")([^"]*)"/g, (m, a, ref) => `${a}${shrink(ref)}"`);
  book.zip.file(t.sheet.part, sheetXml);
  if (t.table) {
    const newRef = t.table.ref.replace(/(\d+)$/, String(entry.oldEnd));
    book.zip.file(t.table.path, t.table.xml.replace(/(<table\b[^>]*\sref=")[^"]*"/, `$1${newRef}"`).replace(/(<autoFilter\b[^>]*\sref=")[^"]*"/, `$1${newRef}"`));
  }
  for (const name of Object.keys(book.zip.files)) {
    if (!/^xl\/pivotCache\/pivotCacheDefinition\d+\.xml$/.test(name)) continue;
    const px = await book.text(name);
    const ws = /<worksheetSource\b[^>]*\/?>/.exec(px);
    if (!ws || attr(ws[0], 'sheet') !== t.sheet.name || !attr(ws[0], 'ref')) continue;
    const nr = shrink(attr(ws[0], 'ref'));
    if (nr !== attr(ws[0], 'ref')) book.zip.file(name, px.replace(ws[0], ws[0].replace(/\sref="[^"]*"/, ` ref="${nr}"`)));
  }
  const esc = t.sheet.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wb = book.wb.replace(new RegExp(`(<definedName\\b[^>]*>)((?:'${esc}'|${esc})![^<]*)(</definedName>)`, 'g'), (m, a, ref, b) => `${a}${shrink(ref)}${b}`);
  if (wb !== book.wb) book.zip.file('xl/workbook.xml', wb);
  // 넣을 때 공유 글자 목록 끝에 더한 글자도 걷어 낸다(그 뒤로 목록이 그대로일 때만 — 엑셀이 다시 저장했으면 그대로 둔다. 남아도 파일은 멀쩡함)
  if (entry.ss && book.ssPath) {
    let ss = await book.text(book.ssPath);
    const tag = /<sst\b[^>]*>/.exec(ss)?.[0] || '';
    if (attr(tag, 'count') === entry.ss.countAfter && attr(tag, 'uniqueCount') === entry.ss.uniqueAfter) {
      let cut = ss.lastIndexOf('</sst>');
      for (let i = 0; i < entry.ss.added && cut > 0; i++) cut = ss.lastIndexOf('<si>', cut - 1);
      if (cut > 0) {
        const setAttr = (x, n, v) => (v == null ? x.replace(new RegExp(`\\s${n}="[^"]*"`), '') : x.replace(new RegExp(`\\s${n}="[^"]*"`), ` ${n}="${v}"`));
        const tag0 = setAttr(setAttr(tag, 'count', entry.ss.count), 'uniqueCount', entry.ss.unique);
        ss = ss.slice(0, cut).replace(tag, tag0) + ss.slice(ss.lastIndexOf('</sst>'));
        book.zip.file(book.ssPath, ss);
      }
    }
  }
  const tmp = path.join(path.dirname(entry.file), `.knock-tmp-${process.pid}-${Date.now()}${path.extname(entry.file)}`);
  try {
    const out = await book.zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 6 } });
    fs.writeFileSync(tmp, out);
    const after = await loadTarget(tmp, entry.sheet);
    if (after.lastNo !== entry.from - 1) throw new Error(`지운 파일을 확인했더니 줄 수가 맞지 않습니다(${after.lastNo} ≠ ${entry.from - 1}).`);
    if (lockedBy(entry.file)) { fs.unlinkSync(tmp); return { ...info, locked: lockedBy(entry.file) }; }
    fs.renameSync(tmp, entry.file);
  } catch (err) {
    try { fs.unlinkSync(tmp); } catch {}
    throw err;
  }
  list = undoList().filter((e) => e !== entry && !(samePath(e.file, entry.file) && e.sheet === entry.sheet && e.from === entry.from));
  saveUndo(list);
  return { ...info, removed: info.count };
}

// ── 보기(AI 가 열 이름·마지막 줄을 확인할 때) ──
async function read({ file, sheet, rows = 5 }) {
  const f = resolveFile(file, /\.(xls|xlsx|xlsm|csv|txt|htm|html)$/i);
  const n = Math.min(Math.max(Number(rows) || 5, 1), 20);
  if (/\.(xlsx|xlsm)$/i.test(f.file) && (await fs.promises.stat(f.file)).size > 3 * 1048576) {
    // 큰 xlsx: 고른 시트만 가볍게
    const book = await openBook(f.file);
    const name = sheet || book.sheets[0].name;
    const t = await loadTarget(f.file, name);
    const last = [];
    for (let r = Math.max(t.headerNo + 1, t.lastNo - n + 1); r <= t.lastNo; r++) {
      const cells = t.cellsOf(r);
      last.push(t.columns.map((c) => { const v = cellValue(cells[c.c], t.shared); return c.kind === 'date' && typeof v === 'number' ? serialText(v, book.date1904) : v; }));
    }
    return { file: f.file, others: f.others, sheets: book.sheets.map((s) => s.name), sheet: t.sheet.name, table: t.table?.name || null,
      headerRow: t.headerNo, lastRow: t.lastNo, columns: t.columns.map((c) => `${c.name}(${KIND[c.kind]})`), last, locked: lockedBy(f.file) };
  }
  const s = sourceRows(f.file, sheet);
  return { file: f.file, others: f.others, kind: s.kind, sheets: s.sheets, sheet: s.sheet, total: s.rows.length, first: s.rows.slice(0, Math.min(8, s.rows.length)), last: s.rows.slice(-n), locked: lockedBy(f.file) };
}
const KIND = { date: '날짜', number: '숫자', text: '글자', formula: '수식', auto: '빈 열' };

module.exports = { plan, write, read, undo, lockedBy, resolveFile, _test: { toDate, toNumber, keyOf, matchColumns, shiftFormula, extendRef } };
