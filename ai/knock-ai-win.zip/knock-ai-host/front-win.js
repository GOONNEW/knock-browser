// 윈도우: 맨 앞 창을 작업 표시줄(탐색기, 보통 권한)로 넘겨 두기(2026-11-13 이든치과).
// 업데이트로 맨 앞이던 Knock Browser 가 꺼지면, 윈도우가 다음 차례인 경리스퀘어의 숨은 관리자 창(0x0)을 맨 앞으로 골랐다.
// 그러면 보통 권한인 원격 조작의 마우스·키보드가 모두 버려지고, 보통 권한으로는 맨 앞을 되찾지도 못했다.
// 그래서 꺼지기 직전, 아직 보통 권한 창이 맨 앞일 때 작업 표시줄을 맨 앞으로 옮겨 둔다.
// 윈도우는 '마지막 입력을 일으킨 프로그램'에게만 맨 앞 바꾸기를 허락한다 — 그래서 Shift 를 한 번 눌렀다 뗀 뒤 바꾼다
// (관리자 창이 맨 앞이면 이 입력도 버려져 안 된다 — 그때는 바꾸지 않는다).
const { spawnSync } = require('child_process');

const ADD_TYPE = String.raw`Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class KnockFront {
  [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindow(string c, string t);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, System.Text.StringBuilder s, int n);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, System.Text.StringBuilder s, int n);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint a, bool i, uint pid);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
  [DllImport("advapi32.dll")] static extern bool OpenProcessToken(IntPtr p, uint a, out IntPtr t);
  [DllImport("advapi32.dll")] static extern bool GetTokenInformation(IntPtr t, int c, out int i, int l, out int r);
  static string Name(IntPtr h) { var t = new System.Text.StringBuilder(256); GetWindowText(h, t, 256); var c = new System.Text.StringBuilder(64); GetClassName(h, c, 64); return t.Length > 0 ? t.ToString() : "(" + c + ")"; }
  static bool Elevated(IntPtr h) {
    uint pid; GetWindowThreadProcessId(h, out pid);
    IntPtr p = OpenProcess(0x1000, false, pid); if (p == IntPtr.Zero) return true;
    bool e = false; IntPtr t;
    if (OpenProcessToken(p, 0x0008, out t)) { int v, r; e = GetTokenInformation(t, 20, out v, 4, out r) && v != 0; CloseHandle(t); }
    CloseHandle(p); return e;
  }
  static void Shift() { keybd_event(0x10, 0, 0, UIntPtr.Zero); keybd_event(0x10, 0, 2, UIntPtr.Zero); }
  public static string ToTaskbar() {
    IntPtr fg = GetForegroundWindow(), bar = FindWindow("Shell_TrayWnd", null);
    string before = Name(fg);
    if (bar == IntPtr.Zero) return "작업 표시줄 없음 · 맨 앞 " + before;
    if (fg == bar) return "이미 작업 표시줄";
    if (fg != IntPtr.Zero && Elevated(fg) && !Elevated(bar)) return "관리자 창이 이미 맨 앞이라 못 넘김 · " + before;
    bool ok = SetForegroundWindow(bar) && GetForegroundWindow() == bar;
    string how = "바로";
    if (!ok) { Shift(); System.Threading.Thread.Sleep(60); ok = SetForegroundWindow(bar) && GetForegroundWindow() == bar; how = "Shift 뒤"; }
    return (ok ? "작업 표시줄로 넘김(" + how + ")" : "못 넘김") + " · 전 " + before + " · 지금 " + Name(GetForegroundWindow());
  }
}
'@
`;
const PS = `$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
${ADD_TYPE}[KnockFront]::ToTaskbar()
`;

// 결과 글을 돌려준다(기록용). 1~2초 걸린다.
function toTaskbar() {
  if (process.platform !== 'win32') return '';
  const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(PS, 'utf16le').toString('base64')], { encoding: 'utf8', windowsHide: true, timeout: 10000 });
  const out = (r.stdout || '').trim();
  return (out || `실패 ${(r.stderr || r.error?.message || '').replace(/#< CLIXML|<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()}`).slice(0, 300);
}

module.exports = { toTaskbar, PS, ADD_TYPE };
