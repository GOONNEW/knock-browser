// 사용자가 "기억해 두기"를 고른 사이트 로그인. 비밀번호는 맥 키체인(서비스 "Knock 로그인", 계정 = 사이트 주소)에만 둔다.
// 아이디와 사이트 목록만 ~/.knock/logins.json 에 둔다(설정 화면 목록용). 비밀번호는 기록 파일·AI 어디에도 남기지 않는다.
// 비밀번호는 명령줄 인자에 드러나지 않게 security -i 의 입력으로 넘기고, 따옴표 문제가 없게 base64 로 담는다.
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { IS_WIN, winSecret } = require('./platform');

const SERVICE = 'Knock 로그인';
const INDEX = path.join(os.homedir(), '.knock', 'logins.json');

function origin(url) {
  const u = new URL(url);
  if (!/^https?:$/.test(u.protocol)) throw new Error('웹 사이트 주소가 아닙니다.');
  return u.origin;
}

function readIndex() {
  try {
    return JSON.parse(fs.readFileSync(INDEX, 'utf8'));
  } catch {
    return {};
  }
}

function writeIndex(index) {
  fs.mkdirSync(path.dirname(INDEX), { recursive: true });
  fs.writeFileSync(INDEX, JSON.stringify(index, null, 2), { mode: 0o600 });
}

function save(url, username, password) {
  const site = origin(url);
  if (!password) throw new Error('비밀번호가 비었습니다.');
  const b64 = Buffer.from(String(password), 'utf8').toString('base64');
  if (IS_WIN) winSecret.set(SERVICE, site, b64); // 윈도우: DPAPI 암호 파일(platform.js)
  const r = IS_WIN ? { status: 0 } : spawnSync('security', ['-i'], { input: `add-generic-password -U -s "${SERVICE}" -a "${site}" -w ${b64}\n`, encoding: 'utf8' });
  if (r.status !== 0) throw new Error('키체인에 저장하지 못했습니다.');
  const index = readIndex();
  index[site] = { username: String(username || '').slice(0, 200), savedAt: Date.now() };
  writeIndex(index);
  return site;
}

// { username, password } 또는 null
function get(url) {
  const site = origin(url);
  if (IS_WIN) {
    const b64 = winSecret.get(SERVICE, site);
    const password = b64 ? Buffer.from(b64, 'base64').toString('utf8') : '';
    return password ? { username: readIndex()[site]?.username || '', password } : null;
  }
  const r = spawnSync('security', ['find-generic-password', '-s', SERVICE, '-a', site, '-w'], { encoding: 'utf8', timeout: 10000 });
  if (r.status === 44) return null; // 이 사이트는 기억해 둔 것이 없음
  if (r.status !== 0) {
    // 키체인이 잠겼거나(화면 잠금 등) 맥이 꺼내 주지 않음 — 이유만 알리고 값은 남기지 않는다
    const why = /interaction is not allowed|locked/i.test(r.stderr || '') ? '맥 키체인이 잠겨 있음(화면 잠금 중일 수 있음)' : `키체인 오류 ${r.status ?? '시간 초과'}`;
    throw new Error(why);
  }
  const password = Buffer.from(r.stdout.trim(), 'base64').toString('utf8');
  return password ? { username: readIndex()[site]?.username || '', password } : null;
}

function list() {
  return Object.entries(readIndex()).map(([site, v]) => ({ site, username: v.username, savedAt: v.savedAt }));
}

function remove(site) {
  if (IS_WIN) winSecret.remove(SERVICE, site);
  else spawnSync('security', ['delete-generic-password', '-s', SERVICE, '-a', site], { encoding: 'utf8' });
  const index = readIndex();
  delete index[site];
  writeIndex(index);
}

module.exports = { save, get, list, remove };
