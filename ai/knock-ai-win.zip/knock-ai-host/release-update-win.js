// 윈도우판(설치 파일로 깐 Knock)의 업데이트 — 맥판(release-update.js)과 같은 흐름, 윈도우에 맞게.
// 새 판은 GitHub(GOONNEW/knock-browser)의 고정 릴리스 "win-latest" 에 올린다: Knock-windows-x64.zip + latest-win.json.
//   latest-win.json = { release: 판 번호, url: zip 주소, sha256, size, date, notes, sig }
//   sig = 우리 열쇠(signing/win-update-ed25519.pem, 저장소에 넣지 않음)로 `knock-win|release|sha256|size` 에 한 서명.
//   윈도우판은 아직 코드 서명이 없어서, GitHub 만 믿지 않고 이 서명이 맞아야 설치한다.
// 설치: 내려받기 → sha256·서명 확인 → 임시 폴더에 풀기 → 따로 도는 PowerShell 이 Knock 이 꺼지길 기다렸다가
//       프로그램 폴더만 바꿔 넣고(사용 기록 User Data 는 그대로) 다시 켠다. 이 도우미(node.exe)도 그 폴더에 있어서 직접은 못 바꾼다.
// AI 부분만 바뀐 판(2026-11-05 — 맥처럼 빨리): latest-win.json 의 ai = { release, base, url, sha256, size, sig }.
//   base(전체 판 번호)가 설치된 전체 판과 같을 때만 쓴다. AI 창(knock-ai)·도우미 코드(knock-ai-host 의 .js)만 담은 작은 zip(1MB 안쪽).
//   sig = `knock-win-ai|release|base|sha256|size`. 설치된 AI 판 번호는 knock-release.json 의 ai.
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn, spawnSync, execFile } = require('child_process');
const { Readable, Transform } = require('stream');
const { pipeline } = require('stream/promises');

// 최신 버전 안내: 똑소리툴즈 서버(2026-11-06 — GitHub 것은 올린 뒤 몇 분 동안 예전 것으로 보였다). 서버가 안 되면 GitHub.
// 어느 쪽이든 서명을 확인하므로(verifyFeed) 안내 파일을 어디서 받아도 안전하다. 설치 파일(zip)은 그대로 GitHub.
const FEED = process.env.KNOCK_UPDATE_FEED_WIN || 'https://hr.knocktools.com/api/knock/release/win';
const FEED_GITHUB = process.env.KNOCK_UPDATE_FEED_WIN ? null : 'https://github.com/GOONNEW/knock-browser/releases/download/win-latest/latest-win.json';
const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAQb1v8Ixm7EjicSNG4Kso8vT2hNkxWYAZQw88zYEgsak=
-----END PUBLIC KEY-----`;
// 이 도우미는 <설치 폴더>\knock-ai-host 안에서 돈다
const APP = path.resolve(__dirname, '..');
const RELEASE_FILE = path.join(APP, 'knock-release.json');

function isRelease() {
  return fs.existsSync(RELEASE_FILE);
}

function installedRelease() {
  try {
    return Number(JSON.parse(fs.readFileSync(RELEASE_FILE, 'utf8')).release) || 0;
  } catch {
    return 0;
  }
}

// 화면에 보이는 AI 번호의 기준(이 전체 판을 낼 때의 ai) — ver 판.(ai-aiBase)
// 화면에 보이는 판 번호(없으면 판 번호)
function installedShown() {
  try {
    const j = JSON.parse(fs.readFileSync(RELEASE_FILE, 'utf8'));
    return Number(j.shown) || Number(j.release) || 0;
  } catch {
    return 0;
  }
}

// 화면에 보이는 버전 세 자리(2026-11-07 버전 규칙) — 없으면 옛 방식
function installedVer() {
  try {
    const v = String(JSON.parse(fs.readFileSync(RELEASE_FILE, 'utf8')).ver || '');
    return /^\d+\.\d+\.\d+$/.test(v) ? v : '';
  } catch {
    return '';
  }
}

function installedAiBase() {
  try {
    return Number(JSON.parse(fs.readFileSync(RELEASE_FILE, 'utf8')).aiBase) || 0;
  } catch {
    return 0;
  }
}

function installedAi() {
  try {
    return Number(JSON.parse(fs.readFileSync(RELEASE_FILE, 'utf8')).ai) || 0;
  } catch {
    return 0;
  }
}

const signedText = (f) => `knock-win|${f.release}|${f.sha256}|${f.size}`;
// 전체 판 정보: full 이 있으면 그것(옛 판이 AI 부분 다리를 먼저 받게 맨 위 판 번호를 낮춰 둘 때 — 2026-11-05), 없으면 맨 위
const fullOf = (f) => (f && f.full) || f;
const signedAiText = (a) => `knock-win-ai|${a.release}|${a.base}|${a.sha256}|${a.size}`;
// 지금 설치된 판에 맞는 AI 부분 새 판(없으면 null)
function aiPatch(f = latest) {
  const a = f && f.ai;
  if (!a || !(fullOf(f).release <= installedRelease()) || a.base !== installedRelease() || !(a.release > installedAi())) return null;
  return a;
}
function verifyFeed(f) {
  if (!Number.isInteger(f.release) || !Number.isInteger(f.size) || !/^[0-9a-f]{64}$/.test(f.sha256 || '')) throw new Error('새 판 정보가 이상합니다.');
  // 시험할 때(KNOCK_UPDATE_FEED_WIN 을 준 때)만 그 정보 파일과 같은 곳의 주소도 받는다 — 서명은 그때도 맞아야 한다
  const testOrigin = process.env.KNOCK_UPDATE_FEED_WIN ? new URL(FEED).origin : null;
  if (!/^https:\/\/(github\.com|objects\.githubusercontent\.com)\//.test(f.url || '') && !(testOrigin && String(f.url).startsWith(`${testOrigin}/`))) throw new Error('새 판 주소가 이상합니다.');
  let ok = false;
  try { ok = crypto.verify(null, Buffer.from(signedText(f)), PUBLIC_KEY, Buffer.from(String(f.sig || ''), 'base64')); } catch {}
  if (!ok) throw new Error('새 판의 서명이 맞지 않아 설치하지 않았습니다.');
  if (f.full) verifyFeed({ ...f.full, ai: null, full: null });
  if (f.ai) {
    const a = f.ai;
    if (!Number.isInteger(a.release) || !Number.isInteger(a.base) || !Number.isInteger(a.size) || !/^[0-9a-f]{64}$/.test(a.sha256 || '')) throw new Error('AI 새 판 정보가 이상합니다.');
    if (!/^https:\/\/(github\.com|objects\.githubusercontent\.com)\//.test(a.url || '') && !(testOrigin && String(a.url).startsWith(`${testOrigin}/`))) throw new Error('AI 새 판 주소가 이상합니다.');
    let okAi = false;
    try { okAi = crypto.verify(null, Buffer.from(signedAiText(a)), PUBLIC_KEY, Buffer.from(String(a.sig || ''), 'base64')); } catch {}
    if (!okAi) throw new Error('AI 새 판의 서명이 맞지 않아 설치하지 않았습니다.');
  }
}

let latest = null; // 마지막으로 읽은 latest-win.json(서명 확인한 것만)

async function readFeed(url) {
  const res = await fetch(url, { redirect: 'follow', headers: { 'cache-control': 'no-cache' }, signal: AbortSignal.timeout(20000) });
  if (!res.ok) throw new Error(`새 판 정보를 받지 못했습니다(${res.status}).`);
  const feed = await res.json();
  verifyFeed(feed);
  return feed;
}
async function refresh() {
  let feed;
  try {
    feed = await readFeed(FEED);
  } catch (err) {
    if (!FEED_GITHUB) throw err;
    feed = await readFeed(FEED_GITHUB);
  }
  latest = feed;
  return feed;
}

// [업데이트]는 다 받아 둔 뒤에 띄운다(받다가 실패했으면 그냥 띄우고 누를 때 받는다)
function parts() {
  const t = target();
  if (!t || !(ready() || prepareFailed === t.key)) return [];
  return [t.ai ? 'AI 부분' : 'Knock 새 판'];
}

// 새 판을 받아 풀어 둔다. 바꿔 넣기는 relaunch 가 띄우는 PowerShell 이 한다.
// 내려받아 크기·sha256 이 맞는지 본다. 330MB 를 받다가 연결이 끊기는 일이 있어("terminated" — 2026-11-05 일반 PC)
// 끊기면 받은 데까지 이어서(Range) 다시 받는다 — 10번까지.
async function download(item, dir, log = () => {}) {
  const zip = path.join(dir, 'Knock.zip');
  fs.writeFileSync(zip, '');
  let lastErr = null;
  for (let attempt = 1; attempt <= 10; attempt++) {
    const have = fs.statSync(zip).size;
    if (have >= item.size) break;
    try {
      const res = await fetch(item.url, { redirect: 'follow', headers: have ? { range: `bytes=${have}-` } : {} });
      if (!res.ok || !res.body) throw new Error(`새 판을 내려받지 못했습니다(${res.status}).`);
      // 이어 받기를 서버가 안 받아 주면(200) 처음부터
      const append = have > 0 && res.status === 206;
      await pipeline(Readable.fromWeb(res.body), fs.createWriteStream(zip, { flags: append ? 'a' : 'w' }));
    } catch (err) {
      lastErr = err;
      log('내려받다 끊김, 이어서 받기', attempt, `${Math.round(fs.statSync(zip).size / 1048576)}MB`, err.message);
      await new Promise((r) => setTimeout(r, Math.min(attempt * 2000, 10000)));
    }
  }
  const size = fs.statSync(zip).size;
  if (size < item.size && lastErr) { fs.rmSync(dir, { recursive: true, force: true }); throw new Error(`새 판을 끝까지 받지 못했습니다(인터넷 연결을 확인해 주세요): ${lastErr.message}`); }
  // 다 받은 뒤 파일을 읽으며 sha256 을 센다(한꺼번에 메모리에 올리지 않는다)
  const hash = crypto.createHash('sha256');
  await pipeline(fs.createReadStream(zip), new Transform({ transform(c, _e, done) { hash.update(c); done(); } }));
  if (size !== item.size || hash.digest('hex') !== item.sha256) {
    fs.rmSync(dir, { recursive: true, force: true });
    throw new Error('내려받은 파일이 올린 것과 달라 설치하지 않았습니다.');
  }
  return zip;
}

// 풀기 — 도우미가 멈추지 않게(뒤에서 받는 동안에도 AI 가 답해야 한다) 따로 돌린다
function unzip(zip, out) {
  return new Promise((resolve) => {
    const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -LiteralPath '${zip}' -DestinationPath '${out}' -Force`], { windowsHide: true, stdio: 'ignore' });
    p.on('close', (code) => resolve(code === 0));
    p.on('error', () => resolve(false));
  });
}

// 지금 설치된 판에 필요한 새 판: { key, ai(AI 부분이면 그 정보) } 또는 null
function target(feed = latest) {
  if (!feed) return null;
  if (fullOf(feed).release > installedRelease()) return { key: `full:${fullOf(feed).release}`, ai: null };
  const ai = aiPatch(feed);
  return ai ? { key: `ai:${ai.base}:${ai.release}`, ai } : null;
}

// 받아서 풀어 둔다. 결과 { key, old(지울 임시 폴더), release, ai, src, aiOnly }
async function prepareNow(feed, t, log) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'knock-update-'));
  const out = path.join(dir, 'new');
  if (t.ai) {
    // AI 부분만: 작은 zip 을 풀어 knock-ai·knock-ai-host 만 바꿔 넣는다(브라우저 본체는 그대로)
    log('AI 새 판 내려받는 중', t.ai.release);
    const zip = await download(t.ai, dir, log);
    if (!(await unzip(zip, out)) || !fs.existsSync(path.join(out, 'knock-ai', 'manifest.json')) || !fs.existsSync(path.join(out, 'knock-release.json'))) {
      fs.rmSync(dir, { recursive: true, force: true });
      throw new Error('AI 새 판 파일을 풀지 못했습니다.');
    }
    fs.rmSync(zip, { force: true });
    log('AI 새 판 풀어 둠', t.ai.release);
    return { key: t.key, old: dir, release: installedRelease(), ai: t.ai.release, src: out, aiOnly: true };
  }
  const full = fullOf(feed);
  log('새 판 내려받는 중', full.release);
  const zip = await download(full, dir, log);
  const src = path.join(out, 'Knock');
  if (!(await unzip(zip, out)) || !fs.existsSync(path.join(src, 'chrome.exe'))) {
    fs.rmSync(dir, { recursive: true, force: true });
    throw new Error('새 판 파일을 풀지 못했습니다.');
  }
  fs.rmSync(zip, { force: true });
  log('새 판 풀어 둠', full.release);
  return { key: t.key, old: dir, release: full.release, src };
}

// ---------- 뒤에서 미리 받기(2026-11-05 "백그라운드에서 다운로드를 완료하고 [업데이트]를 누르면 설치") ----------
// 새 판 정보를 읽을 때마다 부른다. 다 받아 풀어 두면 그때 [업데이트]를 띄운다(누르면 바꿔 넣고 다시 켜기만 — 몇 초).
// 받다가 실패하면 [업데이트]를 띄우고, 누를 때 다시 받는다.
let prepared = null; // 풀어 둔 새 판
let preparing = null; // 받는 중인 { key, promise }
let prepareFailed = ''; // 받다가 실패한 판(key)
function dropPrepared() {
  if (prepared) fs.rmSync(prepared.old, { recursive: true, force: true });
  prepared = null;
}
let swept = false;
function prefetch(log = () => {}) {
  // 지난번에 받아 두고 설치하지 않은 임시 폴더(도우미가 다시 켜져 잊은 것)는 한 번 치운다 — 바꿔 넣는 중일 수 있는 1시간 안 것은 둔다
  if (!swept) {
    swept = true;
    try {
      for (const name of fs.readdirSync(os.tmpdir())) {
        const p = path.join(os.tmpdir(), name);
        if (/^knock-update-/.test(name) && Date.now() - fs.statSync(p).mtimeMs > 3600 * 1000) fs.rmSync(p, { recursive: true, force: true });
      }
    } catch {}
  }
  const t = target();
  if (!t) { dropPrepared(); return Promise.resolve(false); }
  if (prepared && prepared.key === t.key && fs.existsSync(prepared.src)) return Promise.resolve(true);
  if (preparing) return preparing.key === t.key ? preparing.promise : Promise.resolve(false);
  dropPrepared(); // 더 새 판이 나왔으면 예전에 받아 둔 것은 지운다
  const run = prepareNow(latest, t, log)
    .then((r) => { prepared = r; prepareFailed = ''; return true; })
    .catch((err) => { log('새 판 미리 받기 실패', err.message); prepareFailed = t.key; return false; })
    .finally(() => { preparing = null; });
  preparing = { key: t.key, promise: run };
  return run;
}
// 받아 둔 판이 지금 필요한 판인가
const ready = () => { const t = target(); return Boolean(t && prepared && prepared.key === t.key && fs.existsSync(prepared.src)); };

async function install(log = () => {}) {
  const feed = await refresh();
  const t = target(feed);
  if (!t) throw new Error('이미 최신 판입니다.');
  if (preparing && preparing.key === t.key) await preparing.promise; // 받는 중이면 끝날 때까지
  if (prepared && prepared.key === t.key && fs.existsSync(prepared.src)) {
    const r = prepared;
    prepared = null; // 이제 바꿔 넣는 쪽(relaunch)이 임시 폴더를 지운다
    log(r.aiOnly ? 'AI 새 판 받아 둔 것으로 설치' : '새 판 받아 둔 것으로 설치', r.aiOnly ? r.ai : r.release);
    return r;
  }
  return prepareNow(feed, t, log);
}

// Knock 이 꺼지길 기다렸다가 새 판을 넣고 다시 켠다. 이 도우미가 Knock 과 함께 꺼져도 계속 돌게 따로 띄운다.
function relaunch(src, workDir, aiOnly = false) {
  const logFile = path.join(os.homedir(), '.knock', 'host.log');
  // 임시 폴더가 짧은 이름(8.3)으로 올 수 있어 실제 긴 이름으로 바꿔 쓴다
  try { src = fs.realpathSync.native(src); } catch {}
  try { workDir = fs.realpathSync.native(workDir); } catch {}
  const ps = `
$ErrorActionPreference = 'Continue'
New-Item -ItemType Directory -Force (Split-Path '${logFile}') | Out-Null
# 기록 파일을 다시 켠 도우미가 쓰고 있으면 잠깐 막힐 수 있어 몇 번 더 해 본다
# 기록은 도우미 기록 파일과 같은 UTF-8 로(기본값은 윈도우 글자판이라 한글이 깨졌다)
function L($m) { for ($k = 0; $k -lt 5; $k++) { try { Add-Content -LiteralPath '${logFile}' "[win-update] $m" -Encoding UTF8 -ErrorAction Stop; return } catch { Start-Sleep -Milliseconds 200 } } }
# 이 Knock 의 프로세스: 실행 파일 경로가 안 보이는 것(보안 상자 안 화면 프로세스)도 실행 줄로 찾는다
# (예전에는 경로로만 찾아 남은 화면 프로세스가 파일을 붙잡고, 바꿔 넣기가 30초씩 끝없이 다시 해 보며 멈췄다 — 2026-11-05)
function Mine { Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -like "$app\\*" -or $_.CommandLine -like "*$app\\*" } | Where-Object { $_.ProcessId -ne $PID } }
# 업데이트가 두 번 겹치지 않게(먼저 시작한 것만 한다)
$lock = Join-Path $env:TEMP 'knock-update.lock'
try { $lockFile = [IO.File]::Open($lock, 'OpenOrCreate', 'ReadWrite', 'None') } catch { Add-Content -LiteralPath '${logFile}' '[win-update] 다른 업데이트가 이미 하는 중 — 그만둠' -Encoding UTF8; exit 0 }
L '시작'
Start-Sleep -Seconds 1
$app = '${(() => { try { return fs.realpathSync.native(APP); } catch { return APP; } })()}'
$procs = Mine | Where-Object { $_.Name -eq 'chrome.exe' }
# 본체 19 부터: Knock 에게 스스로 꺼지라고 한다(--knock-quit) — 강제로 끄면 작업 표시줄에 빈 아이콘이 남았다(2026-11-07)
if ($procs -and ${installedRelease() >= 19 ? '$true' : '$false'}) {
  L '정상 종료 부탁'
  Start-Process -FilePath (Join-Path $app 'chrome.exe') -ArgumentList '--knock-quit'
  # 본 프로세스(--type= 없는 것)가 끝날 때까지만 기다린다 — 남은 하위 프로세스는 아래에서 정리
  for ($i = 0; $i -lt 30; $i++) { Start-Sleep -Milliseconds 500; if (-not (Mine | Where-Object { $_.Name -eq 'chrome.exe' -and $_.CommandLine -notmatch '--type=' })) { break } }
  Start-Sleep -Seconds 1
  $procs = Mine | Where-Object { $_.Name -eq 'chrome.exe' }
}
# 그래도 남았으면 창을 닫아 달라고 부탁하고(탭·대화는 확장이 미리 저장했다), 20초 안에 안 꺼지면 끈다.
foreach ($p in $procs) { taskkill /PID $p.ProcessId 2>$null | Out-Null }
for ($i = 0; $i -lt 40; $i++) {
  $left = Mine
  if (-not $left) { break }
  Start-Sleep -Milliseconds 500
}
$left = Mine
foreach ($p in $left) { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 1
# 바꿔 넣기. 꺼지지 않는 프로세스(보안 상자 안 화면 프로세스가 죽지 않고 남는 일이 있었다 — 2026-11-05 가상 PC)가
# 파일을 붙잡고 있어도 되게: 덮어쓸 파일은 먼저 이름을 바꿔 비켜 두고(붙잡힌 파일도 이름은 바뀐다) 새 파일을 넣는다.
# 비켜 둔 옛 파일(*.knockold)은 지울 수 있으면 바로, 아니면 다음 업데이트 때 지운다.
function MoveAside($dir, $from) {
  Get-ChildItem -LiteralPath $from -File -Recurse | ForEach-Object {
    $rel = $_.FullName.Substring($from.Length).TrimStart('\\')
    if ($rel -eq 'chrome.exe') { return } # 실행 파일은 맨 끝에 한순간에 바꾼다(아래)
    $dst = Join-Path $dir $rel
    if (Test-Path -LiteralPath $dst) {
      $old = "$dst.$(Get-Date -Format 'yyyyMMddHHmmss').knockold"
      try { Rename-Item -LiteralPath $dst -NewName (Split-Path $old -Leaf) -ErrorAction Stop } catch { L "비켜 두지 못함: $rel" }
    }
  }
}
function DropOld($dir) { Get-ChildItem -LiteralPath $dir -Filter '*.knockold' -File -Recurse -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue }
# 비켜 둔 것을 되돌린다(새 파일이 없는 자리만) — 바꿔 넣기가 잘못됐을 때 원래대로
function Restore($dir) {
  Get-ChildItem -LiteralPath $dir -Filter '*.knockold' -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
    $orig = $_.FullName -replace '\.\d{14}\.knockold$', ''
    if (-not (Test-Path -LiteralPath $orig)) { try { Rename-Item -LiteralPath $_.FullName -NewName (Split-Path $orig -Leaf) -ErrorAction Stop } catch {} }
  }
}
DropOld $app
# 새 판 폴더가 제대로인지 먼저 본다 — 아니면 아무것도 바꾸지 않는다(/MIR 이 엉뚱한 폴더를 따라 지우지 않게)
if (-not (Test-Path -LiteralPath '${src}\\${aiOnly ? 'knock-ai\\manifest.json' : 'chrome.exe'}') -or -not (Test-Path -LiteralPath '${src}\\knock-release.json')) {
  L '새 판 폴더가 이상해서 바꾸지 않음'
  Set-Content -LiteralPath '${path.join(os.homedir(), '.knock', 'update-result.json')}' -Value '{"ok":false,"want":"새 판 폴더 이상"}' -Encoding UTF8
  Start-Process (Join-Path $app 'chrome.exe')
  exit 0
}
$want = (Get-Content -LiteralPath '${src}\\knock-release.json' -Raw).Trim()
# 새 판에 없는 옛 파일 지우기는 robocopy /MIR 에 맡긴다(비켜 둔 *.knockold 는 건드리지 않게 /XF).
# 예전에는 경로를 글자로 잘라 비교했는데, 임시 폴더 경로가 짧은 이름(C:\\Users\\ABCDEF~1)으로 오면 하나도 안 맞아
# 새로 넣은 파일까지 모두 지웠다 — chrome.exe 가 없어져 켜지지 않았다(2026-11-05 이든치과 노트북).
${aiOnly
    ? `MoveAside "$app\\knock-ai" '${src}\\knock-ai'
robocopy '${src}\\knock-ai' "$app\\knock-ai" /MIR /XF *.knockold /R:2 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
L "AI 창 복사 끝 $LASTEXITCODE"
MoveAside "$app\\knock-ai-host" '${src}\\knock-ai-host'
robocopy '${src}\\knock-ai-host' "$app\\knock-ai-host" /E /XF *.knockold /R:2 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
L "도우미 복사 끝 $LASTEXITCODE"
Copy-Item -LiteralPath '${src}\\knock-release.json' -Destination "$app\\knock-release.json" -Force`
    : `# 프로그램 폴더를 통째로 한순간에 바꾼다(2026-11-07 이든치과 노트북: 파일을 하나씩 비켜 두고 복사하는 사이에 Knock 을 켜면
# "chrome_elf.dll 이 없다"는 오류가 났다). 새 판 폴더는 같은 C: 안 임시 칸에 있어 옮기기가 바로 끝난다.
# 붙잡힌 파일이 있어 폴더 이름을 못 바꾸면 예전처럼 하나씩 바꾼다.
$parent = Split-Path $app
$oldDir = Join-Path $parent ("Application.old." + (Get-Date -Format 'yyyyMMddHHmmss'))
$swapped = $false
try {
  Rename-Item -LiteralPath $app -NewName (Split-Path $oldDir -Leaf) -ErrorAction Stop
  try { Move-Item -LiteralPath '${src}' -Destination $app -ErrorAction Stop; $swapped = $true }
  catch { L "새 폴더 옮기기 실패 — 되돌림: $($_.Exception.Message)"; Rename-Item -LiteralPath $oldDir -NewName (Split-Path $app -Leaf) -ErrorAction SilentlyContinue }
} catch { L "폴더 통째로 못 바꿈 — 하나씩 바꿈: $($_.Exception.Message)" }
if ($swapped) {
  L '폴더 통째로 바꿈'
  icacls $app /grant '*S-1-15-2-1:(OI)(CI)(RX)' '*S-1-15-2-2:(OI)(CI)(RX)' /T /C /Q | Out-Null
  Remove-Item -LiteralPath $oldDir -Recurse -Force -ErrorAction SilentlyContinue
  Get-ChildItem -LiteralPath $parent -Directory -Filter 'Application.old.*' -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
} else {
MoveAside $app '${src}'
robocopy '${src}' $app /MIR /XF *.knockold chrome.exe /R:2 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
L "복사 끝 $LASTEXITCODE"
# chrome.exe 는 다른 파일을 다 넣은 뒤 한순간에 바꾼다 — 예전엔 복사하는 수십 초 동안 chrome.exe 가 없어
# 그때 바탕화면 바로 가기를 누르면 "바로 가기 오류(삭제할까요?)"가 떴다(2026-11-07 이든치과 노트북). 같은 C: 안에서 옮기기라 바로 끝난다.
$exe = Join-Path $app 'chrome.exe'
if (Test-Path -LiteralPath $exe) { try { Rename-Item -LiteralPath $exe -NewName "chrome.exe.$(Get-Date -Format 'yyyyMMddHHmmss').knockold" -ErrorAction Stop } catch { L 'chrome.exe 비켜 두지 못함' } }
try { Move-Item -LiteralPath '${src}\\chrome.exe' -Destination $exe -Force -ErrorAction Stop } catch { Copy-Item -LiteralPath '${src}\\chrome.exe' -Destination $exe -Force -ErrorAction SilentlyContinue }
L "실행 파일 바꿈 $(Test-Path -LiteralPath $exe)"
icacls $app /grant '*S-1-15-2-1:(OI)(CI)(RX)' '*S-1-15-2-2:(OI)(CI)(RX)' /T /C /Q | Out-Null
}`}
# 꼭 있어야 할 파일이 없으면 비켜 둔 옛 파일을 되돌린다(켜지기라도 하게)
$must = @('chrome.exe', 'chrome.dll', 'chrome_elf.dll', 'knock-ai\\manifest.json', 'knock-ai-host\\host.js', 'knock-ai-host\\node.exe')
$lost = $must | Where-Object { -not (Test-Path -LiteralPath (Join-Path $app $_)) }
if ($lost) { L "빠진 파일 $($lost -join ',') — 옛 파일로 되돌림"; Restore $app }
else { DropOld $app } # 잘 바뀌었으면 비켜 둔 옛 파일은 지운다(붙잡힌 것은 다음 업데이트 때)
# 정말 바뀌었나(판 번호 파일이 새 것과 같은가) — 결과를 남겨 다시 켠 도우미가 알린다
$got = (Get-Content -LiteralPath "$app\\knock-release.json" -Raw -ErrorAction SilentlyContinue)
$ok = ($got -and $got.Trim() -eq $want)
L "결과 $(if ($ok) { '성공' } else { '실패' }) $want"
Set-Content -LiteralPath '${path.join(os.homedir(), '.knock', 'update-result.json')}' -Value (@{ ok = [bool]$ok; want = $want; at = (Get-Date).ToString('o') } | ConvertTo-Json -Compress) -Encoding UTF8
# 윈도우가 기억해 둔 옛 아이콘(작업 표시줄·맥 Dock 의 Parallels 아이콘)을 새로 읽게 한다
${aiOnly ? '' : `try { Start-Process -FilePath "$env:SystemRoot\\System32\\ie4uinit.exe" -ArgumentList '-show' -WindowStyle Hidden -Wait -ErrorAction Stop } catch {}`}
L '켜는 중'
Start-Process (Join-Path $app 'chrome.exe')
# 정말 켜졌는지 보고, 안 켜졌으면 한 번 더
Start-Sleep -Seconds 4
if (-not (Mine | Where-Object { $_.Name -eq 'chrome.exe' })) { L '안 켜져서 다시 켬'; Start-Process (Join-Path $app 'chrome.exe') }
Remove-Item -LiteralPath '${workDir}' -Recurse -Force -ErrorAction SilentlyContinue
L '다시 켬'
`;
  const file = path.join(os.tmpdir(), `knock-update-${Date.now()}.ps1`);
  // PowerShell 5 는 BOM 이 없으면 한글을 깨뜨려 읽는다
  fs.writeFileSync(file, `﻿${ps}`, 'utf8');
  // Knock 이 꺼질 때 함께 꺼지지 않게(크롬은 도우미와 그 자식을 한 묶음으로 끈다) 윈도우 프로세스 서비스(WMI)로 띄운다
  const cmd = `powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "${file}"`;
  // 창 없이 띄운다(ShowWindow=0) — -WindowStyle Hidden 만으로는 검은 "관리자" 창이 작업 표시줄에 남았다(2026-11-05)
  const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `$si = New-CimInstance -ClassName Win32_ProcessStartup -ClientOnly -Property @{ ShowWindow = [uint16]0 }; $r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = '${cmd.replace(/'/g, "''")}'; ProcessStartupInformation = $si }; exit $r.ReturnValue`], { windowsHide: true });
  if (r.status !== 0) spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', file], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
}

// 바로 가기 고치기(2026-11-06 "원격지에서 아이콘을 누르면 누르는 만큼 새창이 생겨"):
// 작업 표시줄·바탕 화면·시작 메뉴의 Knock 바로 가기가 설치된 곳이 아닌 다른 Knock(압축 푼 폴더 등)을 가리키면,
// 누를 때마다 그 Knock 이 켜지면서 이미 켜진 Knock Browser 에 새 창을 열라고 넘긴다. 설치된 곳으로 바꿔 놓는다.
// 다른 Knock 인지는 그 폴더의 knock-ai 폴더로 알아본다(구글 크롬 바로 가기는 건드리지 않는다).
function fixShortcuts(log = () => {}) {
  const exe = path.join(APP, 'chrome.exe');
  const ps = `
$app = '${exe.replace(/'/g, "''")}'
$ws = New-Object -ComObject WScript.Shell
$dirs = @("$env:APPDATA\\Microsoft\\Internet Explorer\\Quick Launch\\User Pinned\\TaskBar", [Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('CommonDesktopDirectory'), "$env:APPDATA\\Microsoft\\Windows\\Start Menu\\Programs")
foreach ($d in $dirs) {
  if (-not $d -or -not (Test-Path -LiteralPath $d)) { continue }
  foreach ($f in Get-ChildItem -LiteralPath $d -Filter *.lnk -ErrorAction SilentlyContinue) {
    try { $s = $ws.CreateShortcut($f.FullName) } catch { continue }
    $t = [string]$s.TargetPath
    if (-not ($t -like '*\\chrome.exe') -or $t -eq $app) { continue }
    $dir = Split-Path -Parent $t
    $knock = (Test-Path -LiteralPath (Join-Path $dir 'knock-ai')) -or ((-not (Test-Path -LiteralPath $t)) -and $f.Name -like 'Knock*')
    if (-not $knock) { continue }
    $s.TargetPath = $app; $s.WorkingDirectory = (Split-Path -Parent $app); $s.IconLocation = "$app,0"
    try { $s.Save(); "fixed|$($f.FullName)|$t" } catch {}
  }
}`;
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], { windowsHide: true, encoding: 'utf8', timeout: 30000 }, (_err, out) => {
      const fixed = String(out || '').split(/\r?\n/).filter((l) => l.startsWith('fixed|'));
      for (const l of fixed) log('바로 가기 고침', ...l.split('|').slice(1));
      resolve(fixed.length);
    });
  });
}

module.exports = { installedVer, fixShortcuts, download, FEED, APP, isRelease, installedRelease, installedAi, installedAiBase, installedShown, aiPatch, refresh, parts, prefetch, install, relaunch, signedText, signedAiText, verifyFeed };
