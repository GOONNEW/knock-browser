// AI 창에 첨부한 파일을 Claude 가 읽을 수 있는 형태(content block)로 바꾼다.
// 이미지 → image(큰 사진은 AI 창에서 미리 줄여 보낸다), PDF → document(base64), 글 파일 → document(text),
// 엑셀·워드·한글 → 글을 꺼내 document(text). 그 밖의 형식은 웹페이지에 올리는 데만 쓴다.
const { isDocument, extractText } = require('./documents');
const fs = require('fs');
const os = require('os');
const path = require('path');

const MAX_FILES = 10;
const MAX_IMAGE_BYTES = 5 * 1024 * 1024; // API 한도(이미지 한 장 5MB)
const MAX_PDF_BYTES = 30 * 1024 * 1024;
const MAX_TEXT_BYTES = 2 * 1024 * 1024;
const MAX_DOC_BYTES = 30 * 1024 * 1024;
const MAX_DOC_CHARS = 300000;

const IMAGE_TYPES = new Set(['image/png', 'image/jpeg', 'image/gif', 'image/webp']);
const TEXT_EXT = /\.(txt|md|csv|tsv|json|xml|html?|css|js|ts|py|log|ya?ml|ini|sql)$/i;

function kindOf(name, type) {
  if (IMAGE_TYPES.has(type)) return 'image';
  if (type === 'application/pdf' || /\.pdf$/i.test(name)) return 'pdf';
  if (type.startsWith('text/') || type === 'application/json' || TEXT_EXT.test(name)) return 'text';
  return 'other';
}

function mb(bytes) {
  return `${(bytes / 1024 / 1024).toFixed(1)}MB`;
}

// 첨부 파일은 ~/.knock/attachments 에 저장해 두고, AI 가 웹페이지에 올릴 때(upload_file) 쓴다. 일주일 지나면 지운다.
const SAVE_DIR = path.join(os.homedir(), '.knock', 'attachments');
const KEEP_MS = 7 * 24 * 60 * 60 * 1000;

function saveFile(name, buf) {
  fs.mkdirSync(SAVE_DIR, { recursive: true, mode: 0o700 });
  const dir = fs.mkdtempSync(path.join(SAVE_DIR, `${Date.now()}-`));
  const file = path.join(dir, name);
  fs.writeFileSync(file, buf, { mode: 0o600 });
  return file;
}

function cleanOldAttachments() {
  let entries = [];
  try { entries = fs.readdirSync(SAVE_DIR); } catch { return; }
  for (const e of entries) {
    const stamp = Number(e.split('-')[0]);
    if (stamp && Date.now() - stamp > KEEP_MS) fs.rmSync(path.join(SAVE_DIR, e), { recursive: true, force: true });
  }
}

// files: [{ name, type, data(base64 원본), view?: { type, data } (AI 에게 보일 줄인 사진) }]
// → { blocks, saved: [{ name, path, readable }], notes }
async function toBlocks(files = []) {
  const blocks = [];
  const saved = [];
  const notes = [];
  if (files.length > MAX_FILES) notes.push(`한 번에 ${MAX_FILES}개까지만 첨부할 수 있어 ${files.length - MAX_FILES}개는 뺐습니다.`);

  for (const f of files.slice(0, MAX_FILES)) {
    const name = path.basename(String(f.name || '첨부')).replace(/[\\/:*?"<>|]/g, '_') || '첨부';
    const type = String(f.type || '');
    const buf = Buffer.from(f.data || '', 'base64');
    const kind = kindOf(name, type);
    const entry = { name, path: saveFile(name, buf), readable: false };
    saved.push(entry);

    if (kind === 'image') {
      const view = f.view ? Buffer.from(f.view.data, 'base64') : buf;
      if (view.length > MAX_IMAGE_BYTES) {
        notes.push(`${name}: 이미지가 커서(${mb(view.length)}) AI가 보지는 못하고, 페이지에 올리는 데만 쓸 수 있습니다.`);
        continue;
      }
      blocks.push({ type: 'image', source: { type: 'base64', media_type: f.view?.type || type, data: view.toString('base64') } });
      entry.readable = true;
    } else if (kind === 'pdf') {
      if (buf.length > MAX_PDF_BYTES) {
        notes.push(`${name}: PDF가 커서(${mb(buf.length)}) AI가 읽지는 못하고, 페이지에 올리는 데만 쓸 수 있습니다.`);
        continue;
      }
      blocks.push({ type: 'document', title: name, source: { type: 'base64', media_type: 'application/pdf', data: buf.toString('base64') } });
      entry.readable = true;
    } else if (kind === 'text') {
      if (buf.length > MAX_TEXT_BYTES) {
        notes.push(`${name}: 글 파일이 커서(${mb(buf.length)}) AI가 읽지는 못하고, 페이지에 올리는 데만 쓸 수 있습니다.`);
        continue;
      }
      blocks.push({ type: 'document', title: name, source: { type: 'text', media_type: 'text/plain', data: buf.toString('utf8') } });
      entry.readable = true;
    } else if (isDocument(name)) {
      if (buf.length > MAX_DOC_BYTES) {
        notes.push(`${name}: 파일이 커서(${mb(buf.length)}) AI가 읽지는 못하고, 페이지에 올리는 데만 쓸 수 있습니다.`);
        continue;
      }
      let text;
      try {
        text = await extractText(name, buf);
      } catch (err) {
        notes.push(`${name}: 내용을 꺼내지 못했습니다(${err.message || err}). 페이지에 올리는 데는 쓸 수 있습니다.`);
        continue;
      }
      if (!text) {
        notes.push(`${name}: 글자가 없는 문서입니다(그림만 있을 수 있음).`);
        continue;
      }
      if (text.length > MAX_DOC_CHARS) {
        notes.push(`${name}: 글이 길어(${text.length.toLocaleString()}자) 앞 ${MAX_DOC_CHARS.toLocaleString()}자만 AI에게 넘겼습니다.`);
        text = `${text.slice(0, MAX_DOC_CHARS)}\n\n(여기서 잘림: 전체 ${text.length}자 중 앞 ${MAX_DOC_CHARS}자)`;
      }
      blocks.push({ type: 'document', title: name, source: { type: 'text', media_type: 'text/plain', data: text } });
      entry.readable = true;
    } else {
      notes.push(`${name}: AI가 내용을 읽지는 못하고, 페이지에 올리는 데만 쓸 수 있습니다.`);
    }
  }
  return { blocks, saved, notes };
}

module.exports = { toBlocks, cleanOldAttachments };
