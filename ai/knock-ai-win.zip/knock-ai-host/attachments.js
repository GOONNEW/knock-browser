// AI 창에 첨부한 파일을 Claude 가 읽을 수 있는 형태(content block)로 바꾼다.
// 이미지 → image(큰 사진은 AI 창에서 미리 줄여 보낸다), PDF → document(base64), 글 파일 → document(text),
// 엑셀·워드·한글 → 글을 꺼내 document(text). 그 밖의 형식은 웹페이지에 올리는 데만 쓴다.
const { isDocument, extractText, extractImages } = require('./documents');
const fs = require('fs');
const os = require('os');
const path = require('path');

const MAX_FILES = 30; // 폴더를 끌어다 놓으면 안의 사진이 한꺼번에 온다(panel.js FOLDER_MAX)
const MAX_IMAGE_BYTES = 5 * 1024 * 1024; // API 한도(이미지 한 장 5MB)
const MAX_PDF_BYTES = 30 * 1024 * 1024;
const MAX_TEXT_BYTES = 2 * 1024 * 1024;
const MAX_DOC_BYTES = 30 * 1024 * 1024;
const MAX_DOC_CHARS = 300000;
const MAX_DOC_IMAGES_SHOWN = 20; // 문서 안 사진 중 AI 가 직접 볼 장수(나머지는 이름으로만)

const IMAGE_TYPES = new Set(['image/png', 'image/jpeg', 'image/gif', 'image/webp']);
const TEXT_EXT = /\.(txt|md|csv|tsv|json|xml|html?|css|js|ts|py|log|ya?ml|ini|sql)$/i;

function kindOf(name, type) {
  if (IMAGE_TYPES.has(type)) return 'image';
  if (type === 'application/pdf' || /\.pdf$/i.test(name)) return 'pdf';
  if (type.startsWith('text/') || type === 'application/json' || TEXT_EXT.test(name)) return 'text';
  return 'other';
}

// 글 파일 읽기: 옛 한글 방식(EUC-KR·CP949)으로 저장한 파일도 한글이 깨지지 않게(2026-11-09 카드사 보안메일 WooriCard.html)
function decodeText(buf) {
  const head = buf.subarray(0, 4096).toString('latin1');
  const said = (head.match(/charset\s*=\s*["']?([\w-]+)/i)?.[1] || '').toLowerCase();
  const korean = /^(euc-kr|ks_c_5601-1987|cp949|x-windows-949|windows-949|ksc5601)$/.test(said);
  if (!korean) {
    try { return new TextDecoder('utf-8', { fatal: true }).decode(buf); } catch {}
  }
  try { return new TextDecoder('euc-kr').decode(buf); } catch {}
  return buf.toString('utf8');
}

// 카드사·은행·보험사가 보내는 "보안메일"(비밀번호를 넣어야 열리는 HTML) — 파일 안의 내용은 암호라 그대로는 읽을 수 없다
const SECURE_MAIL = /VestMail|YettieSoft|보안\s*메일|SecureMail|Secure\s*Mail|INISAFE\s*Mail|MailSafer|SoftForum|Initech|암호화된\s*(?:메일|문서)|명세서\s*비밀번호/i;
function isSecureMail(name, text) {
  return /\.html?$/i.test(name) && SECURE_MAIL.test(text);
}

function mb(bytes) {
  return `${(bytes / 1024 / 1024).toFixed(1)}MB`;
}

// 첨부 파일은 ~/.knock/attachments 에 저장해 두고, AI 가 웹페이지에 올릴 때(upload_file) 쓴다. 일주일 지나면 지운다.
const SAVE_DIR = path.join(os.homedir(), '.knock', 'attachments');
const KEEP_MS = 7 * 24 * 60 * 60 * 1000;

function saveFile(name, buf) {
  fs.mkdirSync(SAVE_DIR, { recursive: true, mode: 0o700 });
  const dir = fs.mkdtempSync(path.join(SAVE_DIR, `${Date.now()}-`));
  const file = path.join(dir, name);
  fs.writeFileSync(file, buf, { mode: 0o600 });
  return file;
}

function cleanOldAttachments() {
  let entries = [];
  try { entries = fs.readdirSync(SAVE_DIR); } catch { return; }
  for (const e of entries) {
    const stamp = Number(e.split('-')[0]);
    if (stamp && Date.now() - stamp > KEEP_MS) fs.rmSync(path.join(SAVE_DIR, e), { recursive: true, force: true });
  }
}

// files: [{ name, type, data(base64 원본), view?: { type, data } (AI 에게 보일 줄인 사진) }]
// → { blocks, saved: [{ name, path, readable }], notes }
async function toBlocks(files = []) {
  const blocks = [];
  const saved = [];
  const notes = [];
  if (files.length > MAX_FILES) notes.push(`한 번에 ${MAX_FILES}개까지만 첨부할 수 있어 ${files.length - MAX_FILES}개는 뺐습니다.`);

  for (const f of files.slice(0, MAX_FILES)) {
    const name = path.basename(String(f.name || '첨부')).replace(/[\\/:*?"<>|]/g, '_') || '첨부';
    const type = String(f.type || '');
    const buf = Buffer.from(f.data || '', 'base64');
    const kind = kindOf(name, type);
    const entry = { name, path: saveFile(name, buf), readable: false };
    saved.push(entry);

    if (kind === 'image') {
      const view = f.view ? Buffer.from(f.view.data, 'base64') : buf;
      if (view.length > MAX_IMAGE_BYTES) {
        notes.push(`${name}: 이미지가 커서(${mb(view.length)}) AI가 보지는 못하고, 페이지에 올리는 데만 쓸 수 있습니다.`);
        continue;
      }
      blocks.push({ type: 'image', source: { type: 'base64', media_type: f.view?.type || type, data: view.toString('base64') } });
      entry.readable = true;
    } else if (kind === 'pdf') {
      if (buf.length > MAX_PDF_BYTES) {
        notes.push(`${name}: PDF가 커서(${mb(buf.length)}) AI가 읽지는 못하고, 페이지에 올리는 데만 쓸 수 있습니다.`);
        continue;
      }
      blocks.push({ type: 'document', title: name, source: { type: 'base64', media_type: 'application/pdf', data: buf.toString('base64') } });
      entry.readable = true;
    } else if (kind === 'text') {
      if (isSecureMail(name, decodeText(buf.subarray(0, 200000)))) {
        // 그대로 넘기면 AI 는 암호 덩어리만 받는다 — 탭에 열어 사용자가 비밀번호를 넣게 하고, 풀린 화면을 읽게 한다
        entry.secure = true;
        blocks.push({ type: 'text', text: `[첨부 "${name}" 는 비밀번호로 잠긴 보안메일(카드 명세서 등)입니다. 파일 속 내용은 암호라 그대로는 읽을 수 없습니다. `
          + `내용이 필요하면 open_attachment 로 이 파일을 탭에 열고, 사용자에게 "열린 탭에서 비밀번호를 넣으세요"라고 짧게 안내한 뒤 이번 답을 마칩니다. `
          + `사용자가 넣었다고 하면 그 탭(tab_id)을 get_page 로 읽습니다. 비밀번호를 묻거나 대신 넣지 마세요]` });
        continue;
      }
      if (buf.length > MAX_TEXT_BYTES) {
        notes.push(`${name}: 글 파일이 커서(${mb(buf.length)}) AI가 읽지는 못하고, 페이지에 올리는 데만 쓸 수 있습니다.`);
        continue;
      }
      blocks.push({ type: 'document', title: name, source: { type: 'text', media_type: 'text/plain', data: decodeText(buf) } });
      entry.readable = true;
    } else if (isDocument(name)) {
      if (buf.length > MAX_DOC_BYTES) {
        notes.push(`${name}: 파일이 커서(${mb(buf.length)}) AI가 읽지는 못하고, 페이지에 올리는 데만 쓸 수 있습니다.`);
        continue;
      }
      // 문서 안 사진: 따로 꺼내 첨부처럼 둔다(AI 가 보고, upload_file·figma_upload_files 에 이름으로 쓴다)
      try {
        const { images, skipped } = await extractImages(name, buf);
        const base = name.replace(/\.[^.]+$/, '');
        images.forEach((img, i) => {
          const iname = `${base}-그림${String(i + 1).padStart(2, '0')}.${img.ext}`;
          const ientry = { name: iname, path: saveFile(iname, img.data), readable: false, fromDoc: name };
          saved.push(ientry);
          if (i < MAX_DOC_IMAGES_SHOWN && IMAGE_TYPES.has(img.type) && img.data.length <= MAX_IMAGE_BYTES) {
            blocks.push({ type: 'text', text: `[${name} 안의 사진 ${i + 1}: ${iname}]` });
            blocks.push({ type: 'image', source: { type: 'base64', media_type: img.type, data: img.data.toString('base64') } });
            ientry.readable = true;
          }
        });
        if (images.length) notes.push(`${name}: 안에 든 사진 ${images.length}장을 꺼냈습니다(${base}-그림01 …)${images.length > MAX_DOC_IMAGES_SHOWN ? ` — AI는 앞 ${MAX_DOC_IMAGES_SHOWN}장만 봅니다` : ''}.`);
        if (skipped) notes.push(`${name}: 옛 그림 형식(EMF·WMF 등) ${skipped}개는 꺼내지 못했습니다.`);
      } catch (err) {
        notes.push(`${name}: 안의 사진을 꺼내지 못했습니다(${err.message || err}).`);
      }
      let text;
      try {
        text = await extractText(name, buf);
      } catch (err) {
        notes.push(`${name}: 내용을 꺼내지 못했습니다(${err.message || err}). 페이지에 올리는 데는 쓸 수 있습니다.`);
        continue;
      }
      if (!text) {
        notes.push(`${name}: 글자가 없는 문서입니다(그림만 있을 수 있음).`);
        continue;
      }
      if (text.length > MAX_DOC_CHARS) {
        notes.push(`${name}: 글이 길어(${text.length.toLocaleString()}자) 앞 ${MAX_DOC_CHARS.toLocaleString()}자만 AI에게 넘겼습니다.`);
        text = `${text.slice(0, MAX_DOC_CHARS)}\n\n(여기서 잘림: 전체 ${text.length}자 중 앞 ${MAX_DOC_CHARS}자)`;
      }
      blocks.push({ type: 'document', title: name, source: { type: 'text', media_type: 'text/plain', data: text } });
      entry.readable = true;
    } else {
      notes.push(`${name}: AI가 내용을 읽지는 못하고, 페이지에 올리는 데만 쓸 수 있습니다.`);
    }
  }
  return { blocks, saved, notes };
}

module.exports = { toBlocks, cleanOldAttachments };
