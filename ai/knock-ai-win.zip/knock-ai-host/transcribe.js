// 영상 소리 받아쓰기(watch_video, 2026-11-24 원장님 "제미나이처럼 영상을 읽을 수 있게 우리가 만들자").
// 이 컴퓨터 안에서 Whisper(large-v3-turbo, 4비트)로 받아쓴다 — 소리를 밖으로 보내지 않고 요금도 없다.
// 음성 인식 부품(약 760MB)은 처음 쓸 때 한 번 받아 ~/.knock/models 에 둔다.
// 일은 따로 떨어진 일꾼(transcribe-worker.js)이 하고, 10분 동안 일이 없으면 끈다(메모리 약 1GB 를 돌려준다).
const { spawn } = require('child_process');
const path = require('path');

let worker = null;
let idle = null;
let seq = 1;
const jobs = new Map(); // id → { resolve, reject, progress }

function stopWorker() {
  if (!worker) return;
  const w = worker;
  worker = null;
  try { w.kill('SIGKILL'); } catch {}
  for (const j of jobs.values()) j.reject(new Error('받아쓰기 프로그램이 멈췄습니다'));
  jobs.clear();
}

function ensureWorker() {
  if (worker) return worker;
  const w = spawn(process.execPath, [path.join(__dirname, 'transcribe-worker.js')], { cwd: __dirname, stdio: ['pipe', 'pipe', 'ignore'], windowsHide: true });
  worker = w;
  let buf = '';
  w.stdout.setEncoding('utf8');
  w.stdout.on('data', (d) => {
    buf += d;
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i);
      buf = buf.slice(i + 1);
      let m;
      try { m = JSON.parse(line); } catch { continue; }
      const j = jobs.get(m.id);
      if (!j) continue;
      if (m.note) { j.progress?.(m.note); continue; }
      jobs.delete(m.id);
      if (m.error) j.reject(new Error(m.error));
      else j.resolve(m.segments || []);
    }
  });
  w.on('exit', () => { if (worker === w) { worker = null; for (const j of jobs.values()) j.reject(new Error('받아쓰기 프로그램이 멈췄습니다')); jobs.clear(); } });
  w.stdin.on('error', () => {});
  return w;
}

// pcm: 16kHz 모노 16비트(base64) → [{ start, end, text }]
function transcribe(pcm, progress, language = 'korean') {
  clearTimeout(idle);
  const id = seq++;
  return new Promise((resolve, reject) => {
    jobs.set(id, { resolve, reject, progress });
    ensureWorker().stdin.write(`${JSON.stringify({ id, pcm, language })}\n`);
  }).finally(() => {
    if (!jobs.size) { clearTimeout(idle); idle = setTimeout(stopWorker, 10 * 60 * 1000); idle.unref?.(); }
  });
}

process.on('exit', () => { try { worker?.kill('SIGKILL'); } catch {} });

module.exports = { transcribe };
