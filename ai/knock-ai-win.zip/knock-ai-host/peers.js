// 프로필끼리 잇기. Knock 은 프로필마다 AI 확장과 도우미(이 프로그램)가 하나씩 따로 뜬다.
// 도우미마다 ~/.knock/peers/<pid>.sock 에 작은 통로를 열어 두고, 다른 프로필의 탭 정보가 필요하면
// 다른 도우미들에게 물어본다(같은 맥, 같은 사용자 안에서만 — 폴더는 사용자만 읽고 쓸 수 있다).
// 윈도우는 파일 통로를 못 쓰므로 이름 있는 파이프(\\.\pipe\knock-peer-<무작위>)를 열고,
// 그 이름을 ~/.knock/peers/<pid>.pipe 에 적어 둔다(이름을 모르면 찾아올 수 없게 무작위로 짓는다).
//
//   ask(op, args)  → 다른 프로필들의 답 [{ ... }] (답하지 않으면 빼고)
//   serve(handler) → 다른 프로필이 물어오면 handler(op, args) 의 결과로 답한다
const fs = require('fs');
const net = require('net');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const IS_WIN = process.platform === 'win32';
// 시험: KNOCK_PC_HOME 이 있으면 그 폴더를 쓴다(한 맥에서 PC 두 대처럼 — 원장님 Knock 의 프로필과 섞이지 않게)
const DIR = path.join(process.env.KNOCK_PC_HOME || path.join(os.homedir(), '.knock'), 'peers');
const ME = path.join(DIR, `${process.pid}.${IS_WIN ? 'pipe' : 'sock'}`);
const PIPE = IS_WIN ? `\\\\.\\pipe\\knock-peer-${crypto.randomBytes(16).toString('hex')}` : null;
const TIMEOUT_MS = 8000;

function serve(handler) {
  fs.mkdirSync(DIR, { recursive: true, mode: 0o700 });
  fs.chmodSync(DIR, 0o700);
  try { fs.unlinkSync(ME); } catch {}
  const server = net.createServer((sock) => {
    let buf = '';
    sock.on('data', async (d) => {
      buf += d;
      const i = buf.indexOf('\n');
      if (i < 0) return;
      let req;
      try { req = JSON.parse(buf.slice(0, i)); } catch { return sock.destroy(); }
      let result = null;
      try { result = await handler(req.op, req.args || {}); } catch (err) { result = { error: err.message }; }
      sock.end(`${JSON.stringify(result)}\n`);
    });
    sock.on('error', () => {});
  });
  if (IS_WIN) server.listen(PIPE, () => fs.writeFileSync(ME, PIPE, { mode: 0o600 }));
  else server.listen(ME, () => fs.chmodSync(ME, 0o600));
  const cleanup = () => { try { fs.unlinkSync(ME); } catch {} };
  process.on('exit', cleanup);
  return server;
}

function askOne(file, op, args) {
  return new Promise((resolve) => {
    let target = file;
    if (IS_WIN) {
      try { target = fs.readFileSync(file, 'utf8').trim(); } catch { return resolve(undefined); }
    }
    const sock = net.connect(target);
    let buf = '';
    const done = (v) => { clearTimeout(timer); sock.destroy(); resolve(v); };
    const timer = setTimeout(() => done(undefined), TIMEOUT_MS);
    sock.on('connect', () => sock.write(`${JSON.stringify({ op, args })}\n`));
    sock.on('data', (d) => { buf += d; });
    sock.on('end', () => { try { done(JSON.parse(buf)); } catch { done(undefined); } });
    sock.on('error', (err) => {
      // 꺼진 도우미가 남긴 통로 파일은 지운다
      if (err.code === 'ECONNREFUSED' || err.code === 'ENOENT') { try { fs.unlinkSync(file); } catch {} }
      done(undefined);
    });
  });
}

async function ask(op, args) {
  let files = [];
  try { files = fs.readdirSync(DIR).filter((f) => f.endsWith(IS_WIN ? '.pipe' : '.sock')).map((f) => path.join(DIR, f)).filter((f) => f !== ME); } catch {}
  const answers = await Promise.all(files.map((f) => askOne(f, op, args)));
  return answers.filter((a) => a !== undefined && a !== null);
}

module.exports = { serve, ask };
