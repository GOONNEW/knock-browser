// 모든 프로필·모든 AI(Knock AI·옆창 Gemini)가 함께 보는 대화 기록.
// 프로필마다 도우미가 따로 뜨지만 같은 파일(~/.knock/shared-chats.jsonl)에 쓰고 읽으므로 프로필끼리 이어진다.
// 이 맥 사용자만 읽고 쓸 수 있다(0600). 최근 500개·30일만 남긴다.
//   add({ ai, profile, tabId, title, url, user, answer })
//   recent({ limit, query, sinceMs, ai, excludeProfile, excludeTab }) → 최근 것부터
const fs = require('fs');
const os = require('os');
const path = require('path');

const FILE = path.join(os.homedir(), '.knock', 'shared-chats.jsonl');
const KEEP = 500;
const KEEP_MS = 30 * 24 * 60 * 60 * 1000;
const cut = (s, n) => String(s || '').replace(/\s+\n/g, '\n').trim().slice(0, n);

function readAll() {
  let lines = [];
  try { lines = fs.readFileSync(FILE, 'utf8').split('\n'); } catch { return []; }
  const out = [];
  for (const l of lines) {
    if (!l) continue;
    try { out.push(JSON.parse(l)); } catch {}
  }
  return out;
}

function add(e) {
  if (!e || !String(e.user || '').trim()) return;
  const entry = {
    at: Date.now(),
    ai: e.ai === 'gemini' ? 'gemini' : 'knock',
    profile: cut(e.profile, 30),
    tabId: Number(e.tabId) || null,
    title: cut(e.title, 120),
    url: cut(e.url, 300),
    user: cut(e.user, 1500),
    answer: cut(e.answer, 3000),
  };
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.appendFileSync(FILE, `${JSON.stringify(entry)}\n`, { mode: 0o600 });
  // 가끔 오래된 것을 지운다
  if (Math.random() < 0.1) {
    const keep = readAll().filter((x) => Date.now() - x.at < KEEP_MS).slice(-KEEP);
    fs.writeFileSync(FILE, keep.map((x) => JSON.stringify(x)).join('\n') + '\n', { mode: 0o600 });
  }
}

// site: 이 사이트(주소의 호스트)에서 나눈 대화만
const hostOf = (u) => { try { return new URL(u).hostname; } catch { return ''; } };

function recent({ limit = 5, query = '', sinceMs = 0, ai = null, excludeProfile = null, excludeTab = null, site = null } = {}) {
  const words = String(query).toLowerCase().split(/\s+/).filter(Boolean);
  return readAll()
    .reverse()
    .filter((x) => !sinceMs || Date.now() - x.at < sinceMs)
    .filter((x) => !ai || x.ai === ai)
    .filter((x) => !site || hostOf(x.url) === site)
    .filter((x) => !(excludeProfile && x.profile === excludeProfile && x.ai === 'knock' && x.tabId === excludeTab))
    .filter((x) => !words.length || words.every((w) => `${x.title} ${x.user} ${x.answer}`.toLowerCase().includes(w)))
    .slice(0, Math.min(20, Math.max(1, limit)));
}

// AI 에게 보여 줄 글
function describe(list, answerLen = 600) {
  const ago = (t) => {
    const m = Math.round((Date.now() - t) / 60000);
    return m < 60 ? `${m}분 전` : m < 1440 ? `${Math.round(m / 60)}시간 전` : `${Math.round(m / 1440)}일 전`;
  };
  return list.map((x) => `- ${ago(x.at)} · ${x.ai === 'gemini' ? 'Gemini(옆창)' : 'Knock AI'} · 프로필 "${x.profile}"${x.title ? ` · 탭 "${x.title}"` : ''}\n  사용자: ${x.user.slice(0, 400)}\n  답: ${x.answer.slice(0, answerLen) || '(답 없음)'}`).join('\n');
}

module.exports = { add, recent, describe };
