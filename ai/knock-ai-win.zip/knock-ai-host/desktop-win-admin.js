// 윈도우 AI 관리자 도우미(2026-11-18 원장님 "덴트웹을 AI 가 못 눌러"): 덴트웹처럼 관리자 권한으로 켜진 프로그램은
// 보통 권한인 Knock Browser 가 읽거나 누르거나 쓰면 윈도우가 막는다(UIPI). 그래서 그 PC 에서 한 번만 관리자 허락을 받아,
// desktop-win.js 의 창 다루기 프로그램을 관리자 권한으로 도는 윈도우 예약 작업(\KnockBrowser\AiDesktop)으로 둔다.
// 원격 PC 제어의 관리자 통로(input-relay-win.js)와 같은 방식이다.
// - 프로그램 파일은 C:\ProgramData\KnockBrowserAI 에 두고 관리자만 고칠 수 있게 한다(보통 권한 프로그램이 바꿔 치기 못하게).
// - 통로(이름 있는 파이프)는 그 사용자와 시스템만 쓸 수 있다. 한 번에 한 곳만 잇는다.
// - 관리자 도우미는 창 읽기·누르기·쓰기·키·사진만 한다. 프로그램 켜기·파일 붙여 넣기는 하지 않는다(desktop-win.js Handle).
// - 명령·설정 창(cmd·powershell·터미널·regedit·mmc 등)에는 누르기·쓰기·키를 하지 않는다(desktop-win.js ConsoleBlock). 읽기·사진은 된다.
// - 바꾸면 ADMIN_VER 를 올린다 — 옛 판이면 이어 쓰지 않고 다시 허락을 묻는다.
const ADMIN_VER = 3; // 2: 명령·설정 창(cmd·powershell·터미널·regedit 등)에 누르기·입력·키 거절 · 3: 창 사진의 환자 정보 가리기
const TASK = '\\KnockBrowser\\AiDesktop';
const pipeName = (sid) => `knock-ai-uia-${sid}`;

function server(PS_CORE) {
  return `${PS_CORE}
[KnockUia]::AdminMode = $true
$me = [Security.Principal.WindowsIdentity]::GetCurrent()
$sid = $me.User.Value
$name = "knock-ai-uia-$sid"
$utf8 = New-Object System.Text.UTF8Encoding $false
while ($true) {
  $sec = New-Object System.IO.Pipes.PipeSecurity
  $sec.SetSecurityDescriptorSddlForm("D:(A;;GA;;;$sid)(A;;GA;;;SY)")
  try { $srv = New-Object System.IO.Pipes.NamedPipeServerStream($name, [System.IO.Pipes.PipeDirection]::InOut, 1, [System.IO.Pipes.PipeTransmissionMode]::Byte, [System.IO.Pipes.PipeOptions]::None, 65536, 65536, $sec) }
  catch { exit 2 } # 이미 다른 도우미가 떠 있다
  try {
    $srv.WaitForConnection()
    $w = New-Object System.IO.StreamWriter($srv, $utf8); $w.AutoFlush = $true
    $w.WriteLine("knock-ai-admin ${ADMIN_VER}")
    $r = New-Object System.IO.StreamReader($srv, $utf8)
    while ($null -ne ($line = $r.ReadLine())) { $w.WriteLine((Handle $line)) }
  } catch { } finally { try { $srv.Dispose() } catch { } }
}
`;
}

// 관리자 허락을 받은 뒤 한 번 도는 설치. -Sid: 그 PC 사용자, -Src: 도우미 글이 적힌 임시 파일, -Out: 결과 적을 곳
const SETUP = String.raw`param([string]$Sid, [string]$Src, [string]$Out)
$ErrorActionPreference = 'Stop'
function Done($t) { try { Set-Content -LiteralPath $Out -Value $t -Encoding UTF8 } catch { } }
try {
  $dir = Join-Path $env:ProgramData 'KnockBrowserAI'
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $acl = New-Object System.Security.AccessControl.DirectorySecurity
  $acl.SetSecurityDescriptorSddlForm('O:BAG:BAD:PAI(A;OICI;FA;;;BA)(A;OICI;FA;;;SY)(A;OICI;0x1200a9;;;BU)')
  Set-Acl -LiteralPath $dir -AclObject $acl
  $dst = Join-Path $dir 'uia.ps1'
  Copy-Item -LiteralPath $Src -Destination $dst -Force
  $facl = New-Object System.Security.AccessControl.FileSecurity
  $facl.SetSecurityDescriptorSddlForm('O:BAG:BAD:PAI(A;;FA;;;BA)(A;;FA;;;SY)(A;;0x1200a9;;;BU)')
  Set-Acl -LiteralPath $dst -AclObject $facl
  $user = (New-Object System.Security.Principal.SecurityIdentifier($Sid)).Translate([System.Security.Principal.NTAccount]).Value
  $svc = New-Object -ComObject Schedule.Service; $svc.Connect()
  $root = $svc.GetFolder('\')
  try { $folder = $root.GetFolder('KnockBrowser') } catch { $folder = $root.CreateFolder('KnockBrowser') }
  $def = $svc.NewTask(0)
  $def.RegistrationInfo.Description = 'Knock Browser AI: 관리자 권한으로 켜진 프로그램(덴트웹 등)도 AI 가 읽고 누를 수 있게 합니다.'
  $def.Principal.UserId = $user
  $def.Principal.LogonType = 3   # 로그인한 그 사용자 화면에서
  $def.Principal.RunLevel = 1    # 관리자 권한
  $def.Settings.Enabled = $true
  $def.Settings.Hidden = $true
  $def.Settings.ExecutionTimeLimit = 'PT0S'
  $def.Settings.DisallowStartIfOnBatteries = $false
  $def.Settings.StopIfGoingOnBatteries = $false
  $def.Settings.MultipleInstances = 2
  $def.Settings.Priority = 4
  $t = $def.Triggers.Create(9); $t.UserId = $user
  $a = $def.Actions.Create(0)
  $a.Path = Join-Path $env:SystemRoot 'System32\conhost.exe'
  $a.Arguments = '--headless "' + (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') + '" -NoProfile -ExecutionPolicy Bypass -File "' + $dst + '"'
  $task = $folder.RegisterTaskDefinition('AiDesktop', $def, 6, $null, $null, 3, "D:(A;;FA;;;BA)(A;;FA;;;SY)(A;;GRGX;;;$Sid)")
  try { $task.Stop(0) } catch { }
  [void]$task.Run($null)
  Done ('ok ' + $user)
} catch { Done ('fail ' + (($_.Exception.Message) -replace '\s+', ' ')) }
`;

module.exports = { ADMIN_VER, TASK, pipeName, server, SETUP };
