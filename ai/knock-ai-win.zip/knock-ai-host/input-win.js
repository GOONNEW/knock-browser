// 윈도우 원격 조작 프로그램(PowerShell). AI 부분 업데이트는 도우미의 .js 만 바꾸므로 글로 담아 두고 쓸 때 파일로 적는다.
module.exports = String.raw`# Knock 원격(윈도우): 원격으로 받은 마우스·키보드 동작을 이 PC 에 일으킨다 — 맥의 knock-input.swift 와 같은 약속.
# 표준 입력으로 한 줄에 하나씩 JSON 을 받는다(host/remote-input.js 가 이 글을 임시 폴더에 .ps1 로 적어 powershell 로 띄운다).
#   check → {"ok":true}(윈도우는 따로 허락이 없다) · display w,h → 화면 크기가 맞는 모니터(전체 화면이면 모든 모니터)
#   move/down/up x,y(0~1) · wheel dx,dy · key code(KeyboardEvent.code) down · text · focus title(그 창을 맨 앞으로) · clickPx x,y(실제 점 좌표 한 번 누르기) · wait ms
# 맥에서 조작할 때 ⌘(Meta)는 윈도우의 Ctrl 로 바꾼다(⌘C → Ctrl+C).
$ErrorActionPreference = 'SilentlyContinue'
# 기록 글(한글)이 깨지지 않게 내보내는 글은 UTF-8(BOM 없이 — 첫 줄 답이 깨지면 안 된다)
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class KnockInput {
  [StructLayout(LayoutKind.Sequential)] struct MOUSEINPUT { public int dx, dy; public int mouseData; public uint dwFlags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Sequential)] struct KEYBDINPUT { public ushort wVk, wScan; public uint dwFlags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Explicit)] struct UNION { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
  [StructLayout(LayoutKind.Sequential)] struct INPUT { public uint type; public UNION u; }
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int left, top, right, bottom; }
  delegate bool MonitorEnumProc(IntPtr h, IntPtr dc, ref RECT r, IntPtr data);
  [DllImport("user32.dll", SetLastError = true)] static extern uint SendInput(uint n, INPUT[] inputs, int size);
  [DllImport("user32.dll")] static extern int GetSystemMetrics(int i);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] static extern bool EnumDisplayMonitors(IntPtr dc, IntPtr clip, MonitorEnumProc proc, IntPtr data);
  [DllImport("user32.dll")] static extern uint MapVirtualKey(uint code, uint mapType);
  delegate bool WndEnumProc(IntPtr h, IntPtr data);
  [DllImport("user32.dll")] static extern bool EnumWindows(WndEnumProc proc, IntPtr data);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, System.Text.StringBuilder s, int n);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
  [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool attach);
  [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr c);
  [DllImport("user32.dll")] static extern IntPtr GetThreadDpiAwarenessContext();
  [DllImport("user32.dll")] static extern int GetAwarenessFromDpiAwarenessContext(IntPtr c);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, System.Text.StringBuilder s, int n);
  [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr h, out RECT r);
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int x, y; }
  [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr h, ref POINT p);
  // 브라우저 연동(보안 사이트): 페이지 안 자리(0~1)를 이 PC 화면의 실제 점으로 — 창 자리·크기는 윈도우에게 직접 묻는다.
  // 예전에는 페이지가 알려 준 창 자리(screenX 등)에 배율을 곱했는데, 노트북(화면 배율이 큰 PC)에서 2배쯤 엉뚱한 곳을 눌렀다(2026-11-08 이든치과).
  // 창: Knock Browser 창(Chrome_WidgetWin_1, Knock 폴더의 프로그램) 중 제목이 탭 제목인 것 — 없으면 맨 앞 Knock Browser 창.
  // 페이지 칸: 창 안쪽(클라이언트) 아래쪽에 붙어 있고(위는 탭·주소창), 가로는 가운데(옆 창이 열려 있으면 왼쪽).
  static System.Collections.Generic.Dictionary<uint, bool> knockPid = new System.Collections.Generic.Dictionary<uint, bool>();
  static bool IsKnock(IntPtr h) {
    var c = new System.Text.StringBuilder(64); GetClassName(h, c, 64);
    if (c.ToString() != "Chrome_WidgetWin_1") return false;
    uint pid; GetWindowThreadProcessId2(h, out pid);
    bool k;
    if (!knockPid.TryGetValue(pid, out k)) {
      try { k = System.Diagnostics.Process.GetProcessById((int)pid).MainModule.FileName.IndexOf("\\Knock\\", StringComparison.OrdinalIgnoreCase) >= 0; } catch { k = false; }
      knockPid[pid] = k;
    }
    return k;
  }
  [DllImport("user32.dll", EntryPoint = "GetWindowThreadProcessId")] static extern uint GetWindowThreadProcessId2(IntPtr h, out uint pid);
  static IntPtr lastWin = IntPtr.Zero; static string lastTitle = null; static DateTime lastAt;
  static IntPtr FindKnock(string title, out string how) {
    how = "";
    if (lastWin != IntPtr.Zero && lastTitle == title && (DateTime.Now - lastAt).TotalMilliseconds < 1500 && IsWindowVisible(lastWin)) { how = "제목"; return lastWin; }
    IntPtr best = IntPtr.Zero; int score = 9;
    if (!string.IsNullOrEmpty(title)) {
      EnumWindows((h, d) => {
        if (!IsWindowVisible(h) || IsIconic(h)) return true;
        var sb = new System.Text.StringBuilder(512); GetWindowText(h, sb, 512); var t = sb.ToString();
        int s = t == title + " - Knock" ? 0 : t.StartsWith(title) ? 1 : t.Contains(title) ? 2 : 9;
        if (s < score && IsKnock(h)) { score = s; best = h; }
        return score > 0;
      }, IntPtr.Zero);
    }
    if (best != IntPtr.Zero) { how = "제목"; lastWin = best; lastTitle = title; lastAt = DateTime.Now; return best; }
    IntPtr fg = GetForegroundWindow();
    if (fg != IntPtr.Zero && IsKnock(fg)) { how = "맨 앞 창"; return fg; }
    return IntPtr.Zero;
  }
  public static string Info = "";
  public static bool PagePoint(string title, double iw, double ih, double dpr, double nx, double ny, out int x, out int y) {
    x = 0; y = 0; string how;
    IntPtr h = FindKnock(title, out how);
    if (h == IntPtr.Zero) { Info = "Knock Browser 창을 못 찾음"; return false; }
    RECT c; GetClientRect(h, out c); POINT p = new POINT(); ClientToScreen(h, ref p);
    double cw = c.right, ch = c.bottom, vw = iw * dpr, vh = ih * dpr;
    if (vw < 10 || vh < 10 || vw > cw + 3 || vh > ch + 3) { Info = "창(" + how + ") " + cw + "x" + ch + " 페이지 " + Math.Round(vw) + "x" + Math.Round(vh) + " 안 맞음"; return false; }
    double side = (cw - vw) / 2, left, b;
    if (side <= 12 * dpr) { left = p.x + side; b = side; } else { left = p.x; b = 0; } // 옆 창(Knock AI 등)이 오른쪽에 열려 있음
    double top = p.y + ch - b - vh;
    x = (int)Math.Round(left + Math.Min(Math.Max(nx, 0), 1) * (vw - 1));
    y = (int)Math.Round(top + Math.Min(Math.Max(ny, 0), 1) * (vh - 1));
    Info = "창(" + how + ") " + p.x + "," + p.y + " " + cw + "x" + ch + " 페이지 " + Math.Round(vw) + "x" + Math.Round(vh) + " 배율 인식 " + GetAwarenessFromDpiAwarenessContext(GetThreadDpiAwarenessContext());
    return true;
  }
  // 브라우저 연동: 키를 보내기 전에 그 탭의 창(제목에 탭 제목이 들어간 창)을 맨 앞으로 — 윈도우 키 입력은 맨 앞 창으로만 간다(2026-11-08)
  // [앞 창 내리기](2026-11-13 — 가상 PC 창(경리스퀘어)이 앞에 있으면 원격 마우스를 받지 않았다):
  // 맨 앞 창을 최소화하고 Knock Browser 창을 앞으로. 결과는 "전 제목|지금 제목|최소화됐는지"
  public static string LowerFront() {
    IntPtr fg = GetForegroundWindow();
    string before = Title(fg);
    bool lowered = false;
    if (fg != IntPtr.Zero && !before.EndsWith("- Knock") && !before.Contains("Knock AI")) { ShowWindow(fg, 6); System.Threading.Thread.Sleep(250); lowered = IsIconic(fg) || GetForegroundWindow() != fg; }
    IntPtr k = IntPtr.Zero;
    EnumWindows((h, d) => { if (!IsWindowVisible(h)) return true; var t = Title(h); if (t.EndsWith("- Knock")) { k = h; return false; } return true; }, IntPtr.Zero);
    if (k != IntPtr.Zero) {
      if (IsIconic(k)) ShowWindow(k, 9);
      IntPtr cur = GetForegroundWindow();
      uint me = GetCurrentThreadId(), other = GetWindowThreadProcessId(cur, IntPtr.Zero);
      AttachThreadInput(me, other, true); BringWindowToTop(k); SetForegroundWindow(k); AttachThreadInput(me, other, false);
    }
    System.Threading.Thread.Sleep(200);
    return before + "|" + ForegroundTitle() + "|" + (lowered ? "1" : "0");
  }
  static string Title(IntPtr h) { var sb = new System.Text.StringBuilder(512); GetWindowText(h, sb, 512); return sb.ToString(); }
  public static string ForegroundTitle() { var sb = new System.Text.StringBuilder(512); GetWindowText(GetForegroundWindow(), sb, 512); return sb.ToString(); }
  // 맨 앞 창의 주인(2026-11-13): 제목만으로는 어느 프로그램인지 몰라 원인을 잘못 짚었다 — 프로그램 경로·창 종류·관리자 권한·크기를 함께
  [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr p, int flags, System.Text.StringBuilder s, ref int n);
  [DllImport("advapi32.dll", SetLastError = true)] static extern bool OpenProcessToken(IntPtr p, uint access, out IntPtr t);
  [DllImport("advapi32.dll", SetLastError = true)] static extern bool GetTokenInformation(IntPtr t, int cls, out int info, int len, out int ret);
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
  // 이 조작 프로그램이 어디서 도는가(2026-11-13 업데이트 뒤 마우스 먹통): 세션·책상(desktop)·지금 입력을 받는 책상·권한 수준
  [DllImport("kernel32.dll")] static extern uint WTSGetActiveConsoleSessionId();
  [DllImport("user32.dll", SetLastError = true)] static extern IntPtr OpenInputDesktop(uint flags, bool inherit, uint access);
  [DllImport("user32.dll")] static extern IntPtr GetThreadDesktop(uint threadId);
  [DllImport("user32.dll")] static extern bool CloseDesktop(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool GetUserObjectInformation(IntPtr h, int index, System.Text.StringBuilder info, int len, out int needed);
  [DllImport("advapi32.dll", SetLastError = true)] static extern bool GetTokenInformation(IntPtr t, int cls, IntPtr info, int len, out int ret);
  [DllImport("advapi32.dll")] static extern IntPtr GetSidSubAuthority(IntPtr sid, uint n);
  [DllImport("advapi32.dll")] static extern IntPtr GetSidSubAuthorityCount(IntPtr sid);
  static string DeskName(IntPtr h) { var sb = new System.Text.StringBuilder(256); int n; return h != IntPtr.Zero && GetUserObjectInformation(h, 2, sb, 512, out n) ? sb.ToString() : "?"; }
  static string Integrity() {
    IntPtr t;
    if (!OpenProcessToken(System.Diagnostics.Process.GetCurrentProcess().Handle, 0x0008, out t)) return "?";
    try {
      int len; GetTokenInformation(t, 25, IntPtr.Zero, 0, out len);
      IntPtr buf = Marshal.AllocHGlobal(len);
      try {
        if (!GetTokenInformation(t, 25, buf, len, out len)) return "?";
        IntPtr sid = Marshal.ReadIntPtr(buf);
        int rid = Marshal.ReadInt32(GetSidSubAuthority(sid, (uint)(Marshal.ReadByte(GetSidSubAuthorityCount(sid)) - 1)));
        return rid >= 0x4000 ? "시스템" : rid >= 0x3000 ? "높음(관리자)" : rid >= 0x2000 ? "보통" : "낮음";
      } finally { Marshal.FreeHGlobal(buf); }
    } finally { CloseHandle(t); }
  }
  public static string Place() {
    uint mine = (uint)System.Diagnostics.Process.GetCurrentProcess().SessionId;
    IntPtr inp = OpenInputDesktop(0, false, 0x0001);
    string input = inp == IntPtr.Zero ? "못 엶(" + Marshal.GetLastWin32Error() + ")" : DeskName(inp);
    if (inp != IntPtr.Zero) CloseDesktop(inp);
    return "세션 " + mine + "(화면 세션 " + WTSGetActiveConsoleSessionId() + ") · 책상 " + DeskName(GetThreadDesktop(GetCurrentThreadId())) + " · 입력 책상 " + input + " · 권한 " + Integrity();
  }
  public static string ForegroundWho() {
    IntPtr h = GetForegroundWindow();
    if (h == IntPtr.Zero) return "맨 앞 창 없음";
    uint pid; GetWindowThreadProcessId2(h, out pid);
    var c = new System.Text.StringBuilder(128); GetClassName(h, c, 128);
    string path = "?", elev = "?";
    IntPtr p = OpenProcess(0x1000, false, pid);
    if (p == IntPtr.Zero) { path = "못 엶(" + Marshal.GetLastWin32Error() + ")"; elev = "못 엶"; }
    else {
      var sb = new System.Text.StringBuilder(1024); int n = 1024;
      if (QueryFullProcessImageName(p, 0, sb, ref n)) path = sb.ToString();
      IntPtr t;
      if (OpenProcessToken(p, 0x0008, out t)) { int e, r; elev = GetTokenInformation(t, 20, out e, 4, out r) ? (e != 0 ? "예" : "아니오") : "?"; CloseHandle(t); }
      else elev = "못 엶(" + Marshal.GetLastWin32Error() + ")";
      CloseHandle(p);
    }
    RECT w; GetWindowRect(h, out w);
    bool top = (GetWindowLong(h, -20) & 0x8) != 0;
    return "창 주인 pid " + pid + " · " + path + " · 창 종류 " + c + " · 관리자 권한 " + elev + " · 자리 " + w.left + "," + w.top + " " + (w.right - w.left) + "x" + (w.bottom - w.top) + (top ? " · 늘 위" : "") + (IsWindowVisible(h) ? "" : " · 안 보임");
  }
  public static bool Focus(string title) {
    if (string.IsNullOrEmpty(title)) return false;
    IntPtr found = IntPtr.Zero;
    EnumWindows((h, d) => {
      if (!IsWindowVisible(h)) return true;
      var sb = new System.Text.StringBuilder(512); GetWindowText(h, sb, 512);
      var t = sb.ToString();
      if (t.Contains("Knock") && t.Contains(title)) { found = h; return false; }
      return true;
    }, IntPtr.Zero);
    if (found == IntPtr.Zero) return false;
    if (IsIconic(found)) ShowWindow(found, 9);
    IntPtr fg = GetForegroundWindow();
    if (fg == found) return true;
    uint me = GetCurrentThreadId(), other = GetWindowThreadProcessId(fg, IntPtr.Zero);
    AttachThreadInput(me, other, true);
    BringWindowToTop(found); SetForegroundWindow(found);
    AttachThreadInput(me, other, false);
    return GetForegroundWindow() == found;
  }
  static int bx, by, bw, bh; // 보내는 화면(가상 화면 좌표)
  static int lx, ly;
  public static void Init() { try { if (!SetProcessDpiAwarenessContext(new IntPtr(-4))) SetProcessDPIAware(); } catch { SetProcessDPIAware(); } bx = Vx(); by = Vy(); bw = Vw(); bh = Vh(); }
  static int Vx() { return GetSystemMetrics(76); } static int Vy() { return GetSystemMetrics(77); }
  static int Vw() { return GetSystemMetrics(78); } static int Vh() { return GetSystemMetrics(79); }
  // n: 보내는 화면 번호(크롬 이름 "Screen 2" 의 2, 모르면 0) — 크기가 같은 모니터가 여럿이면 그 번호를 고른다(2026-11-13)
  public static int Display(double w, double h, int n) {
    int best = -1; double bestDiff = Math.Abs(Vw() - w) + Math.Abs(Vh() - h);
    bx = Vx(); by = Vy(); bw = Vw(); bh = Vh();
    var list = new System.Collections.Generic.List<RECT>();
    EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, (IntPtr m, IntPtr dc, ref RECT r, IntPtr d) => { list.Add(r); return true; }, IntPtr.Zero);
    for (int i = 0; i < list.Count; i++) {
      var r = list[i]; double diff = Math.Abs(r.right - r.left - w) + Math.Abs(r.bottom - r.top - h);
      if (diff < bestDiff || (diff == bestDiff && best >= 0 && i == n - 1)) { bestDiff = diff; best = i; }
    }
    if (best >= 0) { var r = list[best]; bx = r.left; by = r.top; bw = r.right - r.left; bh = r.bottom - r.top; }
    return best + 1;
  }
  static INPUT Mouse(uint flags, int data) {
    var i = new INPUT(); i.type = 0;
    int vx = Vx(), vy = Vy(), vw = Math.Max(Vw(), 1), vh = Math.Max(Vh(), 1);
    i.u.mi.dx = (int)((lx - vx) * 65535.0 / Math.Max(vw - 1, 1));
    i.u.mi.dy = (int)((ly - vy) * 65535.0 / Math.Max(vh - 1, 1));
    i.u.mi.mouseData = data; i.u.mi.dwFlags = flags | 0x8000 | 0x4000 | 0x0001; // ABSOLUTE | VIRTUALDESK | MOVE
    return i;
  }
  // 윈도우가 입력을 받지 않으면(관리자 권한 창이 앞에 있음·보안 프로그램이 막음 등) 그 까닭 번호를 남긴다 — 보는 쪽에 알린다(2026-11-07 이든치과 노트북)
  static int blocked;
  public static int TakeBlocked() { int b = blocked; blocked = 0; return b; }
  static void Send(params INPUT[] a) {
    if (SendInput((uint)a.Length, a, Marshal.SizeOf(typeof(INPUT))) == 0) { int e = Marshal.GetLastWin32Error(); blocked = e == 0 ? -1 : e; }
  }
  public static void Move(double x, double y) {
    lx = bx + (int)(Math.Min(Math.Max(x, 0), 1) * (bw - 1));
    ly = by + (int)(Math.Min(Math.Max(y, 0), 1) * (bh - 1));
    Send(Mouse(0, 0));
  }
  // 마우스가 정말 옮겨졌는지(2026-11-13 원격 PC 에서 신호는 오는데 마우스가 그대로) — 보낸 자리와 지금 자리, 화면 크기를 글로
  // 보낸 자리로 정말 갔는지(조용히 막히면 SendInput 은 성공이라고 답한다 — 보안 프로그램·관리자 창)
  public static bool Landed() { POINT p; GetCursorPos(out p); return Math.Abs(p.x - lx) <= 3 && Math.Abs(p.y - ly) <= 3; }
  public static string Where() {
    POINT p; GetCursorPos(out p);
    int n = 0; EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, (IntPtr m, IntPtr dc, ref RECT r, IntPtr d) => { n++; return true; }, IntPtr.Zero);
    return "보낸 자리 " + lx + "," + ly + " · 지금 자리 " + p.x + "," + p.y + " · 고른 화면 " + bx + "," + by + " " + bw + "x" + bh
      + " · 전체 " + Vx() + "," + Vy() + " " + Vw() + "x" + Vh() + " · 모니터 " + n + "개 · 막힘 " + blocked;
  }
  // 화면의 한 점(실제 점 좌표)을 한 번 누른다 — 브라우저 연동에서 은행 비밀번호 칸을 진짜 마우스로 눌러 둘 때(2026-11-08)
  public static void MovePx(int x, int y) { lx = x; ly = y; Send(Mouse(0, 0)); }
  // 사람처럼: 옮기고 잠깐 뒤 누르고, 누른 채 잠깐 있다 뗀다(예전엔 셋을 한꺼번에 — 2026-11-08 PC 원격제어와 같게)
  public static void ClickPx(int x, int y) { lx = x; ly = y; Send(Mouse(0, 0)); System.Threading.Thread.Sleep(40); Send(Mouse(0x0002, 0)); System.Threading.Thread.Sleep(90); Send(Mouse(0x0004, 0)); }
  public static void Button(bool down, bool right) {
    uint f = right ? (down ? 0x0008u : 0x0010u) : (down ? 0x0002u : 0x0004u);
    Send(Mouse(f, 0));
  }
  public static void Wheel(double dx, double dy) {
    if (dy != 0) Send(Mouse(0x0800, (int)(-dy * 1.2)));
    if (dx != 0) Send(Mouse(0x1000, (int)(dx * 1.2)));
  }
  public static void Key(int vk, bool down) {
    var i = new INPUT(); i.type = 1; i.u.ki.wVk = (ushort)vk; i.u.ki.wScan = (ushort)MapVirtualKey((uint)vk, 0);
    if (vk == 0x15) i.u.ki.wScan = 0xF2; else if (vk == 0x19) i.u.ki.wScan = 0xF1; // 한/영·한자 키 고유 값(자판에 따라 0 이 나온다)
    uint ext = (vk >= 0x21 && vk <= 0x2E) || vk == 0xA3 || vk == 0xA5 || vk == 0x6F ? 1u : 0u; // 방향키·Home 등·오른쪽 Ctrl/Alt
    i.u.ki.dwFlags = (down ? 0u : 2u) | ext;
    Send(i);
  }
  public static void Text(string s) {
    foreach (char c in s) {
      var d = new INPUT(); d.type = 1; d.u.ki.wScan = c; d.u.ki.dwFlags = 0x0004;
      var u = new INPUT(); u.type = 1; u.u.ki.wScan = c; u.u.ki.dwFlags = 0x0004 | 0x0002;
      Send(d, u);
    }
  }
}
'@
# 위의 Add-Type 이 실패하면(보안 프로그램이 C# 컴파일러를 막음·제한 언어 모드 등) 예전엔 조용히 아무것도 안 했다(2026-11-13).
# 이제는 까닭을 알리고 끝낸다 — 도우미가 host.log 에 남기고 보는 쪽 화면에 알린다
$out0 = [Console]::Out
if (-not ('KnockInput' -as [type])) {
  $why = ([string]$Error[0]) -replace '\s+', ' '
  $out0.WriteLine((@{ fatal = ('조작 부품을 만들지 못함 · 언어 모드 ' + $ExecutionContext.SessionState.LanguageMode + ' · ' + $why) } | ConvertTo-Json -Compress)); $out0.Flush()
  exit 3
}
[KnockInput]::Init()
# 시작 정보: 언어 모드·관리자 여부·입력을 막을 수 있는 보안 프로그램(은행·결제 보안 등)
$sec = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match '^(ASDSvc|astx|AhnLab|nos|npk|nProtect|TouchEn|KDefense|IPinside|Veraport|Delfino|MagicLine|AnySign|CrossEX|keysharp|nppfs|SKCert|V3|ARS)' } | ForEach-Object { $_.ProcessName } | Sort-Object -Unique) -join ','
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$out0.WriteLine((@{ note = ('조작 프로그램 시작 · 언어 모드 ' + $ExecutionContext.SessionState.LanguageMode + ' · 관리자 ' + $admin + ' · ' + [KnockInput]::Place() + ' · 보안 프로그램 ' + $(if ($sec) { $sec } else { '없음' })) } | ConvertTo-Json -Compress)); $out0.Flush()
# 맥의 오른쪽 옵션은 그 PC 의 한/영 키(VK_HANGUL)로 보낸다 — 오른쪽 Alt 로 보내면 Microsoft 입력기가 한/영을 바꾸지 않는다(2026-11-12)
$vk = @{ Backspace=8; Tab=9; Enter=13; NumpadEnter=13; ShiftLeft=0xA0; ShiftRight=0xA1; ControlLeft=0xA2; ControlRight=0xA3; AltLeft=0xA4; AltRight=0x15
  MetaLeft=0xA2; MetaRight=0xA3; Pause=0x13; CapsLock=0x14; Escape=0x1B; Space=0x20; PageUp=0x21; PageDown=0x22; End=0x23; Home=0x24
  ArrowLeft=0x25; ArrowUp=0x26; ArrowRight=0x27; ArrowDown=0x28; PrintScreen=0x2C; Insert=0x2D; Delete=0x2E
  Semicolon=0xBA; Equal=0xBB; Comma=0xBC; Minus=0xBD; Period=0xBE; Slash=0xBF; Backquote=0xC0; BracketLeft=0xDB; Backslash=0xDC; BracketRight=0xDD; Quote=0xDE
  NumpadMultiply=0x6A; NumpadAdd=0x6B; NumpadSubtract=0x6D; NumpadDecimal=0x6E; NumpadDivide=0x6F; NumLock=0x90; Lang1=0x15; Lang2=0x19; ContextMenu=0x5D }
for ($i = 0; $i -lt 26; $i++) { $vk["Key$([char](65 + $i))"] = 65 + $i }
for ($i = 0; $i -lt 10; $i++) { $vk["Digit$i"] = 48 + $i; $vk["Numpad$i"] = 0x60 + $i }
for ($i = 1; $i -le 12; $i++) { $vk["F$i"] = 0x6F + $i }
$held = @{} # 이쪽에서 눌러 둔 키(VK) — 연결이 끊기거나 저쪽이 다 뗐다고 하면 뗀다
$modVk = @{ shift = @(0xA0, 0xA1); ctrl = @(0xA2, 0xA3); alt = @(0xA4, 0xA5) }
function ReleaseAll { foreach ($k in @($held.Keys)) { [KnockInput]::Key([int]$k, $false) }; $held.Clear() }
# 마우스를 누를 때 저쪽 Shift·Ctrl·Alt 상태와 맞춘다(저쪽이 안 누른 것이 이쪽에 눌려 있으면 뗀다 — ⌘ 는 Ctrl)
function SyncMods($mods) {
  if ($null -eq $mods) { return }
  $want = @{ shift = ($mods -contains 'shift'); ctrl = (($mods -contains 'ctrl') -or ($mods -contains 'cmd')); alt = ($mods -contains 'alt') }
  foreach ($m in $modVk.Keys) { if (-not $want[$m]) { foreach ($k in $modVk[$m]) { if ($held.ContainsKey($k)) { [KnockInput]::Key($k, $false); $held.Remove($k) } } } }
}
$out = [Console]::Out
# 브라우저 연동 비밀번호 칸 시험 기록(입력한 글자는 남기지 않는다) — 도우미가 host.log 에 적는다
function Diag($text) { $out.WriteLine((@{ diag = [string]$text } | ConvertTo-Json -Compress)); $out.Flush() }
# 원격 조작 확인 기록(도우미가 host.log 에 '원격 조작 확인'으로 적는다)
function Note($text) { $out.WriteLine((@{ note = [string]$text } | ConvertTo-Json -Compress)); $out.Flush() }
$moves = 0
$told = 0
$miss = 0
$warned = $false
while ($null -ne ($line = [Console]::In.ReadLine())) {
  $b = [KnockInput]::TakeBlocked()
  if ($b -ne 0 -and $told -lt 3) { $told++; $out.WriteLine('{"blocked":' + $b + '}'); $out.Flush() }
  try { $m = $line | ConvertFrom-Json } catch { continue }
  switch ($m.t) {
    'check' { $out.WriteLine('{"ok":true}'); $out.Flush() }
    'display' { $id = 0; try { $id = [int][KnockInput]::Display([double]$m.w, [double]$m.h, [int]$m.n) } catch { }; if ($null -eq $id) { $id = 0 }; $out.WriteLine('{"ok":true,"id":' + $id + '}'); $out.Flush(); Note ("화면 고름 " + $m.w + "x" + $m.h + " 번호 " + $m.n + " → " + $id + " · " + [KnockInput]::Where()) }
    'move' {
      [KnockInput]::Move([double]$m.x, [double]$m.y); $moves++
      # 한 번 어긋난 것으로 알리면 잘 되는데도 경고가 남았다(2026-11-13 원장님) — 두 번 잇따라 안 옮겨질 때만 알리고, 다시 옮겨지면 거둔다
      if ($moves -eq 3 -or $moves -eq 60 -or ($moves % 400) -eq 0 -or (($miss -gt 0 -or $warned) -and ($moves % 40) -eq 0)) {
        Start-Sleep -Milliseconds 30
        $landed = [KnockInput]::Landed()
        Note ("마우스 확인(" + $moves + "번째) " + $(if ($landed) { '옮겨짐' } else { '안 옮겨짐' }) + " · " + [KnockInput]::Where() + " · 맨 앞 창: " + [KnockInput]::ForegroundTitle())
        if ($landed) {
          $miss = 0
          if ($warned) { $warned = $false; $out.WriteLine('{"unblocked":true}'); $out.Flush() }
        } else {
          $miss++
          if ($miss -eq 1) { Note ("안 옮겨질 때 맨 앞 창 · " + [KnockInput]::ForegroundWho() + " · " + [KnockInput]::Place()) }
          if ($miss -ge 2 -and -not $warned -and $told -lt 3) { $told++; $warned = $true; $out.WriteLine((@{ blocked = -3; fg = [KnockInput]::ForegroundTitle() } | ConvertTo-Json -Compress)); $out.Flush() }
        }
      }
    }
    { $_ -eq 'down' -or $_ -eq 'up' } { SyncMods $m.mods; if ($null -ne $m.x) { [KnockInput]::Move([double]$m.x, [double]$m.y) }; [KnockInput]::Button($m.t -eq 'down', $m.button -eq 2) }
    'release' { ReleaseAll }
    'wheel' { [KnockInput]::Wheel([double]$m.dx, [double]$m.dy) }
    'key' { $k = $vk[[string]$m.code]; if ($k) { [KnockInput]::Key([int]$k, [bool]$m.down); if ($m.down) { $held[[int]$k] = 1 } else { $held.Remove([int]$k) } } }
    'text' { if ($m.text) { [KnockInput]::Text([string]$m.text) } }
    'focus' { $ok = [KnockInput]::Focus([string]$m.title); Diag ("focus " + $ok + " · 맨 앞 창: " + [KnockInput]::ForegroundTitle()) }
    'clickPage' { $x = 0; $y = 0; if ([KnockInput]::PagePoint([string]$m.title, [double]$m.iw, [double]$m.ih, [double]$m.dpr, [double]$m.nx, [double]$m.ny, [ref]$x, [ref]$y)) { [KnockInput]::ClickPx($x, $y); Diag ("진짜 마우스 " + $x + "," + $y + " · 페이지 자리 " + [Math]::Round([double]$m.nx, 3) + "," + [Math]::Round([double]$m.ny, 3) + " · " + [KnockInput]::Info) } else { [KnockInput]::ClickPx([int]$m.x, [int]$m.y); Diag ("진짜 마우스(옛 계산) " + $m.x + "," + $m.y + " · " + [KnockInput]::Info) } }
    'movePage' { $x = 0; $y = 0; if ([KnockInput]::PagePoint([string]$m.title, [double]$m.iw, [double]$m.ih, [double]$m.dpr, [double]$m.nx, [double]$m.ny, [ref]$x, [ref]$y)) { [KnockInput]::MovePx($x, $y) } else { [KnockInput]::MovePx([int]$m.x, [int]$m.y) } }
    'movePx' { [KnockInput]::MovePx([int]$m.x, [int]$m.y) }
    'clickPx' { [KnockInput]::ClickPx([int]$m.x, [int]$m.y); Diag ("진짜 마우스 " + $m.x + "," + $m.y + " · 맨 앞 창: " + [KnockInput]::ForegroundTitle()) }
    'diag' { Diag ([string]$m.text + " · 맨 앞 창: " + [KnockInput]::ForegroundTitle()) }
    'lowerFront' { $r = [KnockInput]::LowerFront().Split('|'); $out.WriteLine((@{ front = @{ before = $r[0]; after = $r[1]; lowered = ($r[2] -eq '1') } } | ConvertTo-Json -Compress)); $out.Flush(); Note ("앞 창 내리기 · 전: " + $r[0] + " · 지금: " + $r[1]) }
    'wait' { Start-Sleep -Milliseconds ([Math]::Min([int]$m.ms, 200)) }
  }
}
ReleaseAll
`;
