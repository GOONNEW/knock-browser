// 비밀번호 걸린 엑셀(xlsx) 풀기(2026-11-11 원장님 "열려 있지 않을 땐 비밀번호를 사용자로부터 입력받아서 접근하게 해 줘").
// 새 부품 없이 node 기본 암호 기능으로 오피스 표준 암호(ECMA-376)를 푼다:
//   - Agile(엑셀 2010 이후 — SHA-512·AES-256 등) · Standard(엑셀 2007 — SHA-1·AES-ECB).
// 풀린 내용은 메모리(Buffer)로만 돌려준다 — 디스크에 쓰지 않는다. 비밀번호는 기억하지 않는다.
const crypto = require('crypto');
const CFB = require('cfb');

const WRONG = '비밀번호가 맞지 않습니다.';

function isEncrypted(buf) {
  if (!buf || buf.subarray(0, 8).toString('hex') !== 'd0cf11e0a1b11ae1') return false;
  try {
    const names = CFB.read(buf, { type: 'buffer' }).FileIndex.map((f) => f.name);
    return names.includes('EncryptionInfo') && names.includes('EncryptedPackage');
  } catch { return false; }
}

const HASH = { SHA1: 'sha1', 'SHA-1': 'sha1', SHA256: 'sha256', 'SHA-256': 'sha256', SHA384: 'sha384', 'SHA-384': 'sha384', SHA512: 'sha512', 'SHA-512': 'sha512', MD5: 'md5' };
const hash = (alg, ...parts) => { const h = crypto.createHash(alg); for (const p of parts) h.update(p); return h.digest(); };
const u32 = (n) => { const b = Buffer.alloc(4); b.writeUInt32LE(n >>> 0); return b; };
const fit = (b, len, pad) => (b.length >= len ? b.subarray(0, len) : Buffer.concat([b, Buffer.alloc(len - b.length, pad)]));
function aes(mode, keyBytes, iv, data) {
  const name = `aes-${keyBytes.length * 8}-${mode}`;
  const d = crypto.createDecipheriv(name, keyBytes, mode === 'ecb' ? null : iv);
  d.setAutoPadding(false);
  return Buffer.concat([d.update(data), d.final()]);
}
const attr = (tag, name) => { const m = new RegExp(`\\s${name}="([^"]*)"`).exec(tag); return m ? m[1] : null; };

function agile(info, pkg, password) {
  const xml = info.subarray(8).toString('utf8');
  const kd = /<keyData\b[^>]*>/.exec(xml)?.[0];
  const ke = /<(?:\w+:)?encryptedKey\b[^>]*>/.exec(xml)?.[0];
  if (!kd || !ke) throw new Error('암호 정보를 읽지 못했습니다(지원하지 않는 암호 방식).');
  if (!/AES/i.test(attr(kd, 'cipherAlgorithm') || '') || !/AES/i.test(attr(ke, 'cipherAlgorithm') || '')) throw new Error('AES 가 아닌 암호 방식은 아직 풀 수 없습니다.');
  const kdHash = HASH[attr(kd, 'hashAlgorithm')];
  const keHash = HASH[attr(ke, 'hashAlgorithm')];
  if (!kdHash || !keHash) throw new Error('지원하지 않는 암호 방식입니다.');
  const salt = Buffer.from(attr(ke, 'saltValue'), 'base64');
  const spin = Number(attr(ke, 'spinCount'));
  const keyLen = Number(attr(ke, 'keyBits')) / 8;
  const block = Number(attr(ke, 'blockSize')) || 16;
  // 비밀번호 → 열쇠(spinCount 번 되풀이)
  let h = hash(keHash, salt, Buffer.from(String(password), 'utf16le'));
  for (let i = 0; i < spin; i++) h = hash(keHash, u32(i), h);
  const keyFor = (blockKey) => fit(hash(keHash, h, Buffer.from(blockKey, 'hex')), keyLen, 0x36);
  const iv = fit(salt, block, 0x36);
  // 비밀번호 확인: 확인용 값을 풀어 해시가 맞는지
  const vIn = aes('cbc', keyFor('fea7d2763b4b9e79'), iv, Buffer.from(attr(ke, 'encryptedVerifierHashInput'), 'base64'));
  const vHash = aes('cbc', keyFor('d7aa0f6d3061344e'), iv, Buffer.from(attr(ke, 'encryptedVerifierHashValue'), 'base64'));
  const want = hash(keHash, vIn.subarray(0, Number(attr(ke, 'saltSize')) || salt.length));
  if (!want.equals(vHash.subarray(0, want.length))) throw new Error(WRONG);
  const secret = aes('cbc', keyFor('146e0be7abacd0d6'), iv, Buffer.from(attr(ke, 'encryptedKeyValue'), 'base64')).subarray(0, Number(attr(kd, 'keyBits')) / 8);
  // 내용: 4096 바이트 조각마다 IV = hash(keyData 소금 + 조각 번호)
  const kdSalt = Buffer.from(attr(kd, 'saltValue'), 'base64');
  const kdBlock = Number(attr(kd, 'blockSize')) || 16;
  const size = Number(pkg.readBigUInt64LE(0));
  const data = pkg.subarray(8);
  const out = [];
  for (let i = 0, seg = 0; i < data.length; i += 4096, seg++) {
    let chunk = data.subarray(i, Math.min(i + 4096, data.length));
    if (chunk.length % kdBlock) chunk = fit(chunk, chunk.length + (kdBlock - (chunk.length % kdBlock)), 0);
    out.push(aes('cbc', secret, fit(hash(kdHash, kdSalt, u32(seg)), kdBlock, 0x36), chunk));
  }
  return Buffer.concat(out).subarray(0, size);
}

function standard(info, pkg, password) {
  const headerSize = info.readUInt32LE(8);
  const header = info.subarray(12, 12 + headerSize);
  const algId = header.readUInt32LE(8);
  const keyBits = header.readUInt32LE(16) || 128;
  if (![0x660e, 0x660f, 0x6610].includes(algId)) throw new Error('AES 가 아닌 옛 암호 방식(RC4)은 아직 풀 수 없습니다.');
  const v = info.subarray(12 + headerSize);
  const saltSize = v.readUInt32LE(0);
  const salt = v.subarray(4, 4 + saltSize);
  const encVerifier = v.subarray(4 + saltSize, 20 + saltSize);
  const encVerifierHash = v.subarray(24 + saltSize, 24 + saltSize + 32);
  let h = hash('sha1', salt, Buffer.from(String(password), 'utf16le'));
  for (let i = 0; i < 50000; i++) h = hash('sha1', u32(i), h);
  h = hash('sha1', h, u32(0));
  const x = (c) => { const b = Buffer.alloc(64, c); for (let i = 0; i < h.length; i++) b[i] ^= h[i]; return hash('sha1', b); };
  const key = Buffer.concat([x(0x36), x(0x5c)]).subarray(0, keyBits / 8);
  const verifier = aes('ecb', key, null, encVerifier);
  const vh = aes('ecb', key, null, encVerifierHash).subarray(0, 20);
  if (!hash('sha1', verifier).equals(vh)) throw new Error(WRONG);
  const size = Number(pkg.readBigUInt64LE(0));
  let data = pkg.subarray(8);
  if (data.length % 16) data = fit(data, data.length + (16 - (data.length % 16)), 0);
  return aes('ecb', key, null, data).subarray(0, size);
}

/** 암호 엑셀(buf)을 password 로 풀어 xlsx(zip) Buffer 를 돌려준다. 틀리면 "비밀번호가 맞지 않습니다." */
function decrypt(buf, password) {
  const cfb = CFB.read(buf, { type: 'buffer' });
  const info = Buffer.from(CFB.find(cfb, 'EncryptionInfo')?.content || []);
  const pkg = Buffer.from(CFB.find(cfb, 'EncryptedPackage')?.content || []);
  if (!info.length || !pkg.length) throw new Error('암호 파일이 아닙니다.');
  const major = info.readUInt16LE(0);
  const minor = info.readUInt16LE(2);
  const out = major === 4 && minor === 4 ? agile(info, pkg, password)
    : (minor === 2 && (major === 2 || major === 3 || major === 4)) ? standard(info, pkg, password)
      : null;
  if (!out) throw new Error(`지원하지 않는 암호 방식입니다(${major}.${minor}).`);
  if (out.subarray(0, 2).toString() !== 'PK') throw new Error(WRONG);
  return out;
}

module.exports = { isEncrypted, decrypt, WRONG };
