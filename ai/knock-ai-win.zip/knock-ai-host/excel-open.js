// 이미 열린 엑셀에서 읽기(2026-11-11 원장님 "이미 열려 있는데 접근을 못 하네"): 비밀번호 걸린 파일도 엑셀이 열어 두었으면
// 엑셀에게 직접 값을 받는다(화면을 누르지 않음). 윈도우는 COM(PowerShell), 맥은 엑셀이 이미 켜져 있을 때만 AppleScript.
// 돌려주는 모양은 excel_read 의 큰 xlsx 와 같다: sheets · sheet · headerRow · lastRow · columns · last (+ range).
const os = require('os');
const path = require('path');
const fs = require('fs');
const { spawn, spawnSync } = require('child_process');

const IS_WIN = process.platform === 'win32';

const PS = String.raw`$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding $false
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
function Out($o) { [Console]::Out.WriteLine(($o | ConvertTo-Json -Depth 6 -Compress)); [Console]::Out.Flush() }
$m = [Console]::In.ReadLine() | ConvertFrom-Json
try { $xl = [Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application') } catch { Out @{ ok = $false; none = $true }; exit }
$want = [string]$m.file
$base = [IO.Path]::GetFileName($want)
$stem = [IO.Path]::GetFileNameWithoutExtension($want)
$wb = $null
$names = @()
try {
  foreach ($w in $xl.Workbooks) {
    $names += [string]$w.Name
    if ($null -eq $wb -and ($w.FullName -ieq $want -or $w.Name -ieq $base)) { $wb = $w }
  }
  if ($null -eq $wb -and $stem) { foreach ($w in $xl.Workbooks) { if ([IO.Path]::GetFileNameWithoutExtension([string]$w.Name) -ieq $stem) { $wb = $w; break } } }
} catch { Out @{ ok = $false; error = '엑셀이 바빠 답하지 않습니다(셀을 고치는 중이면 Enter 나 Esc 로 마친 뒤 다시 해 주세요).' }; exit }
if ($null -eq $wb) { Out @{ ok = $false; none = $true; open = $names }; exit }
try {
  $sheets = @(); foreach ($s in $wb.Worksheets) { $sheets += [string]$s.Name }
  if ($m.sheet) { $ws = $wb.Worksheets.Item([string]$m.sheet) } else { $ws = $wb.ActiveSheet }
  $ur = $ws.UsedRange
  $r1 = [int]$ur.Row; $c1 = [int]$ur.Column
  $r2 = $r1 + [int]$ur.Rows.Count - 1; $c2 = [Math]::Min($c1 + [int]$ur.Columns.Count - 1, $c1 + 39)
  # 날짜 열: 마지막 줄 칸의 표시 형식으로 알아본다
  $isDate = @{}
  for ($c = $c1; $c -le $c2; $c++) {
    $f = [string]$ws.Cells.Item($r2, $c).NumberFormat
    $plain = ($f -replace '"[^"]*"', '' -replace '\[[^\]]*\]', '')
    $isDate[$c] = ($plain -match '[yYdD]' -or $plain -match '(?<![hH:])m{1,4}(?![:sS])') -and $plain -ne 'General'
  }
  function Grab($ra, $rb, $ca, $cb) {
    $rows = @()
    if ($rb -lt $ra) { return ,$rows }
    $v = $ws.Range($ws.Cells.Item($ra, $ca), $ws.Cells.Item($rb, $cb)).Value2
    for ($i = 1; $i -le ($rb - $ra + 1); $i++) {
      $row = @()
      for ($j = 1; $j -le ($cb - $ca + 1); $j++) {
        if ($v -is [array]) { $x = $v[$i, $j] } else { $x = $v }
        if ($null -eq $x) { $x = '' }
        elseif ($x -is [double] -and $isDate[$ca + $j - 1] -and $x -gt 0 -and $x -lt 2958466) { $d = [DateTime]::FromOADate($x); $x = if ($d.TimeOfDay.TotalSeconds -gt 0) { $d.ToString('yyyy-MM-dd HH:mm:ss') } else { $d.ToString('yyyy-MM-dd') } }
        $row += ,$x
      }
      $rows += ,$row
    }
    return ,$rows
  }
  $n = [Math]::Max(1, [Math]::Min([int]$m.rows, 20))
  $head = Grab $r1 $r1 $c1 $c2
  $last = Grab ([Math]::Max($r1 + 1, $r2 - $n + 1)) $r2 $c1 $c2
  $range = $null
  if ($m.range) {
    $rg = $ws.Range([string]$m.range)
    $ra = [int]$rg.Row; $ca = [int]$rg.Column
    $rb = [Math]::Min($ra + [int]$rg.Rows.Count - 1, $ra + 199); $cb = [Math]::Min($ca + [int]$rg.Columns.Count - 1, $ca + 39)
    $range = @{ ref = [string]$m.range; rows = (Grab $ra $rb $ca $cb); cut = ([int]$rg.Rows.Count -gt 200) }
  }
  Out @{ ok = $true; file = [string]$wb.FullName; name = [string]$wb.Name; sheets = $sheets; sheet = [string]$ws.Name; headerRow = $r1; lastRow = $r2; columns = $head[0]; last = $last; range = $range }
} catch { Out @{ ok = $false; error = ('열린 엑셀에서 읽지 못했습니다: ' + $_.Exception.Message) } }
`;

// 맥 엑셀(AppleScript): 글은 ASCII 30(줄)·31(칸)으로 나눠 돌려받는다
const AS = `on run argv
  set wantName to item 1 of argv
  set sheetName to item 2 of argv
  set n to (item 3 of argv) as integer
  set rng to item 4 of argv
  set RS to (ASCII character 30)
  set US to (ASCII character 31)
  tell application "Microsoft Excel"
    set wb to missing value
    repeat with w in workbooks
      if (name of w) is wantName then set wb to w
    end repeat
    if wb is missing value then return "NONE"
    set sheetList to {}
    repeat with s in worksheets of wb
      set end of sheetList to (name of s)
    end repeat
    if sheetName is "" then
      set ws to active sheet of wb
    else
      set ws to worksheet sheetName of wb
    end if
    set ur to used range of ws
    set r1 to first row index of ur
    set c1 to first column index of ur
    set r2 to r1 + (count of rows of ur) - 1
    set c2 to c1 + (count of columns of ur) - 1
    if c2 > c1 + 39 then set c2 to c1 + 39
    set fromRow to r2 - n + 1
    if fromRow < r1 + 1 then set fromRow to r1 + 1
    set out to "OK" & RS & (full name of wb) & RS & (name of ws) & RS & r1 & RS & r2
    set AppleScript's text item delimiters to US
    set out to out & RS & (sheetList as text)
    set rowsOut to {}
    repeat with r from r1 to r2
      if r is r1 or r ≥ fromRow then
        set vals to string value of (get resize (cell r of column c1 of ws) column size (c2 - c1 + 1))
        set end of rowsOut to (vals as text)
      end if
    end repeat
    if rng is not "" then
      set end of rowsOut to "RANGE"
      set rg to range rng of ws
      repeat with rr in rows of rg
        set end of rowsOut to ((string value of rr) as text)
      end repeat
    end if
    set AppleScript's text item delimiters to RS
    return out & RS & "ROWS" & RS & (rowsOut as text)
  end tell
end run`;

function runPs(req, timeoutMs) {
  return new Promise((resolve) => {
    const file = path.join(os.tmpdir(), 'knock-excel-open.ps1');
    fs.writeFileSync(file, `﻿${PS}`);
    const p = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', file], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    let out = '';
    let err = '';
    p.stdout.on('data', (d) => { out += d; });
    p.stderr.on('data', (d) => { err += d; });
    const timer = setTimeout(() => { p.kill(); resolve({ ok: false, error: '열린 엑셀이 답하지 않습니다.' }); }, timeoutMs);
    p.on('close', () => {
      clearTimeout(timer);
      const line = out.split(/\r?\n/).find((l) => l.trim().startsWith('{'));
      try { resolve(JSON.parse(line)); } catch { resolve({ ok: false, error: `열린 엑셀에서 읽지 못했습니다: ${(err || out).trim().split('\n').pop() || '알 수 없음'}` }); }
    });
    const ascii = (s) => s.replace(/[\u007f-￿]/g, (c) => `\\u${c.charCodeAt(0).toString(16).padStart(4, '0')}`);
    p.stdin.end(`${ascii(JSON.stringify(req))}\n`);
  });
}

function runMac(req) {
  // 엑셀이 꺼져 있으면 켜지 않는다(AppleScript 가 엑셀을 띄우므로 먼저 확인)
  if (spawnSync('pgrep', ['-x', 'Microsoft Excel']).status !== 0) return { ok: false, none: true };
  const r = spawnSync('osascript', ['-e', AS, path.basename(req.file), req.sheet || '', String(req.rows || 5), req.range || ''], { encoding: 'utf8', timeout: 60000 });
  const text = (r.stdout || '').replace(/\n$/, '');
  if (r.status !== 0) return { ok: false, error: `열린 엑셀에서 읽지 못했습니다: ${(r.stderr || '').trim().split('\n').pop() || '알 수 없음'}` };
  if (text === 'NONE') return { ok: false, none: true };
  const parts = text.split('\x1e');
  if (parts[0] !== 'OK') return { ok: false, error: '열린 엑셀의 답을 읽지 못했습니다.' };
  const [, full, sheet, r1, r2, sheetList] = parts;
  const rest = parts.slice(parts.indexOf('ROWS') + 1);
  const at = rest.indexOf('RANGE');
  const rows = (at >= 0 ? rest.slice(0, at) : rest).map((x) => x.split('\x1f'));
  return {
    ok: true, file: full, name: path.basename(full), sheets: sheetList.split('\x1f'), sheet, headerRow: Number(r1), lastRow: Number(r2),
    columns: rows[0] || [], last: rows.slice(1), range: at >= 0 ? { ref: req.range, rows: rest.slice(at + 1).map((x) => x.split('\x1f')) } : null,
  };
}

/** 엑셀이 이 파일을 열어 두었으면 { ok:true, … }, 아니면 { ok:false, none:true }(또는 error) */
async function readOpen({ file, sheet = '', rows = 5, range = '' }) {
  const req = { file: String(file || ''), sheet: String(sheet || ''), rows: Number(rows) || 5, range: String(range || '') };
  try {
    return IS_WIN ? await runPs(req, 60000) : runMac(req);
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

module.exports = { readOpen, PS, AS };
