// AI 서비스(Claude · ChatGPT · Gemini)를 같은 모양으로 다룬다.
// 셋 다 이 맥에 설치된 공식 명령줄 프로그램(Claude Code · Codex · Gemini CLI)을 띄우고,
// Knock 페이지 도구(MCP 서버 mcp.js)만 쓰게 한다. 각자의 파일·명령어 도구는 끈다.
// 로그인은 Knock 전용 보관 폴더를 써서 이 맥의 다른 로그인과 따로다. API 키는 맥 키체인에 둔다.
//
// 공통 모양:
//   status()            → { installed, loggedIn, email, apiKey: { set, tail }, models: [{ id, name }] }
//   loginCommand()      로그인 명령(뒤에서 돌리면 로그인 페이지가 열리고, 사용자가 직접 로그인)
//   logout() · setKey(key) · removeKey()
//   run(opts, on)       → { stop(), inject?(content) }  on: text(delta, fresh) · session(id) · delivered() · done(error, stopped)
const { spawn, spawnSync, execFile } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { IS_WIN, winSecret } = require('./platform');

const HOME = path.join(os.homedir(), '.knock');
const NODE_DIR = path.dirname(process.execPath);
// 시험용: KNOCK_CLAUDE_CONFIG_DIR=default 로 띄운 시험 창은 이 맥의 기본 로그인을 쓴다
const SHARED_LOGIN = process.env.KNOCK_CLAUDE_CONFIG_DIR === 'default';

function run(cmd, args, env, input) {
  return new Promise((resolve) => {
    const child = execFile(cmd, args, { timeout: 20000, env, windowsHide: true }, (err, stdout, stderr) => resolve({ ok: !err, code: err?.code ?? 0, stdout: String(stdout), stderr: String(stderr) }));
    if (input != null) child.stdin.end(input);
  });
}

function executable(p) {
  try { fs.accessSync(p, fs.constants.X_OK); return true; } catch { return false; }
}

// 키체인(서비스 이름별). 윈도우는 DPAPI 암호 파일(platform.js)
const keychain = IS_WIN ? {
  async get(service) { return winSecret.get(service, 'knock'); },
  async set(service, key) { winSecret.set(service, 'knock', key); },
  async remove(service) { winSecret.remove(service, 'knock'); },
} : {
  async get(service) {
    const r = await run('security', ['find-generic-password', '-s', service, '-a', 'knock', '-w']);
    return r.ok ? r.stdout.trim() || null : null;
  },
  async set(service, key) {
    const r = await run('security', ['add-generic-password', '-U', '-s', service, '-a', 'knock', '-w', key]);
    if (!r.ok) throw new Error(`키체인에 저장하지 못했습니다: ${r.stderr.trim()}`);
  },
  async remove(service) {
    await run('security', ['delete-generic-password', '-s', service, '-a', 'knock']);
  },
};

async function verifyHttp(url, headers, bad) {
  let res;
  try {
    res = await fetch(url, { headers });
  } catch (err) {
    throw new Error(`연결하지 못했습니다(인터넷 확인): ${err.message}`);
  }
  if (res.status === 400 || res.status === 401 || res.status === 403) throw new Error(bad);
  if (!res.ok) throw new Error(`응답 오류 ${res.status}`);
}

// 로그인 명령은 터미널 창 없이 뒤에서 돌린다. 로그인 프로그램들은 화면(터미널)이 있어야 움직이므로
// 맥에 들어 있는 파이썬의 pty 로 보이지 않는 터미널을 붙여 준다(입력은 열어 두어 바로 끝나지 않게).
// 로그인 페이지는 각 프로그램이 기본 브라우저로 연다.
// on.url(주소): 출력에 나온 로그인 주소(브라우저가 안 열렸을 때 AI 창에서 열 수 있게)
// 윈도우에는 pty 가 없어 그대로 띄운다(창은 숨긴다).
// 주소를 받아도 아무것도 열지 않는 프로그램(로그인 프로그램이 컴퓨터 기본 브라우저를 열지 않게)
const NOOP_BROWSER = IS_WIN ? path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'where.exe') : '/usr/bin/true';

// 지금 도는 Knock Browser 실행 파일 — 주소를 주면 켜져 있는 Knock Browser 에 새 탭으로 열린다.
// 윈도우: 이 도우미는 <설치 폴더>\knock-ai-host 안에 있다. 맥: 도우미를 띄운 부모 프로그램(…/Knock.app/Contents/MacOS/Knock).
let knockBin;
function knockBinary() {
  if (knockBin !== undefined) return knockBin;
  knockBin = null;
  try {
    if (IS_WIN) {
      const exe = path.resolve(__dirname, '..', 'chrome.exe');
      if (fs.existsSync(exe)) knockBin = exe;
    } else {
      let pid = process.ppid;
      for (let i = 0; i < 4 && pid > 1 && !knockBin; i++) {
        const r = spawnSync('/bin/ps', ['-o', 'ppid=,comm=', '-p', String(pid)], { encoding: 'utf8' });
        const m = String(r.stdout || '').trim().match(/^(\d+)\s+(.+)$/);
        if (!m) break;
        if (/\/Knock[^/]*\.app\/Contents\/MacOS\/[^/]+$/.test(m[2]) && fs.existsSync(m[2])) knockBin = m[2];
        pid = Number(m[1]);
      }
    }
  } catch {}
  return knockBin;
}

function loginInBackground({ cmd, args, env, cwd, appServer, tty }, on) {
  if (appServer) return appServerLogin({ cmd, args, env, cwd }, on);
  // 로그인 명령은 터미널 안에서만 끝까지 간다(Claude Code 2.1.3xx: 아니면 "stdin isn't a terminal") — 맥은 python pty, 윈도우는 ConPTY
  // (윈도우 가짜 터미널은 tty 로 부탁한 것만 — Gemini 로그인은 터미널이 없어야 코드 입력을 기다린다)
  const child = IS_WIN
    ? (tty ? require('./pty-win').spawnPty(cmd, args, { cwd, env }) : spawn(cmd, args, { cwd, env, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true }))
    : spawn('/usr/bin/python3', ['-c', 'import pty, sys; pty.spawn(sys.argv[1:])', cmd, ...args], { cwd, env, stdio: ['pipe', 'pipe', 'pipe'] });
  let out = '';
  let sent = false;
  const scan = (d) => {
    out += String(d).replace(/\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)/g, '').replace(/\x1b\[[0-9;?]*[A-Za-z]/g, ''); // 글자 색·링크 표시 등 제어 문자 빼기
    const m = out.match(/https:\/\/\S*(auth|oauth|login|account)\S*(?=\s)/i); // 주소가 끝까지 온 뒤에
    if (m && !sent) {
      sent = true;
      on.url(m[0]);
    }
  };
  child.stdout.on('data', scan);
  child.stderr.on('data', scan);
  child.stdin.on('error', () => {});
  child.on('error', () => {});
  return child;
}

// ChatGPT(Codex) 로그인: `codex login` 은 컴퓨터 기본 브라우저(크롬 등)를 스스로 연다(2026-11-05 윈도우에서 크롬이 뜸).
// 편집기용 통로(app-server)는 로그인 주소만 돌려주고 브라우저는 열지 않는다 → 그 주소를 Knock Browser 탭에서 연다.
// 로그인 뒤 돌아오는 주소(127.0.0.1:1455)는 이 프로세스가 받으므로, 로그인이 끝날 때까지 살려 둔다(startLogin 이 끝나면 끈다).
function appServerLogin({ cmd, args, env, cwd }, on) {
  const child = spawn(cmd, args, { cwd, env, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
  const send = (o) => { try { child.stdin.write(`${JSON.stringify(o)}\n`); } catch {} };
  readLines(child.stdout, (ev) => {
    if (ev.id === 1) {
      send({ method: 'initialized' });
      send({ id: 2, method: 'account/login/start', params: { type: 'chatgpt' } });
    } else if (ev.id === 2 && ev.result?.authUrl) on.url(ev.result.authUrl);
  });
  child.stderr.on('data', () => {});
  child.stdin.on('error', () => {});
  child.on('error', () => {});
  send({ id: 1, method: 'initialize', params: { clientInfo: { name: 'knock-browser', title: 'Knock Browser', version: '1' } } });
  return child;
}

// 한 줄씩 JSON 을 읽는다
function readLines(stream, onEvent) {
  let buf = '';
  stream.on('data', (chunk) => {
    buf += chunk;
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line) continue;
      let ev;
      try { ev = JSON.parse(line); } catch { continue; }
      onEvent(ev);
    }
  });
}

// 프로그램이 남긴 오류 글을 사용자가 읽을 수 있게: 잘 알려진 경우는 쉬운 말로, 나머지는 코드 위치(at ...) 줄을 빼고 마지막 몇 줄만
function explainFailure(stderr) {
  if (/UNSUPPORTED_CLIENT|no longer supported for Gemini Code Assist/i.test(stderr)) {
    return 'Google 이 개인 Google 계정으로 Gemini 를 쓰는 연결 방식을 끝냈습니다(무료·Google AI Pro 계정 모두). '
      + '⚙︎ 설정 → Gemini → API 키에 Google AI Studio(aistudio.google.com)에서 만든 키를 넣으면 계속 쓸 수 있습니다. 키에도 무료 사용량이 있습니다.';
  }
  const lines = stderr.split('\n').map((l) => l.trimEnd()).filter((l) => l.trim() && !/^\s+at\s/.test(l) && !/^Warning:|Ripgrep is not available/.test(l));
  return lines.slice(-3).join('\n');
}

// 끝 처리: 오류·멈춤을 한 번만 알린다
function watchExit(child, on, getError) {
  let stderr = '';
  let finished = false;
  child.stderr.on('data', (d) => { stderr += d; });
  const finish = (error, stopped) => {
    if (finished) return;
    finished = true;
    on.done(error, stopped);
  };
  child.on('error', (err) => finish(err.message));
  child.on('close', (code, signal) => {
    // 멈추기(SIGTERM)를 받은 AI 프로그램이 스스로 143(=128+15)·130(Ctrl+C)으로 끝나기도 한다 → 오류가 아니라 멈춤
    if (signal || code === 143 || code === 130) finish(null, true);
    else if (getError()) finish(getError());
    else if (code !== 0) finish(explainFailure(stderr) || `종료 코드 ${code}`);
    else finish(null);
  });
}

// content blocks → 글(ChatGPT·Gemini 용). 이미지는 따로 파일로 넘긴다.
function blocksToText(content) {
  const parts = [];
  for (const b of content) {
    if (b.type === 'text') parts.push(b.text);
    else if (b.type === 'document' && b.source?.type === 'text') parts.push(`[첨부: ${b.title}]\n${b.source.data}`);
    else if (b.type === 'document') parts.push(`[첨부: ${b.title} — PDF 는 이 AI 가 직접 읽지 못합니다]`);
  }
  return parts.join('\n\n');
}

const IMAGE_EXT = /\.(png|jpe?g|gif|webp)$/i;

// ======================= Claude (Claude Code) =======================
const CLAUDE_DIR = path.join(HOME, 'claude-config');

function claudeEnv() {
  if (SHARED_LOGIN) return { ...process.env, MCP_TOOL_TIMEOUT: '480000' };
  fs.mkdirSync(CLAUDE_DIR, { recursive: true, mode: 0o700 });
  // MCP_TOOL_TIMEOUT: 도구 하나를 기다리는 한도(도우미 7분보다 조금 길게 — 허락 카드는 5분까지 기다린다)
  return { ...process.env, CLAUDE_CONFIG_DIR: CLAUDE_DIR, MCP_TOOL_TIMEOUT: '480000' };
}

function claudeBinary() {
  if (IS_WIN) {
    // 윈도우: 공식 설치 프로그램(~/.local/bin/claude.exe) 또는 npm 전역 설치
    const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
    return [path.join(os.homedir(), '.local', 'bin', 'claude.exe'),
      path.join(appData, 'npm', 'node_modules', '@anthropic-ai', 'claude-code', 'bin', 'claude.exe'),
      ...String(process.env.PATH || '').split(path.delimiter).map((d) => path.join(d, 'claude.exe'))]
      .find((p) => fs.existsSync(p)) || null;
  }
  const candidates = [];
  const bundled = path.join(os.homedir(), 'Library/Application Support/Claude/claude-code');
  try {
    const versions = fs.readdirSync(bundled).filter((v) => /^\d+\.\d+\.\d+$/.test(v))
      .sort((a, b) => b.localeCompare(a, undefined, { numeric: true }));
    for (const v of versions) {
      for (const hash of fs.readdirSync(path.join(bundled, v))) candidates.push(path.join(bundled, v, hash, 'claude.app/Contents/MacOS/claude'));
    }
  } catch {}
  candidates.push(path.join(os.homedir(), '.local/bin/claude'), path.join(os.homedir(), '.claude/local/claude'), '/opt/homebrew/bin/claude', '/usr/local/bin/claude');
  return candidates.find(executable) || null;
}

const claude = {
  id: 'claude',
  name: 'Claude',
  keyService: 'Knock AI - Anthropic API key',
  keyHint: 'sk-ant-로 시작하는 키',
  install: IS_WIN ? 'Claude Code 를 설치해 주세요(claude.ai 공식 설치 프로그램).' : 'Claude 데스크톱 앱을 설치해 주세요.',
  // 로그인 화면은 Knock Browser 탭에서: Claude 가 여는 주소(로그인하면 자동으로 연결되는 것)를 Knock Browser 로 열게 BROWSER 에 준다.
  // 화면에 찍히는 주소는 "코드를 붙여 넣으라"는 다른 방식이라 쓰지 않는다(2026-11-05 윈도우에서 코드 화면이 뜸).
  // Knock Browser 실행 파일을 못 찾을 때만 찍힌 주소를 확장이 연다.
  get loginInKnock() { return !knockBinary(); },
  models: () => [
    { id: 'claude-opus-5-5', name: 'Opus 5.5 · 가장 똑똑함' },
    { id: 'claude-sonnet-5-5', name: 'Sonnet 5.5 · 빠르고 균형' },
    { id: 'claude-haiku-5-5', name: 'Haiku 5.5 · 가장 빠름' },
  ],
  async account() {
    const bin = claudeBinary();
    if (!bin) return { installed: false, loggedIn: false };
    const r = await run(bin, ['auth', 'status'], claudeEnv());
    try {
      const s = JSON.parse(r.stdout);
      return { installed: true, loggedIn: Boolean(s.loggedIn), email: s.email || null };
    } catch {
      return { installed: true, loggedIn: false };
    }
  },
  loginCommand() {
    const bin = claudeBinary();
    // Claude 는 BROWSER 가 있으면 그 프로그램으로 주소를 연다 — 컴퓨터 기본 브라우저(크롬 등) 대신 Knock Browser 로(2026-11-05)
    return bin && { cmd: bin, args: ['auth', 'login'], env: { ...claudeEnv(), BROWSER: knockBinary() || NOOP_BROWSER }, cwd: HOME };
  },
  async logout() {
    const bin = claudeBinary();
    if (bin) await run(bin, ['auth', 'logout'], claudeEnv());
  },
  // [설치]: Anthropic 공식 설치 프로그램(claude.ai/install) — ~/.local/bin/claude 에 깐다
  installCommand() {
    return IS_WIN
      ? { cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', 'irm https://claude.ai/install.ps1 | iex'] }
      : { cmd: '/bin/bash', args: ['-c', 'curl -fsSL https://claude.ai/install.sh | bash'] };
  },
  async verifyKey(key) {
    if (!/^sk-ant-[\w-]{20,}$/.test(key)) throw new Error('Anthropic API 키 모양이 아닙니다. "sk-ant-" 로 시작하는 키를 붙여 넣어 주세요.');
    await verifyHttp('https://api.anthropic.com/v1/models?limit=1', { 'x-api-key': key, 'anthropic-version': '2023-06-01' }, '이 키로는 연결되지 않습니다. 키를 다시 확인해 주세요.');
  },
  // 일하는 중에 덧붙인 말을 진짜 사용자 말로 바로 넣을 수 있다(입력을 열어 둠)
  run({ content, sessionId, model, mcp, system, cwd, key, links = [], hide = [], tr = null, hr = null }, on) {
    // MCP 연결(피그마·노션): Knock 전용 설정 폴더에 등록·로그인한 서버를 Claude 가 그대로 읽는다(연결 열쇠가 그 등록에 묶여 있다).
    // 그래서 연결이 있으면 --strict-mcp-config 를 빼고, "늘 화면으로" 등 이번에 쓰지 않을 서비스는 도구를 막는다.
    // 바꾸는 도구는 Knock 확인 카드(approve_remote)를 거친다
    const servers = { 'knock-browser': mcp };
    // 똑소리 TR MCP(2026-11-11): Knock Browser 로그인 열쇠로 TR 서버 도구(조회·넣기). 저장(confirm)은 Knock 카드로 묻는다
    if (tr) servers.knocktr = { type: 'http', url: tr.url, headers: { Authorization: `Bearer ${tr.token}` } };
    if (hr) servers.knockhr = { type: 'http', url: hr.url, headers: { Authorization: `Bearer ${hr.token}` } };
    const ask = links.length || tr || hr;
    const trNote = (tr ? TR_NOTE('mcp__knocktr__ 도구') : '') + (hr ? HR_NOTE('mcp__knockhr__ 도구') : '');
    const linkNote = links.length ? `\n\n연결된 서비스(MCP): ${links.map((l) => `${l.name}(mcp__${l.id}__ 도구)`).join(' · ')}. ${links.map((l) => linkGuide(l)).join(' ')}` : '';
    const args = [
      '-p', '--input-format', 'stream-json', '--output-format', 'stream-json', '--verbose',
      '--include-partial-messages', '--replay-user-messages',
      '--model', model || 'claude-opus-5-5',
      '--mcp-config', JSON.stringify({ mcpServers: servers }), ...(links.length ? [] : ['--strict-mcp-config']),
      '--tools', '', '--allowedTools', 'mcp__knock-browser',
      ...(links.length && hide.length ? ['--disallowedTools', ...hide.map((id) => `mcp__${id}`)] : []),
      ...(ask ? ['--permission-prompt-tool', 'mcp__knock-browser__approve_remote'] : []),
      '--system-prompt', `${system}\n\n도구는 knock-browser(Knock 브라우저) 도구${ask ? '와 연결된 서비스(MCP) 도구' : ''}만 씁니다. 파일·명령어 도구는 없습니다.${linkNote}${trNote}`,
    ];
    if (sessionId) args.push('--resume', sessionId);
    const env = claudeEnv();
    // Claude 계정에 붙여 둔 claude.ai 연결(구글 드라이브 등)은 Knock AI 에 넣지 않는다 — Knock 설정 › MCP 연결에서 연결한 것만
    if (links.length) env.ENABLE_CLAUDEAI_MCP_SERVERS = 'false';
    if (key) env.ANTHROPIC_API_KEY = key;
    else delete env.ANTHROPIC_API_KEY;
    const child = spawn(claudeBinary(), args, { cwd, env, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    // 언제 끝낼지: 덧붙인 말이 모두 AI 에게 들어간 뒤 오는 "답 끝(result)"에서 끝낸다.
    // 예전엔 덧붙일 때마다 답 끝을 하나씩 더 기다렸는데, 일하는 중에 덧붙인 말은 AI 가 지금 답에 함께 담아 답 끝이 하나만 온다 →
    // 끝나지 않고 "실행 중"·주황 테두리가 남았다(2026-11-09 캘린더 "어제 성경도 완료").
    let injected = 0; // 덧붙인 말 수
    let delivered = 0; // 그중 AI 에게 들어간 수(첫 말이 다시 보이는 것은 빼고 — 첫 답 글자가 나온 뒤의 것만 센다)
    let answering = false;
    let idle = null; // 답 끝 뒤에도 덧붙인 말을 기다릴 때, 아무 소식이 없으면 끝낸다(안전장치)
    let wroteText = false;
    let needBreak = false;
    let resultError = null;
    const write = (c) => child.stdin.write(`${JSON.stringify({ type: 'user', message: { role: 'user', content: c } })}\n`);
    child.stdin.on('error', () => {});
    write(content);
    readLines(child.stdout, (ev) => {
      if (idle) { clearTimeout(idle); idle = null; }
      if (ev.session_id) on.session(ev.session_id);
      if (ev.type === 'assistant' || ev.type === 'stream_event') answering = true;
      if (ev.type === 'stream_event' && ev.event?.type === 'content_block_delta' && ev.event.delta?.type === 'text_delta') {
        on.text(ev.event.delta.text, needBreak);
        needBreak = false;
        wroteText = true;
      } else if (ev.type === 'stream_event' && ev.event?.type === 'message_start' && wroteText) {
        needBreak = true;
      } else if (ev.type === 'assistant' && Array.isArray(ev.message?.content)) {
        for (const b of ev.message.content) {
          const m = b.type === 'tool_use' && String(b.name || '').match(/^mcp__([a-z]+)__(.+)$/);
          if (m && (MCP_SERVICES[m[1]] || TOKSORI_NAMES[m[1]])) on.note?.(`${MCP_SERVICES[m[1]]?.name || TOKSORI_NAMES[m[1]]}: ${m[2]}${b.input?.description ? ` — ${String(b.input.description).slice(0, 80)}` : ''}`);
        }
      } else if (ev.type === 'user' && Array.isArray(ev.message?.content) && ev.message.content.some((b) => b.type === 'text')) {
        if (answering) delivered++;
        on.delivered();
      } else if (ev.type === 'result') {
        if (ev.is_error) resultError = ev.result || ev.subtype || '알 수 없는 오류';
        if (delivered >= injected) child.stdin.end(); // 덧붙인 말까지 다 답했으면 끝낸다
        else idle = setTimeout(() => { if (!child.stdin.writableEnded) child.stdin.end(); }, 60 * 1000);
      }
    });
    watchExit(child, on, () => resultError);
    return {
      stop: () => child.kill('SIGTERM'),
      inject: (c) => {
        if (!child.stdin.writable || child.stdin.writableEnded) return false;
        injected++;
        write(c);
        return true;
      },
    };
  },
};

const TOKSORI_NAMES = { knocktr: '똑소리 TR', knockhr: '똑소리 HR' };
// 똑소리 HR MCP 안내(2026-11-11, 1단계는 조회만)
const HR_NOTE = (tools) => '\n\n똑소리 HR(인사: 직원·연차·근태·일정·생일·계약서·급여) 조회는 화면 대신 ' + tools + '로 바로 합니다. '
  + '등록·수정 같은 HR 저장 일은 아직 이 도구로 할 수 없으니 똑소리 HR 화면에서 합니다. 권한 없음·로그인 끊김은 그대로 전합니다.';
// 똑소리 TR MCP 안내(2026-11-11) — Claude·ChatGPT 같은 말
const TR_NOTE = (tools) => '\n\n똑소리 TR(구매·거래 관리: 거래처·거래·결제·미수·명세서) 일은 화면 대신 ' + tools + '로 바로 합니다. '
  + '넣기·고치기·지우기 도구는 먼저 confirm 없이 불러 미리보기를 받고, 그 내용(줄 수·합계)을 사용자에게 보여 준 뒤 같은 도구를 {"confirm": 받은 확인 표} 로 다시 부릅니다(그때 Knock 이 저장할지 묻습니다). '
  + '도구가 권한 없음·로그인 끊김을 알리면 그대로 전하고, 화면으로 돌아가 같은 일을 하지 않습니다.';

// ======================= MCP 연결(설정 › MCP 연결, 2026-11-07) =======================
// 피그마·노션 같은 서비스를 Knock AI(Claude)가 화면을 누르지 않고 바로 다루게 잇는다.
// 연결 열쇠(OAuth)는 Claude Code 가 Knock 전용 설정 폴더(claude-config)에 둔다 — `claude mcp login` 이 서비스 로그인 페이지를
// Knock Browser 탭으로 연다(BROWSER). 사용자의 Claude 데스크톱·터미널 설정은 건드리지 않는다.
const MCP_SERVICES = {
  figma: { name: '피그마', url: 'https://mcp.figma.com/mcp' },
  notion: { name: '노션', url: 'https://mcp.notion.com/mcp' },
};
const MCP_PREFS = path.join(HOME, 'mcp-prefs.json');
function linkGuide(l) {
  if (l.id === 'figma') {
    return '피그마 일은 먼저 피그마 연결 도구로 합니다(파일 키는 피그마 탭 주소 figma.com/design/<파일키>/… 에서). 연결 도구가 막히거나(한도·권한) 사용자가 연결을 허용하지 않으면 그때 화면을 보고 합니다. 사용자가 "화면으로 해줘"라고 하면 화면으로 합니다.';
  }
  if (l.id === 'notion') return '노션 일(페이지 찾기·읽기·만들기·고치기)은 노션 연결 도구로 합니다.';
  return '';
}
let mcpCache = null; // { at, items } — `claude mcp list` 는 서버마다 접속해 보느라 1초 넘게 걸려 5분 동안 다시 쓴다
const mcpLinks = {
  services: MCP_SERVICES,
  available: () => !SHARED_LOGIN && Boolean(claudeBinary()),
  async list(fresh = false) {
    if (!mcpLinks.available()) return [];
    if (!fresh && mcpCache && Date.now() - mcpCache.at < 5 * 60 * 1000) return mcpCache.items;
    const r = await run(claudeBinary(), ['mcp', 'list'], { ...claudeEnv(), ENABLE_CLAUDEAI_MCP_SERVERS: 'false' });
    const out = `${r.stdout}\n${r.stderr}`;
    const items = Object.entries(MCP_SERVICES).map(([id, sv]) => {
      const line = out.split('\n').find((l) => l.startsWith(`${id}:`)) || '';
      return { id, name: sv.name, added: Boolean(line), connected: /✓|connected/i.test(line) && !/needs auth|failed|✗/i.test(line), needsAuth: /needs auth/i.test(line) };
    });
    mcpCache = { at: Date.now(), items };
    return items;
  },
  async add(id) {
    const sv = MCP_SERVICES[id];
    if (!sv) throw new Error('모르는 서비스입니다.');
    const items = await mcpLinks.list(true);
    if (!items.find((x) => x.id === id)?.added) await run(claudeBinary(), ['mcp', 'add', '--transport', 'http', '-s', 'user', id, sv.url], claudeEnv());
  },
  loginCommand(id) {
    // 윈도우: 브라우저는 열지 않게 하고(기본 브라우저가 뜰 수 있다) 찍힌 주소를 확장이 Knock 탭으로 연다
    return { cmd: claudeBinary(), args: ['mcp', 'login', id], env: { ...claudeEnv(), BROWSER: (!IS_WIN && knockBinary()) || NOOP_BROWSER }, cwd: HOME, tty: true };
  },
  async logout(id) {
    if (!MCP_SERVICES[id]) return;
    await run(claudeBinary(), ['mcp', 'logout', id], claudeEnv());
    await run(claudeBinary(), ['mcp', 'remove', id, '-s', 'user'], claudeEnv());
    mcpCache = null;
  },
  forget() { mcpCache = null; },
  // 로그인 명령이 Knock Browser 로 주소를 직접 연다(못 찾으면 확장이 찍힌 주소를 연다)
  opensItself: () => !IS_WIN && Boolean(knockBinary()),
  // 작업 방식(피그마: auto 연결 먼저·막히면 화면 / mcp 늘 연결로 / screen 늘 화면으로)
  prefs() { try { return JSON.parse(fs.readFileSync(MCP_PREFS, 'utf8')); } catch { return {}; } },
  setPrefs(p) { fs.writeFileSync(MCP_PREFS, JSON.stringify(p || {}), { mode: 0o600 }); },
  // 이번 대화에 넘길 것: 연결됐고 "늘 화면으로"가 아닌 서비스
  async forRun() {
    if (!mcpLinks.available()) return { links: [], hide: [] };
    const prefs = mcpLinks.prefs();
    const items = await mcpLinks.list();
    const use = (x) => x.connected && prefs[x.id] !== 'screen';
    return {
      links: items.filter(use).map((x) => ({ ...x, mode: prefs[x.id] || 'auto' })),
      hide: items.filter((x) => x.added && !use(x)).map((x) => x.id), // 등록은 됐지만 이번엔 쓰지 않음(늘 화면으로 · 로그인 안 됨)
    };
  },
};

// ChatGPT(Codex) 쪽 MCP 연결(2026-11-08 "chatgpt와 제미나이도"): 연결 열쇠는 Codex 가 Knock 전용 codex-home 에 둔다.
// 등록은 config.toml 에 직접 적는다(`codex mcp add` 는 곧바로 로그인 브라우저를 스스로 열어서). 로그인은 `codex mcp login --no-browser`
// 가 찍는 주소를 Knock Browser 탭으로 열고, 허용 뒤 돌아오는 주소(127.0.0.1)는 그 로그인 프로세스가 받는다.
let codexMcpCache = null;
const codexLinks = {
  available: () => !SHARED_LOGIN && Boolean(codexCommand()),
  async list(fresh = false) {
    if (!codexLinks.available()) return [];
    if (!fresh && codexMcpCache && Date.now() - codexMcpCache.at < 5 * 60 * 1000) return codexMcpCache.items;
    const c = codexCommand();
    const r = await run(c.cmd, [...c.pre, 'mcp', 'list', '--json'], codexEnv());
    let list = [];
    try { list = JSON.parse(r.stdout); } catch {}
    const items = Object.entries(MCP_SERVICES).map(([id, sv]) => {
      const x = list.find((y) => y.name === id);
      return { id, name: sv.name, added: Boolean(x), connected: Boolean(x) && !['not_logged_in', 'unsupported'].includes(x.auth_status), needsAuth: x?.auth_status === 'not_logged_in' };
    });
    codexMcpCache = { at: Date.now(), items };
    return items;
  },
  async add(id) {
    const sv = MCP_SERVICES[id];
    if (!sv) throw new Error('모르는 서비스입니다.');
    const file = path.join(codexEnv().CODEX_HOME, 'config.toml');
    let text = '';
    try { text = fs.readFileSync(file, 'utf8'); } catch {}
    if (text.includes(`[mcp_servers.${id}]`)) return;
    fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
    fs.writeFileSync(file, `${text}${text && !text.endsWith('\n') ? '\n' : ''}\n[mcp_servers.${id}]\nurl = ${toml(sv.url)}\n`, { mode: 0o600 });
  },
  loginCommand(id) {
    const c = codexCommand();
    return { cmd: c.cmd, args: [...c.pre, 'mcp', 'login', id, '--no-browser'], env: codexEnv(), cwd: HOME };
  },
  async logout(id) {
    if (!MCP_SERVICES[id]) return;
    const c = codexCommand();
    await run(c.cmd, [...c.pre, 'mcp', 'logout', id], codexEnv());
    await run(c.cmd, [...c.pre, 'mcp', 'remove', id], codexEnv());
    codexMcpCache = null;
  },
  forget() { codexMcpCache = null; },
  opensItself: () => false, // 찍힌 주소를 확장이 Knock 탭으로 연다
  async forRun() {
    if (!codexLinks.available()) return { links: [], hide: [] };
    const prefs = mcpLinks.prefs();
    const items = await codexLinks.list();
    const use = (x) => x.connected && prefs[x.id] !== 'screen';
    return { links: items.filter(use).map((x) => ({ ...x, mode: prefs[x.id] || 'auto' })), hide: items.filter((x) => x.added && !use(x)).map((x) => x.id) };
  },
};

// ======================= ChatGPT (OpenAI Codex) =======================
const CODEX_HOME = path.join(HOME, 'codex-home');

// Knock 이 [설치] 단추로 받아 둔 AI 프로그램(사용자 폴더 안이라 관리자 권한이 필요 없다)
const TOOLS = path.join(HOME, 'tools');
const CODEX_PREFIX = path.join(TOOLS, 'codex');
// npm: 도우미와 같이 묶은 것(설치판) → node 옆(윈도우 node 폴더 · 맥 nvm)
function npmCli() {
  return [path.join(__dirname, 'npm', 'bin', 'npm-cli.js'),
    path.join(NODE_DIR, 'node_modules', 'npm', 'bin', 'npm-cli.js'),
    path.join(NODE_DIR, '..', 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js')].find((f) => fs.existsSync(f)) || null;
}

// codex 실행 방법 { cmd, pre }: Knock 이 설치한 것은 공식 시작 파일(codex.js)을 도우미의 node 로 돌린다
function codexCommand() {
  for (const lib of [path.join(CODEX_PREFIX, 'node_modules'), path.join(CODEX_PREFIX, 'lib', 'node_modules')]) {
    const js = path.join(lib, '@openai', 'codex', 'bin', 'codex.js');
    if (fs.existsSync(js)) return { cmd: process.execPath, pre: [js] };
  }
  const bin = codexBinary();
  return bin && { cmd: bin, pre: [] };
}

function codexBinary() {
  if (IS_WIN) {
    // 윈도우: npm 전역 설치(npm i -g @openai/codex)에 들어 있는 실행 파일(codex.cmd 는 쉘을 거쳐야 해서 쓰지 않는다)
    const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
    const vendor = path.join(appData, 'npm', 'node_modules', '@openai', 'codex', 'vendor');
    try {
      for (const triple of fs.readdirSync(vendor).filter((t) => /windows/.test(t)).sort((a) => (a.startsWith(process.arch === 'arm64' ? 'aarch64' : 'x86_64') ? -1 : 1))) {
        const exe = path.join(vendor, triple, 'codex', 'codex.exe');
        if (fs.existsSync(exe)) return exe;
      }
    } catch {}
    return String(process.env.PATH || '').split(path.delimiter).map((d) => path.join(d, 'codex.exe')).find((p) => fs.existsSync(p)) || null;
  }
  const dirs = [NODE_DIR, ...String(process.env.PATH || '').split(':'), '/opt/homebrew/bin', '/usr/local/bin'];
  try {
    for (const v of fs.readdirSync(path.join(os.homedir(), '.nvm/versions/node'))) dirs.push(path.join(os.homedir(), '.nvm/versions/node', v, 'bin'));
  } catch {}
  return dirs.map((d) => path.join(d, 'codex')).find(executable) || null;
}

function codexEnv(extra = {}) {
  const home = SHARED_LOGIN ? path.join(os.homedir(), '.codex') : CODEX_HOME;
  fs.mkdirSync(home, { recursive: true, mode: 0o700 });
  return { ...process.env, PATH: `${NODE_DIR}${path.delimiter}${process.env.PATH || ''}`, CODEX_HOME: home, ...extra };
}

function codexEmail() {
  try {
    const auth = JSON.parse(fs.readFileSync(path.join(codexEnv().CODEX_HOME, 'auth.json'), 'utf8'));
    const payload = JSON.parse(Buffer.from(String(auth.tokens?.id_token || '').split('.')[1] || '', 'base64url').toString());
    return payload.email || null;
  } catch {
    return null;
  }
}

function toml(v) {
  return JSON.stringify(v); // TOML 기본 문자열·배열은 JSON 과 같은 모양으로 쓸 수 있다
}

const chatgpt = {
  id: 'chatgpt',
  name: 'ChatGPT',
  keyService: 'Knock AI - OpenAI API key',
  keyHint: 'sk-로 시작하는 OpenAI 키',
  install: 'OpenAI Codex 를 설치해 주세요(npm i -g @openai/codex).',
  loginInKnock: true, // 로그인 화면을 Knock Browser 탭에서(app-server 가 주소만 준다)
  models() {
    for (const home of [codexEnv().CODEX_HOME, path.join(os.homedir(), '.codex')]) {
      try {
        const list = JSON.parse(fs.readFileSync(path.join(home, 'models_cache.json'), 'utf8'));
        const models = (Array.isArray(list) ? list : list.models || [])
          .filter((m) => m.visibility === 'list')
          .map((m) => ({ id: m.slug || m.id, name: m.display_name || m.slug }));
        if (models.length) return models;
      } catch {}
    }
    return [{ id: 'gpt-6.1-sol', name: 'GPT-6.1-Sol' }, { id: 'gpt-6.1-terra', name: 'GPT-6.1 Terra' }];
  },
  async account() {
    const c = codexCommand();
    if (!c) return { installed: false, loggedIn: false };
    const r = await run(c.cmd, [...c.pre, 'login', 'status'], codexEnv());
    const loggedIn = /logged in/i.test(r.stdout + r.stderr) && !/not logged in/i.test(r.stdout + r.stderr);
    return { installed: true, loggedIn, email: loggedIn ? codexEmail() : null };
  },
  loginCommand() {
    const c = codexCommand();
    return c && { cmd: c.cmd, args: [...c.pre, 'app-server'], env: codexEnv(), cwd: HOME, appServer: true };
  },
  async logout() {
    const c = codexCommand();
    if (c) await run(c.cmd, [...c.pre, 'logout'], codexEnv());
  },
  // [설치]: npm 공식 꾸러미 @openai/codex 를 ~/.knock/tools/codex 에
  installCommand() {
    const npm = npmCli();
    return npm && { cmd: process.execPath, args: [npm, 'install', '-g', '@openai/codex', '--prefix', CODEX_PREFIX, '--no-audit', '--no-fund'] };
  },
  async verifyKey(key) {
    if (!/^sk-[\w-]{20,}$/.test(key)) throw new Error('OpenAI API 키 모양이 아닙니다. "sk-" 로 시작하는 키를 붙여 넣어 주세요.');
    await verifyHttp('https://api.openai.com/v1/models', { authorization: `Bearer ${key}` }, '이 키로는 연결되지 않습니다. 키를 다시 확인해 주세요.');
  },
  run(opts, on) {
    if (opts.links?.length || opts.tr || opts.hr) return codexAppServerRun(opts, on); // 연결 서비스·똑소리 TR 은 묻는 길(app-server)로
    const { content, files, sessionId, model, mcp, system, cwd, key } = opts;
    const env = codexEnv(key ? { CODEX_API_KEY: key } : {});
    const args = ['exec', '--json', '--skip-git-repo-check', '-s', 'read-only',
      '-c', 'approval_policy="never"',
      // Knock 페이지 도구만: Codex 자체의 명령어·파일·브라우저 도구는 끈다
      '--disable', 'shell_tool', '--disable', 'unified_exec', '--disable', 'browser_use', '--disable', 'view_image', '--disable', 'apps',
      '-c', `developer_instructions=${toml(system)}`,
      '-c', `mcp_servers.knock.command=${toml(mcp.command)}`,
      '-c', `mcp_servers.knock.args=${toml(mcp.args)}`,
      '-c', `mcp_servers.knock.env={${Object.entries(mcp.env).map(([k, v]) => `${k}=${toml(v)}`).join(',')}}`,
      '-c', 'mcp_servers.knock.default_tools_approval_mode="approve"',
      '-c', 'mcp_servers.knock.tool_timeout_sec=480', // 도우미 한도(7분)보다 조금 길게 — 허락 카드는 5분까지 기다린다
    ];
    if (model) args.push('-m', model);
    for (const f of files || []) if (IMAGE_EXT.test(f.name)) args.push('-i', f.path);
    if (sessionId) args.push('resume', sessionId, '-');
    else args.push('-');
    const c = codexCommand();
    const child = spawn(c.cmd, [...c.pre, ...args], { cwd, env, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    child.stdin.on('error', () => {});
    child.stdin.end(blocksToText(content));
    let error = null;
    let afterTool = false;
    readLines(child.stdout, (ev) => {
      if (ev.type === 'thread.started' && ev.thread_id) on.session(ev.thread_id);
      const it = ev.item || {};
      if (ev.type === 'item.completed' && it.type === 'agent_message' && it.text) {
        on.text(it.text, true);
        afterTool = false;
      } else if (ev.type === 'item.started' && it.type === 'mcp_tool_call') {
        afterTool = true;
      } else if (ev.type === 'turn.failed') {
        error = ev.error?.message || '알 수 없는 오류';
      } else if (ev.type === 'error' && ev.message && !/reconnect/i.test(ev.message)) {
        error = ev.message;
      }
    });
    watchExit(child, on, () => error);
    return { stop: () => child.kill('SIGTERM') };
  },
};

// 연결된 서비스(피그마·노션)가 있을 때의 ChatGPT 실행(2026-11-08): `codex exec` 는 도구 허락을 물을 길이 없어(묻는 요청을 스스로 취소),
// 편집기용 통로(app-server)로 돌린다. 연결 서비스 도구는 매번 Codex 가 묻게 하고(prompt), 그 물음을 Knock 확인 카드(approve_remote)로
// 넘겨 답한다 — Claude 와 같은 카드·같은 [항상 허용]. Knock 페이지 도구는 묻지 않는다.
function codexAppServerRun({ content, files, sessionId, model, mcp, system, cwd, key, links = [], hide = [], tr = null, hr = null }, on) {
  const env = codexEnv(key ? { CODEX_API_KEY: key } : {});
  // 똑소리 TR(2026-11-11): 열쇠는 명령줄에 남기지 않고 환경 변수로 넘긴다
  if (tr) env.KNOCK_TR_TOKEN = tr.token;
  if (hr) env.KNOCK_HR_TOKEN = hr.token;
  const linkNote = (links.length ? `\n\n연결된 서비스(MCP): ${links.map((l) => `${l.name}(${l.id} 서버 도구)`).join(' · ')}. ${links.map((l) => linkGuide(l)).join(' ')}` : '')
    + (tr ? TR_NOTE('knocktr 서버 도구') : '') + (hr ? HR_NOTE('knockhr 서버 도구') : '');
  const args = [
    '--disable', 'shell_tool', '--disable', 'unified_exec', '--disable', 'browser_use', '--disable', 'view_image', '--disable', 'apps',
    '-c', `developer_instructions=${toml(system + linkNote)}`,
    '-c', `mcp_servers.knock.command=${toml(mcp.command)}`,
    '-c', `mcp_servers.knock.args=${toml(mcp.args)}`,
    '-c', `mcp_servers.knock.env={${Object.entries(mcp.env).map(([k, v]) => `${k}=${toml(v)}`).join(',')}}`,
    '-c', 'mcp_servers.knock.default_tools_approval_mode="approve"',
    '-c', 'mcp_servers.knock.tool_timeout_sec=480',
    ...links.flatMap((l) => ['-c', `mcp_servers.${l.id}.default_tools_approval_mode="prompt"`]),
    ...(tr ? ['-c', `mcp_servers.knocktr.url=${toml(tr.url)}`, '-c', 'mcp_servers.knocktr.bearer_token_env_var="KNOCK_TR_TOKEN"',
      '-c', 'mcp_servers.knocktr.default_tools_approval_mode="prompt"', '-c', 'mcp_servers.knocktr.tool_timeout_sec=120'] : []),
    ...(hr ? ['-c', `mcp_servers.knockhr.url=${toml(hr.url)}`, '-c', 'mcp_servers.knockhr.bearer_token_env_var="KNOCK_HR_TOKEN"',
      '-c', 'mcp_servers.knockhr.default_tools_approval_mode="prompt"', '-c', 'mcp_servers.knockhr.tool_timeout_sec=120'] : []),
    ...hide.flatMap((id) => ['-c', `mcp_servers.${id}.enabled=false`]),
    'app-server',
  ];
  const c = codexCommand();
  const child = spawn(c.cmd, [...c.pre, ...args], { cwd, env, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
  child.stdin.on('error', () => {});
  const send = (o) => { try { child.stdin.write(`${JSON.stringify(o)}\n`); } catch {} };
  let error = null;
  let threadId = null;
  let turnId = null;
  let stopped = false;
  const calls = new Map(); // 진행 중인 연결 서비스 도구 호출(서버 → 마지막 호출) — 묻는 요청에 도구 이름이 없어서 맞춰 본다
  const input = [{ type: 'text', text: blocksToText(content), text_elements: [] }];
  for (const f of files || []) if (IMAGE_EXT.test(f.name)) input.push({ type: 'localImage', path: f.path });
  const threadParams = { cwd, sandbox: 'read-only', approvalPolicy: 'on-request', approvalsReviewer: 'user', ...(model ? { model } : {}) };
  const answerApproval = async (m) => {
    const p = m.params || {};
    const server = String(p.serverName || '');
    const call = calls.get(server);
    const tool = call?.tool || String(p.message || '').match(/tool "([^"]+)"/)?.[1] || '';
    const toolInput = p._meta?.tool_params || call?.arguments || {};
    let allow = false;
    if ((MCP_SERVICES[server] || TOKSORI_NAMES[server]) && tool && on.approve) {
      const r = await on.approve(`mcp__${server}__${tool}`, toolInput).catch(() => null);
      try { allow = JSON.parse(r?.content || '{}').behavior === 'allow'; } catch {}
    }
    send({ id: m.id, result: allow ? { action: 'accept', content: {}, _meta: null } : { action: 'decline', content: null, _meta: null } });
  };
  readLines(child.stdout, (m) => {
    if (m.method && m.id != null) { // 앱 서버가 묻는 것
      if (m.method === 'mcpServer/elicitation/request' && m.params?.mode === 'form' && m.params?._meta?.codex_approval_kind === 'mcp_tool_call') answerApproval(m);
      else if (m.method === 'mcpServer/elicitation/request') send({ id: m.id, result: { action: 'decline', content: null, _meta: null } });
      else send({ id: m.id, error: { code: -32601, message: 'Knock Browser 에서 지원하지 않는 요청입니다.' } });
      return;
    }
    if (m.id === 1) {
      send({ method: 'initialized' });
      send(sessionId ? { id: 2, method: 'thread/resume', params: { threadId: sessionId, ...threadParams } } : { id: 2, method: 'thread/start', params: threadParams });
    } else if (m.id === 2) {
      if (m.error || !m.result?.thread?.id) { error = m.error?.message || 'ChatGPT 대화를 시작하지 못했습니다.'; child.stdin.end(); return; }
      threadId = m.result.thread.id;
      on.session(threadId);
      send({ id: 3, method: 'turn/start', params: { threadId, input } });
    } else if (m.id === 3) {
      if (m.error) { error = m.error.message; child.stdin.end(); } else turnId = m.result?.turn?.id || null;
    } else if (m.method === 'item/started' && m.params?.item?.type === 'mcpToolCall') {
      const it = m.params.item;
      calls.set(it.server, it);
      if (MCP_SERVICES[it.server] || TOKSORI_NAMES[it.server]) on.note?.(`${MCP_SERVICES[it.server]?.name || TOKSORI_NAMES[it.server]}: ${it.tool}`);
    } else if (m.method === 'item/completed' && m.params?.item?.type === 'agentMessage' && m.params.item.text) {
      on.text(m.params.item.text, true);
    } else if (m.method === 'error' && m.params?.error?.message && !m.params.willRetry) {
      error = m.params.error.message;
    } else if (m.method === 'turn/completed') {
      const t = m.params?.turn || {};
      if (t.status === 'failed') error = t.error?.message || error || '알 수 없는 오류';
      child.stdin.end(); // 다 끝났으니 앱 서버를 닫는다
    }
  });
  send({ id: 1, method: 'initialize', params: { clientInfo: { name: 'knock_browser', title: 'Knock Browser', version: '1' } } });
  watchExit(child, on, () => error);
  return {
    stop: () => {
      if (stopped) return;
      stopped = true;
      if (threadId && turnId) send({ id: 9, method: 'turn/interrupt', params: { threadId, turnId } });
      setTimeout(() => child.kill('SIGTERM'), 1500);
    },
  };
}

// ======================= Gemini (Google Gemini CLI) =======================
const GEMINI_HOME = path.join(HOME, 'gemini-home'); // 이 아래 .gemini 에 로그인·설정이 저장된다
const GEMINI_JS = path.join(__dirname, 'node_modules/@google/gemini-cli/bundle/gemini.js');
const GEMINI_SYSTEM = path.join(HOME, 'gemini-system.md');
// Gemini 자체 도구 중 이 맥의 파일·명령어를 다루는 것은 끈다(웹 검색·웹 읽기는 둔다)
const GEMINI_EXCLUDE = ['run_shell_command', 'read_file', 'write_file', 'replace', 'glob', 'search_file_content',
  'grep_search', 'list_directory', 'read_many_files', 'save_memory', 'write_todos'];

function geminiHome() {
  return SHARED_LOGIN ? os.homedir() : GEMINI_HOME;
}

function writeGeminiSettings(via, mcp) {
  const dir = path.join(geminiHome(), '.gemini');
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const file = path.join(dir, 'settings.json');
  let s = {};
  try { s = JSON.parse(fs.readFileSync(file, 'utf8')); } catch {}
  s.security = { ...(s.security || {}), auth: { ...(s.security?.auth || {}), selectedType: via === 'api' ? 'gemini-api-key' : 'oauth-personal' }, folderTrust: { enabled: false } };
  s.tools = { ...(s.tools || {}), exclude: GEMINI_EXCLUDE };
  s.general = { ...(s.general || {}), disableAutoUpdate: true };
  // 탭마다 다른 값(KNOCK_OWNER 등)은 실행할 때 환경 변수로 넘기고 여기서는 $이름 으로 가리킨다
  if (mcp) s.mcpServers = { knock: { command: mcp.command, args: mcp.args, env: Object.fromEntries(Object.keys(mcp.env).map((k) => [k, `$${k}`])), trust: true, timeout: 480000 } };
  fs.writeFileSync(file, JSON.stringify(s, null, 2), { mode: 0o600 });
}

const gemini = {
  id: 'gemini',
  name: 'Gemini',
  keyService: 'Knock AI - Gemini API key',
  keyHint: 'Google AI Studio 의 API 키',
  install: 'Knock AI 도우미에 Gemini CLI 가 없습니다(knock-ai/host 에서 npm install).',
  models: () => [
    { id: 'auto-gemini-3', name: '자동 · 알아서 고름' },
    { id: 'gemini-3-pro-preview', name: 'Gemini 3 Pro · 가장 똑똑함' },
    { id: 'gemini-3-flash-preview', name: 'Gemini 3 Flash · 빠름' },
    { id: 'gemini-2.5-pro', name: 'Gemini 2.5 Pro' },
  ],
  async account() {
    if (!fs.existsSync(GEMINI_JS)) return { installed: false, loggedIn: false };
    const dir = path.join(geminiHome(), '.gemini');
    const loggedIn = fs.existsSync(path.join(dir, 'oauth_creds.json'));
    let email = null;
    try { email = JSON.parse(fs.readFileSync(path.join(dir, 'google_accounts.json'), 'utf8')).active || null; } catch {}
    return { installed: true, loggedIn, email: loggedIn ? email : null };
  },
  // 구글 로그인으로 정해 두고 Gemini 를 띄운다. 터미널 없이 돌면 Gemini 는 브라우저를 열지 않고
  // 로그인 주소를 찍은 뒤 "인증 코드"를 기다린다(NO_BROWSER). Knock 이 그 주소를 자기 탭에서 열고,
  // 로그인 뒤 넘어온 주소(codeassist.google.com/authcode?code=…)에서 코드를 읽어 넣어 준다.
  loginInKnock: true,
  codeUrl: 'https://codeassist.google.com/authcode',
  loginCommand() {
    writeGeminiSettings('account');
    const work = path.join(HOME, 'gemini-work', 'login');
    fs.mkdirSync(work, { recursive: true });
    return { cmd: process.execPath, args: [GEMINI_JS], env: { ...process.env, GEMINI_CLI_HOME: GEMINI_HOME, NO_BROWSER: 'true' }, cwd: work };
  },
  async logout() {
    const dir = path.join(geminiHome(), '.gemini');
    for (const f of ['oauth_creds.json', 'google_accounts.json']) fs.rmSync(path.join(dir, f), { force: true });
  },
  async verifyKey(key) {
    if (!/^[\w-]{30,}$/.test(key)) throw new Error('Gemini API 키 모양이 아닙니다. Google AI Studio 에서 만든 키를 붙여 넣어 주세요.');
    await verifyHttp('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1', { 'x-goog-api-key': key }, '이 키로는 연결되지 않습니다. 키를 다시 확인해 주세요.');
  },
  run({ content, sessionId, model, mcp, system, tabId, key }, on) {
    writeGeminiSettings(key ? 'api' : 'account', mcp);
    fs.writeFileSync(GEMINI_SYSTEM, system);
    // 대화는 폴더(프로젝트)마다 따로 저장된다: 탭마다 폴더를 두고 이어 말할 때는 그 폴더의 마지막 대화를 잇는다
    const cwd = path.join(HOME, 'gemini-work', String(tabId));
    fs.mkdirSync(cwd, { recursive: true });
    const env = { ...process.env, GEMINI_CLI_HOME: geminiHome(), GEMINI_SYSTEM_MD: GEMINI_SYSTEM, ...mcp.env };
    if (key) env.GEMINI_API_KEY = key;
    else delete env.GEMINI_API_KEY;
    const args = [GEMINI_JS, '-o', 'stream-json', '--approval-mode', 'yolo', '--allowed-mcp-server-names', 'knock'];
    if (model) args.push('-m', model);
    if (sessionId) args.push('--resume', 'latest');
    args.push('-p', blocksToText(content));
    const child = spawn(process.execPath, args, { cwd, env, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    let error = null;
    let afterTool = false;
    readLines(child.stdout, (ev) => {
      if (ev.type === 'init' && ev.session_id) on.session(ev.session_id);
      if (ev.type === 'message' && ev.role === 'assistant' && ev.content) {
        on.text(ev.content, afterTool);
        afterTool = false;
      } else if (ev.type === 'tool_use') {
        afterTool = true;
      } else if (ev.type === 'result' && ev.status === 'error') {
        error = ev.error?.message || '알 수 없는 오류';
      } else if (ev.type === 'error' && ev.message) {
        error = ev.message;
      }
    });
    watchExit(child, on, () => error);
    return { stop: () => child.kill('SIGTERM') };
  },
};

const PROVIDERS = { claude, chatgpt, gemini };

// 판(개발용·배포판)별로 서비스마다 켠 연결 방법. 확장이 policy.json 을 읽어 init 으로 알려 준다.
// 알려 주기 전(옛 확장)에는 모두 켠 것으로 본다.
let policy = null;
function setPolicy(p) {
  policy = p && typeof p === 'object' ? p : null;
}
function allowed(id, method) {
  return !policy || !policy[id] || policy[id][method] !== false;
}

// 연결 상태(키 자체는 빼고). via: 실제로 쓸 연결 — API 키가 있으면 키, 없으면 계정
async function statusOf(p) {
  const accountOn = allowed(p.id, 'account');
  const keyOn = allowed(p.id, 'apiKey');
  const [account, storedKey] = await Promise.all([
    accountOn ? p.account() : p.account().then((a) => ({ installed: a.installed, loggedIn: false })),
    keyOn ? keychain.get(p.keyService) : null,
  ]);
  const key = storedKey;
  const via = !account.installed ? null : key ? 'api' : account.loggedIn ? 'account' : null;
  return {
    id: p.id,
    name: p.name,
    installed: account.installed,
    install: p.install,
    canInstall: Boolean(p.installCommand?.()),
    account: { loggedIn: account.loggedIn, email: account.email || null },
    apiKey: key ? { set: true, tail: key.slice(-4) } : { set: false },
    keyHint: p.keyHint,
    allow: { account: accountOn, apiKey: keyOn },
    via,
    ready: Boolean(via),
    models: p.models(),
  };
}

// [설치] 단추: 공식 설치 프로그램을 뒤에서 돌린다(창 없이). 끝나면 프로그램이 찾아지는지로 성공을 판단한다.
function install(p) {
  const command = p.installCommand?.();
  if (!command) return Promise.reject(new Error(`${p.name} 은 자동 설치를 할 수 없습니다. ${p.install}`));
  fs.mkdirSync(TOOLS, { recursive: true });
  return new Promise((resolve, reject) => {
    const child = spawn(command.cmd, command.args, { cwd: HOME, env: { ...process.env, PATH: `${NODE_DIR}${path.delimiter}${process.env.PATH || ''}` }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    let out = '';
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { out += d; });
    const timer = setTimeout(() => child.kill(), 10 * 60 * 1000);
    child.on('error', (err) => { clearTimeout(timer); reject(err); });
    child.on('close', async (code) => {
      clearTimeout(timer);
      const a = await p.account().catch(() => ({}));
      if (a.installed) return resolve();
      const last = out.replace(/\x1b\[[0-9;?]*[A-Za-z]/g, '').split('\n').map((l) => l.trim()).filter(Boolean).slice(-2).join(' / ');
      reject(new Error(`설치하지 못했습니다(종료 코드 ${code}). ${last}`.trim()));
    });
  });
}

async function setKey(p, key) {
  await p.verifyKey(key);
  await keychain.set(p.keyService, key);
}

module.exports = { PROVIDERS, statusOf, setKey, install, keychain, loginInBackground, setPolicy, allowed, CLAUDE_DIR, mcpLinks, codexLinks };
