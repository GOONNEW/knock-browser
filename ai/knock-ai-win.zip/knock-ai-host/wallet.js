// 저장한 카드·계좌(2026-11-06, 피그마 ② 설정 › 기억해 둔 로그인 · 저장한 카드·계좌).
// 사용자가 설정에서 직접 저장한 것만. 번호는 맥 키체인(서비스 "Knock 카드·계좌", 계정 = 저장 번호)·윈도우 DPAPI 파일에만 둔다.
// ~/.knock/wallet.json 에는 이름표·종류·끝 4자리만(목록용). 카드 비밀번호·CVC 는 저장하지 않는다(그때마다 가려진 칸으로 받는다).
// AI 에게는 이름표만 보이고, 번호는 가림표로만 건넨다 — 칸에 넣기 전에는 늘 사용자에게 묻는다(확장 background.js fillSecrets).
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
const { IS_WIN, winSecret } = require('./platform');

const SERVICE = 'Knock 카드·계좌';
// 시험할 때만: 따로 만든 키체인 파일(사용자 키체인을 건드리지 않게)
const KC = process.env.KNOCK_TEST_KEYCHAIN ? [process.env.KNOCK_TEST_KEYCHAIN] : [];
const INDEX = path.join(os.homedir(), '.knock', 'wallet.json');

function readIndex() {
  try { return JSON.parse(fs.readFileSync(INDEX, 'utf8')); } catch { return {}; }
}
function writeIndex(index) {
  fs.mkdirSync(path.dirname(INDEX), { recursive: true });
  fs.writeFileSync(INDEX, JSON.stringify(index, null, 2), { mode: 0o600 });
}

/** { kind: 'card'|'account', label, number } → id */
function save({ kind, label, number }) {
  const num = String(number || '').replace(/[^\d-]/g, '');
  const digits = num.replace(/\D/g, '');
  if (digits.length < 6 || digits.length > 20) throw new Error('번호를 확인해 주세요(숫자 6~20자리).');
  const name = String(label || '').trim().slice(0, 40);
  if (!name) throw new Error('이름표를 적어 주세요(예: 광주은행 카드).');
  const id = crypto.randomBytes(6).toString('hex');
  const b64 = Buffer.from(num, 'utf8').toString('base64');
  if (IS_WIN) winSecret.set(SERVICE, id, b64);
  const r = IS_WIN ? { status: 0 } : spawnSync('security', ['-i'], { input: `add-generic-password -U -s "${SERVICE}" -a "${id}" -w ${b64}${KC.length ? ` "${KC[0]}"` : ''}\n`, encoding: 'utf8' });
  if (r.status !== 0) throw new Error('키체인에 저장하지 못했습니다.');
  const index = readIndex();
  index[id] = { kind: kind === 'account' ? 'account' : 'card', label: name, last4: digits.slice(-4), savedAt: Date.now() };
  writeIndex(index);
  return id;
}

/** 번호(없으면 null) */
function get(id) {
  if (!readIndex()[id]) return null;
  if (IS_WIN) {
    const b64 = winSecret.get(SERVICE, id);
    return b64 ? Buffer.from(b64, 'base64').toString('utf8') : null;
  }
  const r = spawnSync('security', ['find-generic-password', '-s', SERVICE, '-a', id, '-w', ...KC], { encoding: 'utf8', timeout: 10000 });
  if (r.status === 44) return null;
  if (r.status !== 0) {
    const why = /interaction is not allowed|locked/i.test(r.stderr || '') ? '맥 키체인이 잠겨 있음(화면 잠금 중일 수 있음)' : `키체인 오류 ${r.status ?? '시간 초과'}`;
    throw new Error(why);
  }
  return Buffer.from(r.stdout.trim(), 'base64').toString('utf8') || null;
}

function list() {
  return Object.entries(readIndex()).map(([id, v]) => ({ id, ...v }));
}

function remove(id) {
  if (IS_WIN) winSecret.remove(SERVICE, id);
  else spawnSync('security', ['delete-generic-password', '-s', SERVICE, '-a', id, ...KC], { encoding: 'utf8' });
  const index = readIndex();
  delete index[id];
  writeIndex(index);
}

module.exports = { save, get, list, remove };
