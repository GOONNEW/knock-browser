// Knock 원격: 원격에서 받은 마우스·키보드 동작을 이 맥에 일으키는 작은 프로그램(bin/knock-input)을 다룬다.
// 설치판은 묶을 때 미리 만든 것을, 개발판은 없으면 swiftc 로 만들어 쓴다.
// 윈도우는 PowerShell 프로그램(input-win.js 의 글을 임시 폴더에 적어 띄운다) — 따로 허락 없이 바로 된다.
// 시험용: KNOCK_REMOTE_DRY=파일 이면 실제로 움직이지 않고 그 파일에 한 줄씩 적기만 한다.
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { spawn, spawnSync } = require('child_process');

const BIN = path.join(__dirname, 'bin', 'knock-input');
const SRC = path.join(__dirname, 'input', 'knock-input.swift');
const DRY = process.env.KNOCK_REMOTE_DRY;
const IS_WIN = process.platform === 'win32';
const WIN_PS1 = path.join(require('os').tmpdir(), 'knock-input-win.ps1');

let proc = null;
let lastDisplay = null; // 고른 화면(크기·이름) — 조작 프로그램이 다시 켜지면 다시 고른다(2026-11-13)
let deadUntil = 0; // 켜자마자 꺼지면 잠깐 다시 켜지 않는다(마우스 움직일 때마다 PowerShell 을 새로 띄우지 않게)
let waiting = []; // check 답을 기다리는 것들
let onBlocked = null; // 윈도우가 입력을 막았을 때 알림
const setOnBlocked = (f) => { onBlocked = f; };
let onDiag = null; // 브라우저 연동 비밀번호 칸 시험 기록(윈도우)
const setOnDiag = (f) => { onDiag = f; };
// 조작 프로그램이 켜지자마자 꺼짐(보안 프로그램이 막는 등) — 예전엔 아무 기록 없이 입력이 버려졌다(2026-11-13)
let onExit = null;
let onFront = null;
const setOnFront = (f) => { onFront = f; };
let onNote = null; // 원격 조작 확인 기록(마우스가 정말 옮겨졌는지)
const setOnNote = (f) => { onNote = f; };
const setOnExit = (f) => { onExit = f; };

function ensureBin() {
  if (IS_WIN) {
    // UTF-8(BOM) 로 적어야 PowerShell 이 한글 설명을 깨뜨리지 않는다
    fs.writeFileSync(WIN_PS1, `\ufeff${require('./input-win')}`);
    return;
  }
  if (fs.existsSync(BIN)) return;
  if (!fs.existsSync(SRC)) throw new Error('원격 조작 도구가 없습니다.');
  fs.mkdirSync(path.dirname(BIN), { recursive: true });
  const r = spawnSync('swiftc', ['-O', '-o', BIN, SRC], { encoding: 'utf8' });
  if (r.status !== 0) throw new Error(`원격 조작 도구를 만들지 못했습니다: ${(r.stderr || '').trim().split('\n').pop()}`);
  // Knock 이 띄운 프로그램이 만든 파일에는 맥이 '받은 파일' 표시를 붙여 열기를 막는다 — 직접 만든 것이니 뗀다
  spawnSync('xattr', ['-d', 'com.apple.quarantine', BIN]);
}

function start() {
  if (proc) return proc;
  ensureBin();
  const p = (proc = IS_WIN
    ? spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', WIN_PS1], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
    : spawn(BIN, [], { stdio: ['pipe', 'pipe', 'pipe'] }));
  proc.trusted = false;
  p.startedAt = Date.now();
  p.errText = '';
  p.stderr.on('data', (d) => { p.errText = (p.errText + d).slice(-600); });
  p.stdin.on('error', () => {}); // 꺼진 프로그램에 쓰면 나는 오류로 도우미가 죽지 않게
  p.on('error', (err) => { p.errText += ` ${err.message}`; });
  // 다시 켜진 것이면 전에 고른 화면을 다시 고른다(안 그러면 모니터가 여럿일 때 좌표가 어긋난다)
  if (lastDisplay && IS_WIN) {
    waiting.push(() => {});
    p.stdin.write(displayLine(lastDisplay));
  }
  readline.createInterface({ input: proc.stdout }).on('line', (line) => {
    try {
      const r = JSON.parse(line);
      if (r.blocked) return onBlocked?.(r.blocked, r.fg || ''); // 윈도우가 입력을 막음(fg: 그때 맨 앞 창 제목)
      if (r.front) return onFront?.(r.front); // [앞 창 내리기] 결과
      if (r.diag) return onDiag?.(r.diag);
      if (r.note) return onNote?.(r.note);
      if (r.fatal) { p.errText = `${p.errText} ${r.fatal}`; return; } // 꺼질 때(onExit) 까닭과 함께 남는다
      waiting.shift()?.(r);
    } catch {}
  });
  p.on('exit', (code) => {
    const mine = proc === p; // stop() 으로 끈 것이 아니다
    if (mine) proc = null;
    for (const w of waiting.splice(0)) w({ ok: false });
    if (mine && Date.now() - p.startedAt < 15000) deadUntil = Date.now() + 30000;
    if (mine) onExit?.(code, String(p.errText || '').replace(/\s+/g, ' ').trim().slice(-300), Date.now() - p.startedAt);
  });
  return p;
}

// 원격 동작 하나 보내기(답을 기다리지 않는다)
function send(ev) {
  if (!ev || typeof ev.t !== 'string' || ev.t === 'check' || ev.t === 'display') return;
  if (ev.t === 'lowerFront' && !IS_WIN) return onFront?.({ before: '', after: '', lowered: false, unsupported: true });
  if (DRY) return fs.appendFileSync(DRY, `${JSON.stringify(ev)}\n`);
  if (!proc && Date.now() < deadUntil) return;
  // 한글 등은 \uXXXX 로 — 윈도우 도우미(PowerShell)는 받은 글을 옛 한글 코드로 읽어 탭 제목·한글 입력이 깨졌다(2026-11-08)
  start().stdin.write(`${JSON.stringify(ev).replace(/[\u007f-\uffff]/g, (c) => `\\u${c.charCodeAt(0).toString(16).padStart(4, '0')}`)}\n`);
}

// 손쉬운 사용 권한이 있는지(prompt 면 맥 설정 창을 띄운다).
// 맥은 이 권한을 프로그램이 켜질 때 정해 두므로, 확인은 매번 새로 띄운 프로그램으로 한다.
// 권한이 새로 켜졌으면 이미 떠 있던 조작 프로그램은 닫는다(다음 조작 때 새로 켜져 권한을 받는다).
function check(prompt = false) {
  if (DRY || IS_WIN) return Promise.resolve(true);
  ensureBin();
  const r = spawnSync(BIN, [], { input: `${JSON.stringify({ t: 'check', prompt })}\n`, encoding: 'utf8', timeout: 5000 });
  let ok = false;
  try { ok = !!JSON.parse(r.stdout.trim().split('\n')[0]).ok; } catch {}
  if (ok && proc && !proc.trusted) stop();
  if (ok && proc) proc.trusted = true;
  return Promise.resolve(ok);
}

// 보내는 화면 고르기(화면 크기로 맞춘다)
// label: 보내는 화면 이름(크롬이 붙인 "Screen 2"·"화면 2" 등) — 크기가 같은 모니터가 여럿일 때 번호로 고른다
function displayLine(d) {
  const n = Number(String(d.label || '').match(/(\d+)\s*$/)?.[1]) || 0;
  return `${JSON.stringify({ t: 'display', w: Number(d.w) || 0, h: Number(d.h) || 0, n })}\n`;
}
function display(w, h, label = '') {
  if (DRY) return Promise.resolve(0);
  return new Promise((resolve) => {
    const p = start();
    lastDisplay = { w, h, label }; // 켠 다음에 적어야 이번에 두 번 고르지 않는다
    waiting.push((r) => resolve(r.id || 0));
    p.stdin.write(displayLine(lastDisplay));
  });
}

function stop() {
  // 끄기 전에 눌린 채 남은 키를 뗀다(입력을 닫으면 프로그램이 다 떼고 끝난다 — 바로 죽이면 Shift 등이 눌린 채 남는다)
  const p = proc;
  proc = null;
  deadUntil = 0;
  lastDisplay = null;
  if (!p) return;
  try { p.stdin.write(`${JSON.stringify({ t: 'release' })}\n`); p.stdin.end(); } catch {}
  setTimeout(() => p.kill(), 1500);
}

module.exports = { send, check, display, stop, setOnBlocked, setOnDiag, setOnExit, setOnNote, setOnFront };
